from appium.webdriver.common.mobileby import MobileBy

from apps.hbontv.pages.base.page import Page


class SubscribeGreeter(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)

        self.sign_in_button = dict(
            locator="SIGN IN",
            type=MobileBy.NAME)

    def is_sign_in_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.sign_in_button, timeout)

    def click_on_sign_in_button(self, timeout=5):
        self.helper.click(self.sign_in_button, timeout)
