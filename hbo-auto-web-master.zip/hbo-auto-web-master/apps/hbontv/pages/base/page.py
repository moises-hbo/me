from helpers.pagehelper import PageHelper


class Page(object):
    def __init__(self, driver):
        self.driver = driver
        self.helper = PageHelper(driver)
