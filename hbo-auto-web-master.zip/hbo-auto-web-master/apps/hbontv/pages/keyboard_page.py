from appium.webdriver.common.mobileby import MobileBy

from apps.hbontv.pages.base.page import Page


class Keyboard(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)

        self.next_button = dict(locator="next", type=MobileBy.NAME)
        self.delete_button = dict(
            locator="delete", type=MobileBy.ACCESSIBILITY_ID)
        self.keys_list = dict(
            locator="//XCUIElementTypeKeyboard[@name='Keyboard']"
            "//XCUIElementTypeKey", type=MobileBy.XPATH)

    def click_on_next_button(self, timeout=5):
        self.helper.click(self.next_button, timeout)

    def get_keyboard_representation(self):
        keys = self.get_list_of_keys()
        kboard_repr = dict()
        rows = list(set([k.location["y"] for k in keys]))

        for row in rows:
            columns = [c.text for c in keys if c.location["y"] == row]
            kboard_repr[row] = columns

        # move focused to correct row
        # location of "y" is off by 8
        for key in kboard_repr:
            if kboard_repr.get(key + 8) is not None:
                kboard_repr[key + 8].append(kboard_repr[key][0])
                kboard_repr[key + 8].sort()
                del kboard_repr[key]
                break

        return kboard_repr

    def get_list_of_keys(self, timeout=5):
        return self.helper.get_list(self.keys_list, timeout)

    def get_locations_of_keys(self, timeout=5):
        keys = self.get_list_of_keys(timeout)
        return [self.helper.get_location(x) for x in keys]

    def get_active_key(self):
        # 'y' location of focused element will be slightly different
        # so we use that to retrieve correct one
        keys = self.get_list_of_keys()
        y_locs = [self.helper.get_location(key)["y"] for key in keys]
        distinct_y_locs = list(set(y_locs))
        unique_y_loc = [
            y_loc for y_loc in distinct_y_locs if y_locs.count(y_loc) == 1][0]
        active_key_element = [
            key for key in keys
            if self.helper.get_location(key)["y"] == unique_y_loc][0]

        return active_key_element
