from helpers.sleeper import Sleeper as sleep

from appium.webdriver.common.mobileby import MobileBy

from apps.hbontv.pages.base.page import Page


class Login(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)

        self.sign_in_button = dict(
            locator="SIGN IN WITH EMAIL",
            type=MobileBy.NAME)
        self.sign_in_activation_code = dict(
            locator="SIGN IN WITH ACTIVATION CODE",
            type=MobileBy.NAME)
        # XPATH could be better
        self.sign_in_field = dict(
            locator="//XCUIElementTypeOther[1]/XCUIElementTypeOther"
            "/XCUIElementTypeTextField", type=MobileBy.XPATH)
        self.password_field = dict(
            locator="//XCUIElementTypeOther[2]/XCUIElementTypeOther"
            "/XCUIElementTypeSecureTextField", type=MobileBy.XPATH)

    def is_sign_in_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.sign_in_button, timeout)

    def is_sign_in_with_activation_code_displayed(self, timeout=10):
        return self.helper.is_visible(self.sign_in_activation_code, timeout)

    def is_sign_in_field_displayed(self, timeout=5):
        return self.helper.is_visible(self.sign_in_field, timeout)

    def is_password_field_displayed(self, timeout=5):
        return self.helper.is_visible(self.password_field, timeout)

    def click_on_sign_in_button(self, timeout=3):
        self.helper.click(self.sign_in_button, timeout)
        sleep(1)

    def click_on_sign_in_field(self, timeout=3):
        self.helper.click(self.sign_in_field, timeout)
        sleep(1)


class EmailChooser(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)

        self.enter_new_button = dict(
            locator="Enter New…", type=MobileBy.ACCESSIBILITY_ID)

    def click_on_enter_new_button(self, timeout=5):
        self.helper.click(self.enter_new_button, timeout)
