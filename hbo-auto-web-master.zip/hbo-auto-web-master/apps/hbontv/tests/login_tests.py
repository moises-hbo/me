import pytest

from apps.hbontv.pages.subscribe_page import SubscribeGreeter
from apps.hbontv.pages.login_page import Login
from apps.hbontv.pages.keyboard_page import Keyboard


@pytest.mark.env("preprod")
@pytest.mark.category("sanity")
@pytest.mark.id()
def test_login_success(driver, user):
    # TODO: Finish test case

    page = SubscribeGreeter(driver)
    assert page.is_sign_in_button_displayed(timeout=20)

    driver.helper.go_down()
    driver.helper.click()

    page = Login(driver)
    assert page.is_sign_in_button_displayed()
    assert page.is_sign_in_with_activation_code_displayed()

    page.click_on_sign_in_button()

    assert page.is_sign_in_field_displayed()
    assert page.is_password_field_displayed()
    assert not page.is_sign_in_button_displayed(0)
    assert not page.is_sign_in_with_activation_code_displayed(0)

    page.click_on_sign_in_field()

    driver.helper.go_down(5)
    driver.helper.click()

    page = Keyboard(driver)

    assert False
