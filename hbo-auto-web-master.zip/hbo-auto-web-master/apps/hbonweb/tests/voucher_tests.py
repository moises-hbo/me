import pytest

from apps.hbonweb.pages.home_page import WhyHBO
from apps.hbonweb.pages.signup_page import SignUp, Voucher, VoucherFailed
from apps.hbonweb.pages.myaccount_page import MyAccount

from apps.hbonweb.flows.signup_flow import enter_signup_info_and_continue


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("signup", "voucher")
@pytest.mark.id("C2861922")
def test_used_voucher_new_acc(driver, user_tmp, used_voucher):
    """ Invalid voucher (IBM check ) - Un-Auth via start Free Trial
    Checks:
    #1: Signing up with used voucher lands you at VoucherFailed page
    #2: Clicking on my account button takes to you to
        MyAccount-Subscription page
    """
    WhyHBO(driver).click_on_free_trial_button()

    page = SignUp(driver)
    page.click_on_add_voucher_button()

    # 1
    page = Voucher(driver)
    page.input_text_on_voucher_field(used_voucher)
    page.click_on_add_voucher_button()

    enter_signup_info_and_continue(driver, user_tmp.email, user_tmp.password)

    page = VoucherFailed(driver)
    assert page.is_voucher_failed_page()

    # 2
    page.click_on_myaccount_button()

    page = MyAccount(driver)
    assert page.is_sub_buy_button_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("signup", "voucher")
@pytest.mark.id("C2861922")
def test_used_voucher_new_acc_refresh(driver, user_tmp, used_voucher):
    """ Invalid voucher (IBM check ) - Un-Auth via start Free Trial
    Checks:
    #1: Signing up with used voucher lands you at VoucherFailed page
    #2: Refreshing page takes to you to MyAccount-Subscription page
    """
    WhyHBO(driver).click_on_free_trial_button()

    page = SignUp(driver)
    page.click_on_add_voucher_button()

    # 1
    page = Voucher(driver)
    page.input_text_on_voucher_field(used_voucher)
    page.click_on_add_voucher_button()

    enter_signup_info_and_continue(driver, user_tmp.email, user_tmp.password)

    page = VoucherFailed(driver)
    assert page.is_voucher_failed_page()

    # 2
    driver.helper.refresh_page()

    page = MyAccount(driver)
    assert page.is_sub_buy_button_displayed()
