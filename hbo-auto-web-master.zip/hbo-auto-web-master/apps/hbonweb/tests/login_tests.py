import datetime
import pytest
from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.loginform_page import LoginForm, AdultKidsSelection
from apps.hbonweb.pages.home_page import WhyHBO
from apps.hbonweb.pages.loginform_page import ForgotPassword
from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter, \
    MoreInfoFooter
from apps.hbonweb.pages.signup_page import SignUp
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner

from apps.hbonweb.flows.login_flow import login, login_without_section

from apps.hbonshared.resourcesmanager import ResourcesManager

from helpers.configmanager import ConfigManager
from helpers.enums import Country

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("smoke", "deploy")
@pytest.mark.id("C419")
def test_login_success(driver, user):
    """C419: Be able to login with valid credentials

    https://hbo.testrail.com/index.php?/cases/view/419
    """
    # to force non-cached version // deploy
    dt = str(datetime.datetime.now()).replace(" ", "_")
    driver.helper.go_to_url(f"{cm.url}/{dt}")
    sleep(5)

    page = login(driver, user.email, user.password)

    page.click_on_hbo_logo_img()

    assert page.is_my_account_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("smoke")
@pytest.mark.id("C422")
def test_login_with_invalid_fields(driver):
    """ Sign In errors
    Checks:
    #1: Submitting empty email/pw gives errors on both
    """
    login_without_section(driver, "", "")

    # 1
    page = LoginForm(driver)
    assert page.is_email_warning_displayed(2)
    assert page.is_password_warning_displayed(2)

    # 2
    page.input_text_on_email("$$$")
    page.click_on_password_input()

    assert page.is_email_warning_displayed(2)

    # 3
    page.input_text_on_password("@@@$$$@@@@")
    page.click_on_submit_button()

    assert page.is_email_warning_displayed(2)

    # 4
    page.clear_text_on_email()
    page.clear_text_on_password()

    page.input_text_on_email("valid.looking@email.com")
    page.input_text_on_password("N0t£nt1r£ly")
    page.click_on_submit_button()

    assert page.is_wrong_credentials_alert_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C423")
def test_login_with_invalid_email(driver):
    """C243: Receive an error when trying to login with an
    invalid (wrongly formatted) email

    https://hbo.testrail.com/index.php?/cases/view/243
    """
    login_without_section(driver, "IncorrectFormat$dude.ettes", "asdfasdf")
    page = LoginForm(driver)

    # TODO: Firefox fails (because no error is seen during auto)
    assert page.is_email_warning_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C424")
def test_login_with_wrong_credentials(driver, user):
    """C424: Receive an error alert when providing wrong credentials

    https://hbo.testrail.com/index.php?/cases/view/424
    """
    login_without_section(driver, user.email, "wrongPa$$")

    page = LoginForm(driver)
    assert page.is_wrong_credentials_alert_displayed()
    sleep(1)

    page.click_on_hbo_logo_img()
    login_without_section(driver, "invalid@houpna.uk", "asdfasdf")

    assert page.is_wrong_credentials_alert_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("smoke")
@pytest.mark.id("C4515")
def test_login_in_other_country(driver):
    """C4515 Sign In with account from another country

    https://hbo.testrail.com/index.php?/cases/view/4515
    """
    country = ResourcesManager.get_country()
    other_user = None

    if country == Country.ES:
        other_user = ResourcesManager.get_user(country=Country.SE)
    else:
        other_user = ResourcesManager.get_user(country=Country.ES)

    login_without_section(driver, other_user.email, other_user.password)

    page = LoginForm(driver)
    assert page.is_wrong_credentials_alert_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id()
# TODO: Replace with C418
def test_do_not_login_when_show_password(driver, user):
    """BUG: https://jira.hbo.com/browse/MAIN-1986
    Affects firefox & ie"""
    WhyHBO(driver).click_on_sign_in_link()
    page = LoginForm(driver)
    page.input_text_on_email(user.email)
    page.input_text_on_password(user.password)
    page.click_on_password_show_toggle()

    page = AdultKidsSelection(driver)
    assert not page.is_series_movies_button_displayed(timeout=5)


@pytest.mark.env("preprod")
@pytest.mark.category()
@pytest.mark.id("C412")
def test_sign_in_view(driver):
    """ Sign In view
    Checks:
    #1: Product box image, free trial button, desc, USPs are visible in
        sign in view
    #2: In mobile view, product box is collapsed and can be opened
    #3: Top menu only contains HBO Logo
    #4: Footer only contains the Copyright/Language part
    #5: Clicking 'back' or on HBO logo takes you back to WhyHBO
    #6: Clicking on Free Trial button takes you to SignUp
    #7: Clicking on Forgot password link takes you to Forgot password overlay
        page
    #8: Remember me checkbox is checked by default, and can be unchecked
    """
    CookieBanner(driver).click_on_accept_button()
    WhyHBO(driver).click_on_sign_in_link()
    page = LoginForm(driver)

    # 1
    assert page.is_product_box_displayed()
    assert page.is_pb_image_displayed()
    assert page.is_pb_description_displayed()
    assert page.are_pb_usps_items_displayed()
    assert page.is_pb_free_trial_button_displayed()

    # 2
    ori_win_size = driver.helper.get_window_size()
    driver.helper.resize_window(400, 800)
    assert page.is_pb_description_displayed()
    assert not page.are_pb_usps_items_displayed()

    page.click_on_pb_mobile_show_more_less_button()
    assert page.are_pb_usps_items_displayed()

    driver.helper.resize_window(ori_win_size["width"], ori_win_size["height"])

    # 3
    nav = Navigation(driver)
    assert nav.is_hbo_logo_img_displayed()
    assert not nav.is_home_logged_in_link_displayed(0)
    assert not nav.is_kids_link_displayed(0)
    assert not nav.is_watchlist_link_displayed(0)
    assert not nav.is_sign_in_link_displayed(0)
    assert not nav.is_search_button_displayed(0)
    assert not nav.is_free_trial_button_displayed(0)

    # 4
    footer = CopyrightLanguageFooter(driver)
    assert footer.is_copyright_text_displayed(0)
    assert footer.is_language_button_displayed(0)
    footer2 = MoreInfoFooter(driver)
    assert not footer2.is_how_to_watch_link_displayed(0)
    assert not footer2.is_about_link_displayed(0)
    assert not footer2.is_faq_link_displayed(0)
    assert not footer2.is_contact_link_displayed(0)
    assert not footer2.is_press_link_displayed(0)
    assert not footer2.is_terms_and_conditions_link_displayed(0)
    assert not footer2.is_data_policy_link_displayed(0)
    assert not footer2.is_footer_start_free_trial_button_displayed(0)

    # 5
    page.click_on_hbo_logo_img()
    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()

    page.click_on_sign_in_link()
    driver.helper.go_back()
    assert page.is_why_hbo_active_link_displayed()

    # 6
    page.click_on_sign_in_link()
    page = LoginForm(driver)
    page.click_on_signin_free_trial_link()

    page = SignUp(driver)
    assert page.is_signup_page()

    driver.helper.go_back()
    page = LoginForm(driver)

    # 7
    page.click_on_forgot_password_link()

    page = ForgotPassword(driver)
    assert page.is_forgot_password_page()

    page.click_on_sign_in_link()

    # 8
    page = LoginForm(driver)
    assert page.is_remember_me_checked()
    page.click_on_remember_me_checkbox()
    assert not page.is_remember_me_checked()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C428")
def test_forgot_password_view(driver):
    """ Forgot password view
    Checks:
    #1: Instructions, email input, send button all seen.
        instructions at top, then input, then button
    #2: Only log and sign in at top nav & lang picker and copyright at footer
    #3: Going back exits forgot password view
    #4: From forgot password view, clicking sign in redirects to LoginForm
    """
    WhyHBO(driver).click_on_sign_in_link()

    page = LoginForm(driver)
    page.click_on_forgot_password_link()

    # 1
    page = ForgotPassword(driver)
    assert page.is_fp_instructions_displayed()
    assert page.is_email_input_displayed()
    assert page.is_send_email_button_displayed()

    assert page.get_location_of_fp_instructions()["y"] < \
        page.get_location_of_email_input()["y"]
    assert page.get_location_of_email_input()["y"] < \
        page.get_location_of_send_email_button()["y"]

    # 2
    nav = Navigation(driver)
    assert nav.is_hbo_logo_img_displayed()
    assert nav.is_sign_in_link_displayed(0)
    assert not nav.is_home_logged_in_link_displayed(0)
    assert not nav.is_kids_link_displayed(0)
    assert not nav.is_watchlist_link_displayed(0)
    assert not nav.is_search_button_displayed(0)
    assert not nav.is_free_trial_button_displayed(0)

    footer = CopyrightLanguageFooter(driver)
    assert footer.is_copyright_text_displayed(0)
    assert footer.is_language_button_displayed(0)
    footer2 = MoreInfoFooter(driver)
    assert not footer2.is_how_to_watch_link_displayed(0)
    assert not footer2.is_about_link_displayed(0)
    assert not footer2.is_faq_link_displayed(0)
    assert not footer2.is_contact_link_displayed(0)
    assert not footer2.is_press_link_displayed(0)
    assert not footer2.is_terms_and_conditions_link_displayed(0)
    assert not footer2.is_data_policy_link_displayed(0)
    assert not footer2.is_footer_start_free_trial_button_displayed(0)

    # 3
    driver.helper.go_back()

    page = LoginForm(driver)
    assert page.is_loginform_page()

    # 4
    page.click_on_forgot_password_link()

    page = ForgotPassword(driver)
    assert page.is_forgot_password_page()

    page.click_on_sign_in_link()

    page = LoginForm(driver)
    assert page.is_loginform_page()
