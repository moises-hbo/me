from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonweb.pages.home_page import Home, WhyHBO
from apps.hbonweb.pages.myaccount_page import \
    MyAccount, UpdatePersonalInformation, AuthForgotPassword
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner
from apps.hbonweb.pages.contact_page import Contact

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.navigation_flow import go_to_myaccount
from apps.hbonweb.flows.personalinformation_flow import \
    change_user_info, change_password

from apps.hbonshared.resourcesmanager import ResourcesManager as RM


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C359")
def test_name_change_in_my_account(driver, user_change_info):
    """C359: Change first name through My Account.
    Log in and go to My Account,
    Change first name and save changes,
    Verify your name has changed in your
    Logout and verify your name is no longer shown on My Account
    - rather it shouldn't exist anymore (replaced with Sign In)
    https://hbo.testrail.com/index.php?/cases/view/359
    """
    # It's in the way later
    CookieBanner(driver).click_on_accept_button()

    login(driver, user_change_info.email, user_change_info.password)

    page = Home(driver)

    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.input_text_on_first_name(user_change_info.tmp_firstname)
    page.click_on_save_changes_button()

    assert page.is_updated_changes_success_alert_displayed()
    assert page.is_my_account_link_displayed()

    page.click_on_sign_out_link()
    page = WhyHBO(driver)

    assert page.is_sign_in_link_displayed(20)
    assert page.is_free_trial_button_displayed()
    assert not page.is_my_account_link_displayed(0)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C510")
def test_myaccount_nav(driver, user):
    """C510: Verify the myaccount navigation.
    Check that we can correctly see each view.

    https://hbo.testrail.com/index.php?/cases/view/510
    """
    # Arrange
    page = WhyHBO(driver)

    page = login(driver, user.email, user.password)
    go_to_myaccount(driver)
    page = MyAccount(driver)

    assert page.is_personal_information_link_selected_displayed()
    assert page.is_save_changes_button_displayed()

    page.click_on_change_password_link()

    assert not page.is_personal_information_link_selected_displayed(timeout=1)
    assert page.is_change_password_link_selected_displayed()
    assert page.is_change_password_button_displayed()

    page.click_on_subscription_link()

    assert not page.is_change_password_link_selected_displayed(timeout=1)
    assert page.is_subscription_link_selected_displayed()

    page.click_on_payment_history_link()

    assert not page.is_subscription_link_selected_displayed()
    assert page.is_payment_history_link_selected_displayed()

    page.click_on_manage_devices_link()

    assert not page.is_payment_history_link_selected_displayed(timeout=1)
    assert page.is_manage_devices_link_selected_displayed()
    assert page.is_add_device_button_displayed()

    page.click_on_parental_controls_link()

    assert not page.is_manage_devices_link_selected_displayed(timeout=1)
    assert page.is_parental_controls_link_selected_displayed()
    if page.is_reset_pin_button_displayed(timeout=1):
        assert page.is_turn_off_pin_displayed()
    else:
        assert page.is_set_pin_button_displayed()

    page.click_on_personal_info_link()

    assert not page.is_parental_controls_link_selected_displayed(timeout=1)
    assert page.is_personal_information_link_selected_displayed()
    assert page.is_save_changes_button_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C515")
def test_pi_view_and_newsletter(driver, user):
    """C515: Check personal information fields and newsletter.

    https://hbo.testrail.com/index.php?/cases/view/515
    """
    login(driver, user.email, user.password)
    page = go_to_myaccount(driver)

    assert page.get_text_of_first_name()
    assert page.get_text_of_last_name()
    assert page.get_text_of_email()

    change_user_info(driver, firstname="Temp", lastname="Hemp",
                     email="an@ema.il", newsletter=True)
    assert page.is_newsletter_checkbox_active()
    sleep(5)
    assert user.api.get_settings().get("newsletter") == "false"

    change_user_info(driver, firstname=user.firstname,
                     lastname=user.lastname, email=user.email,
                     newsletter=False)
    assert not page.is_newsletter_checkbox_active()
    sleep(5)
    assert user.api.get_settings().get("newsletter") == "true"


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C516")
def test_personal_information_change_error(driver, user_change_info):
    """ Personal Information Errors
    Checks:
    #1: Deleting First & Last name and submitting updates info
    #2: Submitting empty email gives error message on email
    #3: Entering invalid email and submitting gives error message on email
    #4: Entering invalid email and unfocus'ing email field gives error message
        on email
    """
    user = user_change_info
    login(driver, user.email, user.password)
    page = go_to_myaccount(driver)

    # 1
    page.clear_text_on_first_name()
    page.clear_text_on_last_name()
    page.click_on_save_changes_button()
    assert page.is_ok_toast_displayed()

    # 2
    page.clear_text_of_email()
    page.click_on_save_changes_button()
    assert page.is_email_error_displayed()

    # 3
    page.input_text_on_email("$$$")
    page.click_on_save_changes_button()
    assert page.is_email_error_displayed()

    # Just verifying error goes away in-between
    page.clear_text_of_email()
    page.input_text_on_email(user.email)
    assert not page.is_email_error_displayed(0)

    # 4
    page.clear_text_of_email()
    page.input_text_on_email("$$$")
    page.click_on_first_name_input()
    assert page.is_email_error_displayed()

    # Change back
    page.input_text_on_first_name(user.firstname)
    page.input_text_on_last_name(user.lastname)
    page.input_text_on_email(user.email)
    page.click_on_save_changes_button()
    assert page.is_ok_toast_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C517")
def test_update_personal_info(driver, user_change_info):
    """C517: Update personal information from My Account.
    Change first & last name
    While in password view, verify elements

    https://hbo.testrail.com/index.php?/cases/view/517
    """
    login(driver, user_change_info.email, user_change_info.password)
    page = go_to_myaccount(driver)

    change_user_info(
        driver, firstname=user_change_info.tmp_firstname,
        lastname=user_change_info.tmp_lastname,
        save_changes=True)

    assert page.is_updated_changes_success_alert_displayed()
    assert page.get_text_of_first_name() == user_change_info.tmp_firstname
    assert page.get_text_of_last_name() == user_change_info.tmp_lastname


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C517")
def test_update_email(driver, user_change_email):
    """C517: Update personal information from My Account.
    Change email, and verify with password
    While in password view, verify elements

    https://hbo.testrail.com/index.php?/cases/view/517
    """
    login(driver, user_change_email.email, user_change_email.password)
    page = go_to_myaccount(driver)

    change_user_info(
        driver, email=user_change_email.tmp_email, save_changes=True)

    page = UpdatePersonalInformation(driver)
    sleep(1)
    # TODO: Do add more elements to verify against
    assert page.is_close_view_button_displayed()

    page.input_text_on_password(user_change_email.password)
    page.click_on_submit_button()

    page = MyAccount(driver)
    assert page.is_updated_changes_success_alert_displayed()
    assert page.get_text_of_email() == user_change_email.tmp_email


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C518")
def test_change_email_external_links(driver, user_change_email):
    """ Update Personal Information view
    Checks:
    #1: Entering a different email and submitting opens
        the Update Personal Information page
    #2: Clicking on forgot password page will direct to auth'ed
        ForgotPassword page
    #3: Clicking on contact customer support directs you to contact page
    """
    user = user_change_email
    login(driver, user.email, user.password)
    page = go_to_myaccount(driver)

    # 1
    page.input_text_on_email("forgot@password.link")
    sleep(1)
    page.click_on_save_changes_button()

    page = UpdatePersonalInformation(driver)
    assert page.is_update_personal_information_page()

    # 2
    page.click_on_forgotten_password_link()

    page = AuthForgotPassword(driver)
    assert page.is_auth_forgot_password_page()

    assert page.get_email_to_send_reset_text() == user.email
    assert page.is_send_reset_password_button_displayed()
    assert driver.helper.get_url().endswith("/forgot-password")

    driver.helper.go_back()

    page = MyAccount(driver)
    page.input_text_on_email("customer@service.link")
    sleep(1)
    page.click_on_save_changes_button()

    page = UpdatePersonalInformation(driver)

    # 3
    page.click_on_contact_customer_service_link()

    page = Contact(driver)
    assert page.is_contact_header_displayed()
    assert driver.helper.get_url().endswith("/contact")


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C518")
def test_submit_new_mail(driver, user_change_email):
    """ Update Personal Information view
    Checks:
    #1: Submitting correct password when changing mail directs us
        back to my account personal information page
    """
    user = user_change_email
    login(driver, user.email, user.password)
    page = go_to_myaccount(driver)

    # 1
    page = change_user_info(
        driver, email=user.tmp_email, password=user.password,
        save_changes=True)
    assert page.is_ok_toast_displayed()
    assert page.is_personal_information_link_selected_displayed()

    # Change back
    page = change_user_info(
        driver, email=user.email, password=user.password,
        save_changes=True)
    assert page.is_ok_toast_displayed()
    assert page.is_personal_information_link_selected_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C519")
def test_change_email_with_invalid_password(driver, user_change_email):
    """ Update Information Errors
    Checks:
    #1: Password input displays an error when trying to submit it empty
    #2: Submitting wrong password gives an error alert
    """
    user = user_change_email
    login(driver, user.email, user.password)
    page = go_to_myaccount(driver)

    page.input_text_on_email(user.tmp_email)
    page.click_on_save_changes_button()

    # 1
    page = UpdatePersonalInformation(driver)
    page.click_on_submit_button()
    assert page.is_password_error_displayed()

    # 2
    page.input_text_on_password("¡@£$€¥{[]\\±´}][{¥}]")
    page.click_on_submit_button()
    assert page.is_error_alert_displayed()
    assert page.get_text_of_error_alert() == \
        RM.get_lang_text("myaccount_invalid_password")


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C519")
def test_change_email_to_already_existing(driver, user_change_email,
                                          user_change_info):
    """ Update Information Errors
    Checks:
    #1: Get error alert when trying to change to an already existing email
    """
    user = user_change_email
    login(driver, user.email, user.password)
    page = go_to_myaccount(driver)

    page.input_text_on_email(user_change_info.email)
    page.click_on_save_changes_button()

    # 1
    page = UpdatePersonalInformation(driver)
    page.input_text_on_password(user.password)
    page.click_on_submit_button()

    assert page.is_error_alert_displayed()
    assert page.get_text_of_error_alert() == \
        RM.get_lang_text("myaccount_update_email_exists")


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C520")
def test_change_password(driver, user_change_password):
    """C520: Change password to valid new one"""
    # It's in the way later
    CookieBanner(driver).click_on_accept_button()

    login(driver, user_change_password.email, user_change_password.password)

    page = go_to_myaccount(driver)
    page.click_on_change_password_link()
    change_password(
        driver, user_change_password.password,
        user_change_password.tmp_password, save_changes=True)

    assert page.is_updated_changes_success_alert_displayed()

    page.click_on_current_password_input()
    assert page.is_current_password_toggle_displayed()
    page.click_on_new_password_input()
    assert page.is_new_password_toggle_displayed()
    page.click_on_confirm_password_input()
    assert page.is_confirm_password_toggle_displayed()

    page.click_on_sign_out_link()
    login(
        driver, user_change_password.email, user_change_password.tmp_password)

    assert page.is_my_account_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C521")
def test_invalid_password(driver, user_change_password):
    """ Update Information Errors
    Checks:
    #1: Get error on current password when attempting to submit
        new with current being empty
    #2: Get error on confirm when new and confirm passwords don't match
    #3: Get error alert when trying to submit with current password being wrong
    """
    user = user_change_password
    login(driver, user.email, user.password)
    page: MyAccount = go_to_myaccount(driver)

    page.click_on_change_password_link()

    # 1
    page.input_text_on_new_password(user.tmp_password)
    page.input_text_on_confirm_password(user.tmp_password)
    page.click_on_change_password_button()

    assert page.is_current_password_error_displayed()
    assert not page.is_new_password_error_displayed(0)
    assert not page.is_confirm_password_error_displayed(0)

    # 2
    page.input_text_on_current_password(user.tmp_password)
    page.input_text_on_confirm_password(user.tmp_password + "$$$")
    page.click_on_change_password_button()

    assert page.is_confirm_password_error_displayed()

    # 3
    page.input_text_on_confirm_password(user.tmp_password)
    page.click_on_change_password_button()

    assert page.is_error_alert_displayed()
    assert page.get_text_of_error_alert() == \
        RM.get_lang_text("myaccount_invalid_password")
