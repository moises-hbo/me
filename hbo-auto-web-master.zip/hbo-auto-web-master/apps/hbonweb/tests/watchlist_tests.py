from random import randrange
from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.watchlist_flow import is_kids_asset_in_watchlist, \
    is_watchlist_full, add_asset_to_watchlist, \
    is_watchlist_recently_added_sorted, is_watchlist_a_z_sorted, \
    is_watchlist_release_date_sorted
from apps.hbonweb.flows.search_flow import search_item, \
    open_first_search_result, open_recent_search_result
from apps.hbonweb.flows.kids_flow import go_to_kids_locked, \
    go_out_from_kids_locked
from apps.hbonshared.api_flow import add_to_watchlist

from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.watchlist_page import Watchlist
from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.series_page import Series
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("sanity")
@pytest.mark.id()
def test_watchlist_exists_after_unauthed_nav(driver, user_full_watchlist):
    """ A bug-fix verification test to check that Watchlist exists
        after first navigating un-authed
    """
    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()
    assert not page.is_watchlist_link_displayed(1)
    page.click_on_home_logged_out_link()

    page = Home(driver)
    assert page.is_home_logged_out_active_link_displayed()
    assert not page.is_watchlist_link_displayed(1)
    page.click_on_kids_link()

    page = Kids(driver)
    assert page.is_kids_active_link_displayed()
    assert not page.is_watchlist_link_displayed(1)
    page.click_on_why_hbo_link()

    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()
    assert not page.is_watchlist_link_displayed(1)

    ufw = user_full_watchlist
    page = login(driver, ufw.email, ufw.password)
    assert page.is_watchlist_link_displayed()
    page.click_on_watchlist_link()

    page = Watchlist(driver)
    assert page.is_watchlist_active_link_displayed()

    assert page.is_watchlist_results_displayed()
    assert not page.is_explore_shows_button_displayed(1)
    assert not page.is_no_content_message_displayed(1)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C571")
def test_watchlist_general_requirements(driver, user, movie):
    """C571 - General Requirements
    |1.|Open hbo app and check the main page |
    |2.|Log in with a test user|
    |3.|Add an item |
    |4.|Remove an item |
    """
    # Arrange
    # 1 Open page
    user.api.clear_watchlist()

    page = Watchlist(driver)
    assert not page.is_watchlist_link_displayed(timeout=3)

    # 2 Login
    login(driver, user.email, user.password)
    watchlist = user.api.get_watchlist()

    assert page.is_watchlist_link_displayed()

    # 3 Add an item
    search_item(driver, movie.title)
    open_first_search_result(driver)
    Movie(driver).click_on_add_to_watchlist_button()
    assert page.is_feedback_toast_displayed()

    page.click_on_watchlist_link()
    watchlist = user.api.get_watchlist()
    assert page.is_watchlist_active_link_displayed()
    assert page.is_watchlist_results_displayed()
    assert page.is_sort_dropdown_button_displayed()
    if is_kids_asset_in_watchlist(watchlist):
        assert page.is_hide_toonix_content_button_displayed()

    # 4 Remove an item
    page.remove_asset()
    watchlist = user.api.get_watchlist()
    assert not page.is_watchlist_results_displayed(timeout=3)
    assert not page.is_sort_dropdown_button_displayed(timeout=3)
    assert not page.is_hide_toonix_content_button_displayed(timeout=3)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C572")
def test_empty_watchlist(driver, user):
    """C572 - Empty Watchlist
    |1.|Log in to the app and navigate to Watchlist |
    |2.| Check the empty view |
    |3.| Click the button |
    """
    user.api.clear_watchlist()

    # 1 Login
    login(driver, user.email, user.password)
    page = Watchlist(driver)
    page.click_on_watchlist_link()

    # 2 Check watchlist view
    assert page.is_no_content_message_displayed()
    assert page.is_explore_shows_button_displayed()

    # Click explore button
    page.click_on_explore_shows_button()
    assert page.is_home_logged_in_active_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C574")
def test_watchlist_with_items(driver, user_full_watchlist):
    """C574 - Watchlist with Items - Item Interaction
    Preconditions: A full Watchlist with 30 assets
    |1.| Log in to the app and navigate to Watchlist |
    |2.| Check the view and the assets |
    |3.| Select one of the assets |
    |4.| In the Watchlist view hover over an episode |
    |5.| Hover over an asset and click Add/Remove from Watchlist
    """
    user = user_full_watchlist

    # Step 1
    login(driver, user.email, user.password)
    page = Watchlist(driver)
    page.click_on_watchlist_link()
    watchlist = user.api.get_watchlist()

    # Step 2
    assert is_watchlist_full(watchlist)
    assert page.is_watchlist_results_displayed()
    if is_kids_asset_in_watchlist(watchlist):
        assert page.is_hide_toonix_content_button_displayed()

    # Step 3
    page.click_on_watchlist_asset(randrange(0, 30))
    # or Series(driver)
    page = Movie(driver)
    assert page.is_asset_title_displayed(timeout=3)

    page.click_on_watchlist_link()
    assert Watchlist(driver).is_watchlist_active_link_displayed()
    # Step 4, 5 fulfilled by C571


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C103865")
def test_sorting_general(driver, user,
                         movie, kids_movie, episode, kids_episode):
    """C103865 Sorting - General
    |1.| Log in to the app and navigate to Watchlist (it should be empty) |
    |2.| Add an asset and check the view |
    |3.| Remove the asset from the list |
    |4.| Add a range of assets and check the order in which they are
        presented |
    |5.| Navigate to the picker of sorting preferences |
    |6.| Click on the picker |
    |7.| Change sort order from default to one of the options and navigate
        through the app, then come back to Watchlist |
    |8.| Check the Watchlist setting for the same user on another device |
    |9.| Sign out of the app, sign in again and go to Watchlist |
    """
    assets = [movie, kids_movie, episode, kids_episode]
    user.api.clear_watchlist()

    # Step 1
    login(driver, user.email, user.password)
    page = Watchlist(driver)
    page.click_on_watchlist_link()

    assert not page.is_sort_dropdown_button_displayed(2)

    # Step 2
    search_item(driver, movie.title)
    open_first_search_result(driver)
    Movie(driver).click_on_add_to_watchlist_button()
    page.click_on_watchlist_link()

    assert page.is_watchlist_results_displayed()
    assert page.is_sort_dropdown_button_displayed()

    # Step 3
    page.remove_asset()
    assert not page.is_sort_dropdown_button_displayed(timeout=2)

    page.click_on_home_logged_in_link()

    # Step 4
    for a in assets:
        add_to_watchlist(user, a)
    driver.helper.refresh_page(wait=3)
    page.click_on_watchlist_link()
    assert is_watchlist_recently_added_sorted(
        driver, [a.title for a in assets])

    # Step 5, 6
    page.a_z_sort()
    assert is_watchlist_a_z_sorted(driver, [a.title for a in assets])
    # Step 7
    page.click_on_home_logged_in_link()
    page.click_on_my_account_link()
    page.click_on_watchlist_link()
    assert is_watchlist_a_z_sorted(driver, [a.title for a in assets])


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C576")
def test_sorting_choosing_options(driver, user,
                                  movie, kids_movie, episode, kids_episode):
    """ C576 Sorting - Choosing options
    |1.|Log in to the app and navigate to Watchlist |
    |2.| Check default sorting list by recently added |
    |3.| Select a new sort order from the picker |
    |4.|Sort list by recently released |
    |5.| Sort the list alphabetically |
    """
    # Arrange
    assets = (movie, kids_movie, episode, kids_episode)
    user.api.clear_watchlist()

    # Step 1
    login(driver, user.email, user.password)
    page = Watchlist(driver)
    page.click_on_watchlist_link()

    assert not page.is_sort_dropdown_button_displayed(2)
    page.click_on_home_logged_in_link()

    for a in assets:
        add_to_watchlist(user, a)
    driver.helper.refresh_page(wait=3)

    # Step 2
    page.click_on_watchlist_link()
    assert page.is_watchlist_results_displayed()
    assert page.is_sort_dropdown_button_displayed()
    assert is_watchlist_recently_added_sorted(
        driver, [x.title for x in assets])

    # Step 3, 4
    page.release_date_sort()
    assert is_watchlist_release_date_sorted(driver, user, assets)

    # Step 5
    page.a_z_sort()
    assert is_watchlist_a_z_sorted(driver, [x.title for x in assets])


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C577")
def test_filtering_kids_content(driver, user, episode, kids_episode):
    """ C577 Filtering out Toonix/Kids content
    |1.| Log in to the app and navigate to Watchlist (it should be empty) |
    |2.| Add an asset from the adult section and check the view |
    |3.| Add an asset from the Toonix/Kids section and check the view |
    |4.| Remove Toonix/Kids asset from the list |
    |5.|Add assets from adult and Toonix/Kids section to Watchlist and
        change the filter to ON |
    |6.| Toggle the filter back to OFF |
    |7.| Leave only Toonix/Kids assets in the list and toggle the filter ON |
    |8.|Navigate through the app and then come back to Watchlist |
    |9.| Log in with the same user on another device and check the Watchlist |
    |10.| Sign out and log in again |
    """
    # Arrange
    a, k = episode, kids_episode
    user.api.clear_watchlist()

    # Step 1
    login(driver, user.email, user.password)
    page = Watchlist(driver)
    page.click_on_watchlist_link()

    def add_asset(asset_title):
        """For step 2,3 & 5"""
        search_item(driver, asset_title)
        open_first_search_result(driver)
        page = Series(driver)
        page.wait_until_asset_preview_is_displayed()
        page.click_on_add_to_watchlist_button()
        assert page.is_feedback_toast_displayed()

        page.click_on_watchlist_link()

    # Step 2
    add_asset(a.title)
    assert not page.is_hide_toonix_content_button_displayed(timeout=3)

    # Step 3
    add_asset(k.title)
    assert page.is_hide_toonix_content_button_displayed()

    # Step 4
    wassets = page.get_watchlist_results()
    page.remove_asset()
    wassets_ar = page.get_watchlist_results()
    sleep(1)
    assert len(wassets_ar) == len(wassets) - 1
    assert not page.is_hide_toonix_content_button_displayed(1)

    # Step 5
    add_asset(k.title)
    assert page.is_hide_toonix_content_button_displayed()
    both = len(page.get_watchlist_results())
    page.click_on_hide_toonix_content_button()
    ao = len(page.get_watchlist_results())
    assert both > ao

    # Step 6
    page.click_on_hide_toonix_content_button()
    re_both = len(page.get_watchlist_results())
    assert re_both > ao

    # Step 7
    page.remove_asset(1)
    page.click_on_hide_toonix_content_button()
    assert page.is_only_kids_assets_text_displayed()

    # Step 8
    page.click_on_home_logged_in_link()
    page.click_on_watchlist_link()
    assert page.is_only_kids_assets_text_displayed()
    page.click_on_hide_toonix_content_button()
    assert not page.is_only_kids_assets_text_displayed(timeout=2)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C578")
def test_adding_items(driver, user, movie, episode):
    """ C578 - Adding Items - Locations
    |1.| Log in to the app and navigate to episode detail view, add the
        series to Watchlist
    |2.| Navigate to movies detail view, add the movie to Watchlist
    |3.| Hover over a generic shelf item and add it to Watchlist

    Note: navigating to series or movie assets is very finnicky as
    shelves and asset location change all the time.
        Practically we SHOULD
    end up in the same asset details no matter if we enter it through
    navigating to it, or searching. This is the assumption made below."""
    # Arrange
    m, ep = movie, episode
    user.api.clear_watchlist()

    # Step 1
    login(driver, user.email, user.password)

    page = Watchlist(driver)

    add_asset_to_watchlist(driver, ep.title, "series")
    assert page.is_feedback_toast_displayed()

    # Step 2
    add_asset_to_watchlist(driver, m.title, "movie")
    assert page.is_feedback_toast_displayed()

    page.click_on_watchlist_link()
    assert page.is_watchlist_results_displayed()

    page.remove_asset(0)  # The movie

    # Step 3
    open_recent_search_result(driver, 0, from_page=Watchlist)
    # Because our last search was a movie
    Movie(driver).click_on_add_to_watchlist_button()
    assert page.is_feedback_toast_displayed()

    # Step 4 fulfilled with 1, 2
    # TODO: Get a proper Step 5. For now fulfilled by 1, 2


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C581")
def test_unauthenticated_watchlist(driver, movie):
    """ C581 - Unauthenticated user using Watchlist
    |1.|Open the app but do not log in |
    |2.| Navigate to a location where you can add an item to Watchlist |
    |3.| Click Add to Watchlist |A prompt appears enabling to sign in
        or sign up |
    """
    # It's in the way later
    CookieBanner(driver).click_on_accept_button()

    page = Watchlist(driver)
    add_asset_to_watchlist(driver, movie.title, "movie")
    assert page.is_product_box_displayed(timeout=3)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C582")
def test_hiding_kids_watchlist(driver, user, movie):
    """ C582 - Hiding Watchlist functionality from user
    |1.|Open the app and log in |Watchlist is presented |
    |2.| Switch to "kids mode" |user no longer has access to Watchlist,
        user cannot add/remove) |
    |3.| Switch back to adult mode and add an asset to Watchlist |
        Asset is added |
    """
    user.api.clear_watchlist()

    login(driver, user.email, user.password)
    page = Watchlist(driver)
    assert page.is_watchlist_link_displayed()

    page.click_on_watchlist_link()
    assert page.is_watchlist_active_link_displayed()

    go_to_kids_locked(driver)
    assert not page.is_watchlist_link_displayed()

    go_out_from_kids_locked(driver, user.pin)
    assert page.is_watchlist_link_displayed()

    add_asset_to_watchlist(driver, movie.title, "movie")
    page.click_on_watchlist_link()
    assert page.is_watchlist_results_displayed()
