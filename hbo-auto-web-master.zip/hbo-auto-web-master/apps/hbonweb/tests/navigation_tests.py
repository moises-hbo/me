import pytest

from apps.hbonweb.pages.home_page import Home, WhyHBO
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.watchlist_page import Watchlist

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.navigation_flow import is_home_page, is_whyhbo_page, \
    click_on_asset_in_home


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C246")
def test_unauth_menu_items(driver):
    """C246: Menu items (Unauth).

    Verify HBO Logo, Why HBO, Home, Toonix,
    Free trial, Sign In, Search is in menu when unauthenticated
    https://hbo.testrail.com/index.php?/cases/view/246
    """
    page = WhyHBO(driver)

    assert page.is_hbo_logo_img_displayed()
    assert page.is_why_hbo_link_displayed()
    assert page.is_home_logged_out_link_displayed()
    assert page.is_kids_link_displayed()
    assert page.is_free_trial_button_displayed()
    assert page.is_sign_in_link_displayed()
    assert page.is_search_button_displayed()
    assert not page.is_watchlist_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C247")
def test_auth_menu_items(driver, user):
    """C247: Test case to verify.

    HBO Logo, Home, Toonix, Watchlist, My Account,
    Search is in menu when authenticated
    """
    login(driver, user.email, user.password)
    page = Home(driver)

    assert page.is_hbo_logo_img_displayed()
    assert page.is_home_logged_in_link_displayed()
    assert page.is_kids_link_displayed()
    assert page.is_watchlist_link_displayed()
    assert page.is_my_account_link_displayed()
    assert page.is_search_button_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C252")
def test_menu_highlighted_links_unauth(driver):
    """C252: Menu Items highlighting (Unauth).

    https://hbo.testrail.net/index.php?/cases/view/252
    """
    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()
    assert not page.is_home_logged_out_active_link_displayed(timeout=1)
    assert not page.is_kids_active_link_displayed(timeout=1)

    page.click_on_home_logged_out_link()
    page = Home(driver)
    assert page.is_home_logged_out_active_link_displayed()
    assert not page.is_why_hbo_active_link_displayed(timeout=1)
    assert not page.is_kids_active_link_displayed(timeout=1)

    click_on_asset_in_home(driver, 1, 1, avoid_play_button=True)
    assert not page.is_kids_active_link_displayed(timeout=1)
    assert not page.is_why_hbo_active_link_displayed(timeout=1)
    assert not page.is_home_logged_out_active_link_displayed(timeout=1)

    page.click_on_kids_link()
    page = Kids(driver)
    assert page.is_kids_active_link_displayed()
    assert not page.is_why_hbo_active_link_displayed(timeout=1)
    assert not page.is_home_logged_out_active_link_displayed(timeout=1)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C252")
def test_menu_highlighted_links_auth(driver, user):
    """C252: Menu Items highlighting (Auth).

    https://hbo.testrail.net/index.php?/cases/view/252
    """
    login(driver, user.email, user.password)

    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()
    assert not page.is_kids_active_link_displayed(timeout=1)
    assert not page.is_watchlist_active_link_displayed(timeout=1)

    click_on_asset_in_home(driver, 1, 1, avoid_play_button=True)
    assert not page.is_kids_active_link_displayed(timeout=1)
    assert not page.is_why_hbo_active_link_displayed(timeout=1)
    assert not page.is_home_logged_out_active_link_displayed(timeout=1)

    page.click_on_kids_link()
    page = Kids(driver)
    page.click_on_got_it_alert_button()
    assert page.is_kids_active_link_displayed()
    assert not page.is_home_logged_in_active_link_displayed(timeout=1)
    assert not page.is_watchlist_active_link_displayed(timeout=1)

    page.click_on_watchlist_link()
    page = Watchlist(driver)
    assert page.is_watchlist_active_link_displayed()
    assert not page.is_home_logged_in_active_link_displayed(timeout=1)
    assert not page.is_kids_active_link_displayed(timeout=1)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C358")
def test_hbo_logo_is_linking_to_home_page_logout(driver):
    """C358: HBO logo links to Why HBO for unauthenticated."""
    page = WhyHBO(driver)
    page.click_on_hbo_logo_img()

    assert is_whyhbo_page(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C358")
def test_hbo_logo_is_linking_to_home_page_login(driver, user):
    """C358: HBO logo links to Home page for authenticated."""
    login(driver, user.email, user.password)
    page = Home(driver)
    page.click_on_hbo_logo_img()

    assert is_home_page(driver)
