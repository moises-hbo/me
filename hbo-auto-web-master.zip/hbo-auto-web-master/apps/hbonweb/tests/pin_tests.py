import pytest
from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.home_page import Home
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.pin_page import Pin
from apps.hbonweb.pages.myaccount_page import MyAccount

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.pin_flow import input_pin_code


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("pin")
@pytest.mark.id("C597")
def test_parental_controls(driver, user_change_pin):
    """  Parental Controls - Main Content & Interaction
    Checks:
    #1: With no PIN, set PIN option seen in Parental Controls
    #2: Click set PIN. Set it. Reset and Turn off options now visible
    #3: Click reset PIN. Set it. same as before (reset/turn off)
    #4: Click turn off PIN. Now set PIN should be visible again
    #5: Go to Kids, lock, and unlock. No PIN should be presented
        and we end up at Home
    """
    user_change_pin.api.reset_pin(remove=True)

    login(driver, user_change_pin.email, user_change_pin.password)

    page = Home(driver)
    page.click_on_my_account_link()

    # 1
    page = MyAccount(driver)
    page.click_on_parental_controls_link()

    assert page.is_set_pin_button_displayed()
    assert not page.is_reset_pin_button_displayed(0)
    assert not page.is_turn_off_pin_displayed(0)

    # 2
    page.click_on_set_pin_button()
    for i in range(2):
        input_pin_code(driver, 1234)

    assert page.is_reset_pin_button_displayed()
    assert page.is_turn_off_pin_displayed()
    assert not page.is_set_pin_button_displayed(0)

    # 3
    page.click_on_reset_pin_button()
    for i in range(2):
        input_pin_code(driver, 4321)

    assert page.is_reset_pin_button_displayed()
    assert page.is_turn_off_pin_displayed()
    assert not page.is_set_pin_button_displayed(0)

    # 4
    page.click_on_turn_off_pin_button()

    assert page.is_set_pin_button_displayed()
    assert not page.is_reset_pin_button_displayed(0)
    assert not page.is_turn_off_pin_displayed(0)

    # 5
    page.click_on_kids_link()
    page = Kids(driver)
    page.click_on_got_it_alert_button()
    page.click_on_lock_button()

    assert page.is_kids_mode_locked()

    page.click_on_lock_button()

    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C641")
def test_prompt_set_pin_choose_profile(driver, user_change_pin):
    """
    C641: User has no PIN set and not selected "Don't ask again"

    https://hbo.testrail.net/index.php?/cases/view/641
    """
    user_change_pin.api.reset_pin()

    login(driver, user_change_pin.email, user_change_pin.password)
    page = Pin(driver)

    assert page.is_set_pin_title_displayed()

    page.click_on_maybe_later_link()
    page = Home(driver)

    assert page.is_my_account_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C641")
def test_no_prompt_set_pin_choose_profile(driver, user_change_pin):
    """
    C641: User has set "Don't ask me again" (Removed PIN entirely)

    https://hbo.testrail.net/index.php?/cases/view/641
    """
    login(driver, user_change_pin.email, user_change_pin.password)
    page = Pin(driver)

    assert not page.is_set_pin_title_displayed(timeout=2)

    page = Home(driver)

    assert page.is_my_account_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C641")
def test_prompt_set_pin_exit_kids(driver, user_change_pin):
    """
    C641: Exit kids mode with no PIN set

    https://hbo.testrail.net/index.php?/cases/view/641
    """
    user_change_pin.api.reset_pin()

    login(driver, user_change_pin.email, user_change_pin.password)
    page = Pin(driver)

    assert page.is_set_pin_title_displayed()

    page.click_on_maybe_later_link()
    page = Home(driver)
    page.click_on_kids_link()
    page = Kids(driver)
    page.click_on_got_it_alert_button()
    page.click_on_lock_button()  # Lock
    page.click_on_lock_button()  # Unlock
    page = Pin(driver)

    assert page.is_set_pin_title_displayed()

    page.click_on_maybe_later_link()
    page = Home(driver)

    assert page.is_my_account_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C641")
def test_no_prompt_set_pin_exit_kids(driver, user_change_pin):
    """
    C641: Exit kids mode with "Don't ask med again" set (No PIN entirely)

    https://hbo.testrail.net/index.php?/cases/view/641
    """
    login(driver, user_change_pin.email, user_change_pin.password)
    page = Pin(driver)
    assert not page.is_set_pin_title_displayed(timeout=2)

    page = Home(driver)
    page.click_on_kids_link()
    page = Kids(driver)
    page.click_on_got_it_alert_button()
    page.click_on_lock_button()  # Lock
    page.click_on_lock_button()  # Unlock
    page = Pin(driver)

    assert not page.is_set_pin_title_displayed(timeout=2)

    page = Home(driver)

    assert page.is_my_account_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C643")
def test_enter_pin(driver, user_change_pin):
    """C643: User can select prompted options
    Checks:
    #1: Set pin title is displayed
    #2: That non-digit won't be input
    #3: That digit-number can be input
    #4: Backspace removes added digit
    #5: Enter valid pin puts us at confirm pin
    #6: Entering valid confirm puts us at parental controls,
      where we can see Reset and Turn Off
    """
    user_change_pin.api.reset_pin(remove=True)
    page = login(driver, user_change_pin.email, user_change_pin.password)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_parental_controls_link()
    page.click_on_set_pin_button()

    page = Pin(driver)
    # 1
    assert page.is_set_pin_title_displayed()

    # 2
    page.enter_pin_number("t", 1)
    assert not page.get_text_of_pin_digit(1)

    # 3
    page.enter_pin_number(1)
    assert page.get_text_of_pin_digit(1) == "1"

    # 4
    page.enter_backspace_on_pin_number(1)
    assert not page.get_text_of_pin_digit(1)

    # 5
    page.enter_pin(1234)
    assert page.wait_until_confirm_pin_is_displayed()

    # 6
    page.enter_pin(1234, confirm=True)
    page = MyAccount(driver)
    assert page.is_reset_pin_button_displayed()
    assert page.is_turn_off_pin_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C643")
def test_set_maybe_later(driver, user_change_pin):
    """C643: User can select prompted options
    Checks:
    #1: Clicking maybe later puts us at home
    #2: Set pin vill be displayed
    #3: Set pin will be triggered next login
    """
    user_change_pin.api.reset_pin(remove=True)
    page = login(driver, user_change_pin.email, user_change_pin.password)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_parental_controls_link()
    page.click_on_set_pin_button()

    page = Pin(driver)

    # 1
    page.click_on_maybe_later_link()
    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()

    # 2
    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_parental_controls_link()
    assert page.is_set_pin_button_displayed()

    # 3
    page.click_on_sign_out_link()
    sleep(5)
    login(driver, user_change_pin.email, user_change_pin.password)
    page = Pin(driver)
    assert page.is_set_pin_title_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C643")
def test_set_dont_ask_again(driver, user_change_pin):
    """C643: User can select prompted options
    Checks:
    #1: Clicking don't ask again puts us at home
    #2: Set pin vill be displayed
    #3: Set pin will NOT be triggered next login
    """
    user_change_pin.api.reset_pin(remove=True)
    page = login(driver, user_change_pin.email, user_change_pin.password)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_parental_controls_link()
    page.click_on_set_pin_button()

    page = Pin(driver)

    # 1
    page.click_on_dont_ask_again_link()
    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()

    # 2
    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_parental_controls_link()
    assert page.is_set_pin_button_displayed()

    # 3
    page.click_on_sign_out_link()
    sleep(5)
    page = login(driver, user_change_pin.email, user_change_pin.password)
    assert page.is_home_logged_in_active_link_displayed()
