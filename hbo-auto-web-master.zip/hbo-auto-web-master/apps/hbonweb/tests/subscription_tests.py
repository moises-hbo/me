import datetime
import random

import pytest

from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.loginform_page import LoginForm
from apps.hbonweb.pages.myaccount_page import MyAccount, CancelSubscription
from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.series_page import Series
from apps.hbonweb.pages.startwatchingnow_page import StartWatchingNow
from apps.hbonweb.pages.productbox_partial import ProductBox
from apps.hbonweb.pages.payment_page import PaymentDetails
from apps.hbonweb.pages.signup_page import CantSubscribe, GetStarted
from apps.hbonweb.pages.player_page import Player
from apps.hbonweb.pages.contact_page import Contact
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner, \
    CookieReadMore

from apps.hbonweb.flows.signup_flow import do_complete_registration, \
    did_we_successfully_register_and_subscribe_and_return_to_home, \
    is_card_type_visible, enter_4digit_card, enter_signup_info_and_continue, \
    are_non_interactive_payment_elements_outside_iframe_visible, \
    are_non_interactive_payment_elements_within_iframe_visible, \
    enter_credit_card_info
from apps.hbonweb.flows.search_flow import search_asset_open, search_item, \
    open_first_search_result
from apps.hbonweb.flows.cookies_banner_flow import accept_cookie_banner

from apps.hbonshared.resourcesmanager import ResourcesManager as RM

from helpers.configmanager import ConfigManager
from helpers.sleeper import Sleeper as sleep

cm = ConfigManager()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_home(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From Home - End at Home.
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    WhyHBO(driver).click_on_home_logged_out_link()
    page = Home(driver)
    page.click_on_free_trial_button()

    do_complete_registration(driver, user_tmp, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_kids(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From Kids - End at Home.
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    WhyHBO(driver).click_on_kids_link()
    Kids(driver).click_on_free_trial_button()

    do_complete_registration(driver, user_tmp, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_productbox_whyhbo(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From WhyHBO Product Box - End at Home.
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    page = ProductBox(driver)
    assert page.is_text_displayed_on_product_box()
    page.click_on_pb_free_trial_button()  # Partial page

    do_complete_registration(driver, user_tmp, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_productbox_kids(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From Home Product Box - End at Home.
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    WhyHBO(driver).click_on_kids_link()

    page = ProductBox(driver)
    assert page.is_text_displayed_on_product_box()
    page.click_on_pb_free_trial_button()  # Partial page

    do_complete_registration(driver, user_tmp, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_productbox_home(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From Home Product Box - End at Home.
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    WhyHBO(driver).click_on_home_logged_out_link()

    page = ProductBox(driver)
    assert page.is_text_displayed_on_product_box()
    page.click_on_pb_free_trial_button()  # Partial page

    do_complete_registration(driver, user_tmp, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.xfail(reason="Home isn't highlighted at end")
@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("episode")])
def test_successful_subscription_signup_from_asset(driver, user_tmp, cc,
                                                   asset):
    page = search_asset_open(driver, asset)
    # TODO: Implement support for deciding if we want a movie/series
    page.click_on_pb_free_trial_button()

    do_complete_registration(driver, user_tmp, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_startwatchingnow(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From StartWatchingNow (Play Now button) - End at Asset View
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    asset = RM.get_special_asset("movie")

    search_item(driver, asset.title)
    open_first_search_result(driver)

    Series(driver).click_on_play_button()
    StartWatchingNow(driver).click_on_free_trial_button()

    do_complete_registration(driver, user_tmp, cc)

    assert not PaymentDetails(driver).is_payment_frame_displayed(timeout=1)
    assert not Navigation(driver).is_complete_registration_banner_displayed(
        timeout=1)
    assert driver.current_url.endswith("/play")


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_whyhbo(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From WhyHBO - End at Home.
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    WhyHBO(driver).click_on_free_trial_button()

    do_complete_registration(driver, user_tmp, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C461")
def test_successful_subscription_from_signin(driver, user_tmp, cc):
    """C461: Successful subscription

    Create new user. Provide valid subscription.
    From SignIn - End at Home.
    https://hbo.testrail.net/index.php?/cases/view/461
    """
    # Bug-fix, would otherwise be in the way
    accept_cookie_banner(driver)

    WhyHBO(driver).click_on_sign_in_link()
    LoginForm(driver).click_on_signin_free_trial_link()

    # No GetStarted since we accepted cookie banner
    do_complete_registration(driver, user_tmp, cc, False)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id()
def test_successful_subscription(driver, user_tmp_ss, cc):
    """Create a valid user with a valid subscription.

    Not part of any test case currently. Made for tracking user.
    """
    WhyHBO(driver).click_on_free_trial_button()

    do_complete_registration(driver, user_tmp_ss, cc)

    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription", "playback")
@pytest.mark.id("C545")
def test_cancelled_subscription(driver, user_tmp_cs, cc, movie):
    """C545: Cancel Subscription.
    Checks:
    #1: Cancel Subscription page turns up when you choose to cancel sub
    #2: Clicking on "Watch now" will redirect to Series page
    #3: Clicking on "keep subscription" returns you to my account sub page
    #4: Clicking on "cancel subscription" cancels subscription. My account sub
        page notifies you of this - shows reactivate & voucher buttons
    #5: Check subscription end date
    #6: Check that as a 'suspended' user, playback still works
    """
    # Arrange
    WhyHBO(driver).click_on_free_trial_button()
    do_complete_registration(driver, user_tmp_cs, cc)
    assert did_we_successfully_register_and_subscribe_and_return_to_home(
        driver)

    Home(driver).click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_subscription_link()

    # 1
    page.click_on_cancel_subscription_link()
    page = CancelSubscription(driver)
    assert page.is_page_active()

    # 2
    current_url = driver.helper.get_url()
    watch_now_href = page.get_link_of_watch_now_button()
    page.click_on_watch_now_button()

    page = Series(driver)
    assert page.is_series_page()
    assert watch_now_href == driver.helper.get_url()
    assert current_url != driver.helper.get_url()

    driver.back()
    page = CancelSubscription(driver)

    # 3
    page = MyAccount(driver)
    page.click_on_cancel_subscription_link()

    page = CancelSubscription(driver)
    page.click_on_keep_subscription_button()

    page = MyAccount(driver)
    assert page.is_subscription_link_selected_displayed()

    # 4
    page.click_on_cancel_subscription_link()

    page = CancelSubscription(driver)
    page.click_on_cancel_subscription_button()

    page = MyAccount(driver)
    assert page.is_subscription_cancelled_header_displayed()
    assert page.is_reactivate_subscription_button_displayed()
    assert page.is_add_voucher_button_displayed()

    cancelled_msg_exp = RM.get_lang_text(
        "myaccount_subscription_cancelled_message")
    cancelled_msg_act = page.get_text_of_cancelled_sub_message()
    assert cancelled_msg_exp in cancelled_msg_act

    # 5
    exp_date = datetime.datetime.now() + datetime.timedelta(days=14)
    assert str(exp_date.day) and str(exp_date.year) in cancelled_msg_act

    sleep(5)  # Wait for darkened overlay
    page.click_on_hbo_logo_img()

    page = Home(driver)
    assert page.is_complete_registration_banner_displayed()

    # 6
    page = search_asset_open(driver, movie)
    page = page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C457")
def test_payment_form(driver, user_tmp):
    """C457: General look of Payment details form

    https://hbo.testrail.com/index.php?/cases/view/457
    """
    # Arrange
    WhyHBO(driver).click_on_free_trial_button()
    enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password, no_news_offers=False)

    # Step 1
    page = PaymentDetails(driver)
    page.wait_until_payment_submit_button_displayed()
    assert are_non_interactive_payment_elements_outside_iframe_visible(driver)
    page.enter_payment_iframe()
    assert are_non_interactive_payment_elements_within_iframe_visible(driver)

    # TODO: add steps to validate strings


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C460")
def test_4char_card_recognition(driver, user_tmp, cc):
    """C460: Payment details interaction

    https://hbo.testrail.com/index.php?/cases/view/460
    """
    # Arrange
    WhyHBO(driver).click_on_free_trial_button()
    enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password, no_news_offers=False)

    # Step 1
    enter_4digit_card(driver, cc)
    assert is_card_type_visible(driver)


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C108004")
def test_updating_payment_with_wrong_region_cc(driver, user_tmp, cc, wrong_cc):
    """ Unable to Update payment
    Checks:
    #1: Entering an invalid credit card (such as from the wrong country)
        directs you to CantSubscribe page
    #2: Clicking on customer support page lands you on Contact page
    #3: Going back returns you to PaymentDetails page
    """
    page = do_complete_registration(driver, user_tmp, cc, goto_signup=True)

    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_subscription_link()
    page.click_on_change_payment_button()

    # 1
    page = PaymentDetails(driver)
    enter_credit_card_info(
        driver, wrong_cc.number, wrong_cc.cvv, wrong_cc.name, wrong_cc.month,
        wrong_cc.year)

    page = CantSubscribe(driver)
    assert page.is_cant_subscribe_page()
    assert page.is_change_payment_button_displayed()
    assert page.is_customer_service_link_displayed()

    # 2
    page.click_on_customer_service_link()

    page = Contact(driver)
    assert page.is_contact_page()

    # 3
    driver.helper.go_back()

    page = PaymentDetails(driver)
    assert page.is_payment_no_signup_page()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C546")
def test_reactivate_cancelled_sub(driver, user_tmp, cc):
    """ Subscription Reactivation
    Checks:
    #1: Reactivating payment updates UI to reflect OK state
    #2: Billing date & price should be correct
    """
    page = do_complete_registration(driver, user_tmp, cc, goto_signup=True)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_subscription_link()
    page.click_on_cancel_subscription_link()

    page = CancelSubscription(driver)
    page.click_on_cancel_subscription_button()

    # 1
    page = MyAccount(driver)
    assert page.is_sub_reactivate_button_displayed(20)
    sleep(2)  # For hidden overlay to disappear

    page.click_on_sub_reactivate_button()
    assert page.is_change_payment_button_displayed()
    assert page.is_cancel_subscription_button_displayed()

    sleep(5)  # Give billing a sec

    # 2
    billing_date = page.get_text_of_next_billing_date()
    next_month = datetime.datetime.now() + datetime.timedelta(days=14)
    assert str(next_month.year) in billing_date

    billing_price = page.get_text_of_billing_amount()
    billing = RM.get_billing_price()
    assert str(billing.amount) in billing_price
    assert billing.currency in billing_price


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C4678960")
def test_accept_some_cookies_before_signup(driver, user_tmp, cc):
    """ Accepting cookies before/after sign-up
    Checks:
    #1: Go to cookies read more info page. accept some cookies. save
    #2: Do a full subscription. Verify we end up at Home with
        the welcome message, without the Get started page
    """
    # 1
    CookieBanner(driver).click_on_read_more_button()
    page = CookieReadMore(driver)
    page.click_on_select_all_checkbox()
    page.click_on_facebook_option_checkbox()
    page.click_on_google_option_checkbox()
    page.click_on_save_button()

    # 2
    page = do_complete_registration(
        driver, user_tmp, cc, accept_getstarted=False, goto_signup=True)
    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()
    assert page.is_welcome_header_displayed()
    assert page.is_welcome_intro_text_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C108002")
def test_wrong_credit_card_country(driver, user_tmp):
    """ Using wrong credit card (not country-specific)
    Checks:
    #1: Attempting to sign up with a CC that's from a wrong country
        will give a Can't Subscribe page
    #2: Click on change payment, and try with a second wrong CC.
        Cant Subscribe page again
    #3: Click on customer service link. Customer Service page should appear
    """
    countries = RM.get_countries()
    countries.remove(cm.country_id)
    cc = RM.get_credit_card("VISA", random.choice(countries))
    countries.remove(cc.country)
    ccn = RM.get_credit_card("VISA", random.choice(countries))

    # 1
    WhyHBO(driver).click_on_free_trial_button()
    do_complete_registration(driver, user_tmp, cc, accept_getstarted=False)

    page = CantSubscribe(driver)
    assert page.is_cant_subscribe_page()

    # 2
    page.click_on_change_payment_button()

    page = PaymentDetails(driver)
    enter_credit_card_info(
        driver, ccn.number, ccn.cvv, ccn.name, ccn.month, ccn.year)

    page = CantSubscribe(driver)
    assert page.is_cant_subscribe_page()

    # 3
    page.click_on_customer_service_link()

    # NOTE: Currently this page is displayed first. Have to verify if it should
    page = GetStarted(driver)
    assert not page.is_get_started_page()

    page = Contact(driver)
    assert page.is_contact_page()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C4678960")
def test_accept_some_cookies_after_signup(driver, user_tmp, cc):
    """ Accepting cookies before/after sign-up
    Checks:
    #1: Complete subscription process. At Get Started page, go to
        cookies alternatives, make some changes and save
    #2: Verify we end up at Home with the welcome message
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = do_complete_registration(
        driver, user_tmp, cc, accept_getstarted=False)

    # 1
    assert page.is_get_started_page()
    page.click_on_show_alternatives_button()

    page = CookieReadMore(driver)
    assert page.is_cookie_banner_read_more_page()
    page.click_on_save_button()

    # 2
    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()
    assert page.is_welcome_header_displayed()
    assert page.is_welcome_intro_text_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C4678960")
def test_accept_all_cookies_before_signup(driver, user_tmp, cc):
    """ Accepting cookies before/after sign-up
    Checks:
    #1: Accept all cookies
    #2: Do a full subscription. Verify we end up at Home with
        the welcome message, without the Get started page
    """
    # 1
    CookieBanner(driver).click_on_accept_button()

    WhyHBO(driver).click_on_free_trial_button()

    # 2
    page = do_complete_registration(
        driver, user_tmp, cc, accept_getstarted=False)
    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()
    assert page.is_welcome_header_displayed()
    assert page.is_welcome_intro_text_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C1033340")
def test_myaccount_fields(driver, user_tmp, cc):
    """ Account Details - Personal Information
    Checks:
    #1: MyAccount button changes color to blue when hovered over.
        Doesn't get underlined
    #2: Check that first and last are empty after new registration,
        with placeholder saying 'Optional'. Email has user email.
        No newsletter is checked
    """
    blue = "rgba(0, 163, 218, 1)"
    page = do_complete_registration(driver, user_tmp, cc, goto_signup=True)

    # 1
    myacc_btn_color = page.get_color_of_myaccount_button()
    page.hover_over_myaccount_button()
    myacc_btn_hover_color = page.get_color_of_myaccount_button()
    assert myacc_btn_color != myacc_btn_hover_color
    assert myacc_btn_hover_color == blue
    assert "underline" not in page.get_text_decoration_of_myaccount_button()

    page.click_on_my_account_link()
    page = MyAccount(driver)

    # 2
    assert not page.get_text_of_first_name()
    assert not page.get_text_of_last_name()
    assert page.get_text_of_email() == user_tmp.email
    assert page.is_newsletter_checkbox_active()
    placeholder = RM.get_lang_text("myaccount_name_placeholder")
    assert page.get_placeholder_of_firstname_input() == placeholder
    assert page.get_placeholder_of_lastname_input() == placeholder


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C1033909")
def test_update_myaccount_fields(driver, user_tmp, cc):
    """ Updating Account Details - Personal Information
    Checks:
    #1: Entering first and lastname and saving gives a success toast
        and placeholder text is replaced by first & lastname
    """
    page = do_complete_registration(driver, user_tmp, cc, goto_signup=True)

    page.click_on_my_account_link()
    page = MyAccount(driver)

    # 1
    page.input_text_on_first_name(user_tmp.firstname)
    page.input_text_on_last_name(user_tmp.lastname)
    page.click_on_save_changes_button()
    assert page.is_updated_changes_success_alert_displayed()
    assert page.get_text_of_first_name() == user_tmp.firstname
    assert page.get_text_of_last_name() == user_tmp.lastname
    driver.refresh()
    assert not page.get_placeholder_of_firstname_input()
    assert not page.get_placeholder_of_lastname_input()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription", "deploy")
@pytest.mark.id("C1033338")
def test_successful_subscription_cc(driver, user_tmp, cc):
    """  Successful subscription creation - CreditCard
    Checks:
    #1: That Welcome section is placed below the Carousel
    #2: That we have a list of supported devices being shown
    #3: That the welcome message doesn't include user firstname
    """
    # to force non-cached version // deploy
    dt = str(datetime.datetime.now()).replace(" ", "_")
    driver.helper.go_to_url(f"{cm.url}/{dt}")
    sleep(5)

    page = do_complete_registration(driver, user_tmp, cc, goto_signup=True)

    assert page.is_welcome_header_displayed()

    # 1
    assert page.get_location_of_welcome_header()["y"] > \
        page.get_location_of_carousel()["y"]

    # 2
    device_list = page.get_devices_list()
    assert len(device_list) >= 6

    # 3
    welcome_message = page.get_text_of_welcome_header()
    assert user_tmp.firstname not in welcome_message
    assert "HBON" not in welcome_message
    assert "HBOE" not in welcome_message
