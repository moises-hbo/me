import pytest

from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.series_page import Series

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.search_flow import search_item, \
    open_first_search_result, search_series_open_episode, \
    search_movie_open
from apps.hbonweb.flows.movie_flow import is_right_movie_title_displayed, \
    is_right_movie_metadata_order, is_right_movie_poster_displayed, \
    is_movie_overview_correctly_displayed, is_movie_year_format_valid
from apps.hbonweb.flows.series_flow import \
    is_right_series_title_displayed, is_right_episode_poster_displayed, \
    is_episode_overview_correctly_displayed, \
    is_series_overview_correctly_displayed, is_right_series_metadata_order, \
    is_series_year_format_valid, switch_seasons_in_navbar


from helpers.utility_functions import is_duration_format_valid, \
    get_duration_in_sec


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C523")
# TODO Documentary movies haven`t cast section (also some Specials)
def test_movie_overview(driver, user, movie):
    """ C523: Movie Overview

    Go to the HBO web app and Sign In with active user
    Navigate to any Movie and open overview
    Check Expected results for Movie page
    """
    login(driver, user.email, user.password)

    page = search_movie_open(driver, movie.title)

    asset_metadata = user.api.get_asset_metadata(
        'MOVIE', movie.title.upper())
    asset_duration = user.api.get_asset_duration(
        'MOVIE', movie.title.upper())

    if asset_metadata.get("title"):
        assert is_right_movie_title_displayed(driver, movie.title)

    assert is_right_movie_poster_displayed(driver, movie.title)
    assert is_movie_overview_correctly_displayed(
        driver, asset_metadata, asset_duration)

    if not page.is_movies_lock_button_displayed(timeout=1):
        if asset_metadata.get("actors"):
            assert page.is_movies_cast_displayed()
        if asset_metadata.get("director"):
            assert page.is_movies_director_displayed()
    assert page.is_movies_add_to_watchlist_button_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C523")
def test_episode_overview(driver, user, episode):
    """C523: Episode Overview

    Go to the HBO web app and Sign In with active user
    Navigate to any Series and open Episode overview
    Check Expected results for Episode page
    """
    login(driver, user.email, user.password)

    page = search_series_open_episode(
        driver, episode.title, episode.season, episode.ep_name)

    asset_metadata = user.api.get_asset_metadata(
        'SERIES', episode.title.upper(),
        str(episode.season), str(episode.episode))
    asset_duration = user.api.get_asset_duration(
        'SERIES', episode.title.upper(),
        str(episode.season), str(episode.episode))

    page = Series(driver)
    assert is_episode_overview_correctly_displayed(
        driver, asset_metadata, asset_duration)
    assert is_right_episode_poster_displayed(driver)
    assert page.is_series_add_to_watchlist_button_displayed(hover=False)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C664")
# TODO Add API response metadata check to verify fields which provided by API
def test_series_overview(driver, user, episode):
    """ C664: Series/Season Metadata

    Go to the HBO web app and Sign In with active account
    Navigate to any Series and check Expected results
    """
    login(driver, user.email, user.password)
    search_item(driver, episode.title)
    open_first_search_result(driver)

    page = Series(driver)

    if page.is_show_more_button_displayed():
        sm_loc = page.get_location_of_show_more_button()
        driver.helper.scroll(0, sm_loc["y"] + 25)
        page.click_on_show_more_button()

    assert page.is_overview_tab_landing_page()
    assert is_right_series_title_displayed(driver, episode.title)
    assert is_series_overview_correctly_displayed(driver)
    assert is_right_series_metadata_order(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C542")
# TODO Add API response metadata check to verify fields which provided by API
def test_movie_metadata(driver, user, movie):
    """ C542: Movie Metadata

    Go to the HBO web app and Sign In with active account
    Navigate to the Movie page and check Expected results
    All metadata for which values are provided by API are shown in UI
    """
    login(driver, user.email, user.password)

    search_movie_open(driver, movie.title)

    displayed_duration = Movie(driver).get_movies_displayed_duration()
    asset_duration = user.api.get_asset_duration(
        'MOVIE', movie.title.upper())

    assert get_duration_in_sec(displayed_duration) == asset_duration
    assert is_duration_format_valid(displayed_duration)
    assert is_movie_year_format_valid(driver)
    assert is_right_movie_metadata_order(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C542")
def test_episode_metadata(driver, user, episode):
    """ C542: Episode Metadata

    Go to the HBO web app and Sign In with active account
    Navigate to the Movie page and check Expected results
    All metadata for which values are provided by API are shown in UI
    """
    login(driver, user.email, user.password)

    page = search_series_open_episode(
        driver, episode.title, episode.season, episode.ep_name)

    displayed_duration = page.get_episode_displayed_duration()
    asset_duration = user.api.get_asset_duration(
        "SERIES", episode.title.upper(),
        str(episode.season), str(episode.episode))

    assert get_duration_in_sec(displayed_duration) == asset_duration
    assert is_duration_format_valid(page.get_episode_displayed_duration())
    assert is_series_year_format_valid(driver)
    assert is_right_series_metadata_order(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C636")
def test_season_picker(driver, user, episode):
    """C636: Navigation & Season Picker

    Go to the HBO web app and Sign In with active account
    Navigate to any Series and check Expected results
    """
    login(driver, user.email, user.password)
    search_item(driver, episode.title)
    open_first_search_result(driver)

    assert Series(driver).is_overview_tab_landing_page()
    assert switch_seasons_in_navbar(driver)
