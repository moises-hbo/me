from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonweb.pages.home_page import Home, WhyHBO
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.search_page import Search as SearchPage

from helpers.utility_functions import replace_special_characters

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.series_flow import is_right_series_title_displayed
from apps.hbonweb.flows.kids_flow import go_to_kids_locked, \
    go_out_from_kids_locked
from apps.hbonweb.flows.search_flow import search_item, \
    is_search_result_in_list, is_search_result_in_grid, \
    get_all_titles_from_search_result, open_search_result, \
    open_sequently_search_results, is_item_on_search_result, \
    open_first_search_result, can_interact_with_first_search_result, \
    can_play_first_search_result, can_open_first_search_result, \
    is_search_waiting_for_input, is_no_search_result
from apps.hbonweb.flows.footer_flow import change_language_to_nonactive

from helpers.configmanager import ConfigManager

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C584")
@pytest.mark.xfail(cm.driver_name == "chrome",
                   reason="Chrome can't be made small enough")
def test_resized_window_shows_list_instead_of_grid(driver):
    """C584 Search result with max. resizing is displayed on
    list instead of on a grid"""
    search_item(driver, "the")
    sleep(2)
    width = 400
    for _ in range(5):
        driver.helper.resize_window(width, 720)
        width -= 50
        sleep(1)

    assert is_search_result_in_list(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C584")
def test_maximized_window_shows_search_result_in_grid(driver):
    """C584 Search result with maximized window is
    displayed on a grid with a rows"""
    search_item(driver, "the")

    assert is_search_result_in_grid(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C584")
def test_resized_window_shows_all_searched_assets(driver):
    """C584 Search result is displayed after window resizing"""
    search_item(driver, "the")

    titles_on_large_window = get_all_titles_from_search_result(driver)
    driver.helper.resize_window(200, 1800)
    sleep(1)
    titles_on_small_window = get_all_titles_from_search_result(driver)

    assert titles_on_large_window == titles_on_small_window


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C591")
def test_recent_search_header_is_displayed(driver, kids_episode):
    """C591 Recent search result has a header with text"""
    ke = kids_episode
    page = SearchPage(driver)

    search_item(driver, ke.title)
    open_search_result(driver)
    page.click_on_hbo_logo_img()
    Home(driver).click_on_search_button()

    assert page.is_recent_search_result_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C591")
def test_recent_search_is_cleared_with_new_session(driver, user):
    """C591 Recent search result is cleared with new session"""
    page = login(driver, user.email, user.password)
    page.click_on_search_button()

    page = SearchPage(driver)
    assert page.is_search_more_input_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C591")
def test_recent_search_is_cleared_after_language_change(driver, user,
                                                        kids_episode):
    """C591 Recent search result is cleared after language change"""
    # Arrange
    ke = kids_episode

    login(driver, user.email, user.password)
    page = SearchPage(driver)

    search_item(driver, ke.title)
    open_search_result(driver)
    page.click_on_hbo_logo_img()

    change_language_to_nonactive(driver)

    Home(driver).click_on_search_button(20)

    assert page.is_search_more_input_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C591")
def test_kids_recent_search_excluded_in_adults(driver, user,
                                               kids_episode):
    """C591 Recent search result from Kids
    locked is not displayed in Home page"""
    # Arrange
    ke = kids_episode

    login(driver, user.email, user.password)
    page = SearchPage(driver)

    go_to_kids_locked(driver)

    search_item(driver, ke.title)
    open_search_result(driver)
    page.click_on_hbo_logo_img()

    go_out_from_kids_locked(driver, user.pin)

    Kids(driver).click_on_search_button()

    page = SearchPage(driver)
    assert page.is_search_more_input_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C591")
def test_adults_recent_search_excluded_in_kids(driver, user, episode):
    """C591 Recent search result from Home page is
    not displayed in Kids locked"""
    # Arrange
    ep = episode

    login(driver, user.email, user.password)
    page = SearchPage(driver)
    search_item(driver, ep.title)
    open_search_result(driver)
    page.click_on_hbo_logo_img()

    go_to_kids_locked(driver)
    Kids(driver).click_on_search_button()

    assert page.is_search_more_input_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C590")
def test_user_sees_recent_kids_searches(driver, user):
    """C590 User can see up to 3 recent search on Search Page for Kids"""
    login(driver, user.email, user.password)
    go_to_kids_locked(driver)
    page = SearchPage(driver)
    phrase = dict(fi="ma", se="al", dk="de", no="de", es="at")[cm.country_id]
    number_of_items = 2

    titles = open_sequently_search_results(
        driver, number_of_items, phrase)
    Kids(driver).click_on_search_button()

    for index in range(0, number_of_items):
        asset_from_search = titles[(index + 1) * -1]
        recent_search = page.get_title_of_recent_search_result(index)
        assert asset_from_search == recent_search


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C590")
def test_user_sees_recent_adults_searches(driver, user):
    """C590 User can see up to 5 recent search on Search Page for Adults"""
    page = login(driver, user.email, user.password)
    random_phrase = "the"
    number_of_items = 3

    titles = open_sequently_search_results(
        driver, number_of_items, random_phrase)
    page.click_on_search_button()

    page = SearchPage(driver)
    for index in range(0, number_of_items):
        asset_from_search = titles[(index + 1) * -1]
        recent_search = page.get_title_of_recent_search_result(index)
        assert asset_from_search == recent_search


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C590")
def test_no_recent_search_after_typing(driver, user, episode):
    """C590 There is no recent search after typing something in the search"""
    ep = episode

    login(driver, user.email, user.password)
    page = SearchPage(driver)
    search_item(driver, ep.title)
    page.click_on_first_search_result()
    page.click_on_hbo_logo_img()
    search_item(driver, "the")
    assert not is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(ep.title), ep.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C587")
def test_adults_content_not_searchable_in_kids_locked(driver, user,
                                                      episode):
    """C587 User cannot search adults content in Kids locked"""
    ep = episode

    login(driver, user.email, user.password)
    page = Kids(driver)
    page.click_on_kids_link()
    page.click_on_got_it_alert_button()
    page.click_on_lock_button()
    page = SearchPage(driver)
    search_item(driver, ep.title)
    assert not is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(ep.title), ep.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C587")
def test_kids_content_searchable_in_kids_locked(driver, user,
                                                kids_episode):
    """C587 User can search kids content in adults section"""
    # Arrange
    ke = kids_episode

    login(driver, user.email, user.password)
    page = Kids(driver)
    page.click_on_kids_link()
    page.click_on_got_it_alert_button()
    page.click_on_lock_button()
    page = SearchPage(driver)
    search_item(driver, ke.title)
    path = page.get_exact_search_result_item_path(ke.title)
    assert is_item_on_search_result(
        driver, path, ke.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C587")
def test_kids_content_searchable_in_kids_unlocked(driver, user,
                                                  kids_episode):
    """C587 User can search kids content in adults section"""
    # Arrange
    ke = kids_episode

    login(driver, user.email, user.password)
    page = Kids(driver)
    page.click_on_kids_link()
    page.click_on_got_it_alert_button()
    page = SearchPage(driver)
    search_item(driver, ke.title)
    assert is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(ke.title), ke.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C587")
def test_kids_content_searchable_in_adults(driver, kids_episode):
    """C587 User can search kids content in adults section"""
    ke = kids_episode
    page = SearchPage(driver)
    search_item(driver, ke.title)
    assert is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(ke.title), ke.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C585")
def test_search_tv_series_authenticated(driver, user, episode):
    """C585 Search finds tv-series for authenticated user"""
    ep = episode

    login(driver, user.email, user.password)
    page = SearchPage(driver)
    search_item(driver, ep.title)
    assert is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(ep.title), ep.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C588")
def test_search_result_opens_right_series_unauthenticated(driver, episode):
    """C588 User can interact - search result opens right series"""
    ep = episode
    search_item(driver, ep.title)
    open_first_search_result(driver)
    assert is_right_series_title_displayed(driver, ep.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C613")
def test_search_special_characters_unauthenticated(driver,
                                                   movie_special_characters):
    """C613 Search shows results with special characters"""
    msc = movie_special_characters
    page = SearchPage(driver)
    title_without_special_char = replace_special_characters(msc.title)
    search_item(driver, title_without_special_char)

    assert is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(msc.title), msc.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C588")
def test_search_result_is_interactable_unauthenticated(driver, movie):
    """C588 User can interact - hover searched results"""
    search_item(driver, movie.title)

    assert can_interact_with_first_search_result(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C588")
def test_search_result_is_openable_unauthenticated(driver, movie):
    """C588 User can interact - open searched result"""
    search_item(driver, movie.title)
    assert can_open_first_search_result(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C588")
def test_search_result_is_playable_unauthenticated(driver, movie):
    """C588 User can interact - play searched results"""
    search_item(driver, movie.title)
    assert can_play_first_search_result(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C586")
def test_search_is_performed_for_two_signs_unauthenticated(driver):
    """C586 Search is performed for 2 or more signs"""
    title = "12"
    search_item(driver, title)
    assert not is_search_waiting_for_input(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C586")
def test_no_search_performed_for_no_input_unauthenticated(driver):
    """C586 Search is not performed if there is no text input provided"""
    title = ""
    search_item(driver, title)
    assert is_search_waiting_for_input(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C586")
def test_no_search_performed_for_one_sign_unauthenticated(driver):
    """C586 Search is not performed if there is only one sign typed"""
    title = "1"
    search_item(driver, title)
    assert is_search_waiting_for_input(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C585")
def test_search_no_results_unauthenticated(driver):
    """C585 A message about no search results is displayed"""
    title = "Lorem ipsum"
    search_item(driver, title)
    assert is_no_search_result(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C585")
def test_search_movie_unauthenticated(driver, movie):
    """C585 Search finds movies for unauthenticated user"""
    page = SearchPage(driver)
    search_item(driver, movie.title)
    assert is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(movie.title),
        movie.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C585")
def test_search_movie_authenticated(driver, user, movie):
    """C585 Search finds movies for authenticated user"""
    login(driver, user.email, user.password)
    page = SearchPage(driver)
    search_item(driver, movie.title)
    assert is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(movie.title),
        movie.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C585")
def test_search_tv_series_unauthenticated(driver, episode):
    """C585 Search finds tv-series for unauthenticated user"""
    ep = episode
    page = SearchPage(driver)
    search_item(driver, ep.title)
    assert is_item_on_search_result(
        driver, page.get_exact_search_result_item_path(ep.title),
        ep.title)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C583")
def test_close_search_unauthenticated(driver):
    """C583 Closing search redirecting to the last page"""
    page = WhyHBO(driver)
    page.click_on_kids_link()  # any other then default subpage
    expected_url = page.helper.get_link(page.kids_link)
    page.click_on_search_button()

    page = SearchPage(driver)
    page.click_on_close_search_button()
    actual_url = driver.helper.get_url()
    assert expected_url == actual_url


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C583")
def test_search_field_shows_predefined_text_unauthenticated(driver):
    """C583 Searchbox show -search- predefined text"""
    page = WhyHBO(driver)
    page.click_on_search_button()

    page = SearchPage(driver)
    search_field_text = page.get_searchbox_text()
    assert search_field_text


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C583")
def test_search_is_available_unauthenticated(driver):
    """C583 Search button is available"""
    page = Home(driver)
    assert page.is_search_button_displayed()
