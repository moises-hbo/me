import pytest

from apps.hbonweb.pages.player_page import Player

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.search_flow import search_asset_open
from apps.hbonweb.flows.player_flow import switch_to_subtitle_lang, \
    get_language_of_playing_subtitle, sub_lang_to_lang

from apps.hbonshared.api_flow import set_bookmark

from apps.hbonshared.resourcesmanager import ResourcesManager as RM


@pytest.mark.env("preprod")
@pytest.mark.category("playback")
@pytest.mark.id("C611")
def test_subtitles_are_available(driver, user_playback, cc, movie):
    """ Subtitles and Dubbing
    Checks:
    #1 That options are seen only when hovering
    #2 That subtitle options are available
    #3 That the 'None' option is available
    #4 That options disappear when not hovering
    """
    set_bookmark(user_playback, movie, 3, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, movie)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    # 1
    assert not page.are_subtitle_options_displayed(0)

    # 2
    page.hover_over_tracks_button()
    assert page.are_subtitle_options_displayed()

    # 3
    none = RM.get_lang_text("subtitle_option_none")
    assert none in page.get_subtitle_text_options()

    # 4
    page.hover_over_video()
    assert not page.are_subtitle_options_displayed(0)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C611")
def test_selected_subtitle_option(driver, user_playback, cc, movie, tmp_path):
    """ Subtitles and Dubbing
    Checks:
    #1 That chosen subtitle option is selected
    #2 That chosen subtitle is what is seen
    """
    set_bookmark(user_playback, movie, 3, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, movie)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    def verify_subtitle(expected, scan_subs=True):
        page.hover_over_tracks_button()
        # 1
        assert page.get_text_of_selected_subtitle_option() == expected
        if scan_subs:
            # 2
            lang = sub_lang_to_lang(expected)
            assert get_language_of_playing_subtitle(
                driver, tmp_path, lang) == lang

    none = RM.get_lang_text("subtitle_option_none")
    verify_subtitle(none, False)

    page.hover_over_tracks_button()
    langs = page.get_subtitle_text_options()
    for l in langs[1:]:
        switch_to_subtitle_lang(driver, l)
        verify_subtitle(l)
