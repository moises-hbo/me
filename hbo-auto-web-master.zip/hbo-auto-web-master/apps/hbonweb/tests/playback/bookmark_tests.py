from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonweb.pages.player_page import Player
from apps.hbonweb.pages.kids_page import Kids

from apps.hbonweb.flows.search_flow import search_asset_open
from apps.hbonweb.flows.login_flow import login, logout

from apps.hbonshared.api_flow import get_bookmark
from apps.hbonshared.resourcesmanager import ResourcesManager as RM

from helpers.configmanager import ConfigManager
from helpers.drivermanager import DriverManager as DM

cm = ConfigManager()
heartbeat = 60


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C531012")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode"),
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie")
])
def test_refresh_browser_while_player_playing(driver, user_playback, cc,
                                              asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    def refresh_check_elapsed(continue_playing=True):
        elapsed = page.get_elapsed_in_seconds()
        driver.helper.refresh_page()
        sleep(10)
        page.wait_for_player_controls_to_disappear()

        new_elapsed = page.get_elapsed_in_seconds()
        assert new_elapsed <= elapsed
        assert new_elapsed > elapsed - heartbeat
        if continue_playing:
            page.click_on_viewport_play_button()
            sleep(heartbeat)

    refresh_check_elapsed()
    refresh_check_elapsed()
    refresh_check_elapsed(False)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C531013")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_refresh_browser_while_player_paused(driver, user_playback, cc, asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    def pause_refresh_check_elapsed(continue_playing=True):
        if not page.is_player_controls_displayed(0):
            page.make_player_controls_appear()
        page.click_on_pause_button()

        elapsed = page.get_elapsed_in_seconds()
        # Let bookmark get updated
        sleep(5)
        driver.helper.refresh_page()
        sleep(10)
        page.wait_for_player_controls_to_disappear()

        new_elapsed = page.get_elapsed_in_seconds()
        assert new_elapsed <= elapsed + 1
        if continue_playing:
            page.click_on_play_button()
            sleep(heartbeat)

    pause_refresh_check_elapsed()
    pause_refresh_check_elapsed()
    pause_refresh_check_elapsed(False)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C533528")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_navigate_out_while_player_playing(driver, user_playback, cc, asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    el1 = page.get_elapsed_in_seconds()
    assert el1 >= heartbeat

    # Back out
    page.click_on_back_button()

    # Re-search for asset
    page = search_asset_open(driver, asset)
    bookmark = get_bookmark(user_playback, asset, api=user_playback.api)
    assert el1 >= bookmark - 2

    # If kids series
    locked = Kids(driver).is_kids_mode_locked()
    sleep(10) if locked and asset.type == "series" \
        else page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    el2 = page.get_elapsed_in_seconds()
    assert el2 >= el1

    # Back out
    page.click_on_back_button()

    # Re-search for asset from home/kids
    driver.helper.go_to_url(cm.url)
    sleep(5)

    # If it's a kids asset
    page = Kids(driver)
    if page.is_kids_mode_locked():
        page.click_on_got_it_alert_button()

    page = search_asset_open(driver, asset)
    bookmark = get_bookmark(user_playback, asset, api=user_playback.api)
    assert el2 >= bookmark - 2

    # If kids series
    sleep(10) if locked and asset.type == "series" \
        else page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    el3 = page.get_elapsed_in_seconds()
    assert el3 >= el2


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C533532")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_navigate_out_while_player_paused(driver, user_playback, cc, asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    page.click_on_pause_button()
    el1 = page.get_elapsed_in_seconds()
    assert el1 >= heartbeat

    # Back out
    page.wait_for_player_controls_to_disappear()
    page.click_on_back_button()

    # Re-search for asset
    page = search_asset_open(driver, asset)
    bookmark = get_bookmark(user_playback, asset, api=user_playback.api)
    assert el1 >= bookmark - 2

    # If kids series
    locked = Kids(driver).is_kids_mode_locked()
    sleep(10) if locked and asset.type == "series" \
        else page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    page.click_on_pause_button()
    el2 = page.get_elapsed_in_seconds()
    assert el2 >= el1

    # Back out
    page.wait_for_player_controls_to_disappear()
    page.click_on_back_button()

    # Re-search for asset from home
    driver.helper.go_to_url(cm.url)
    sleep(5)

    page = Kids(driver)
    if page.is_kids_mode_locked():
        page.click_on_got_it_alert_button()

    page = search_asset_open(driver, asset)
    bookmark = get_bookmark(user_playback, asset, api=user_playback.api)
    assert el2 >= bookmark - 2

    # If kids series
    sleep(10) if locked and asset.type == "series" \
        else page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    el3 = page.get_elapsed_in_seconds()
    assert el3 >= el2


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C534515")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_logout_while_player_is_playing(driver, user_playback, cc, asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    el1 = page.get_elapsed_in_seconds()
    assert el1 > heartbeat

    page.click_on_back_button()

    page = Kids(driver)
    if page.is_kids_mode_locked():
        page.click_on_lock_button()

    logout(driver)
    bookmark = get_bookmark(user_playback, asset, api=user_playback.api)
    assert el1 >= bookmark - 2
    page = login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    page.wait_for_player_controls_to_disappear()

    el2 = page.get_elapsed_in_seconds()
    assert el2 >= el1


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C534521")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_logout_while_player_is_paused(driver, user_playback, cc, asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    page.click_on_pause_button()
    el1 = page.get_elapsed_in_seconds()
    assert el1 > heartbeat

    page.wait_for_player_controls_to_disappear()
    page.click_on_back_button()

    page = Kids(driver)
    if page.is_kids_mode_locked():
        page.click_on_lock_button()

    logout(driver)
    bookmark = get_bookmark(user_playback, asset, api=user_playback.api)
    assert el1 >= bookmark - 2
    page = login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    page.wait_for_player_controls_to_disappear()

    el2 = page.get_elapsed_in_seconds()
    assert el2 >= el1


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C1125")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_close_tab_while_player_is_playing(driver, user_playback, cc, asset):
    login(driver, user_playback.email, user_playback.password)

    # Open new tab and switch to it
    url = driver.helper.get_url()
    driver.helper.open_window(url)
    driver.helper.switch_to_window(1)
    sleep(5)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    el1 = page.get_elapsed_in_seconds()
    assert el1 > heartbeat

    # Close and switch back to old tab
    driver.helper.close_window()
    driver.helper.switch_to_window(0)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    el2 = page.get_elapsed_in_seconds()
    assert el2 > el1 - heartbeat


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C531010")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_close_tab_while_player_is_paused(driver, user_playback, cc, asset):
    login(driver, user_playback.email, user_playback.password)

    # Open new tab and switch to it
    url = driver.helper.get_url()
    driver.helper.open_window(url)
    driver.helper.switch_to_window(1)
    sleep(5)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    page.click_on_pause_button()

    el1 = page.get_elapsed_in_seconds()
    assert el1 > heartbeat

    # Close and switch back to old tab
    driver.helper.close_window()
    driver.helper.switch_to_window(0)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    el2 = page.get_elapsed_in_seconds()
    assert el2 > el1 - heartbeat


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C1125")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_close_browser_while_player_is_playing(driver, user_playback, cc,
                                               asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(heartbeat)

    el1 = page.get_elapsed_in_seconds()
    assert el1 > heartbeat

    # Kill browser
    driver.close()
    driver.quit()

    # Open new browser
    driver = DM.init_driver()

    # Re-login
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    el2 = page.get_elapsed_in_seconds()
    assert el2 > el1 - 60

    # Now we have to manually kill it
    driver.quit()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C531010")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_episode")
])
def test_close_browser_while_player_is_paused(driver, user_playback, cc,
                                              asset):
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    sleep(60)

    page.click_on_pause_button()

    el1 = page.get_elapsed_in_seconds()
    assert el1 > 60

    # Kill browser
    driver.close()
    driver.quit()

    # Open new browser
    driver = DM.init_driver()

    # Re-login
    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    el2 = page.get_elapsed_in_seconds()
    assert el2 > el1 - 60

    # Now we have to manually kill it
    driver.quit()
