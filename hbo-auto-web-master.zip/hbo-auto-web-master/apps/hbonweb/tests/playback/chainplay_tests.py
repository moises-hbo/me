from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonweb.pages.series_page import Series
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.player_page import Player

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.search_flow import search_series_open_episode
from apps.hbonshared.api_flow import set_bookmark, \
    get_asset_metadata, get_asset_duration

from apps.hbonshared.resourcesmanager import ResourcesManager as RM


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C522229")
def test_viewport_minimize_in_chainplay(driver, user_playback, cc,
                                        has_chainplay):
    cp = has_chainplay
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    playing_video_size = page.get_size_of_video()
    assert page.wait_for_chainplay_to_appear(200)

    assert page.get_text_of_title() == cp.title.upper()
    assert page.get_text_of_season().endswith(str(cp.season))
    assert page.get_text_of_episode().endswith(str(cp.episode))
    assert page.is_back_button_displayed()
    assert page.is_cp_continue_watching_button_displayed()

    sleep(2)
    cp_video_size = page.get_size_of_cp_cw_video()

    assert playing_video_size["width"] > cp_video_size["width"]
    assert playing_video_size["height"] > cp_video_size["height"]

    loc_cp_cw_video = page.get_location_of_cp_cw_video_window()
    assert page.get_location_of_back_button()["y"] < \
        loc_cp_cw_video["y"]
    assert page.get_location_of_season_text()["y"] < \
        loc_cp_cw_video["y"]
    assert page.get_location_of_episode_text()["y"] < \
        loc_cp_cw_video["y"]
    assert page.get_location_of_title_text()["y"] < \
        loc_cp_cw_video["y"]


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C536816")
@pytest.mark.parametrize("cp,nee", [
    (RM.get_special_asset("has_chainplay"),
     RM.get_special_asset("has_chainplay")),
    (RM.get_special_asset("kids_has_chainplay"),
     RM.get_special_asset("kids_has_chainplay"))
])
def test_series_next_ep_info(driver, user_playback, cc, cp, nee):
    nee.episode += 1
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    nee_meta = get_asset_metadata(user_playback, nee, api=user_playback.api)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    assert page.wait_for_chainplay_to_appear(200)

    assert page.get_text_of_cp_next_ep_title() == nee_meta["title"]
    next_ep_info = page.get_text_of_cp_next_ep_info()
    assert next_ep_info.startswith(f"{cp.title}:")
    assert f"{nee_meta['season']} / " in next_ep_info
    assert next_ep_info.endswith(f"{nee_meta['episodeInSeason']}")


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C522230")
@pytest.mark.parametrize("cp", [
    RM.get_special_asset("has_chainplay"),
    RM.get_special_asset("kids_has_chainplay")
])
def test_series_countdown_counts_down(driver, user_playback, cc, cp):
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    if cp.section == "kids":
        Kids(driver).click_on_lock_button()
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    assert page.wait_for_chainplay_to_appear()

    first = page.get_cp_cw_in_secs()
    sleep(1)
    second = page.get_cp_cw_in_secs()
    sleep(1)
    third = page.get_cp_cw_in_secs()
    assert first <= 15
    assert first > second > third


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C536820")
def test_transition_to_next_episode(driver, user_playback, cc):
    cp = RM.get_special_asset("has_chainplay")
    nep = RM.get_special_asset("has_chainplay")
    nep.episode += 1
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    assert page.wait_for_chainplay_to_appear()

    while page.get_cp_cw_in_secs(0) > 1:
        sleep(0.9)
    sleep(30)

    # New episode playing
    assert page.is_player_playing(wait=10, checks=3)

    nep_meta = get_asset_metadata(user_playback, nep)
    current_ep_nr = page.get_text_of_episode().split(" ")[1]
    assert current_ep_nr == nep_meta["episodeInSeason"]


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C536821")
@pytest.mark.parametrize("cp,nee", [
    (RM.get_special_asset("has_chainplay"),
     RM.get_special_asset("has_chainplay")),
    (RM.get_special_asset("kids_has_chainplay"),
     RM.get_special_asset("kids_has_chainplay"))
])
def test_ignore_next_episode_bookmark(driver, user_playback, cc, cp, nee):
    nee.episode += 1
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)
    nep_dur = get_asset_duration(user_playback, nee, api=user_playback.api)
    set_bookmark(user_playback, nee, int(nep_dur / 60 / 2),
                 api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    if cp.section == "kids":
        Kids(driver).click_on_lock_button()
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    assert page.wait_for_chainplay_to_appear()

    while page.get_cp_cw_in_secs(0) > 1:
        sleep(0.9)
    sleep(30)

    # Next episode
    assert page.is_player_playing(wait=10, checks=3)

    assert page.get_elapsed_in_seconds() < 60


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C522231")
@pytest.mark.parametrize("cp", [
    RM.get_special_asset("has_chainplay"),
    RM.get_special_asset("kids_has_chainplay")
])
def test_going_back_to_credits_on_chainplay(driver, user_playback, cc, cp):
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    if cp.section == "kids":
        Kids(driver).click_on_lock_button()
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    # After cuepoint triggered
    assert page.wait_for_chainplay_to_appear(200)

    assert page.is_cp_continue_watching_button_displayed()
    assert page.is_cp_countdown_displayed()

    while page.get_cp_cw_in_secs(0) >= 8:
        sleep(1)

    page.click_on_cp_continue_watching_button()
    assert not page.is_cp_countdown_displayed(1)

    # After credits ended
    assert page.wait_for_chainplay_to_appear()

    assert page.is_cp_continue_watching_button_displayed()
    assert page.is_cp_countdown_displayed()
    assert page.get_cp_cw_in_secs(0) > 10

    page.click_on_cp_continue_watching_button()

    # TODO: verify if this is correct behaviour
    page = Series(driver)
    assert page.is_play_button_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C536822")
@pytest.mark.parametrize("cp", [
    RM.get_special_asset("has_chainplay"),
    RM.get_special_asset("kids_has_chainplay")
])
def test_go_back_during_chainplay(driver, user_playback, cc, cp):
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    if cp.section == "kids":
        Kids(driver).click_on_lock_button()
    page.click_on_play_button()

    page = Player(driver)
    sleep(20)

    assert page.is_player_playing()
    assert page.wait_for_chainplay_to_appear()

    page.click_on_back_button()
    page = Series(driver)
    assert page.is_play_button_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C536823")
@pytest.mark.parametrize("cp", [
    RM.get_special_asset("has_chainplay"),
    RM.get_special_asset("kids_has_chainplay")
])
def test_start_next_episode_during_chainplay(driver, user_playback, cc, cp):
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    if cp.section == "kids":
        Kids(driver).click_on_lock_button()

    page.click_on_play_button()
    page = Player(driver)

    assert page.is_player_playing()
    assert page.wait_for_chainplay_to_appear()

    while page.get_cp_cw_in_secs() > 10:
        sleep(1)

    page.click_on_cp_play_next_ep_button()
    sleep(5)
    assert not page.is_cp_countdown_displayed(1)

    sleep(30)
    assert page.is_player_playing()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C536824")
@pytest.mark.parametrize("cp", [
    RM.get_special_asset("has_chainplay"),
    RM.get_special_asset("kids_has_chainplay")
])
def test_cuepoint_only_triggered_once(driver, user_playback, cc, cp):
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season,
                                      cp.ep_name)
    if cp.section == "kids":
        Kids(driver).click_on_lock_button()
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    # Await cuepoint
    assert page.wait_for_chainplay_to_appear()

    # Go back to stream
    page.click_on_cp_continue_watching_button()

    # Jump behind cuepoint
    e_p = page.get_elapsed_in_percent()
    page.click_on_progress_bar(percent=e_p - 7)

    assert page.is_player_playing(wait=10, checks=6)

    # Wait for elapsed time to pass cuepoint
    while page.get_elapsed_in_percent() < e_p:
        sleep(20)
    # Verify we're not seeing chainplay
    assert not page.is_chainplay_displayed(1)

    # Verify chainplay appears at end of stream
    assert page.wait_for_chainplay_to_appear()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id()
def test_clicking_several_times_on_play_next_ep_button(driver, user_playback,
                                                       cc, has_chainplay):
    cp = has_chainplay
    set_bookmark(user_playback, cp, 2, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, cp.title, cp.season, cp.ep_name)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    assert page.wait_for_chainplay_to_appear()

    # Click on play several times
    for _ in range(3):
        play_next = page.get_cp_play_next_button()
        if not play_next:
            break
        page.helper.click(play_next)
        sleep(0.1)

    # Verify we're not at series page
    page = Series(driver)
    assert not page.is_play_button_displayed(3)

    page = Player(driver)
    sleep(20)
    assert page.is_player_playing()
