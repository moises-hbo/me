import datetime
import pytest
from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.series_page import Series
from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.player_page import Player

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.search_flow import search_movie_open, \
    search_series_open_episode, search_asset_open
from apps.hbonweb.flows.asset_flow import get_asset_page
from apps.hbonshared.api_flow import get_asset_guid, set_bookmark, \
    get_asset_duration

from apps.hbonshared.resourcesmanager import ResourcesManager as RM

from helpers.configmanager import ConfigManager

cm = ConfigManager()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback", "deploy")
@pytest.mark.id("C522219")
def test_player_overview(driver, user_playback, cc, episode):
    # to force non-cached version // deploy
    dt = str(datetime.datetime.now()).replace(" ", "_")
    driver.helper.go_to_url(f"{cm.url}/{dt}")
    sleep(5)

    ep = episode

    login(driver, user_playback.email, user_playback.password)

    guid = get_asset_guid(user_playback, ep, api=user_playback.api)

    page = search_series_open_episode(driver, ep.title, ep.season, ep.ep_name)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()
    # Verify Header items displayed
    assert page.get_text_of_title() == ep.title.upper()
    assert page.get_text_of_season().endswith(str(ep.season))
    assert page.get_text_of_episode().endswith(str(ep.episode))
    assert page.is_back_button_displayed()

    # Verify Bottom items displayed
    assert page.is_pause_button_displayed()
    assert page.is_skip_back_button_displayed()
    assert page.is_skip_forward_button_displayed()
    assert page.is_subtitles_audio_button_displayed()
    assert page.is_volume_button_displayed()
    assert page.is_fullscreen_button_displayed()
    assert page.is_elapsed_time_displayed()
    assert page.is_duration_time_displayed()
    # Chromecast won't show when automating
    # assert page.is_chromecast_button_displayed(10)

    # Verify url
    assert driver.helper.get_url().endswith(guid + "/play")


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C533848")
def test_player_fade_in_out(driver, user_playback, cc, episode):
    ep = episode

    login(driver, user_playback.email, user_playback.password)

    page = search_series_open_episode(driver, ep.title, ep.season, ep.ep_name)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()
    # Let playback start
    assert page.is_player_playing(3, 3, 10)

    # Verify controls fade out
    assert page.wait_for_player_controls_to_disappear(20)

    # Verify controls fade in
    assert page.make_player_controls_appear()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C533527")
def test_player_exiting(driver, user_playback, cc, episode):
    ep = episode

    login(driver, user_playback.email, user_playback.password)

    def verify_playing_and_exit(browser_back=False):
        page = Player(driver)

        assert page.is_player_playing()

        # Exit by using the browser back
        if browser_back:
            driver.back()
        else:
            # Exit by clicking back in player
            page.click_on_back_button()

    page = search_series_open_episode(driver, ep.title, ep.season, ep.ep_name)

    url = driver.helper.get_url()
    # Open new tab / deeplinking with asset
    driver.helper.open_window(url)
    sleep(1)
    driver.helper.close_window()
    # Make new tab active
    driver.helper.switch_to_window(0)

    page = Series(driver)
    assert page.is_episode_play_button_displayed()
    sleep(10)
    page.click_on_play_button()

    # Playback from new tab, exit with back button
    verify_playing_and_exit()

    page = Series(driver)
    assert page.is_episode_play_button_displayed()
    sleep(10)

    # Go to original tab
    driver.helper.switch_to_window()
    page.click_on_play_button()

    # Playback from original tab, exit with back button
    verify_playing_and_exit()

    assert page.is_episode_play_button_displayed()
    sleep(10)

    page.click_on_play_button()

    # Playback from original tab, exit with browser back
    verify_playing_and_exit(True)

    assert page.is_episode_play_button_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C534355")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("last_episode"),
    RM.get_special_asset("kids_last_episode")
])
def test_player_close_on_asset_end(driver, user_playback, cc, asset):
    """
        Verify we end up back where we were before starting playback
        after it's done playing, with a series
    """
    set_bookmark(user_playback, asset, 3, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)

    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    page = get_asset_page(driver, asset)
    assert page.is_play_button_displayed(300)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C536826")
def test_player_play_pause(driver, user_playback, cc, movie):
    login(driver, user_playback.email, user_playback.password)

    search_movie_open(driver, movie.title)

    page = Movie(driver)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()

    assert page.is_pause_button_displayed()

    page.click_on_pause_button()
    assert page.is_play_button_displayed()
    assert page.is_viewport_play_button_displayed()
    assert not page.is_player_playing(3, 3, 2)

    page.click_on_play_button()
    assert page.is_pause_button_displayed()
    assert page.is_player_playing()

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()

    assert page.is_pause_button_displayed()

    page.click_on_pause_button()
    assert page.is_play_button_displayed()
    assert page.is_viewport_play_button_displayed()
    assert not page.is_player_playing(3, 3, 2)

    page.click_on_viewport_play_button()
    assert page.is_pause_button_displayed()
    assert page.is_player_playing()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C534517")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("episode")
])
def test_play_past_cuepoint(driver, user_playback, cc, asset):
    set_bookmark(user_playback, asset, 2, True, api=user_playback.api)
    duration = get_asset_duration(user_playback, asset, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_asset_open(driver, asset)

    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    assert page.get_elapsed_in_seconds() > duration - 200

    if asset.type == "series":
        assert page.wait_for_chainplay_to_appear()
    else:
        while page.is_player_playing():
            if page.get_elapsed_in_seconds() > duration - 75:
                break

    page.click_on_back_button()
    sleep(5)

    page = Series(driver) if asset.type == "series" else Movie(driver)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    assert page.get_elapsed_in_seconds() < 60


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C534512")
def test_player_progress_bar(driver, user_playback, cc, movie):
    login(driver, user_playback.email, user_playback.password)

    page = search_movie_open(driver, movie.title)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    elapsed_percent = page.get_elapsed_in_percent()
    duration_secs = page.get_duration_in_seconds()

    # Verify elapsed seconds is continually updated
    for _ in range(5):
        ts1 = page.get_elapsed_in_seconds()
        sleep(20)
        ts2 = page.get_elapsed_in_seconds()
        assert ts2 > ts1 + 10

    # Verify progress bar is moving
    new_elapsed_percent = page.get_elapsed_in_percent()
    assert new_elapsed_percent > elapsed_percent

    # Verify duration stays the same
    new_duration_secs = page.get_duration_in_seconds()
    assert new_duration_secs == duration_secs
    # Double check against what the API says
    api_duration = get_asset_duration(user_playback, movie,
                                      api=user_playback.api)
    assert new_duration_secs <= api_duration + 1
    assert new_duration_secs >= api_duration - 1

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()

    page.click_on_back_button()
    sleep(2)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C534516")
def test_player_bookmark_heartbeat(driver, user_playback, cc, movie):
    duration = get_asset_duration(user_playback, movie, api=user_playback.api)
    set_bookmark(user_playback, movie, int((duration / 60) / 2), True,
                 api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_movie_open(driver, movie.title)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    elapsed = page.get_elapsed_in_percent()
    assert elapsed >= 49 and elapsed <= 52

    while page.get_elapsed_in_percent() < 55:
        sleep(30)

    page.make_player_controls_appear()
    page.click_on_back_button()

    page = Movie(driver)
    sleep(5)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    elapsed = page.get_elapsed_in_percent()
    assert elapsed >= 54 and elapsed <= 58

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C534516")
def test_player_bookmark_after_pause(driver, user_playback, cc, movie):
    duration = get_asset_duration(user_playback, movie, api=user_playback.api)
    set_bookmark(user_playback, movie, int((duration / 60) / 2), True,
                 api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_movie_open(driver, movie.title)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    elapsed_percent = page.get_elapsed_in_percent()
    assert elapsed_percent >= 49 and elapsed_percent <= 52

    while page.get_elapsed_in_percent() < 55:
        sleep(30)

    page.make_player_controls_appear()
    page.click_on_pause_button()
    sleep(2)
    elapsed_seconds = page.get_elapsed_in_seconds()
    page.click_on_back_button()

    page = Movie(driver)
    sleep(5)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    elapsed_seconds_new = page.get_elapsed_in_seconds()
    assert elapsed_seconds_new > elapsed_seconds and \
        elapsed_seconds_new < elapsed_seconds + 30
    elapsed_percent = page.get_elapsed_in_percent()
    assert elapsed_percent >= 54 and elapsed_percent <= 58


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C533530")
def test_player_back_then_browser_back(driver, user_playback, cc, movie):
    login(driver, user_playback.email, user_playback.password)

    page = search_movie_open(driver, movie.title)

    url = page.get_link_of_play_button()
    # Open new tab / deeplinking with asset
    driver.helper.open_window(url)
    # Make new tab active
    driver.helper.switch_to_window(1)

    page = Player(driver)
    page.click_on_play_button()
    assert page.is_player_playing()

    assert driver.helper.get_url().endswith("/play")

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()

    page.click_on_back_button()
    sleep(2)
    assert not driver.helper.get_url().endswith("/play")

    driver.helper.go_back()
    sleep(2)
    assert driver.helper.get_url().endswith("/play")

    assert page.is_player_playing()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C512546")
def test_player_jump_forward_backward_10sec_buttons(driver, user_playback, cc,
                                                    movie):
    set_bookmark(user_playback, movie, 10, False, True, api=user_playback.api)

    login(driver, user_playback.email, user_playback.password)

    page = search_movie_open(driver, movie.title)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()

    # Skip forward 10 secs
    elapsed = page.get_elapsed_in_seconds()
    page.click_on_skip_forward_button()
    sleep(1)
    new_elapsed = page.get_elapsed_in_seconds()
    assert new_elapsed >= elapsed + 9 and \
        new_elapsed <= elapsed + 12

    page.wait_for_player_controls_to_disappear()
    page.make_player_controls_appear()

    # Skip backward 10 secs
    elapsed = page.get_elapsed_in_seconds()
    page.click_on_skip_back_button()
    sleep(1)
    new_elapsed = page.get_elapsed_in_seconds()
    assert new_elapsed <= elapsed - 9 and \
        new_elapsed >= elapsed - 12
