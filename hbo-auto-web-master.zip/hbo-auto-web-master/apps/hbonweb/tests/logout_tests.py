import pytest

from apps.hbonweb.pages.home_page import Home, WhyHBO
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.myaccount_page import MyAccount
from apps.hbonweb.pages.watchlist_page import Watchlist
from apps.hbonweb.pages.carousel_partial import Carousel

from apps.hbonweb.flows.login_flow import login


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C445")
def test_logout(driver, user):
    """C445: Navigate throughout menu items & verify successful logout

    https://hbo.testrail.com/index.php?/cases/view/445
    """
    page = login(driver, user.email, user.password)
    page.click_on_kids_link()

    page = Kids(driver)
    page.click_on_got_it_alert_button()
    page.click_on_watchlist_link()

    page = Watchlist(driver)
    page.click_on_home_logged_in_link()

    page = Home(driver)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_sign_out_link()

    page = WhyHBO(driver)
    assert page.is_sign_in_link_displayed()
    assert page.is_why_hbo_active_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id()
def test_carousel_exists_after_logout(driver, user):
    """
    Issue seen with Carousel disappearing after logout
    """
    page = login(driver, user.email, user.password)
    page.click_on_kids_link()

    page = Kids(driver)
    page.click_on_got_it_alert_button()
    page.click_on_watchlist_link()

    page = Watchlist(driver)
    page.click_on_home_logged_in_link()

    page = Home(driver)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_sign_out_link()

    page = WhyHBO(driver)
    assert page.is_sign_in_link_displayed()
    assert page.is_why_hbo_active_link_displayed()

    # Issue with carousel disappearing after logging out
    assert Carousel(driver).is_carousel_list_displayed()
