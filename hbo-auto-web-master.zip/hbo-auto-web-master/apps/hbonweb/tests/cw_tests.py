import pytest
from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.home_page import Home, WhyHBO
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.player_page import Player
from apps.hbonshared.api_flow import reset_bookmark

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.search_flow import search_asset_open

from apps.hbonshared.resourcesmanager import ResourcesManager as RM


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("sanity")
@pytest.mark.id()
def test_cw_exists_after_unauthed_nav(driver, user_playback):
    """ A bug-fix verification test to see if Continue Watching shelf is seen
        after logging in; after first having navigated around un-authed
    """
    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()
    assert not page.is_cw_shelf_displayed(1)
    page.click_on_home_logged_out_link()

    page = Home(driver)
    assert page.is_home_logged_out_active_link_displayed()
    assert not page.is_cw_shelf_displayed(1)
    page.click_on_kids_link()

    page = Kids(driver)
    assert page.is_kids_active_link_displayed()
    assert not page.is_cw_shelf_displayed(1)
    page.click_on_why_hbo_link()

    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()
    assert not page.is_cw_shelf_displayed(1)

    page = login(driver, user_playback.email, user_playback.password)
    assert page.is_cw_shelf_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("sanity")
@pytest.mark.id("C651")
def test_cw_exists_auth(driver, user_playback):
    """C651: Continue Watching shelf
    Checks:
    #1: That CW shelf is displayed and being top shelf, in Home
    #2: That CW shelf is NOT displayed in unlocked Kids
    #3: That CW shelf is displayed and being top shelf, in locked Kids
    """
    page = login(driver, user_playback.email, user_playback.password)

    # 1
    assert page.is_cw_shelf_displayed()
    assert page.is_cw_shelf_at_top()

    page.click_on_kids_link()
    page = Kids(driver)
    page.click_on_got_it_alert_button()

    # 2
    assert not page.is_cw_shelf_displayed()

    page.click_on_lock_button()

    # 3
    assert page.is_cw_shelf_displayed()
    assert page.is_cw_shelf_at_top()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("sanity")
@pytest.mark.id("C651")
def test_no_cw_unauth(driver):
    """C651: Continue Watching shelf
    Checks:
    #1: That Continue Watching shelf doesn't exist in Home & Kids
        when not logged in
    """
    page = WhyHBO(driver)
    page.click_on_home_logged_out_link()
    page = Home(driver)

    # 1
    assert not page.is_cw_shelf_displayed(1)
    page.click_on_kids_link()
    page = Kids(driver)
    assert not page.is_cw_shelf_displayed(1)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("playback")
@pytest.mark.id("C651")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("kids_episode")
])
def test_latest_played_newest_in_cw(driver, user_playback, asset):
    """C651: Continue Watching shelf
    Checks:
    #1: That last watched asset is newest item in Continue Watching shelf
    """
    reset_bookmark(
        user_playback, asset, api=user_playback.api)

    page = login(driver, user_playback.email, user_playback.password)
    page = search_asset_open(driver, asset, lock_kids=False)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing(checks=10)
    sleep(75)

    page.click_on_back_button()

    page = Movie(driver)
    page.click_on_home_logged_in_link()
    page = Home(driver)

    driver.helper.refresh_page(wait=5)

    # 1
    title = page.get_title_of_asset_in_shelf(0, 0)
    assert title.upper() == asset.title.upper()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C651")
def test_no_cw_for_unplayed_user(driver, user_no_cw):
    """C651: Continue Watching shelf
    Checks:
    #1: That CW shelf is not seen if a user hasn't played anything.
        Home, Kids unlocked/locked
    """
    page = login(driver, user_no_cw.email, user_no_cw.password)

    # 1
    assert not page.is_cw_shelf_displayed(1)
    page.click_on_kids_link()
    page = Kids(driver)
    page.click_on_got_it_alert_button()
    assert not page.is_cw_shelf_displayed(1)
    page.click_on_lock_button()
    assert not page.is_cw_shelf_displayed(1)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C651")
def test_hover_over_cw_item(driver, user_playback):
    """C651: Continue watching shelf
    Checks:
    #1: That items in CW shelf can be hovered over. Add to watchlist
        button will be visible
    """
    page = login(driver, user_playback.email, user_playback.password)

    assert page.is_cw_shelf_displayed()

    # 1
    for i in range(3):
        assert page.is_add_to_watchlist_displayed(0, i)
