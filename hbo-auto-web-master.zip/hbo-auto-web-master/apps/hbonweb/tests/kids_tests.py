from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonweb.pages.home_page import Home
from apps.hbonweb.pages.kids_page import Kids

from apps.hbonweb.flows.login_flow import login

from helpers.configmanager import ConfigManager

cm = ConfigManager()

@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C555")
def test_lock_hidden_icon_unauth(driver):
    """C555: Navigation & Lock Icon

    Verify that lock is hidden when entering Toonix/Kids
    as unauthenticated,
    """
    Home(driver).click_on_kids_link()
    page = Kids(driver)

    assert not page.is_kids_lock_button_displayed(timeout=2)
    assert page.is_home_logged_out_link_displayed()
    assert page.is_why_hbo_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C555")
def test_lock_showing_icon_auth(driver, user):
    """C555: Navigation & Lock Icon

    Verify lock icon is showing when entering Toonix/Kids
    as authenticaed
    """
    login(driver, user.email, user.password)
    Home(driver).click_on_kids_link()

    page = Kids(driver)
    page.click_on_got_it_alert_button()
    assert page.is_kids_lock_button_displayed()
    assert page.is_home_logged_in_link_displayed()
    assert page.is_watchlist_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C555")
@pytest.mark.driver_profile("mobile_web")
def test_lock_hidden_icon_auth_mobile_web(driver, user):
    """C555: Navigation & Lock Icon

    Verify lock icon is hidden when entering
    for mobile web user
    """
    # Cookie banner is no longer displayed in mobile web (apparently)
    # CookieBanner(driver).click_on_accept_button()
    page = Home(driver)
    page.helper.wait_until_clickable(page.sign_in_link)
    sleep(1)

    login(driver, user.email, user.password, is_mobile_web=True)

    page.click_on_kids_link(timeout=20)
    page = Kids(driver)

    assert not page.is_kids_lock_button_displayed(timeout=5)
    assert page.is_home_logged_in_link_displayed()
    assert page.is_watchlist_link_displayed()
