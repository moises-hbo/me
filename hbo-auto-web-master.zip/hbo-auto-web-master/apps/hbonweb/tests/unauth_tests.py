import pytest

from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.signup_page import SignUp
from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.series_page import Series
from apps.hbonweb.pages.watchlist_page import Watchlist
from apps.hbonweb.pages.player_page import Player
from apps.hbonweb.pages.startwatchingnow_page import StartWatchingNow
from apps.hbonweb.pages.howtowatch_page import HowToWatch
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner
from apps.hbonweb.pages.loginform_page import LoginForm

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.search_flow import search_item, \
    open_first_search_result, search_movie_open, search_asset_open
from apps.hbonweb.flows.signup_flow import do_complete_registration

from apps.hbonshared.resourcesmanager import ResourcesManager as RM

from helpers.configmanager import ConfigManager

cm = ConfigManager()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C467")
def test_landing_pages(driver, user):
    """ Landing pages
    Checks:
    #1: Why HBO page by default when unauthed, menu link is active
    #2: Home page by default when logged in, menu link is active
    """
    CookieBanner(driver).click_on_accept_button()

    # 1
    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()

    # 2
    page: Home = login(driver, user.email, user.password)
    assert page.is_home_logged_in_active_link_displayed()
    assert not page.is_why_hbo_link_displayed(timeout=1)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C469")
def test_carousel(driver):
    """ Carousel
    Checks:
    #1: Why HBO page by default
    #2: Carousel exists, with first item holding Start Free trial button
    #3: Clicking on start free trial button directs you to signup page
    """
    CookieBanner(driver).click_on_accept_button()

    # 1
    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()

    # 2
    assert page.is_carousel_list_displayed()
    assert page.get_carousel_start_free_trial_button()
    assert page.get_carousel_start_free_trial_button_from_first_item()

    # 3
    page.click_on_carousel_start_free_trial_button()
    page = SignUp(driver)
    assert page.is_signup_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C470")
def test_benefits(driver):
    """ Benefits section
    Checks:
    #1: USPS, description, CTA button displayed on product box
    #2: Resizing window to smaller portrait will change UI accordingly
    #3: Clicking on product box start free trial directs you to Signup page
    """
    CookieBanner(driver).click_on_accept_button()

    page = WhyHBO(driver)
    page.scroll_to_product_box()

    # 1
    assert page.is_pb_header_intro_displayed()
    assert page.is_product_box_displayed()
    assert page.is_pb_description_displayed()
    assert len(page.get_bullet_points_list()) >= 1
    assert page.is_pb_free_trial_button_displayed()

    curr_size = driver.helper.get_window_size()

    # 2
    loc_desc = page.get_location_of_description()
    loc_first_bp = page.get_locations_of_bullet_points()[0]
    # description and first bullet point are at same height
    assert loc_desc["y"] == loc_first_bp["y"]

    driver.helper.resize_window(400, 800)
    loc_desc = page.get_location_of_description()
    loc_first_bp = page.get_locations_of_bullet_points()[0]
    # description above first bullet point when in portrait mode
    assert loc_desc["y"] > loc_first_bp["y"]

    driver.helper.resize_window(curr_size["width"], curr_size["height"])

    # 3
    page.click_on_pb_free_trial_button()
    page = SignUp(driver)
    assert page.is_signup_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C471")
def test_trailer(driver):
    """ Trailer section
    Checks:
    #1: Trailer is below product box
    #2: trailer's a big image, with a play button
    #3: clicking play button opens trailer modal, with trailer,
        and product box description, start free trial button
    #4: Clicking start free trial button directs you to Signup page
    #5: Re-do same with mobile-sized window
    """
    CookieBanner(driver).click_on_accept_button()

    def check_trailer():
        page = WhyHBO(driver)

        # 1
        pb_loc = page.get_location_of_product_box()
        trailer_loc = page.get_location_of_trailer_frame()
        assert pb_loc["y"] < trailer_loc["y"]

        # 2
        page.scroll_to_trailer()
        assert page.is_trailer_image_displayed()
        assert page.is_trailer_play_button_displayed(scroll=False)

        # 3
        page.click_on_trailer_play_button()
        assert page.is_trailer_modal_pb_description_displayed()
        assert page.is_trailer_modal_pb_start_free_trial_button_displayed()

        # 4
        page.click_on_trailer_modal_pb_start_free_trial_button()
        page = SignUp(driver)
        assert page.is_signup_page()

        driver.helper.go_back()

    check_trailer()

    # 5
    driver.helper.resize_window(400, 800)
    check_trailer()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C472")
def test_devices(driver):
    """ Devices section
    Checks:
    #1: List of supported devices/platforms are seen
    #2: Clicking on the devices directs you to HowToWatch with
        chosen device selected
    #3: Same for mobile sized view
    """
    CookieBanner(driver).click_on_accept_button()

    page = WhyHBO(driver)

    # 1
    page.scroll_to_devices()
    devices_list = page.get_devices_list()
    assert len(devices_list) >= 6

    def check_devices():
        for i in range(len(devices_list)):
            page = WhyHBO(driver)

            d_name = page.get_text_of_device_name(i)
            page.click_on_device(i)

            page = HowToWatch(driver)
            assert page.is_device_active(i)

            htw_name = page.get_text_of_device_name(i)
            assert d_name == htw_name
            assert page.is_device_description_displayed()

            driver.helper.go_back()

    # 2
    check_devices()

    # 3
    driver.helper.resize_window(400, 800)
    page.scroll_to_devices()
    check_devices()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C475")
def test_signup_button_at_top_and_bottom(driver):
    """ Top & Footer Navigation
    Checks:
    #1: That Sign In link and Start Free Trial are available at top menu,
        and Get Started/Order in footer
    #2: Clicking on Start free trial in top menu directs you to signup
    #3: Clicking on start free trial in footer menu directs you to signup
    """
    CookieBanner(driver).click_on_accept_button()

    page = WhyHBO(driver)

    # 1
    assert page.is_sign_in_link_displayed()
    assert page.is_free_trial_button_displayed()
    assert page.is_footer_start_free_trial_button_displayed()

    # 2
    page.click_on_free_trial_button()
    page = SignUp(driver)
    assert page.is_signup_page()

    driver.helper.go_back()
    page = WhyHBO(driver)

    # 3
    driver.helper.scroll_to_bottom()
    page.click_on_footer_start_free_trial_button()

    page = SignUp(driver)
    assert page.is_signup_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C476")
@pytest.mark.skipif(
    cm.driver_name == "chrome", reason="Chrome can't be resized small enough")
def test_signup_button_at_top_and_bottom_mobile(driver, movie, episode):
    """ Mobile web - Top & Footer Navigation
    Checks:
    #1: Regular top/bottom start free trial buttons replaced with
        one static at bottom
    #2: Free trial button sticks as we go down on page
    #3: same free trial can be seen, and stays static, on different pages.
        On pretty much all non-signup/signin pages
    """
    CookieBanner(driver).click_on_accept_button()

    driver.helper.resize_window(400, 800)
    page = WhyHBO(driver)

    # 1
    assert page.is_mobile_free_trial_button_displayed()
    assert not page.is_free_trial_button_displayed(0)
    assert not page.is_footer_start_free_trial_button_displayed(0)

    # Since it follows page, y position will heighten as we scroll down
    def check_scroll(page):
        loc1 = page.get_location_of_mobile_free_trial_button()

        driver.helper.scroll(y=200)
        loc2 = page.get_location_of_mobile_free_trial_button()

        driver.helper.scroll(y=400)
        loc3 = page.get_location_of_mobile_free_trial_button()

        assert loc3["y"] > loc2["y"] > loc1["y"]
        driver.helper.scroll_to_top()

    # 2
    check_scroll(page)

    # 3
    # Trailer
    page.click_on_trailer_play_button()
    assert page.is_mobile_free_trial_button_displayed()
    # No scroll
    page.click_on_trailer_modal_close_button()
    driver.helper.scroll_to_top()

    # Home
    page.click_on_home_logged_out_link()
    page = Home(driver)
    assert page.is_mobile_free_trial_button_displayed()
    check_scroll(page)

    # Kids
    page = page.click_on_kids_link()
    page = Kids(driver)
    assert page.is_mobile_free_trial_button_displayed()
    check_scroll(page)

    search_item(driver, movie.title)
    open_first_search_result(driver)

    # Movie
    page = Movie(driver)
    assert page.is_mobile_free_trial_button_displayed()
    check_scroll(page)

    search_item(driver, episode.title)
    open_first_search_result(driver)

    # Series
    page = Series(driver)
    assert page.is_mobile_free_trial_button_displayed()
    check_scroll(page)

    # Season
    page.click_on_mobile_season_dropdown()
    page.click_on_mobile_season_option(episode.season)
    assert page.is_mobile_free_trial_button_displayed()
    check_scroll(page)

    # Episode
    page.click_on_mobile_episode(episode.ep_name)
    assert page.is_mobile_free_trial_button_displayed()
    check_scroll(page)

    # Start Watching Now
    page.click_on_play_button()
    page = StartWatchingNow(driver)
    assert page.is_mobile_free_trial_button_displayed()
    # No scrolling


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C478")
def test_startwatching_view(driver, movie):
    """ Start Watching View
    Checks:
    #1: Attempting to play movie unauthed opens StartWatchingNow view
    #2: Check the StartWatchingNow view and its items
    #3: Clicking close button returns to movie view
    """
    CookieBanner(driver).click_on_accept_button()

    page = search_movie_open(driver, movie.title)

    # 1
    page.click_on_play_button()
    page = StartWatchingNow(driver)
    assert page.is_start_watching_header_displayed()

    # 2
    assert page.is_product_box_displayed()
    assert page.is_free_trial_button_displayed()
    assert page.is_have_account_text_displayed()
    assert page.is_sign_in_button_displayed()
    assert page.is_close_button_displayed()

    # 3
    page.click_on_close_button()
    page = Movie(driver)
    assert page.is_asset_title_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("signup", "subscription")
@pytest.mark.id("C478")
def test_signup_through_startwatchingnow(driver, movie, user_tmp, cc):
    """ Start Watching View
    Checks:
    #1: Attempting to add to watchlist opens StartWatchingNow view
    #2: Click on Free trial/CTA button and perform a full account creation
        with subcription
    #3: Go to watchlist and see that asset was added
    """
    CookieBanner(driver).click_on_accept_button()

    page = search_movie_open(driver, movie.title)

    # 1
    page.click_on_add_to_watchlist_button()
    page = StartWatchingNow(driver)
    assert page.is_start_watching_header_displayed()

    # 2
    page.click_on_free_trial_button()
    page = do_complete_registration(driver, user_tmp, cc,
                                    accept_getstarted=False)

    # 3
    page.click_on_watchlist_link()
    page = Watchlist(driver)
    assert page.is_watchlist_results_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("playback")
@pytest.mark.id("C478")
def test_signin_through_startwatchingnow(driver, user_playback, movie):
    """ Start Watching View
    Checks:
    #1: Attempting to play asset opens StartWatchingNow view
    #2: Click on sign in and do valid login
    #3: Playback should start directly after login
    """
    user = user_playback
    CookieBanner(driver).click_on_accept_button()

    page = search_movie_open(driver, movie.title)

    # 1
    page.click_on_play_button()
    page = StartWatchingNow(driver)
    assert page.is_start_watching_header_displayed()

    # 2
    page.click_on_sign_in_button()
    login(driver, user.email, user.password, go_to_login=False)

    # 3
    page = Player(driver)
    assert page.is_player_playing(checks=3)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C4649121")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("episode"), RM.get_special_asset("movie")
    ])
def test_mobile_signin_view_through_startwatchingnow(driver, asset):
    """  Mobile Web - Start Watching View
    Checks:
    #1: in mobile, adding to watchlist opens StartWatchingNow view
    #2: Clicking on sign in directs you to login view
    """
    CookieBanner(driver).click_on_accept_button()

    page = search_asset_open(driver, asset)

    driver.helper.resize_window(400, 800)

    # 1
    page.scroll_to_add_to_watchlist_button()
    page.click_on_add_to_watchlist_button(hover=False)
    page = StartWatchingNow(driver)
    assert page.is_start_watching_header_displayed()

    # 2
    page.click_on_sign_in_button()
    page = LoginForm(driver)
    assert page.is_sign_in_header_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C4649121")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("episode"), RM.get_special_asset("movie")
    ])
def test_mobile_signup_view_through_startwatchingnow(driver, asset):
    """  Mobile Web - Start Watching View
    Checks:
    #1: In mobile, adding to watchlist opens StartWatchingNow view
    #2: Clicking on signup directs you to signup view
    """
    CookieBanner(driver).click_on_accept_button()

    page = search_asset_open(driver, asset)

    driver.helper.resize_window(400, 800)

    # 1
    page.scroll_to_add_to_watchlist_button()
    page.click_on_add_to_watchlist_button(hover=False)
    page = StartWatchingNow(driver)
    assert page.is_start_watching_header_displayed()

    # 2
    page.click_on_free_trial_button()
    page = SignUp(driver)
    assert page.is_signup_page()
