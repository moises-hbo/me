from helpers.sleeper import Sleeper as sleep
import pytest
from helpers.configmanager import ConfigManager
from helpers.enums import Region, Language, Country

from apps.hbonweb.pages.home_page import Home
from apps.hbonweb.pages.geoblock_page import InsideEU
from apps.hbonweb.pages.contact_page import Contact

from apps.hbonweb.flows.login_flow import login

from apps.hbonshared.resourcesmanager import ResourcesManager


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C97522")
def test_geoblock_page(driver):
    # Arrange
    CM = ConfigManager()
    RM = ResourcesManager()
    message = "As an HBO subscriber you may log in to get access to all of " \
        "your favorite series and movies in the EU. Signing up for an HBO " \
        "subscription is not allowed from your current location."
    region = Region.ESPANA if RM.get_region() \
        == Region.NORDIC else Region.NORDIC
    user = RM.get_user(country=Country.ES) if region == \
        Region.ESPANA else RM.get_user(country=Country.SE)
    url = RM.get_url(env=CM.environment, region=region, lang=Language.EN)

    driver.get(url)

    # Geoblock page
    page = InsideEU(driver)
    # Check against Espana or Nordic logo
    assert page.get_hbo_logo_region() == region
    assert page.get_text_of_hbo_subscriber_within_eu_message() == message

    # Go to contact page
    page.click_on_contact_link()
    page = Contact(driver)
    assert page.get_text_of_contact_header() == "Contact"

    # Back to geoblock login
    driver.helper.go_back()
    sleep(2)

    # Sign in
    login(driver, user.email, user.password, from_page=InsideEU)

    assert Home(driver).is_my_account_link_displayed()
