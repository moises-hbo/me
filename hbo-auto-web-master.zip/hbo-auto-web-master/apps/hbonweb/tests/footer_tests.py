import pytest
from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.home_page import WhyHBO
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner

from helpers.configmanager import ConfigManager


cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C362")
def test_open_not_choose_language_in_picker(driver, languages):
    """ Checks:
    #1: That language options not visible by default
    #2: Are shown when we click on language picker
    #3: That language/country stays same when we click outside language picker
    #4: That language options once again not visible
    """
    page = CookieBanner(driver)
    page.click_on_accept_button()
    page = WhyHBO(driver)
    assert page.is_loaded()

    driver.helper.scroll_to_bottom()

    # 1
    for opt in page.get_language_options():
        assert not page.helper.is_visible(opt, 0)

    # 2
    page.click_on_language_button()
    for opt in page.get_language_options():
        assert page.helper.is_visible(opt, 0)

    # 3
    lang_btn = page.get_language_button()
    driver.helper.move_mouse_to_and_about(lang_btn, -50, 0)
    driver.helper.click_on_screen()

    active = page.get_text_of_active_language_option()
    url = driver.helper.get_url()
    country_code = url[url.find("//") + 2:url.find("//") + 4]
    assert languages[country_code] == active

    # 4
    for opt in page.get_language_options():
        assert not page.helper.is_visible(opt, 0)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C362")
def test_not_wrong_region_languages_available_from_picker(driver,
                                                          languages_all):
    """ Checks:
    #1: Verifies correct options for correct region exists
    #2: Verifies the wrong regions' options doesn't exist
    """
    wrong_region = "nordic" if cm.region == "spain" else "spain"

    page = CookieBanner(driver)
    page.click_on_accept_button()
    page = WhyHBO(driver)
    assert page.is_loaded()

    driver.helper.scroll_to_bottom()
    page.click_on_language_button()

    lang_options = page.get_text_of_language_options()
    # 1
    for l in languages_all[cm.region].values():
        assert l in lang_options
    # 2
    del languages_all[wrong_region]["en"]  # Exists in both
    for l in languages_all[wrong_region].values():
        assert l not in lang_options


@pytest.mark.env("prod", "preprod")
@pytest.mark.category()
@pytest.mark.id("C362")
def test_change_language_using_picker_unauth(driver, languages):
    """ Checks:
    #1: That active language in picker corresponds to country code in URL
    """
    page = CookieBanner(driver)
    page.click_on_accept_button()
    page = WhyHBO(driver)

    for nr in range(len(page.get_language_options())):
        driver.helper.scroll_to_bottom()
        sleep(1)

        # 1
        url = driver.helper.get_url()
        country_code = url[url.find("//") + 2:url.find("//") + 4]
        lang = page.get_text_of_active_language_option()
        assert languages[country_code] == lang

        page.click_on_language_button()
        page.select_language_nr(nr)
        sleep(1)
