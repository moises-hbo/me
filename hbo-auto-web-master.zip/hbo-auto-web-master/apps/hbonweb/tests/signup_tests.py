import pytest

from selenium.webdriver.common.keys import Keys

from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.signup_page import SignUp, Voucher, GetStarted
from apps.hbonweb.pages.payment_page import PaymentDetails, WithDrawalRight
from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter, \
    MoreInfoFooter
from apps.hbonweb.pages.data_policy_page import DataPolicy
from apps.hbonweb.pages.termsconditions_page import TermsAndConditions

from apps.hbonweb.flows.signup_flow import is_signup_field_labels_visible, \
    enter_signup_info_and_continue, register_user_and_go_to_myaccount

from apps.hbonshared.resourcesmanager import ResourcesManager as RM

from helpers.sleeper import Sleeper as sleep


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C449")
def test_reduced_navigation_and_footer(driver):
    """C449: Navigation and Footer is reduced in sign up

    https://hbo.testrail.net/index.php?/cases/view/449
    """
    WhyHBO(driver).click_on_free_trial_button()
    nav = Navigation(driver)  # SignUp inherits reduced. check against the full

    # Nav should exist
    assert nav.is_hbo_logo_img_displayed()
    assert nav.is_sign_in_link_displayed()
    # Nav shouldn't exist
    assert not nav.is_why_hbo_link_displayed(timeout=0)
    assert not nav.is_home_logged_out_link_displayed(timeout=0)
    assert not nav.is_kids_link_displayed(timeout=0)
    assert not nav.is_free_trial_button_displayed(timeout=0)
    assert not nav.is_search_button_displayed(timeout=0)

    driver.helper.scroll()  # back to top
    # Footer should exist
    cl_footer = CopyrightLanguageFooter(driver)
    assert cl_footer.is_copyright_text_displayed()
    assert cl_footer.is_language_button_displayed()
    # Footer shouldn't exist
    mi_footer = MoreInfoFooter(driver)
    assert not mi_footer.is_how_to_watch_link_displayed(timeout=0)
    assert not mi_footer.is_about_link_displayed(timeout=0)
    assert not mi_footer.is_faq_link_displayed(timeout=0)
    assert not mi_footer.is_contact_link_displayed(timeout=0)
    assert not mi_footer.is_press_link_displayed(timeout=0)
    assert not mi_footer.is_terms_and_conditions_link_displayed(timeout=0)
    assert not mi_footer.is_data_policy_link_displayed(timeout=0)
    assert not mi_footer.is_footer_start_free_trial_button_displayed(timeout=0)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C449")
def test_exit_signup(driver):
    """C449: Exit signup by clicking HBO logo and/or use
    the back functionality on browser.

    https://hbo.testrail.net/index.php?/cases/view/449
    """
    page = WhyHBO(driver)
    original_url = driver.helper.get_url()
    page.click_on_free_trial_button()

    # Clicking on HBO Logo
    page = SignUp(driver)
    signup_url = driver.helper.get_url()
    page.click_on_hbo_logo_img()
    page = WhyHBO(driver)
    assert not original_url == signup_url
    assert original_url == driver.helper.get_url()

    # Using back button in browser
    page.click_on_free_trial_button()
    page = SignUp(driver)
    signup_url = driver.helper.get_url()
    driver.back()

    assert not original_url == signup_url
    assert original_url == driver.helper.get_url()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C450")
def test_fields_labels(driver):
    """C450: Field interaction in Create account view
    Look for labels identifying fields

    https://hbo.testrail.net/index.php?/cases/view/450
    """
    WhyHBO(driver).click_on_free_trial_button()
    assert is_signup_field_labels_visible(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C450")
def test_password_field_masked_and_show(driver):
    """C450: Field interaction in Create account view
    looking at masked/unmasked password field

    https://hbo.testrail.net/index.php?/cases/view/450
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)
    page.input_text_on_password_field("TestingMaskedAndCleartext")
    assert page.is_password_field_masked()

    page.click_on_password_show_toggle()
    assert page.is_password_field_cleartext()

    page.click_on_password_show_toggle()
    assert page.is_password_field_masked()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C450")
def test_tab_and_text_input(driver, user_tmp):
    """C450: Field interaction in Create account view
    Tabs between fields and check text input as well as clearing

    https://hbo.testrail.net/index.php?/cases/view/450
    """
    from selenium.webdriver.common.keys import Keys

    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)

    page.click_on_email_field()
    driver.helper.press_keys(user_tmp.email)
    assert page.helper.get_attribute(page.email_field, "value") == \
        user_tmp.email
    driver.helper.hold_down_keys(Keys.BACKSPACE, 6)
    assert not page.helper.get_attribute(page.email_field, "value")

    driver.helper.press_keys(Keys.TAB)  # Password
    driver.helper.press_keys(user_tmp.password)
    assert page.helper.get_attribute(
        page.password_field, "value") == user_tmp.password
    driver.helper.hold_down_keys(Keys.BACKSPACE, 3)
    assert not page.helper.get_attribute(page.password_field, "value")


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C452")
def test_no_news_and_terms_checkboxes(driver):
    """C452: verify appearance and functionality of news offers and terms
    checkboxes. Look that news is on by default
    Terms is off by default. Should correctly switch when pressed on.

    Step 1 & 2
    https://hbo.testrail.net/index.php?/cases/view/452
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)

    assert page.is_no_news_offers_checkbox_displayed()
    # News is unchecked my default
    assert not page.is_no_news_offers_checkbox_active()
    page.click_on_no_news_offers_checkbox()
    assert page.is_no_news_offers_checkbox_active()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C452")
def test_terms_and_data_policy_links(driver):
    """C452: verify appearance of Terms and Policy links
    Checks that they're links and link to correct location/view

    Step 3
    https://hbo.testrail.net/index.php?/cases/view/452
    """
    WhyHBO(driver).click_on_free_trial_button()
    sleep(1)
    page = SignUp(driver)

    terms_link = page.helper.get_link(page.terms_and_conditions_link)
    page.click_on_terms_and_conditions_link()
    # Switch to terms tab
    driver.switch_to.window(driver.window_handles[1])

    assert driver.helper.get_url() == terms_link
    driver.back()
    # Switch tab back
    driver.switch_to.window(driver.window_handles[0])

    # TODO: find something specific & cross-language to
    # terms view to make sure we're at the correct page

    data_policy_link = page.helper.get_link(page.data_policy_link)
    page.click_on_data_policy_link()
    # Switch to policy tab
    driver.switch_to.window(driver.window_handles[2])

    assert driver.helper.get_url() == data_policy_link
    # TODO: find something specific & cross-language to policy view
    # to make sure we're at the correct page


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C453")
def test_empty_fields(driver):
    """C453: Continue empty field give warnings when we
    try to continue without providing info.

    Step 1 & 5
    https://hbo.testrail.net/index.php?/cases/view/453
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)
    page.click_on_continue_button()

    assert page.is_email_warning_displayed()
    assert page.is_password_warning_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C453")
def test_invalid_email(driver):
    """C453: Enter invalid email during signup and receive warning

    Step 2
    https://hbo.testrail.net/index.php?/cases/view/453
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)
    page.click_on_continue_button()

    email_empty_warning = page.helper.get_text(page.email_warning_text)
    page.input_text_on_email_field("BHUU$$")
    page.click_on_continue_button()
    email_invalid_warning = page.helper.get_text(page.email_warning_text)

    assert not email_empty_warning == email_invalid_warning


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C453")
def test_too_short_password(driver):
    """C453: Enter too short a password and receive a relevant
    warning mentioning this

    Step 3
    https://hbo.testrail.net/index.php?/cases/view/453
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)
    page.click_on_continue_button()

    password_empty_warning = page.helper.get_text(page.password_warning_text)
    page.input_text_on_password_field("12")
    page.click_on_continue_button()
    password_too_short_warning = page.helper.get_text(
        page.password_warning_text)

    assert not password_empty_warning == password_too_short_warning


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C453")
def test_invalid_voucher(driver):
    """C453: Enter an invalid voucher code and receive warning

    Step 6
    https://hbo.testrail.net/index.php?/cases/view/453
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)

    page.click_on_add_voucher_button()
    page = Voucher(driver)
    page.input_text_on_voucher_field("safa sgsd sdv")

    assert page.is_voucher_code_warning_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C455")
def test_email_already_in_use(driver, user):
    """C455: Get an error message when we try signup with an existing email"""
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)
    enter_signup_info_and_continue(
        driver, user.email, user.password)

    assert page.is_error_alert_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C456")
def test_valid_signup_no_newsletter_on(driver, user_tmp):
    """C456 Saving the newsletter preferences
    with newsletter set"""
    page = register_user_and_go_to_myaccount(
        driver, user_tmp.email, user_tmp.password, no_news_offers=True)
    assert page.is_newsletter_checkbox_active()

    api = RM.get_api(user_tmp.email, user_tmp.password)
    assert not api.get_settings().get("newsletter")

    page.click_on_newsletter_button()
    sleep(2)
    assert api.get_settings().get("newsletter") == "true"

    page.click_on_newsletter_button()
    sleep(2)
    assert api.get_settings().get("newsletter") == "false"


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C456")
def test_valid_signup_no_newsletter_off(driver, user_tmp):
    """C456 Saving the newsletter preferences
    with newsletter unset"""
    page = register_user_and_go_to_myaccount(
        driver, user_tmp.email, user_tmp.password, no_news_offers=False)
    assert not page.is_newsletter_checkbox_active()

    api = RM.get_api(user_tmp.email, user_tmp.password)
    # There's no 'newsletter' if we never set it
    assert api.get_settings().get("newsletter") == "true"


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C458")
def test_navigation_in_payment_details(driver, user_tmp):
    WhyHBO(driver).click_on_free_trial_button()
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)

    # Expected menu element
    assert page.is_hbo_logo_img_displayed()

    page = CopyrightLanguageFooter(driver)
    # Expected footer elements
    assert page.is_copyright_text_displayed()
    assert page.is_language_button_displayed()

    page = Navigation(driver)
    # Not expected menu elements
    assert not page.is_why_hbo_link_displayed(timeout=1)
    assert not page.is_home_logged_out_link_displayed(timeout=1)
    assert not page.is_home_logged_in_link_displayed(timeout=1)
    assert not page.is_kids_link_displayed(timeout=1)
    assert not page.is_watchlist_link_displayed(timeout=1)
    assert not page.is_my_account_link_displayed(timeout=1)
    assert not page.is_search_button_displayed(timeout=1)

    page = MoreInfoFooter(driver)
    # Not expected footer elements
    assert not page.is_how_to_watch_link_displayed(timeout=1)
    assert not page.is_about_link_displayed(timeout=1)
    assert not page.is_faq_link_displayed(timeout=1)
    assert not page.is_contact_link_displayed(timeout=1)
    assert not page.is_press_link_displayed(timeout=1)
    assert not page.is_terms_and_conditions_link_displayed(timeout=1)
    assert not page.is_data_policy_link_displayed(timeout=1)
    assert not page.is_footer_start_free_trial_button_displayed(timeout=1)

    driver.back()
    driver.back()
    GetStarted(driver).click_on_accept_button()
    sleep(1)

    page = Home(driver)
    assert page.is_my_account_link_displayed()

    driver.forward()
    driver.forward()
    sleep(1)

    page.click_on_hbo_logo_img()

    page = Navigation(driver)
    assert page.is_my_account_link_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id()
def test_newsletter_text(driver):
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)

    assert page.get_text_of_no_news_offers() == \
        RM.get_lang_text("signup_newsletter")


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("signup")
@pytest.mark.id("C1021994")
def test_create_account_page(driver):
    """ Sign-up: Create Account page: General look
    Checks:
    #1: That HBO Logo & Sign In in navigation exists
    #2: That we are at step 1 out of 3
    #3: That email & password fields
    #4: That newsletter checkbox is unchecked by default, and verifies
        its' text
    #5: That T&C box exists with T&C, Data Policy links, and accept button
    #6: That product box exists, and with bullet points
    #7: That learn more box exists, with a learn more link
    #8: That voucher box exists with 'add voucher' and info buttons
    #9: That copyright footer exists with © text and language picker
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)

    # 1
    assert page.is_hbo_logo_img_displayed()
    assert page.is_sign_in_link_displayed()

    # 2
    assert len(page.get_steps_list()) == 3
    assert page.is_step_1_active()

    # 3
    assert page.is_email_label_displayed()
    assert page.is_email_input_displayed()
    assert page.is_password_label_displayed()
    assert page.is_password_input_displayed()

    # 4
    assert not page.is_no_news_offers_checkbox_active()
    assert RM.get_lang_text("signup_newsletter") == \
        page.get_text_of_no_news_offers()

    # 5
    assert page.is_terms_conditions_box_displayed()
    assert page.is_terms_and_conditions_link_displayed()
    assert page.is_data_policy_link_displayed()
    assert page.is_accept_and_continue_button_displayed()

    # 6
    assert page.is_product_box_displayed()
    assert page.is_bullet_points_list_populated()

    # 7
    assert page.is_learn_more_box_displayed()
    assert page.is_gdpr_learn_more_button_displayed()

    # 8
    assert page.is_voucher_box_displayed()
    assert page.is_add_voucher_button_displayed()
    assert page.is_add_voucher_tooltip_icon_displayed()

    # 9
    assert page.is_copyright_text_displayed()
    assert page.is_language_button_displayed()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("signup")
@pytest.mark.id("C1022859")
def test_error_messages_create_account(driver):
    """ Error messaging on Create Account page
    Checks:
    #1: A warning text replaces Email label after inputting wrongly
        formatted email. Is red.
    #2: warning disappears when clearing inputted text
    #3: A warning text replaces Password label after inputting too
        short password. Is red.
    #4: Entering a correctly lengthed password makes the warning disappear
    #5: Clearing password also makes warning disappear.
    #6: with cleared fields and clicking on Continue button gives warning texts
        on both Email and Password. They differ from wrongly
        formatted warnings
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)

    # 1
    email_label = page.get_text_of_email_label()
    page.input_text_on_email_field("test2.tesst.com")
    page.click_on_password_field()
    assert page.is_email_warning_displayed()
    assert page.get_color_of_email_warning() == "rgba(229, 57, 53, 1)"
    email_warning = page.get_text_of_email_warning()
    assert email_label != email_warning

    # 2
    page.click_on_email_field()
    driver.helper.hold_down_keys(Keys.BACKSPACE, 3)
    new_email_label = page.get_text_of_email_label()
    assert email_label == new_email_label

    # 3
    pass_label = page.get_text_of_password_label()
    page.input_text_on_password_field("123")
    page.click_on_email_field()
    assert page.is_password_warning_displayed()
    assert page.get_color_of_password_warning() == "rgba(229, 57, 53, 1)"
    pass_warning = page.get_text_of_password_warning()
    assert pass_label != pass_warning

    # 4
    page.input_text_on_password_field("456")
    new_pass_label = page.get_text_of_password_label()
    assert pass_label == new_pass_label

    # 5
    driver.helper.hold_down_keys(Keys.BACKSPACE, 3)
    page.click_on_email_field()
    new_new_pass_label = page.get_text_of_password_label()
    assert new_pass_label == new_new_pass_label

    # 6
    page.click_on_continue_button()
    assert page.is_email_warning_displayed()
    assert page.is_password_warning_displayed()
    new_email_warning = page.get_text_of_email_warning()
    new_pass_warning = page.get_text_of_password_warning()
    assert new_email_warning != email_warning
    assert new_pass_warning != pass_warning
    assert page.get_color_of_email_warning() == "rgba(229, 57, 53, 1)"
    assert page.get_color_of_password_warning() == "rgba(229, 57, 53, 1)"


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C454", "C1032787")
def test_successful_signup(driver, user_tmp):
    """ Successful account creation
    Checks:
    #1: That Payment page comes after create account page
    #2: That the "Complete registration" banner is
        visible (we didn't add payment method)
    """
    WhyHBO(driver).click_on_free_trial_button()

    # 1
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)
    assert page.is_payment_page()

    # 2
    page.click_on_hbo_logo_img()
    GetStarted(driver).click_on_accept_button()
    assert Home(driver).is_complete_registration_banner_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C1024004")
def test_payment_details_page(driver, user_tmp):
    """C1024004: Sign-up: Payment Details page: General look
    Checks:
    #1: Entering signup info and continuing lands us at Payment page
    #2: That HBO logo, copyright footer text, language chooser and
        the legal text is visible
    #3: That Step 2 of 3 is highlighted
    #4: That Product Box exists, with bullet points
    #5: That the product boxs' info has currency/cost info in
        active language
    #6: That we have a Credit card & a Paypal tab/options of payment
    #7: That payment form has card number, date (month & year) selectors,
        CVV number and card holder inputs
    #8: That card number label exists with text depending on language
    #9: That Month & Year labels exist (Not.Impl.)
    #10: That the month / year dropdowns placeholder texts contains
        'Select' in active language
    #11: That CVV label with an image showing preview exists
    #12: That Card holder input is empty by default, and label explains
        the use and that max 29 letters allowed, in active language
    """
    # 1
    WhyHBO(driver).click_on_free_trial_button()
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)
    assert page.is_payment_page()

    # 2
    assert page.is_hbo_logo_img_displayed()
    assert page.is_copyright_text_displayed()
    assert page.is_language_button_displayed()
    assert page.is_legal_message_displayed()

    # 3
    assert not page.is_step_1_active()
    assert page.is_step_2_active()
    assert not page.is_step_3_active()

    # 4
    assert page.is_product_box_displayed()
    assert page.is_bullet_points_list_populated()

    # 5
    currency = RM.get_lang_text("product_box_currency")
    bullet_texts = page.get_bullet_points_texts()
    bullet_subtexts = page.get_bullet_points_subtexts()
    assert True in [currency in x for x in bullet_texts + bullet_subtexts]

    # 6
    assert page.get_paypal_tab()
    assert page.is_paypal_button_displayed()
    assert page.get_cc_tab()

    page.enter_payment_iframe()

    assert page.is_card_image_visa_displayed()
    assert page.is_card_image_mastercard_displayed()

    # 7
    assert page.is_cc_input_displayed()
    assert page.is_cc_date_month_selector_displayed()
    assert page.is_cc_date_year_selector_displayed()
    assert page.is_cc_cvv_input_displayed()
    assert page.is_cc_cardholder_input_displayed()

    # 8
    cc_label = RM.get_lang_text("credit_card_label")
    assert page.get_text_label_credit_card_number() == cc_label

    # 9
    # Verify Month/Year labels when they are there

    # 10
    cc_exp_month = RM.get_lang_text("credit_card_month_placeholder")
    assert cc_exp_month in page.get_text_of_cc_exp_month_selected_option()
    cc_exp_year = RM.get_lang_text("credit_card_year_placeholder")
    assert cc_exp_year in page.get_text_of_cc_exp_year_selected_option()

    # 11
    assert page.get_text_of_cvv_label() == "CVV"
    assert page.is_cvv_image_displayed()

    # 12
    assert not page.get_text_of_credit_card_holder_input()
    cc_holder = RM.get_lang_text("credit_card_holder_label")
    assert cc_holder in page.get_text_of_cc_holder_label()

    page.exit_payment_iframe()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C1022320")
def test_create_account_hover(driver):
    """  Hovers and UI modifications on Create Account page
    Checks:
    #1: Links in T&C box has same color as text
    #2: Links are underlined
    #3: Links turn blue when hovered over
    #4: Hovering over add voucher help icon shows tooltip
    #5: Terms & Conditions link open in a new tab
    #6: Data Policy link open in a new tab
    """
    blue = "rgba(0, 163, 218, 1)"
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)
    assert page.is_terms_conditions_box_displayed()

    # 1
    tc_color = page.get_color_of_tc_box_text()
    assert page.get_color_of_terms_and_conditions_link() == tc_color
    assert page.get_color_of_data_policy_link() == tc_color

    # 2
    assert "underline" in \
        page.get_text_decoration_of_terms_and_conditions_link()
    assert "underline" in page.get_text_decoration_of_data_policy_link()

    # 3
    page.hover_over_terms_and_conditions_link()
    assert page.get_color_of_terms_and_conditions_link() == blue
    page.hover_over_data_policy_link()
    assert page.get_color_of_data_policy_link() == blue

    # 4
    page.hover_over_voucher_help_icon()
    # Hovering over voucher icon gives a pseudo-element, ::before
    # Selenium can't locate these

    # 5
    page.click_on_terms_and_conditions_link()
    driver.helper.switch_to_window(1)
    page = TermsAndConditions(driver)
    assert page.is_terms_and_conditions_page()

    driver.helper.close_window()
    driver.helper.switch_to_window(0)
    page = SignUp(driver)

    # 6
    page.click_on_data_policy_link()
    driver.helper.switch_to_window(1)
    page = DataPolicy(driver)
    assert page.is_data_policy_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C1024005")
def test_payment_details_hovers(driver, user_tmp):
    """ C1024005: Hovers on Payment Details page
    Checks:
    #1: That legal text and link have the same color. Link is underlined
    #2: Link turns blue when hovered over
    #3: Clicking on withdraw right link opens withdraw modal page
    #4: Clicking on T&C in withdraw right link opens new tab with T&C
    #5: Can click on close button in withdraw modal page to close it
    #6: CVV Preview/Zoom appears when hovering over CVV img
    """
    blue = ["rgba(0, 163, 218, 1)", "rgb(0, 163, 218)"]
    WhyHBO(driver).click_on_free_trial_button()
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)

    # just to get payment time to load
    page.enter_payment_iframe()
    page.exit_payment_iframe()

    # 1
    text_color = page.get_color_of_legal_message()
    link_color = page.get_color_of_legal_withdraw_link()
    assert text_color == link_color
    assert "underline" in page.get_text_decoration_of_legal_withdraw_link()

    # 2
    page.hover_over_legal_message_withdraw_link()
    link_color_hovered = page.get_color_of_legal_withdraw_link()
    assert link_color_hovered != link_color
    assert link_color_hovered in blue

    # 3
    page.click_on_legal_withdraw_right_link()
    page = WithDrawalRight(driver)
    assert page.is_withdrawal_page()

    # 4
    # Chrome doesn't seem to correctly click link
    page.click_on_terms_and_conditions_link()
    driver.helper.switch_to_window(1)
    page = TermsAndConditions(driver)
    assert page.is_terms_and_conditions_page()

    driver.helper.close_window()
    driver.helper.switch_to_window(0)

    page = WithDrawalRight(driver)
    assert page.is_withdrawal_page()

    # 5
    page.click_on_close_button()
    page = PaymentDetails(driver)

    # 6
    page.enter_payment_iframe()
    assert not page.is_cvv_image_preview_displayed(0)
    page.hover_over_cvv_image()
    assert page.is_cvv_image_preview_displayed()

    # Move away from hovering over CVV
    driver.helper.move_mouse_about(-100, 75)

    # 7
    driver.helper.resize_window(400, 800)
    sleep(1)
    assert not page.is_cvv_image_preview_displayed(0)
    # Firefox doesn't work, as it still acts as desktop browser
    page.click_on_cvv_image()
    sleep(1)
    assert page.is_cvv_image_preview_displayed()

    page.exit_payment_iframe()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C1031306")
def test_interaction_on_payment_page(driver, user_tmp):
    """  Interaction with the form on Payment Details page
    Checks:
    #1: That MasterCard img icon gets dimmed when starting to
        enter a VISA card
    #2: That VISA img icon gets dimmed when starting to enter
        a MasterCard card
    #3: That both card icons are 'lit' when invalid card is entered
    #4: That you can choose month & year using the dropdown pickers
    #5: Entering text on CVV input works
    #6: Entering text on card holder input works
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)

    page.enter_payment_iframe()

    # 1
    page.enter_text_on_cc("4000")
    assert page.is_cc_visa_active()
    assert not page.is_cc_master_active()

    page.clear_text_on_cc_number()

    # 2
    page.enter_text_on_cc("5100")
    assert page.is_cc_master_active()
    assert not page.is_cc_visa_active()

    page.clear_text_on_cc_number()

    # 3
    page.enter_text_on_cc("9999")
    # They're both lit when both 'inactive'
    assert not page.is_cc_visa_active()
    assert not page.is_cc_master_active()

    # 4
    page.drop_down_in_exp_month_by_value("11")
    assert page.get_text_of_selected_in_exp_month().strip() == "11"
    page.drop_down_in_exp_year_by_value("2037")
    assert page.get_text_of_selected_in_exp_year().strip() == "2037"

    # 5
    page.enter_text_on_cc_cvv("123")
    assert page.get_text_of_cvv_input() == "123"

    # 6
    name = f"{user_tmp.firstname} {user_tmp.lastname}"
    page.enter_text_on_cc_holder_name(name)
    assert page.get_text_of_credit_card_holder_input() == name

    page.exit_payment_iframe()


@pytest.mark.env("preprod")
@pytest.mark.category("signup")
@pytest.mark.id("C1032225")
def test_error_messages_payment_details(driver, user_tmp, cc):
    """ Error messaging on Payment Details page
    Checks:
    #1: Clicking submit without filling any info replaces input labels
        with error labels
    #2: Filling some, but not all fields and submitting will give errors
        on the non-filled, and retain entered text on the others
    #3: Submitting valid, but wrong CC info should return an error
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)

    page.wait_until_payment_submit_button_displayed()

    # 1
    page.click_on_cc_submit_button()
    page.enter_payment_iframe()

    assert page.is_credit_card_input_error_displayed()
    assert page.is_credit_card_exp_error_displayed()
    assert page.is_credit_card_cvv_error_displayed()
    assert page.is_credit_card_holder_input_error_displayed()

    # 2
    page.enter_text_on_cc(cc.number)
    page.enter_text_on_cc_holder_name(cc.name)

    page.exit_payment_iframe()
    page.click_on_cc_submit_button()
    page.enter_payment_iframe()

    assert not page.is_credit_card_input_error_displayed(1)
    assert not page.is_credit_card_holder_input_error_displayed(1)
    inputted_number = page.get_text_of_cc_number_input().replace(" ", "")
    assert inputted_number == cc.number
    assert page.get_text_of_credit_card_holder_input() == cc.name
    assert page.is_credit_card_exp_error_displayed()
    assert page.is_credit_card_cvv_error_displayed()

    # 3
    page.drop_down_in_exp_month_by_value("01")
    page.drop_down_in_exp_year_by_value("2019")
    page.enter_text_on_cc_cvv(cc.cvv)

    page.exit_payment_iframe()
    page.click_on_cc_submit_button()
    assert page.is_alert_snackbar_error_displayed(15)
