from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.loginform_page import LoginForm
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner, \
    CookieReadMore
from apps.hbonweb.pages.data_policy_page import DataPolicy
from apps.hbonweb.pages.signup_page import GetStarted
from apps.hbonweb.pages.myaccount_page import MyAccount
from apps.hbonweb.pages.pin_page import Pin

from apps.hbonweb.flows.login_flow import login
from apps.hbonweb.flows.cookies_banner_flow import is_cookies_banner_shown, \
    are_all_data_policy_checkboxes_checked, \
    are_all_data_policy_option_descriptions_displayed, \
    click_all_data_policy_checkboxes, are_specific_data_policy_options_checked
from apps.hbonweb.flows.signup_flow import do_complete_registration, \
    create_new_user_and_go_to_home

from helpers.configmanager import ConfigManager

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119967")
def test_banner_view(driver):
    """C119968: Banner view
    Check that banner is visible in different pages
    and after switching language."""
    # Arrange
    page = WhyHBO(driver)

    # WhyHBO
    assert is_cookies_banner_shown(driver)

    # Home unauth
    page.click_on_home_logged_out_link()
    sleep(0.5)
    assert is_cookies_banner_shown(driver)

    # Kids
    Home(driver).click_on_kids_link()
    sleep(0.5)
    assert is_cookies_banner_shown(driver)

    # Login
    Kids(driver).click_on_sign_in_link()
    sleep(0.5)
    assert is_cookies_banner_shown(driver)

    # How to watch footer
    LoginForm(driver).click_on_hbo_logo_img()
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    page.click_on_how_to_watch_link()
    assert is_cookies_banner_shown(driver)

    # About footer
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    page.click_on_about_link()
    assert is_cookies_banner_shown(driver)

    # FAQ footer
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    page.click_on_faq_link()
    assert is_cookies_banner_shown(driver)

    # Contact footer
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    page.click_on_contact_link()
    assert is_cookies_banner_shown(driver)

    # Press footer
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    page.click_on_press_link()
    assert is_cookies_banner_shown(driver)

    # Terms footer
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    page.click_on_terms_and_conditions_link()
    assert is_cookies_banner_shown(driver)

    # Data policy footer
    sleep(0.5)
    driver.helper.scroll_to_bottom()
    page.click_on_footer_data_policy_link()
    assert is_cookies_banner_shown(driver)

    page.click_on_hbo_logo_img()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119968")
def test_banner_readmore_view_in_all_languages(driver):
    """C119968: Banner View: Read More
    Verify read more view between languages."""
    CookieBanner(driver).click_on_read_more_button()
    page = CookieReadMore(driver)
    langs = len(page.get_language_options())

    for i in range(0, langs):
        page.driver.helper.scroll_to_bottom()
        page.click_on_language_button()
        page.select_language_nr(i)

        assert page.is_cookie_banner_read_more_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119968")
def test_banner_readmore_shown_when_browser_back(driver):
    """C119968: Banner View: Read More
    Verify banner is shown again after backing out of Read More view"""
    CookieBanner(driver).click_on_read_more_button()
    assert CookieReadMore(driver).is_cookie_banner_read_more_page()

    driver.back()
    assert is_cookies_banner_shown(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119968")
def test_banner_hidden_when_saved(driver):
    """C119968: Banner View: Read More
    Verify banner is hidden when data policies are saved"""
    assert is_cookies_banner_shown(driver)
    CookieBanner(driver).click_on_read_more_button()

    # Saved
    CookieReadMore(driver).click_on_save_button()
    assert not is_cookies_banner_shown(driver, 2)

    # Refreshing, verify saved
    driver.refresh()
    assert not is_cookies_banner_shown(driver, 5)

    # Refreshing, cleansing cookies, verify shown again
    driver.delete_all_cookies()
    driver.refresh()
    assert is_cookies_banner_shown(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119968")
def test_data_policy_checkboxes(driver):
    """C119968: Banner View: Read More
    Verify checkboxes get correctly un/checked"""
    CookieBanner(driver).click_on_read_more_button()

    page = CookieReadMore(driver)
    # All checked by default
    assert page.is_select_all_checkbox_checked()
    assert are_all_data_policy_checkboxes_checked(driver)
    assert are_all_data_policy_option_descriptions_displayed(driver)

    # Unchecked with select all
    page.click_on_select_all_checkbox()
    assert not page.is_select_all_checkbox_checked()
    assert not are_all_data_policy_checkboxes_checked(driver)

    # Checked all by clicking them
    click_all_data_policy_checkboxes(driver)
    assert page.is_select_all_checkbox_checked()
    assert are_all_data_policy_checkboxes_checked(driver)

    # Unchecked all by clicking them
    click_all_data_policy_checkboxes(driver)
    assert not page.is_select_all_checkbox_checked()
    assert not are_all_data_policy_checkboxes_checked(driver)

    # Checked with select all
    page.click_on_select_all_checkbox()
    assert page.is_select_all_checkbox_checked()
    assert are_all_data_policy_checkboxes_checked(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119969")
def test_banner_data_policy_link(driver):
    """C119969: Banner View: Data Policy
    Verify banner has link to data policy"""
    CookieBanner(driver).click_on_data_policy_link()
    assert DataPolicy(driver).is_data_policy_page()


@pytest.mark.env("preprod")
@pytest.mark.category("gdpr", "signup", "subscription")
@pytest.mark.id("C119970")
def test_signup_without_setting_data_policy(driver, user_tmp, cc):
    """C119970: Sign Up without cookie set
    Verify functionality of the Get Started page when
    cookie wasn't accepted."""
    assert is_cookies_banner_shown(driver)

    do_complete_registration(driver, user_tmp, cc, False, goto_signup=True)

    page = GetStarted(driver)
    page.click_on_data_policy_link()
    assert DataPolicy(driver).is_data_policy_page()

    driver.back()
    assert page.is_get_started_page()

    page.click_on_show_alternatives_button()
    page = CookieReadMore(driver)
    assert page.is_select_all_checkbox_checked()
    assert are_all_data_policy_checkboxes_checked(driver)
    assert are_all_data_policy_option_descriptions_displayed(driver)


@pytest.mark.env("preprod")
@pytest.mark.category("gdpr", "signup", "subscription")
@pytest.mark.id("C119971")
def test_signup_with_cookie_accepted(driver, user_tmp, cc):
    """C119971: Sign Up with cookie set
    Verify no banner, no get started, and all cookies accepted"""
    assert is_cookies_banner_shown(driver)

    CookieBanner(driver).click_on_accept_button()
    assert not is_cookies_banner_shown(driver, 2)

    do_complete_registration(driver, user_tmp, cc, False, goto_signup=True)
    Home(driver).click_on_my_account_link()
    MyAccount(driver).click_on_cookie_settings_link()
    assert are_all_data_policy_checkboxes_checked(driver)


@pytest.mark.env("preprod")
@pytest.mark.category("gdpr", "signup", "subscription")
@pytest.mark.id("C119971")
def test_signup_with_no_cookies_chosen(driver, user_tmp, cc):
    """C119971: Sign Up with cookie set
    Verify no banner, no get started, and all cookies chosen not to keep"""
    assert is_cookies_banner_shown(driver)

    CookieBanner(driver).click_on_read_more_button()
    # Disable all
    CookieReadMore(driver).click_on_select_all_checkbox()
    assert not are_all_data_policy_checkboxes_checked(driver)

    CookieReadMore(driver).click_on_save_button()
    assert not is_cookies_banner_shown(driver, 2)

    do_complete_registration(driver, user_tmp, cc, False, goto_signup=True)
    Home(driver).click_on_my_account_link()
    MyAccount(driver).click_on_cookie_settings_link()
    assert not are_all_data_policy_checkboxes_checked(driver)


@pytest.mark.env("preprod")
@pytest.mark.category("gdpr", "signup", "subscription")
@pytest.mark.id("C119971")
def test_signup_with_some_cookies_chosen(driver, user_tmp, cc):
    """C119971: Sign Up with cookie set
    Verify no banner, no get started, and some
    cookies (first 2) chosen to keep"""
    # Cookie banner displayed by default
    assert is_cookies_banner_shown(driver)

    # Don't accept, see more
    CookieBanner(driver).click_on_read_more_button()

    # Disable all
    page = CookieReadMore(driver)
    page.click_on_select_all_checkbox()
    assert not are_all_data_policy_checkboxes_checked(driver)

    # Enable Facebook & Google
    page.click_on_facebook_option_checkbox()
    page.click_on_google_option_checkbox()
    assert are_specific_data_policy_options_checked(
        driver, True, True, False, False, False)

    # Save cookie consent
    page.click_on_save_button()
    assert not is_cookies_banner_shown(driver, 2)
    assert page.driver.helper.cookie_exists("consentCookie")

    # Complete registration
    do_complete_registration(driver, user_tmp, cc, accept_getstarted=False,
                             goto_signup=True)
    assert not is_cookies_banner_shown(driver, 2)
    assert not page.driver.helper.cookie_exists("consentCookie")

    # Go to my account, cookies
    Home(driver).click_on_my_account_link()
    MyAccount(driver).click_on_cookie_settings_link()
    assert are_specific_data_policy_options_checked(
        driver, True, True, False, False, False)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("gdpr", "signup")
@pytest.mark.id("C119972")
def test_signin_with_all_cookies_set_user_unset(driver, user_tmp):
    """C119972: Sign In with cookie set
    Disable cookies. Login with user without cookies set
    Simulate old, unset, user by creating it"""
    # Cookie displayed by default
    assert is_cookies_banner_shown(driver)

    # Create new user
    create_new_user_and_go_to_home(
        driver, user_tmp.email, user_tmp.password)

    # Delete cookies, refresh and go to homepage
    driver.delete_all_cookies()
    driver.refresh()
    driver.get(cm.url)

    # Cookie displayed since not set
    assert is_cookies_banner_shown(driver)

    # Accept all cookies
    CookieBanner(driver).click_on_accept_button()
    sleep(1)
    assert not is_cookies_banner_shown(driver, 1)
    assert driver.helper.cookie_exists("consentCookie")

    # Login
    login(driver, user_tmp.email, user_tmp.password)
    Pin(driver).click_on_maybe_later_link()

    # Verify all cookies accepted
    Home(driver).click_on_my_account_link()
    MyAccount(driver).click_on_cookie_settings_link()
    assert are_all_data_policy_checkboxes_checked(driver)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("gdpr", "signup")
@pytest.mark.id("C119972")
def test_signin_with_no_cookies_set_user_unset(driver, user_tmp):
    """C119972: Sign In with cookie set
    Accept cookies. Login with user without cookies set
    Simulate old, unset, user by creating it"""
    # Cookie displayed by default
    assert is_cookies_banner_shown(driver)

    # Create new user
    create_new_user_and_go_to_home(
        driver, user_tmp.email, user_tmp.password, accept_getstarted=False)

    # Delete cookies, refresh and go to homepage
    driver.delete_all_cookies()
    driver.refresh()
    driver.get(cm.url)

    # Cookie displayed since not set
    assert is_cookies_banner_shown(driver)

    # Disable all cookies
    CookieBanner(driver).click_on_read_more_button()
    page = CookieReadMore(driver)
    page.click_on_select_all_checkbox()
    page.click_on_save_button()
    assert not is_cookies_banner_shown(driver, 2)

    # Login
    login(driver, user_tmp.email, user_tmp.password)
    Pin(driver).click_on_maybe_later_link()

    # Verify all cookies accepted
    Home(driver).click_on_my_account_link()
    MyAccount(driver).click_on_cookie_settings_link()
    assert not are_all_data_policy_checkboxes_checked(driver)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("gdpr", "signup")
@pytest.mark.id("C119972")
def test_signin_with_some_cookies_set_user_unset(driver, user_tmp):
    """C119972: Sign In with cookie set
    Accept some of the cookies. Login with user without cookies set
    Simulate old, unset, user by creating it"""
    # Cookie displayed by default
    assert is_cookies_banner_shown(driver)

    # Create new user
    create_new_user_and_go_to_home(
        driver, user_tmp.email, user_tmp.password, accept_getstarted=False)

    # Delete cookies, refresh and go to homepage
    driver.delete_all_cookies()
    driver.refresh()
    driver.get(cm.url)

    # Cookie displayed since not set
    assert is_cookies_banner_shown(driver)

    # Disable all cookies
    CookieBanner(driver).click_on_read_more_button()
    page = CookieReadMore(driver)
    page.click_on_google_option_checkbox()
    page.click_on_bing_option_checkbox()
    page.click_on_save_button()
    sleep(3)
    assert not is_cookies_banner_shown(driver, 2)

    # Login
    login(driver, user_tmp.email, user_tmp.password)
    Pin(driver).click_on_maybe_later_link()

    # Verify all cookies accepted
    Home(driver).click_on_my_account_link()
    MyAccount(driver).click_on_cookie_settings_link()
    assert are_specific_data_policy_options_checked(
        driver, True, False, True, False, True)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119973")
def test_signin_with_all_cookies_accepted_but_already_set(driver, user):
    """C119973: Sign In with cookie set, user with preferences already set
    Accept cookies. Verify overwritten by user settings when logged in"""
    # Cookie banner displayed by default
    assert is_cookies_banner_shown(driver)

    # Accept cookie banner (with everything on)
    CookieBanner(driver).click_on_accept_button()
    assert not is_cookies_banner_shown(driver, 2)
    assert driver.helper.cookie_exists("consentCookie")

    # Login
    page = login(driver, user.email, user.password)
    assert not is_cookies_banner_shown(driver, 2)
    assert not page.driver.helper.cookie_exists("consentCookie")

    # My account, cookies
    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_cookie_settings_link()

    # All but thirdparty should be disabled since that's what's saved
    assert are_specific_data_policy_options_checked(driver,
                                                    False,
                                                    False,
                                                    False,
                                                    False,
                                                    True)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119973")
def test_signin_with_no_cookies_accepted_but_already_set(driver, user):
    """C119973: Sign In with cookie set, user with preferences already set
    Disable all cookies. Verify overwritten by user settings when logged in"""
    # Cookie banner displayed by default
    assert is_cookies_banner_shown(driver)

    # Disable cookies
    CookieBanner(driver).click_on_read_more_button()
    page = CookieReadMore(driver)
    page.click_on_select_all_checkbox()
    assert not are_all_data_policy_checkboxes_checked(driver)

    # Save cookies (as in, no cookies)
    page.click_on_save_button()
    assert not is_cookies_banner_shown(driver, 2)
    assert page.driver.helper.cookie_exists("consentCookie")

    # Login
    page = login(driver, user.email, user.password)
    assert not is_cookies_banner_shown(driver, 2)
    assert not page.driver.helper.cookie_exists("consentCookie")

    # Go to my account, cookie settings
    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_cookie_settings_link()

    # All but thirdparty should be disabled since that's what's saved
    assert are_specific_data_policy_options_checked(
        driver, False, False, False, False, True)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119973")
def test_signin_with_some_cookies_accepted_but_already_set(driver, user):
    """C119973: Sign In with cookie set, user with preferences already set
    Accept google & twitter cookie. Verify overwritten when logged in"""
    # Cookie banner displayed by default
    assert is_cookies_banner_shown(driver)

    # Read more. Accept Google & Twitter cookies only
    CookieBanner(driver).click_on_read_more_button()
    page = CookieReadMore(driver)
    page.click_on_select_all_checkbox()
    assert not are_all_data_policy_checkboxes_checked(driver)

    page.click_on_google_option_checkbox()
    page.click_on_twitter_option_checkbox()
    assert are_specific_data_policy_options_checked(
        driver, False, True, True, False, False)
    # Save cookie consent
    page.click_on_save_button()
    assert not is_cookies_banner_shown(driver, 2)
    assert page.driver.helper.cookie_exists("consentCookie")

    # Login
    page = login(driver, user.email, user.password)
    assert not is_cookies_banner_shown(driver, 2)
    assert not page.driver.helper.cookie_exists("consentCookie")

    # Go to my account
    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_cookie_settings_link()

    # Verify "old" settings are used
    assert are_specific_data_policy_options_checked(driver,
                                                    False,
                                                    False,
                                                    False,
                                                    False,
                                                    True)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("gdpr", "signup")
@pytest.mark.id("C119977")
def test_signin_user_not_set_cookies(driver, user_tmp):
    """C119977: Sign in with banner
    Verify banner is still shown for logged in user if cookies not set
    Creating a user without setting cookie consent to simulate old user"""
    # Banner shown by default
    assert is_cookies_banner_shown(driver)

    # Create new user, without setting consent
    create_new_user_and_go_to_home(
        driver, user_tmp.email, user_tmp.password, accept_getstarted=False)

    # Delete cookies, refresh and go to homepage
    driver.delete_all_cookies()
    driver.refresh()
    driver.get(cm.url)
    sleep(5)

    # Logged out. no cookies set. Banner should be shown
    assert is_cookies_banner_shown(driver)

    # Login
    login(driver, user_tmp.email, user_tmp.password)
    Pin(driver).click_on_maybe_later_link()

    # Banner should be shown since cookies was never set
    assert is_cookies_banner_shown(driver)


@pytest.mark.env("preprod")
@pytest.mark.category("gdpr", "signup")
@pytest.mark.id("C119974", "C119975", "C119976")
def test_signup_after_signin_and_accept_cookies(driver, user_tmp, cc):
    """C119974: SignUp. Cookie settings should not persist from
    one authenticated user to another
    C119975: SignIn. Cookie settings should not persist from
    one authenticated user to anothe
    C119976: Authenticated user after deploy
    Sign in with user without cookie consent (create it to simulate it).
    Accept cookies.
    Log out. Create new user. Verify Get Started page is shown during signup"""
    # Banner shown by default
    assert is_cookies_banner_shown(driver)

    # Create new user, without setting consent
    create_new_user_and_go_to_home(
        driver, user_tmp.email, user_tmp.password, accept_getstarted=False)

    # Delete cookies, refresh and go to homepage
    driver.delete_all_cookies()
    driver.refresh()
    driver.get(cm.url)
    sleep(5)

    # Logged out. no cookies set. Banner should be shown
    assert is_cookies_banner_shown(driver)

    # Login
    page = login(driver, user_tmp.email, user_tmp.password)
    Pin(driver).click_on_maybe_later_link()

    # Banner should be shown since cookies wasn't set
    assert is_cookies_banner_shown(driver)

    # Accept cookies
    CookieBanner(driver).click_on_accept_button()
    sleep(2)
    assert not is_cookies_banner_shown(driver, 2)

    # Consent sent to IBM rather than saved locally (since logged in)
    assert not page.driver.helper.cookie_exists("consentCookie")

    # Verify cookies are set
    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_cookie_settings_link()
    assert are_all_data_policy_checkboxes_checked(driver)

    # Log out
    page.click_on_sign_out_link()
    page = WhyHBO(driver)
    assert not is_cookies_banner_shown(driver, 2)

    # Change email of user so we can create new account
    i = user_tmp.email.find("@")
    user_tmp.email = user_tmp.email[:i] + "-2" + user_tmp.email[i:]

    # Do new registration
    do_complete_registration(driver, user_tmp, cc, accept_getstarted=False,
                             goto_signup=True)

    # Verify we see get started page
    page = GetStarted(driver)
    assert page.is_get_started_page()

    # Only save Bing, to verify difference to previous user
    page.click_on_show_alternatives_button()
    page = CookieReadMore(driver)
    page.click_on_select_all_checkbox()
    page.click_on_bing_option_checkbox()
    page.click_on_save_button()
    assert not is_cookies_banner_shown(driver, 2)

    # Verify only Bing is active
    Home(driver).click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_cookie_settings_link()
    assert are_specific_data_policy_options_checked(driver, False, False,
                                                    False, True, False)


@pytest.mark.env("prod", "preprod")
@pytest.mark.category("gdpr")
@pytest.mark.id("C119979")
def test_ga_cookie_exists(driver):
    """C119979: Standard Google Analytics cookie is always placed on browser
    Verify GA cookie is always there"""
    # Let webapp load
    page = WhyHBO(driver)
    assert page.is_why_hbo_active_link_displayed()
    sleep(20)

    assert page.driver.helper.cookie_exists("_ga")
    assert page.driver.helper.cookie_exists("_gid")
