import pytest

from apps.hbonweb.pages.home_page import Home, WhyHBO
from apps.hbonweb.pages.player_page import Player
from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.myaccount_page import MyAccount, CancelSubscription
from apps.hbonweb.pages.payment_page import PaymentDetails, Paypal
from apps.hbonweb.pages.signup_page import GetStarted, CantSubscribe

from apps.hbonweb.flows.paypal_flow import paypal_do_full_signup, \
    paypal_login, enter_signup_info_and_continue, \
    paypal_sign_in_approve_payment, enter_signup_info_and_open_paypal, \
    paypal_approve_payment
from apps.hbonweb.flows.signup_flow import enter_credit_card_info, \
    do_complete_registration
from apps.hbonweb.flows import search_flow
from apps.hbonweb.flows import login_flow
from apps.hbonweb.flows import cookies_banner_flow

from apps.hbonshared import api_flow
from apps.hbonshared.resourcesmanager import ResourcesManager as RM

from helpers.sleeper import Sleeper as sleep


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup", "subscription")
@pytest.mark.id("C3709")
def test_successful_subscription(driver, user_tmp, paypal_user,
                                 movie):
    # Sign up. Subscribe with valid paypal user
    page = paypal_do_full_signup(driver, user_tmp, paypal_user)

    assert page.is_my_account_link_displayed()
    assert not page.is_complete_registration_banner_displayed(1)

    # Verify playback works
    page = search_flow.search_movie_open(driver, movie.title)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    page.click_on_back_button()

    # Verify Paypal is seen as method of payment
    page = Movie(driver)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_subscription_link()
    assert page.get_payment_text() == "PayPal"


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup", "subscription")
@pytest.mark.id("C904478")
def test_successful_subscription_with_pending_user(
        driver, user_tmp, paypal_user, movie):
    # Sign up, don't subscribe
    api_flow.create_account(user_tmp)

    page = login_flow.login(
        driver, user_tmp.email, user_tmp.password, first_login=True)

    # Verify pending state ('cause why not)
    assert page.is_complete_registration_banner_displayed()

    # Initiate subscription with paypal
    page = Home(driver)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_subscription_link()
    page.click_on_sub_buy_button()

    page = PaymentDetails(driver)
    page.wait_until_payment_submit_button_displayed()
    page.click_on_paypal_button()

    # Do valid paypal payment
    page = paypal_sign_in_approve_payment(
        driver, paypal_user, accept_getstarted=False)

    page = Home(driver)
    assert page.is_my_account_link_displayed()
    assert not page.is_complete_registration_banner_displayed(1)

    # Verify playback works
    page = search_flow.search_movie_open(driver, movie.title)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    page.click_on_back_button()

    # Verify Paypal is seen as method of payment
    page = Movie(driver)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_subscription_link()
    assert page.get_payment_text() == "PayPal"


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup", "subscription")
@pytest.mark.id("C868529")
def test_subscribe_with_cookies_unset(driver, user_tmp, paypal_user):
    page = paypal_do_full_signup(
        driver, user_tmp, paypal_user, False)
    assert page.is_get_started_page()


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup", "subscription")
@pytest.mark.id("C868529")
def test_subscribe_with_cookies_set(driver, user_tmp, paypal_user):
    cookies_banner_flow.accept_cookie_banner(driver)

    paypal_do_full_signup(driver, user_tmp, paypal_user, False)
    assert Home(driver).is_home_logged_in_active_link_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup", "subscription")
@pytest.mark.id("C396268")
def test_subscribe_with_invalid_paypal_user(driver, user_tmp):
    ppuser = RM.get_paypal_user("en")

    paypal_do_full_signup(
        driver, user_tmp, ppuser, accept_getstarted=False)

    page = CantSubscribe(driver)
    assert page.is_cant_subscribe_page()


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup")
@pytest.mark.id("C923821")
@pytest.mark.xfail(strict=True, reason="Bug: Toast not seen with popup paypal")
def test_close_paypal_window(driver, user_tmp):
    enter_signup_info_and_open_paypal(driver, user_tmp)

    page = Paypal(driver)
    # Paypal popup
    driver.switch_to.window(driver.window_handles[1])
    # The Cancel Link element cannot be interacted with for some reason
    # Closing window instead
    driver.helper.close_window()
    driver.switch_to.window(driver.window_handles[0])

    # Return to Payment
    page = PaymentDetails(driver)
    assert page.wait_until_paypal_checkout_overlay_gone()
    assert page.is_ok_toast_displayed()

    # Go to Home, Verify Pending user
    page.click_on_hbo_logo_img()
    page = GetStarted(driver)
    page.click_on_accept_button()
    page = Home(driver)
    assert page.is_complete_registration_banner_displayed()

    # Go to My Account, Verify no payment option active
    page.click_on_my_account_link()
    page = MyAccount(driver)
    page.click_on_subscription_link()
    assert page.is_sub_buy_button_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup")
@pytest.mark.id("C817301")
def test_see_add_cc_with_ppuser_without_cc(driver, user_tmp, paypal_user_nocc):
    enter_signup_info_and_open_paypal(driver, user_tmp)
    paypal_login(driver, paypal_user_nocc)

    page = Paypal(driver)
    assert page.is_message_banner_displayed()
    assert page.is_cc_input_displayed()
    assert page.is_add_card_button_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup", "subscription", "playback")
@pytest.mark.id("C3703")
def test_playback_after_cancel_paypal_subscription(driver, user_tmp,
                                                   paypal_user, movie):
    """ Termination of PayPal user through HBO
    Checks:
    #1: Can cancel paypal subscription
    #2: Can still playback after cancellation
    """
    page = paypal_do_full_signup(driver, user_tmp, paypal_user)
    page.click_on_my_account_link()

    # 1
    page = MyAccount(driver)
    page.click_on_subscription_link()
    page.click_on_cancel_subscription_link()

    page = CancelSubscription(driver)
    page.click_on_cancel_subscription_button()

    page = MyAccount(driver)
    assert page.is_reactivate_subscription_button_displayed()

    page = search_flow.search_asset_open(driver, movie)

    # 2
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()


@pytest.mark.env("preprod")
@pytest.mark.category("paypal", "signup", "subscription")
@pytest.mark.id("C3703")
def test_reactivation_after_cancel_paypal_subscription(driver, user_tmp,
                                                       paypal_user):
    """ Termination of PayPal user through HBO
    Checks:
    #1: Can cancel paypal subscription
    #2: Can reactivate subscription
    """
    page = paypal_do_full_signup(driver, user_tmp, paypal_user)
    page.click_on_my_account_link()

    # 1
    page = MyAccount(driver)
    page.click_on_subscription_link()
    page.click_on_cancel_subscription_link()

    page = CancelSubscription(driver)
    page.click_on_cancel_subscription_button()

    page = MyAccount(driver)
    assert page.is_reactivate_subscription_button_displayed()

    # 2
    page.click_on_sub_reactivate_button()

    assert page.wait_until_cancel_sub_link_is_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription", "paypal")
@pytest.mark.id("C4736269")
def test_change_from_cc_to_pp(driver, user_tmp, cc, paypal_user):
    """ Switch from CC to PayPal
    Checks:
    #1: Paypal button is an option in PaymentDetails
    #2: No product box seen since we already have valid payment
    #3: Approve payment through Paypal
    #4: No product box in paypal confirmation page
    #5: Subscription info says paypal is active sub
    """
    page = do_complete_registration(driver, user_tmp, cc, goto_signup=True)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_subscription_link()
    page.click_on_change_payment_button()

    page = PaymentDetails(driver)
    # 1
    assert page.is_paypal_button_displayed(15)
    # 2
    assert not page.is_product_box_displayed()

    # 3
    page.click_on_paypal_button()
    page = paypal_sign_in_approve_payment(
        driver, paypal_user, accept_getstarted=False, submit=False)

    # 4
    assert not page.is_product_box_displayed()

    page.click_on_paypal_submit_button()

    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()

    page.click_on_my_account_link()

    # 5
    page = MyAccount(driver)
    page.click_on_subscription_link()
    assert page.is_paypal_active_img_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription", "paypal")
@pytest.mark.id("C4736270")
def test_change_from_pp_to_cc(driver, user_tmp, cc, paypal_user):
    """ Switch from PayPal to Credit card
    Checks:
    #1: Changing payment from existing valid should not have ProductBox
        in PaymentDetails
    #2: Changing payment to CC should work. arrive at Home
    #3: Check that our subscription payment method is by CC
    """
    page = paypal_do_full_signup(driver, user_tmp, paypal_user)
    page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_subscription_link()
    page.click_on_change_payment_button()

    # 1
    page = PaymentDetails(driver)
    assert not page.is_product_box_displayed()

    # 2
    enter_credit_card_info(
        driver, cc.number, cc.cvv, cc.name, cc.month, cc.year)
    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()

    page.click_on_my_account_link()

    # 3
    page = MyAccount(driver)
    page.click_on_subscription_link()
    assert page.is_card_number_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription", "paypal")
@pytest.mark.id("C4677084")
def test_change_payment_from_pp_to_pp_again(driver, user_tmp, cc, paypal_user):
    """ Payment change between PP and CC
    Checks:
    #1: Start signup, choose paypal and complete process up to checkout
    #2: Click on change payment and again choose paypal, complete process
    """
    WhyHBO(driver).click_on_free_trial_button()

    # 1
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)

    page.click_on_paypal_button()
    page = paypal_login(driver, paypal_user)
    page = paypal_approve_payment(driver)

    # 2
    page.click_on_pp_checkout_change_payment_button(10)
    page.click_on_paypal_button()
    page = paypal_approve_payment(driver)

    page.click_on_paypal_submit_button()
    page = GetStarted(driver)
    page.click_on_accept_button()

    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription", "paypal")
@pytest.mark.id("C4677084")
def test_change_payment_from_pp_to_cc(driver, user_tmp, cc, paypal_user):
    """ Payment change between PP and CC
    Checks:
    #1: Start signup, choose paypal and complete process up to checkout
    #2: Click on change payment and complete subscription with
        a credit card
    """
    WhyHBO(driver).click_on_free_trial_button()

    # 1
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)

    page.click_on_paypal_button()
    page = paypal_login(driver, paypal_user)
    page = paypal_approve_payment(driver)

    # 2
    page.click_on_pp_checkout_change_payment_button(10)
    page = enter_credit_card_info(driver, cc.number, cc.cvv, cc.name)
    page.click_on_accept_button()

    page = Home(driver)
    assert page.is_home_logged_in_active_link_displayed()


@pytest.mark.env("preprod")
@pytest.mark.category("signup", "subscription", "paypal")
@pytest.mark.id()
def test_successful_subscription_pp(driver, user_tmp, paypal_user):
    """ Successful subscription creation - PayPal (generic)
    Checks:
    #1: Switch focus to another tab to hide the paypal popup
    #2: Click on Continue button to put paypal popup at front
    #3: Login to paypal and verify the confirm purchase button
    #4: Click on confirm. Popup should disappear and we be back at HBO
    #5: HBO Logo, legal text and copyright text & language picker
        in footer
    #6: That step 2 of 3 is active
    #7: The product box is displayed
    #8: Check the Sub type header, email, payment type &
        change payment button
    #9: Clicking Submit lands us at Home with a Welcome module
    #10: Check that Welcome is below Carousel and that 'name' is not
        in welcome info
    """
    WhyHBO(driver).click_on_free_trial_button()
    page = enter_signup_info_and_continue(
        driver, user_tmp.email, user_tmp.password)
    page.click_on_paypal_button()

    # 1
    driver.helper.open_window("")
    driver.helper.switch_to_window(1)
    driver.helper.close_window()
    driver.helper.switch_to_window(0)

    # 2
    page.enter_paypal_modal_iframe()
    assert page.is_paypal_modal_displayed()
    page.click_on_paypal_modal_continue_button()
    page.exit_paypal_modal_iframe()

    # 3
    driver.helper.switch_to_window(1)
    page = paypal_login(driver, paypal_user)
    assert page.is_approve_proceed_button_displayed()

    # 4
    page.click_on_approve_proceed_button()
    driver.helper.switch_to_window(0)
    sleep(5)
    assert len(driver.helper.get_windows()) == 1

    # 5
    page = PaymentDetails(driver)
    assert page.is_hbo_logo_img_displayed()
    assert page.is_copyright_text_displayed()
    assert page.is_language_button_displayed()
    assert page.is_legal_message_displayed()

    # 6
    assert not page.is_step_1_active()
    assert page.is_step_2_active()
    assert not page.is_step_3_active()

    # 7
    assert page.is_product_box_displayed()
    assert page.is_bullet_points_list_populated()

    # 8
    assert page.is_pp_checkout_sub_type_text_displayed()
    assert page.get_text_of_pp_checkout_email() == user_tmp.email
    assert page.is_pp_checkout_logo_displayed()
    assert page.is_pp_checkout_change_payment_button_displayed()

    # 9
    page.click_on_paypal_submit_button()
    GetStarted(driver).click_on_accept_button(15)
    page = Home(driver)
    assert page.is_welcome_header_displayed()

    # 10
    assert page.get_location_of_welcome_header()["y"] > \
        page.get_location_of_carousel()["y"]
    assert len(page.get_devices_list()) >= 6
    welcome = page.get_text_of_welcome_header()
    assert user_tmp.firstname not in welcome
    assert "HBON" not in welcome
    assert "HBOE" not in welcome
