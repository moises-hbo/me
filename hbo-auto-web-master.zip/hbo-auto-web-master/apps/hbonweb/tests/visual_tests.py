import pytest

from applitools.selenium import Target

from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.loginform_page import LoginForm
from apps.hbonweb.pages.signup_page import SignUp
from apps.hbonweb.pages.search_page import Search


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("visual")
@pytest.mark.id()
def test_top_menu_pages(eyes):
    # WhyHBO
    page = WhyHBO(eyes.driver)
    eyes.check(page.name, Target.window())

    page.click_on_home_logged_out_link()

    # Home
    page = Home(eyes.driver)
    eyes.check(page.name, Target.window())

    page.click_on_kids_link()

    # Kids
    page = Kids(eyes.driver)
    eyes.check(page.name, Target.window())

    page.click_on_free_trial_button()

    # SignUp
    page = SignUp(eyes.driver)
    eyes.check(page.name, Target.window())

    page.click_on_sign_in_link()

    # Login
    page = LoginForm(eyes.driver)
    eyes.check(page.name, Target.window())

    page.click_on_hbo_logo_img()
    page = WhyHBO(eyes.driver)
    page.click_on_search_button()

    # Search
    page = Search(eyes.driver)
    eyes.check(page.name, Target.window())

    eyes.close()
