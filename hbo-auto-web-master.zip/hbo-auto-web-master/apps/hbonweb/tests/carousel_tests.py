import pytest

from apps.hbonweb.pages.home_page import WhyHBO
from apps.hbonweb.pages.signup_page import SignUp


@pytest.mark.env("preprod", "prod")
@pytest.mark.category()
@pytest.mark.id("C469")
def test_carousel_start_trial(driver):
    """ Checks:
    #1: That carousel with items is displayed with intro and free trial button
        as first item
    #2: Clicking on free trial button directs us to Create Account page
    """
    # NOTE: locations are messed up, would report x: -2300 even
    # though you can see the items. Preprod issue only

    page = WhyHBO(driver)

    # 1
    assert page.is_carousel_list_displayed()
    assert page.is_carousel_intro_text_displayed()
    assert page.get_carousel_start_free_trial_button_from_first_item()
    assert page.is_carousel_intro_text_in_first_item()

    # 2
    page.click_on_carousel_start_free_trial_button()
    page = SignUp(driver)
    assert page.is_signup_page()
