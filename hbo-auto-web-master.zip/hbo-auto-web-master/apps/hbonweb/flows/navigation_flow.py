from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.myaccount_page import MyAccount
from apps.hbonweb.pages.series_page import Series
from apps.hbonweb.pages.startwatchingnow_page import StartWatchingNow


def is_whyhbo_page(driver, from_page=WhyHBO):
    page = from_page(driver)
    current_url = driver.helper.get_url()
    whyHBO_url = page.helper.get_link(page.why_hbo_link)
    return current_url == whyHBO_url


def is_home_page(driver, from_page=Home):
    page = from_page(driver)
    current_url = driver.helper.get_url()
    home_url = page.helper.get_link(page.HomeAuth_link)
    return current_url == home_url


def go_to_myaccount(driver, from_page=Home):
    """Clicks on your name/My Account in Nav bar
    and returns the MyAccount page object"""
    page = from_page(driver)
    page.click_on_my_account_link()
    return MyAccount(driver)


def get_asset_from_home_shelf(driver, asset_index, shelf_index,
                              hover_over_asset=True, wait_to_load=0):
    """Find ands scrolls to asset as per asset & shelf asset_index
    optionally hover over asset
    returns asset"""
    if wait_to_load:
        sleep(wait_to_load)
    page = Home(driver)
    shelf = page.helper.get_list(page.shelves)[shelf_index]
    shelf_loc = page.helper.get_location(shelf)

    page.driver.helper.scroll(shelf_loc["x"], shelf_loc["y"] - 150)
    sleep(1.5)
    # Need to re-get shelves since they update after scrolling / stale element
    shelf = page.helper.get_list(page.shelves)[shelf_index]
    asset = shelf.find_element_by_xpath(
        f".//div[@data-index='{asset_index}']/figure/div")
    if hover_over_asset:
        page.driver.helper.move_mouse_to(asset)
        sleep(0.5)
    return asset


def click_on_asset_in_home(driver, asset_index, shelf_index,
                           avoid_play_button=False):
    asset = get_asset_from_home_shelf(
        driver, asset_index, shelf_index, wait_to_load=5)
    if avoid_play_button:
        driver.helper.move_mouse_about(100, 0)
        driver.helper.click_on_screen()
    else:
        asset.click()


def go_to_startwatching_page_after_clicking_asset(driver):
    """After clicking an asset, will return StartWatchingNow.
    If it was a series and we entered series overview - will press Play Now
    from within.
    """
    page = StartWatchingNow(driver)
    series = Series(driver)

    if page.is_start_watching_header_displayed(5):
        return page
    elif series.is_product_box_displayed(5):  # It's a series
        loc = series.helper.get_location_when_visible(
            series.start_watching_img)
        driver.helper.scroll(loc["x"], loc["y"] - 250)
        driver.helper.move_mouse_to(series.helper.get(
            series.start_watching_img))
        series.click_on_play_button()
        return page
    else:
        raise Exception("Neither StartWatchingNow or Series was found!")
