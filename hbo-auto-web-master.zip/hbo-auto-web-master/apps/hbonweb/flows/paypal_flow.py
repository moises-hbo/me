from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.payment_page import Paypal, PaymentDetails
from apps.hbonweb.pages.signup_page import GetStarted
from apps.hbonweb.pages.home_page import Home, WhyHBO

from apps.hbonweb.flows.signup_flow import enter_signup_info_and_continue


def paypal_login(driver, paypal_user):
    driver.helper.switch_to_window(1)
    page = Paypal(driver)

    page.wait_for_loading_spinner_to_disappear()

    if page.is_cookie_banner_displayed(5):
        page.click_on_cookies_accept_button()

    page.enter_text_on_email(paypal_user.email)
    if page.is_next_button_displayed():
        page.click_on_next_button()
        sleep(2)
    page.enter_text_on_password(paypal_user.password)
    page.click_on_login_button()

    page.wait_for_loading_spinner_to_disappear()

    if page.is_cookie_banner_displayed(5):
        page.click_on_cookies_accept_button()

    return page


def paypal_approve_payment(driver):
    driver.helper.switch_to_window(1)
    page = Paypal(driver)

    page.click_on_approve_proceed_button(15)

    page.wait_for_loading_spinner_to_disappear()

    driver.helper.switch_to_window(0)
    return PaymentDetails(driver)


def paypal_sign_in_approve_payment(driver, paypal_user,
                                   accept_getstarted=True, submit=True):
    paypal_login(driver, paypal_user)
    page = paypal_approve_payment(driver)

    page.wait_until_paypal_submit_button_clickable()
    if submit:
        page.click_on_paypal_submit_button()

        if accept_getstarted:
            page = GetStarted(driver)
            # Tmp bug-fix; getstarted not always shown
            if not page.wait_until_get_started_header_displayed():
                Home(driver).click_on_home_logged_in_link()
            page.click_on_accept_button()
            return Home(driver)
        return GetStarted(driver)
    return PaymentDetails(driver)


def enter_signup_info_and_open_paypal(driver, hbo_user):
    page = WhyHBO(driver)
    page.click_on_free_trial_button()

    page = enter_signup_info_and_continue(
        driver, hbo_user.email, hbo_user.password)
    page.wait_until_payment_submit_button_displayed()
    page.click_on_paypal_button()


def paypal_do_full_signup(driver, hbo_user, paypal_user,
                          accept_getstarted=True):
    enter_signup_info_and_open_paypal(driver, hbo_user)
    page = paypal_sign_in_approve_payment(
        driver, paypal_user, accept_getstarted)
    return page
