from helpers.sleeper import Sleeper as sleep
from pathlib import Path

from apps.hbonweb.pages.player_page import Player

from apps.hbonshared.resourcesmanager import ResourcesManager as RM


def switch_to_subtitle_lang(driver, lang: str):
    page = Player(driver)

    page.hover_over_tracks_button()
    page.click_on_subtitle_option_with_text(lang.upper())
    page.wait_for_player_controls_to_disappear()


def switch_to_subtitle_index(driver, index: int = 0):
    page = Player(driver)

    page.hover_over_tracks_button()
    page.click_on_subtitle_option(index)
    page.wait_for_player_controls_to_disappear()


def get_language_of_playing_subtitle(driver, screenshot_path, lang=None,
                                     max_screenshots=30):
    page = Player(driver)

    for i in range(0, max_screenshots):
        path = str(Path(f"{screenshot_path}/screenshot{i}.png"))
        page.take_screenshot_of_video(path)
        text = page.get_subtitles_text_of_video(path, lang)
        detected = RM.detect_language(text.split(" "), lang)
        if detected:
            return detected
        sleep(3)
    return None


def sub_lang_to_lang(subtitle_lang):
    """ Translate language from player dropdown to english """
    subs = {"SVENSKA": "SWEDISH",
            "SUOMI": "FINNISH",
            "NORSK": "NORWEGIAN",
            "DANSK": "DANISH",
            "ESPAÑOL": "SPANISH",
            "ENGLISH": "ENGLISH"}
    return subs[subtitle_lang]
