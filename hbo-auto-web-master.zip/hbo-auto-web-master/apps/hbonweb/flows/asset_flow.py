from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.series_page import Series


def get_asset_page(driver, asset):
    return Movie(driver) if asset.type == "movie" else Series(driver)
