import re
from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.watchlist_page import Watchlist
from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.series_page import Series

from apps.hbonweb.flows.search_flow import search_item, \
    open_first_search_result
from apps.hbonweb.flows.series_flow import open_season_and_episode
from apps.hbonshared.api_flow import get_asset_metadata

from apps.hbonshared.resourcesmanager import ResourcesManager as RM
from helpers.enums import Region


def is_watchlist_full(watchlist):
    """Checks is watchlist full, returns True if Full (has 30 assets)"""
    return True if len(watchlist) == 30 else False


def is_kids_asset_in_watchlist(watchlist):
    """Checks are there any kids assets in the watchlist"""
    return True if any(asset['TYPE'] == 'FAMILY' or asset['TYPE']
                       == 'FAMILY MOVIE' for asset in watchlist) else False


def is_each_asset_clickable(driver, from_page=Watchlist):
    """
    Clicks on each asset in the watchlist,
    returns True if all are clickable
    """
    page = from_page(driver)
    watchlist_results = page.get_watchlist_results()

    for i in range(0, len(watchlist_results)):
        watchlist_asset = "//ul//figure[contains" \
            f"(@data-automation, 'watchlist-results-{i}')]" \
            "//figcaption[@class='caption']"
        page.helper.click(watchlist_asset)
        page.click_on_watchlist_link()
        page.driver.helper.scroll(
            page.helper.get_location(watchlist_asset)['x'],
            page.helper.get_location(watchlist_asset)['y'] - 200)
    return True


def add_asset_to_watchlist(driver, title, asset_type, season=0, episode=0):
    search_item(driver, title)
    open_first_search_result(driver)
    sleep(10)
    # Series
    if asset_type == "series":
        page = Series(driver)
        if season > 0 and episode > 0:
            open_season_and_episode(driver, season, episode)
            page.driver.helper.scroll_to_bottom()
        page.click_on_add_to_watchlist_button()
    # Movie
    elif asset_type == "movie":
        page = Movie(driver)
        page.driver.helper.scroll_to_bottom()
        page.click_on_add_to_watchlist_button()


def get_watchlist_assets_titles(driver, from_page=Watchlist):
    """Returns list with titles of assets visible in the watchlist"""
    page = from_page(driver)
    watchlist_results = page.get_watchlist_results()
    watchlist_assets = []

    for i in range(0, len(watchlist_results)):
        watchlist_asset_name = "//ul//figure[contains" \
            f"(@data-automation, 'watchlist-results-{i}')]" \
            "//figcaption[@class='caption']//a//span"
        watchlist_assets.append(page.get_asset_title(watchlist_asset_name))
    return watchlist_assets


def is_watchlist_recently_added_sorted(driver, titles):
    """Returns True if watchlist sorted by date added"""
    return True if get_watchlist_assets_titles(driver)[::-1] == titles \
        else False


def is_watchlist_a_z_sorted(driver, titles):
    """Returns True if watchlist sorted alphabetically"""
    return True if sorted(get_watchlist_assets_titles(driver)) == \
        sorted(titles) else False


def is_watchlist_release_date_sorted(driver, user, assets):
    """Returns True if watchlist sorted by release date"""
    release_dates = []

    for a in assets:
        metadata = get_asset_metadata(user, a)
        release_dates.append(re.search("(\\d{4}-\\d{2}-\\d{2})",
                                       metadata['available']).group())

    return True if sorted(release_dates, reverse=True) == release_dates \
        else False
