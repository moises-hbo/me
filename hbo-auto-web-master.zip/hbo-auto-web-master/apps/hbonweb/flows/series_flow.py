from helpers.sleeper import Sleeper as sleep
import random
import re

from apps.hbonweb.pages.series_page import Series

from helpers.utility_functions import is_year_format_valid


def is_right_series_title_displayed(driver, title, from_page=Series):
    """Compares displayed title and actual searched title"""
    page = from_page(driver)
    displayed_title = page.get_series_title()
    return displayed_title == title


def switch_seasons_in_navbar(driver, from_page=Series):
    """Switches season tabs, clicks on each tab 'show more/less'
        button, checks on each tab metadata visibility"""
    page = from_page(driver)
    seasons_navbar = page.get_seasons_list()

    seasons_navbar_loc = page.get_seasons_navbar_location()
    driver.helper.scroll(seasons_navbar_loc["x"],
                         seasons_navbar_loc["y"] - 160)
    page.helper.is_visible(seasons_navbar)

    for season in seasons_navbar:
        driver.helper.scroll()
        page.click_on_season_link(season)
        if page.is_show_more_button_displayed():
            page.click_on_show_more_button()
        if not page.is_series_synopsis_displayed(timeout=1) or \
                not page.is_series_cast_displayed(timeout=1) or \
                not page.is_series_creator_displayed(timeout=1) or \
                not page.is_series_year_displayed(timeout=1) or \
                not is_series_year_format_valid(driver) or \
                not is_right_series_metadata_order(driver):
            return False
    return True


def is_series_year_format_valid(driver, from_page=Series):
    """Checks displayed year format (1900-2099)"""
    page = from_page(driver)
    displayed_year = page.get_series_year()
    return is_year_format_valid(displayed_year)


def is_right_series_metadata_order(driver, from_page=Series):
    """Checks metadata order on the series page"""
    page = from_page(driver)
    cast_loc = page.get_series_cast_location()
    creator_loc = page.get_series_creator_location()
    year_loc = page.get_series_year_location()

    return False if cast_loc['y'] >= creator_loc['y'] \
        or creator_loc['y'] >= year_loc['y'] else True


def open_season(driver, season_nr: int):
    page = Series(driver)
    seasons = page.get_seasons_list()

    for s in seasons:
        if page.helper.get_text(s).endswith(f" {season_nr}"):
            page.helper.click(s)
            return

    # Assuming there's no seasons, just "all episodes"
    page.helper.click(seasons[len(seasons) - 1])


def open_episode(driver, episode_name: str):
    page = Series(driver)
    episodes = page.get_episode_grid_list()

    # Look for episode
    for e in episodes:
        if page.helper.get_text(e).endswith(episode_name):
            s_loc = page.helper.get_location(e)
            page.driver.helper.scroll(0, s_loc["y"] - 250)
            page.helper.click(e)
            break


def open_season_and_episode(driver, season_nr, episode_name):
    open_season(driver, season_nr)
    open_episode(driver, episode_name)


def open_s1_e1(driver, from_page=Series):
    """Opens season 1 episode 1 of the series"""
    page = from_page(driver)
    sleep(3)
    s1_e1_loc = page.helper.get_location(page.assets_season_episode_mark)
    page.driver.helper.scroll(s1_e1_loc['x'], s1_e1_loc['y'] - 150)
    page.helper.click(page.assets_season_episode_mark)


def open_random_episode(driver, from_page=Series):
    """Opens random episode in random season"""
    page = from_page(driver)
    seasons_navbar_loc = page.get_seasons_navbar_location()
    page.driver.helper.scroll(seasons_navbar_loc["x"],
                              seasons_navbar_loc["y"] - 160)

    seasons_navbar = page.get_seasons_list()
    random_season = random.choice(seasons_navbar)
    page.click_on_season_link(random_season)

    episode_grid = page.get_episode_grid_list()
    random_episode = random.choice(episode_grid)
    random_episode_loc = page.get_episode_location(random_episode)
    page.driver.helper.scroll(random_episode_loc['x'],
                              random_episode_loc['y'] - 160)
    page.click_on_episode_link(random_episode)

    random_episode_number = get_episode_or_season_number(
        driver.current_url, 'episode')
    random_episode_season_number = get_episode_or_season_number(
        driver.current_url, 'season')
    return random_episode_number, random_episode_season_number


def get_episode_or_season_number(episode_url, season_episode):
    """Returns season/episode number of random_episode"""
    return re.search(f'(?<={season_episode}-)[0-9]+', episode_url).group()


def is_right_episode_poster_displayed(driver, from_page=Series):
    """Compares episode title name and episode poster name(thumbnail image)"""
    page = from_page(driver)
    displayed_poster_title = page.get_episode_poster_label()
    displayed_episode_title = page.get_episode_title()
    return displayed_poster_title == displayed_episode_title


def is_series_overview_correctly_displayed(driver):
    """Checks for series metadata visibility"""
    page = Series(driver)
    return page.is_series_rating_displayed() and \
        page.is_series_genre_displayed() and \
        page.is_series_synopsis_displayed() and \
        page.is_series_cast_displayed() and \
        page.is_series_creator_displayed() and \
        page.is_series_year_displayed() and \
        page.is_series_add_to_watchlist_button_displayed() and \
        page.is_series_play_button_displayed() and \
        page.is_series_episode_name_displayed() and \
        page.is_series_season_episode_mark_displayed()


def is_episode_overview_correctly_displayed(driver, asset_metadata,
                                            asset_duration):
    """Checks for episode metadata visibility"""
    page = Series(driver)
    if asset_metadata.get("rating") != 'UNRATED':
        return page.is_episode_rating_displayed()
    elif asset_metadata.get("keywords"):
        return page.is_episode_genre_displayed()
    elif asset_metadata.get("title"):
        return page.is_episode_title_displayed()
    elif asset_metadata.get("description"):
        return page.is_series_synopsis_displayed()
    elif asset_duration:
        return page.is_series_duration_displayed()
    elif asset_metadata.get("actors"):
        return page.is_series_cast_displayed()
    elif asset_metadata.get("director"):
        return page.is_series_creator_displayed()
    elif asset_metadata.get("year"):
        return page.is_series_year_displayed()
    return page.is_episode_add_to_watchlist_button_displayed() and \
        page.is_episode_play_button_displayed()
