from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.loginform_page import AdultKidsSelection, LoginForm
from apps.hbonweb.pages.myaccount_page import MyAccount
from apps.hbonweb.pages.pin_page import Pin


class Section(object):
    """enum class for choosing section."""
    ADULT = "adult"
    KIDS = "kids"


def choose_section(driver, go_to_section=Section.ADULT):
    """Flow to choose section after successful login. Defaults to adult.
    'go_to_section' is the section we choose after successful login."""
    page = AdultKidsSelection(driver)
    if go_to_section is Section.ADULT and \
            page.is_series_movies_button_displayed(60):
        sleep(1)
        page.click_on_series_movies_button()
        return Home(driver)
    elif go_to_section is Section.KIDS and \
            page.is_kids_button_displayed(60):
        sleep(1)
        page.click_on_kids_button()
        return Kids(driver)


def login_without_section(driver, email, password, from_page=WhyHBO,
                          go_to_login=True):
    """Flow to login. Does not choose section as part of function after
    trying to login.
    'from_page' is the page object we are supposed to be on when we
    press the login button."""
    page = from_page(driver)
    if go_to_login:
        page.click_on_sign_in_link()  # Switches page to the login page
    page = LoginForm(driver)
    page.clear_text_on_email()
    page.input_text_on_email(email)
    page.clear_text_on_password()
    page.input_text_on_password(password)
    page.click_on_submit_button()  # Switches page to the section selector


def login(driver, email, password, from_page=WhyHBO, 
          go_to_section=Section.ADULT, is_mobile_web=False, first_login=False,
          go_to_login=True):
    """Flow to login. Logs in and chooses section to enter after successful login.
    'from_page' is the page object we are supposed to be on when we
    press the login button.
    'go_to_section' is the section we choose after successful login."""
    login_without_section(driver, email, password, from_page, go_to_login)
    if not is_mobile_web:
        page = choose_section(driver, go_to_section)
        # If it's the first time we login, will see create PIN
        if first_login:
            Pin(driver).click_on_dont_ask_again_link()
        return page

    LoginForm(driver).wait_for_loading_pulse_to_disappear()
    return Home(driver)


def logout(driver, from_page=Home):
    page = from_page(driver)
    if not isinstance(page, MyAccount):
        page.click_on_my_account_link()

    page = MyAccount(driver)
    page.click_on_sign_out_link()

    return WhyHBO(driver)
