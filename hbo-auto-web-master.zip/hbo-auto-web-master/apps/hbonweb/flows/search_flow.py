from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.search_page import Search
from apps.hbonweb.pages.series_page import Series
from apps.hbonweb.pages.movie_page import Movie
from apps.hbonweb.pages.kids_page import Kids

from apps.hbonweb.flows.series_flow import open_season_and_episode

from helpers.configmanager import ConfigManager

cm = ConfigManager()


def search_item(driver, item_name):
    page = Navigation(driver)
    page.click_on_search_button()
    page = Search(driver)
    sleep(1)
    page.input_text_on_search(item_name)
    if not page.have_search_results_returned():
        raise ValueError("None of the expected search "
                         "responses were seen!")


def is_item_on_search_result(driver, item_path, searched_item,
                             from_page=Search):
    page = from_page(driver)
    try:
        title = page.helper.get_text(item_path)
    except AttributeError:
        return False
    return searched_item in title


def is_no_search_result(driver, from_page=Search):
    page = from_page(driver)
    return page.is_no_search_result_displayed()


def is_search_waiting_for_input(driver, from_page=Search):
    page = from_page(driver)
    return page.is_search_more_input_displayed()


def can_interact_with_first_search_result(driver, from_page=Search):
    page = from_page(driver)
    page.hover_on_result_item()
    return page.is_play_button_displayed()


def can_open_first_search_result(driver, from_page=Search):
    page = from_page(driver)
    try:
        page.click_on_first_search_result()
    except Exception:
        return False
    return True


def can_play_first_search_result(driver, from_page=Search):
    page = from_page(driver)
    page.hover_on_result_item()
    page.play_first_search_result()
    return True


def open_first_search_result(driver, from_page=Search):
    sleep(1)  # Potential fix for unstable test cases
    open_search_result(driver, 0)


def open_search_result(driver, index=0):
    page = Search(driver)
    if page.is_search_result_grid_displayed(0):
        driver.helper.move_mouse_to(page.helper.get(
                                    page.get_search_result_path(index)))
        driver.helper.move_mouse_about(35, 35)
        driver.helper.click_on_screen()
    elif page.is_mobile_search_result_list_displayed(0):
        page.click_on_mobile_search_result(index)
    sleep(1)


def open_recent_search_result(driver, index=0, from_page=Search):
    page = from_page(driver)
    if not isinstance(page, Search):
        page.click_on_search_button()
        page = Search(driver)
    page.driver.helper.move_mouse_to(
        page.helper.get(page.get_search_recent_result_path(index)))
    driver.helper.move_mouse_about(35, 35)
    driver.helper.click_on_screen()
    sleep(1)


def open_sequently_search_results(driver, number_of_assets, phrase,
                                  from_page=Search):
    page = from_page(driver)
    titles = []
    for index in range(0, number_of_assets):
        search_item(driver, phrase)
        titles.append(page.get_title_of_search_result(index))
        open_search_result(driver, index)
        page.click_on_hbo_logo_img()
    return titles


def get_all_titles_from_search_result(driver, from_page=Search):
    page = from_page(driver)
    is_more_results = True
    number_of_asset = 0
    titles = []

    while is_more_results:
        try:
            titles.append(page.get_title_of_search_result(number_of_asset))
            number_of_asset += 1
        except Exception:
            is_more_results = False

    return titles


def is_search_result_in_list(driver, from_page=Search):
    page = from_page(driver)
    return not page.is_search_result_row_displayed()


def is_search_result_in_grid(driver, from_page=Search):
    page = from_page(driver)
    return page.is_search_result_row_displayed() and \
        page.is_search_result_grid_displayed()


def search_movie_open(driver, title):
    search_item(driver, title)
    open_first_search_result(driver)
    return Movie(driver)


def search_series_open_episode(driver, title, season, episode_name):
    search_item(driver, title)
    open_first_search_result(driver)
    open_season_and_episode(driver, season, episode_name)
    return Series(driver)


def search_asset_open(driver, asset, original_title=False, lock_kids=True):
    title = asset.original_title if original_title else asset.title
    if asset.type == "series":
        page: Series = search_series_open_episode(driver, title, asset.season,
                                                  asset.ep_name)
    elif asset.type == "movie":
        page: Movie = search_movie_open(driver, title)

    if asset.section == "kids":
        kids = Kids(driver)
        if lock_kids and not kids.is_kids_mode_locked():
            kids.click_on_lock_button()
        # Open episode if already kids mode will start playback
        else:
            sleep(25 if cm.region == "spain" else 10)
    return page
