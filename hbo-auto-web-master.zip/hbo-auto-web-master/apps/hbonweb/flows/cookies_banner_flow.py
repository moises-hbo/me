from helpers.sleeper import Sleeper as sleep
from apps.hbonweb.pages.cookie_banner_overlay import CookieBanner, \
    CookieReadMore


def is_cookies_banner_shown(driver, timeout=10):
    cb = CookieBanner(driver)
    return cb.is_cookies_banner_displayed(timeout=timeout) \
        and cb.is_accept_button_displayed(timeout=0) \
        and cb.is_read_more_button_displayed(timeout=0)


def accept_cookie_banner(driver):
    page = CookieBanner(driver)
    page.click_on_accept_button()


def click_all_data_policy_checkboxes(driver):
    page = CookieReadMore(driver)
    labels = page.get_data_policy_option_labels()

    for l in labels:
        page.helper.click(l)
        sleep(0.25)


def are_all_data_policy_checkboxes_checked(driver):
    """If expect is False, and all checked are False,
    returns True"""
    page = CookieReadMore(driver)
    checkboxes = page.get_data_policy_option_checkboxes()

    for cb in checkboxes:
        checked = page.is_data_policy_option_checked(cb)
        if not checked:
            return False
    return True


def are_all_data_policy_option_descriptions_displayed(driver):
    page = CookieReadMore(driver)
    for h, d in page.get_data_policy_option_headers_and_descs():
        htext = page.helper.get_text(h)
        dtext = page.helper.get_text(d)
        # Shortest header: "Bing" / 4 chars
        if not len(htext) >= 4 or not len(dtext) > 20:
            return False
    return True


def are_specific_data_policy_options_checked(driver, facebook, google,
                                             twitter, bing, thirdparty):
    page = CookieReadMore(driver)
    f = page.is_data_policy_option_checked(page.facebook_option_checkbox)
    g = page.is_data_policy_option_checked(page.google_option_checkbox)
    t = page.is_data_policy_option_checked(page.twitter_option_checkbox)
    bi = page.is_data_policy_option_checked(page.bing_option_checkbox)
    bl = page.is_data_policy_option_checked(page.thirdparty_option_checkbox)
    return f == facebook and g == google and \
        t == twitter and bi == bing and bl == thirdparty
