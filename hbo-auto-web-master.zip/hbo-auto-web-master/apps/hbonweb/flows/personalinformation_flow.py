from apps.hbonweb.pages.myaccount_page import MyAccount, \
    UpdatePersonalInformation


def change_user_info(driver, firstname="", lastname="", email="",
                     newsletter=False, save_changes=False, password=""):
    page = MyAccount(driver)
    if firstname:
        page.input_text_on_first_name(firstname)
    if lastname:
        page.input_text_on_last_name(lastname)
    if email:
        page.input_text_on_email(email)
    # NOTE: workaround since newsletter checkbox is bugged
    page.click_on_newsletter_button()
    if newsletter:
        if not page.is_newsletter_checkbox_active():
            page.click_on_newsletter_button()
    elif not newsletter:
        if page.is_newsletter_checkbox_active():
            page.click_on_newsletter_button()
    if save_changes:
        page.click_on_save_changes_button()
        if email and password:
            page = UpdatePersonalInformation(driver)
            page.input_text_on_password(password)
            page.click_on_submit_button()
    return MyAccount(driver)


def change_password(driver, old, new, save_changes=False):
    page = MyAccount(driver)
    page.input_text_on_current_password(old)
    page.input_text_on_new_password(new)
    page.input_text_on_confirm_password(new)
    if save_changes:
        page.click_on_change_password_button()
