from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.signup_page import SignUp, GetStarted, Voucher
from apps.hbonweb.pages.payment_page import PaymentDetails
from apps.hbonweb.pages.home_page import WhyHBO, Home
from apps.hbonweb.pages.myaccount_page import MyAccount

from helpers.logger import Log


def enter_signup_info(driver, email, password, no_news_offers=True,
                      code=None):
    page = SignUp(driver)
    page.input_text_on_email_field(email)
    page.input_text_on_password_field(password)

    if no_news_offers:
        page.click_on_no_news_offers_checkbox()  # Inactive by default
        sleep(0.5)

    if code:
        page.click_on_add_voucher_button()

        page = Voucher(driver)
        page.input_text_on_voucher_field(code)
        page.click_on_add_voucher_button()


def enter_signup_info_and_continue(driver, email, password,
                                   no_news_offers=True, code=None):
    enter_signup_info(
        driver, email, password, no_news_offers, code)
    page = SignUp(driver)
    page.click_on_continue_button()

    page.wait_for_signin_button_to_disappear()
    sleep(1)
    return PaymentDetails(driver)


def create_new_user_and_go_to_home(driver, email, password,
                                   no_news_offers=True,
                                   code=None, accept_getstarted=True):
    WhyHBO(driver).click_on_free_trial_button()
    enter_signup_info_and_continue(
        driver, email, password, no_news_offers, code)
    page = SignUp(driver)
    sleep(3)
    page.click_on_hbo_logo_img()

    if accept_getstarted:
        page = GetStarted(driver)
        if page.is_get_started_page(3):
            page.click_on_accept_button()

    page = Home(driver)
    page.is_my_account_link_displayed()
    return page


def is_signup_field_labels_visible(driver):
    page = SignUp(driver)
    vd_loc = page.helper.get_location_when_visible(page.add_voucher_button)
    page.driver.helper.scroll(vd_loc["x"], vd_loc["y"])

    return page.is_email_label_displayed() \
        and page.is_password_label_displayed() \
        and page.is_add_voucher_button_displayed()


def register_user_and_go_to_myaccount(
        driver, email, password, no_news_offers):
    WhyHBO(driver).click_on_free_trial_button()
    page = SignUp(driver)

    page = enter_signup_info_and_continue(
        driver, email, password, no_news_offers=no_news_offers)

    page.click_on_hbo_logo_img()

    page = GetStarted(driver)
    page.click_on_accept_button()

    page = Home(driver)
    page.click_on_my_account_link()

    return MyAccount(driver)


def enter_credit_card_info(driver, credit_card_number, cvv_code,
                           credit_card_nameholder,
                           expiration_month=None,
                           expiration_year=None, submit=True):
    page = PaymentDetails(driver)
    page.wait_until_payment_submit_button_displayed()
    sleep(3)
    page.enter_payment_iframe()

    page.enter_text_on_cc(credit_card_number)
    page.drop_down_in_exp_month_by_value(expiration_month)
    page.drop_down_in_exp_year_by_value(expiration_year)
    page.enter_text_on_cc_cvv(cvv_code)
    page.enter_text_on_cc_holder_name(credit_card_nameholder)

    page.exit_payment_iframe()
    if submit:
        page.click_on_cc_submit_button()
        return GetStarted(driver)
    return PaymentDetails(driver)


def do_complete_registration(driver, user, creditcard, accept_getstarted=True,
                             goto_signup=False):
    if goto_signup:
        WhyHBO(driver).click_on_free_trial_button()
    enter_signup_info_and_continue(
        driver, user.email, user.password)
    enter_credit_card_info(
        driver, creditcard.number, creditcard.cvv, creditcard.name)
    page = GetStarted(driver)
    if accept_getstarted:
        # TODO: Temporary bug workaround
        if not page.is_get_started_page(10):
            Home(driver).click_on_home_logged_in_link()
        page.click_on_accept_button()
        page = Home(driver)
        page.is_my_account_link_displayed(timeout=10)
        return page
    else:
        getstarted = page.is_get_started_page()
        if getstarted:
            return page
        page = Home(driver)
        return page


def wait_for_payment_iframe_to_disappear(driver, timeout=30):
    Log("Waiting for payment iframe to be gone.\n")
    while PaymentDetails(driver).is_payment_frame_displayed(0):
        timeout -= 1
        if timeout <= 0:
            Log("Payment iframe still seen after "
                f"timeout hit at: {timeout}")
            break


def wait_for_payment_page_to_disappear(driver, timeout=30):
    wait_for_payment_iframe_to_disappear(driver, timeout)
    Log("Waiting for payment page to be gone.\n")
    while PaymentDetails(driver).is_payment_page(0):
        sleep(1)
        timeout -= 1
        if timeout <= 0:
            Log(
                "Payment page was still visible "
                f"after timeout hit at: {timeout}\n")
            break


def did_we_successfully_register_and_return_to_home(driver):
    page = Home(driver)
    return page.is_home_logged_in_active_link_displayed() and \
        page.is_welcome_header_displayed()


def did_we_successfully_register_and_subscribe_and_return_to_home(driver):
    page = Home(driver)
    return not PaymentDetails(driver).is_payment_frame_displayed(timeout=1) \
        and did_we_successfully_register_and_return_to_home(driver) \
        and not page.is_complete_registration_banner_displayed(
        timeout=1)


def are_non_interactive_payment_elements_within_iframe_visible(driver):
    page = PaymentDetails(driver)
    return page.is_label_credit_card_number_displayed() and \
        page.is_label_card_expiration_displayed() and \
        page.is_cvv_image_displayed() and \
        page.is_label_cc_holder_displayed()


def are_non_interactive_payment_elements_outside_iframe_visible(driver):
    page = PaymentDetails(driver)
    return page.is_legal_message_displayed()


def is_card_type_visible(driver):
    page = PaymentDetails(driver)
    sleep(1)
    return page.is_card_image_visa_displayed()


def enter_4digit_card(driver, creditcard):
    page = PaymentDetails(driver)
    page.enter_payment_iframe()
    page.enter_text_on_cc(creditcard.number[:4])
