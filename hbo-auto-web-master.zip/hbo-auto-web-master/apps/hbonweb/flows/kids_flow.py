from apps.hbonweb.pages.kids_page import Kids
from apps.hbonweb.pages.pin_page import Pin
from apps.hbonweb.flows.pin_flow import input_pin_code


def go_to_kids_locked(driver, from_page=Kids):
    page = from_page(driver)
    page.click_on_kids_link()
    page.click_on_got_it_alert_button()
    page.click_on_lock_button()


def go_out_from_kids_locked(driver, pin, from_page=Kids):
    page = from_page(driver)
    page.click_on_lock_button()
    page = Pin(driver)
    if page.is_exit_kids_page_title_displayed(2):
        input_pin_code(driver, pin)
