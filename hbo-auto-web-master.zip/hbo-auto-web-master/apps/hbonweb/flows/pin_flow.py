from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.pin_page import Pin


def input_pin_code(driver, pin, from_page=Pin):
    pin_length = 4

    try:
        int(pin)
    except ValueError as ve:
        raise ve("PIN is not a number")

    if len(str(pin)) != pin_length:
        raise ValueError("PIN has to contain 4 digits")

    page = Pin(driver)
    page.enter_pin(pin)
    sleep(1.5)
