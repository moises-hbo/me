from helpers.sleeper import Sleeper as sleep

from helpers.configmanager import ConfigManager

from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter

from apps.hbonshared.resourcesmanager import Language

cm = ConfigManager()


def click_on_cookies_banner_close_button(driver,
                                         from_page=CopyrightLanguageFooter):
    page = from_page(driver)
    page.driver.helper.move_mouse_to(page.cookies_banner_close_button)
    # Just clicking on button throws "Element is not visible"
    page.helper.move_mouse_about(20, 5)
    page.helper.click_on_screen()


def change_language_to(driver, lang=Language.EN,
                       from_page=CopyrightLanguageFooter):
    page = from_page(driver)
    page.driver.helper.scroll_to_bottom()
    if lang == Language.EN:
        page.select_english_language()
    elif lang == Language.DK:
        page.select_danish_language()
    elif lang == Language.NO:
        page.select_norwegian_language()
    elif lang == Language.FI:
        page.select_finish_language()
    elif lang == Language.SE:
        page.select_swedish_language()
    elif lang == Language.ES:
        page.select_spanish_language()
    else:
        raise AttributeError()
    sleep(3)  # For page load


def change_language_to_nonactive(driver, from_page=CopyrightLanguageFooter):
    page = from_page(driver)
    page.driver.helper.scroll_to_bottom()
    sleep(1)

    # Change to English by default
    lang = Language.EN
    if cm.lang_id == "english":
        if cm.region == "nordic":
            lang = Language.SE
        elif cm.region == "spain":
            lang = Language.ES
    change_language_to(driver, lang)
