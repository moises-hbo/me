from apps.hbonweb.pages.movie_page import Movie

from helpers.utility_functions import *


def is_right_movie_title_displayed(driver, title, from_page=Movie):
    """Compares displayed title and actual searched title"""
    page = from_page(driver)
    displayed_title = page.get_movies_title()
    return displayed_title == title


def is_right_movie_poster_displayed(driver, poster_title, from_page=Movie):
    """Compares episode title name and movie poster name(thumbnail image)"""
    page = from_page(driver)
    displayed_poster_title = page.get_movies_poster_label()
    return displayed_poster_title == poster_title


def is_movie_year_format_valid(driver, from_page=Movie):
    """Checks displayed year format (1900-2099)"""
    page = from_page(driver)
    displayed_year = page.get_movies_year()
    return is_year_format_valid(displayed_year)


def is_right_movie_metadata_order(driver, from_page=Movie):
    """Checks metadata order on the movie page"""
    page = from_page(driver)
    duration_loc = page.get_movies_duration_location()
    year_loc = page.get_movies_year_location()
    if not page.is_movies_lock_button_displayed():
        cast_loc = page.get_movies_cast_location()
        director_loc = page.get_movies_director_location()
        return False if duration_loc['y'] >= cast_loc['y'] \
                        or cast_loc['y'] >= director_loc['y'] \
                        or director_loc['y'] >= year_loc['y'] else True
    else:
        return False if duration_loc['y'] >= year_loc['y'] else True


def is_movie_overview_correctly_displayed(driver, asset_metadata, asset_duration):
    """Checks for movie metadata visibility"""
    page = Movie(driver)
    if asset_metadata["rating"] != 'UNRATED':
        return page.is_movies_rating_displayed()
    elif asset_metadata["keywords"]:
        return page.is_movies_genre_displayed()
    elif asset_metadata["description"]:
        return page.is_movies_synopsis_displayed()
    elif asset_duration:
        return page.is_movies_duration_displayed()
    elif asset_metadata["year"]:
        return page.is_movies_year_displayed()
    return page.is_movies_add_to_watchlist_button_displayed() and \
        page.is_movies_play_button_displayed()
