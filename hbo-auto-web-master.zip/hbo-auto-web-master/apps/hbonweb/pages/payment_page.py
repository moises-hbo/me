from time import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.common.exceptions import TimeoutException

from apps.hbonweb.pages.base.page import BasePageObject as Page
from apps.hbonweb.pages.navigation_partial import NavigationLogo
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter
from apps.hbonweb.pages.signup_page import RegistrationSteps, SignUpProductBox

from helpers.sleeper import Sleeper as sleep

class PaymentDetails(NavigationLogo, CopyrightLanguageFooter,
                     RegistrationSteps, SignUpProductBox):
    def __init__(self, driver):
        super().__init__(driver)
        self.paypal_tab = "//div[@id='paypal']"
        self.paypal_button = self.paypal_tab + "/div/button"
        self.cc_tab = "//div[@id='zuora_payment']"
        self.payment_header = "//h1[@class='XOtw6 LD_c1']"
        self.payment_frame = "//*[@id='z_hppm_iframe']"
        self.payment_submit_button = \
            "//button[@data-analytics='payment-details']"
        self.credit_card_input = "//*[@id='input-creditCardNumber']"
        self.credit_card_input_error = dict(
            locator="div#error-creditCardNumber", type=By.CSS_SELECTOR)
        self.credit_card_exp_month_dropdown = \
            "//select[@name='field_creditCardExpirationMonth']"
        self.credit_card_exp_month_selected = \
            self.credit_card_exp_month_dropdown + \
            "/option[@selected='selected']"
        self.credit_card_exp_year_dropdown = \
            "//select[@name='field_creditCardExpirationYear']"
        self.credit_card_exp_year_selected = \
            self.credit_card_exp_year_dropdown + \
            "/option[@selected='selected']"
        self.credit_card_exp_error = dict(
            locator="div#error-creditCardExpirationMonth",
            type=By.CSS_SELECTOR)
        self.credit_card_cvv_input = "//input[@id='input-cardSecurityCode']"
        self.credit_card_cvv_label = \
            "//label[@id='form-label-cardSecurityCode']"
        self.credit_card_cvv_input_error = dict(
            locator="div#error-cardSecurityCode", type=By.CSS_SELECTOR)
        self.credit_card_holder_input = "//*[@id='input-creditCardHolderName']"
        self.credit_card_holder_input_error = dict(
            locator="div#error-creditCardHolderName", type=By.CSS_SELECTOR)
        self.credit_card_submit_button = \
            "//form/div[contains(@class,'pulse-button')]" \
            "//button[@data-analytics='payment-details']"
        self.label_credit_card_number = \
            "//*[@id='form-label-creditCardNumber']"
        self.label_creditcard_holder = \
            "//label[@id='form-label-creditCardHolderName']"
        self.label_card_expiration = \
            "//label[@id='form-label-creditCardExpirationMonth']"
        self.legal_message = "//div[contains(@class, '_1EsWS')]"
        self.legal_message_withdraw_link = "//button[@class='_3vFNj']"
        self.cvv_image = "//img[@class='image-cvv']"
        self.cvv_image_preview = "//div[@id='vvDes']"
        self.card_image_visa = \
            "//div[@id='card-image-container-Visa']"
        self.card_image_visa_active = self.card_image_visa.replace(
            "]", " and @aria-hidden='false']")
        self.card_image_master = \
            "//div[@id='card-image-container-MasterCard']"
        self.card_image_master_active = self.card_image_master.replace(
            "]", " and @aria-hidden='false']")
        self._loading_pulse = \
            "//body[@class='ready hide-focus-outlines ui-overlay-active']"
        self._loading_pulse_inactive = \
            "//body[@class='ready hide-focus-outlines ui-overlay-inactive']"
        self.paypal_modal_iframe = "//iframe[@title='PayPal Checkout Overlay']"
        self.paypal_modal = "//div[@class='paypal-checkout-modal']"
        self.paypal_modal_continue = \
            "//div[@class='paypal-checkout-continue']/a"
        self.paypal_submit_button = \
            "//div[@class='pulse-button _3ViRN']/button"
        self.paypal_checkout_logo = "//img[@class='_3Zw1r']"
        self.pp_checkout_sub_type_text = "//p[@class='_1iA9F']"
        self.pp_checkout_email_text = "//p[@class='Khn5q']"
        self.pp_checkout_change_payment_button = "//a[@class='_1XEHt _1Ojdv']"
        self.alert_snackbar = dict(
            locator="div[data-automation='form-server-error']",
            type=By.CSS_SELECTOR)
        # Locator differ on Payment page
        self.product_box = self.product_box.replace(
            "sign-upproduct-box", "undefinedproduct-box")
        self.bullet_points_texts = self.bullet_points_texts.replace(
            "sign-upproduct-box", "undefinedproduct-box")
        self.bullet_points_subtexts = self.bullet_points_subtexts.replace(
            "sign-upproduct-box", "undefinedproduct-box")

    def is_payment_page(self, timeout=10):
        return self.is_step_2_active()

    def is_payment_no_signup_page(self, timeout=10):
        return self.is_payment_header_displayed(timeout)

    def enter_payment_iframe(self):
        payment_iframe = self.helper.get(self.payment_frame, 30)
        self.wait_until_payment_submit_button_displayed()
        self.driver.helper.enter_iframe(payment_iframe)
        sleep(1)

    def exit_payment_iframe(self):
        self.driver.helper.exit_iframe()
        sleep(1)

    def enter_paypal_modal_iframe(self):
        self.driver.helper.enter_iframe(
            self.helper.get(self.paypal_modal_iframe))

    def exit_paypal_modal_iframe(self):
        self.exit_payment_iframe()

    def click_on_cc_submit_button(self):
        self.helper.click(self.credit_card_submit_button)
        sleep(1)
        t1 = time()
        try:
            while self.helper.get(self._loading_pulse, 1):
                sleep(1)
                if time() - t1 > 30:
                    break
        except TimeoutException:
            pass
        if self.helper.get(self._loading_pulse_inactive, 5):
            sleep(2)

    def click_on_paypal_button(self, timeout=30):
        pp = self.get_paypal_button(timeout)
        self.driver.execute_script("arguments[0].click();", pp)
        sleep(7)

    def click_on_paypal_modal_continue_button(self, timeout=4):
        self.helper.click(self.paypal_modal_continue, timeout)

    def click_on_paypal_submit_button(self, timeout=10):
        self.is_paypal_submit_button_displayed()
        sleep(2)
        self.helper.click(self.paypal_submit_button, timeout)

    def click_on_legal_withdraw_right_link(self, timeout=5):
        self.helper.click(self.legal_message_withdraw_link, timeout)

    def click_on_cvv_image(self, timeout=5):
        self.helper.click(self.cvv_image, timeout)

    def click_on_pp_checkout_change_payment_button(self, timeout=5):
        self.helper.click(self.pp_checkout_change_payment_button, timeout)

    def enter_text_on_cc(self, text):
        self.helper.input_text(self.credit_card_input, text,
                               locator_type=By.XPATH)
        sleep(0.5)

    def enter_text_on_cc_cvv(self, text):
        self.helper.input_text(self.credit_card_cvv_input, text)
        sleep(0.5)

    def enter_text_on_cc_holder_name(self, text):
        self.helper.input_text(self.credit_card_holder_input, text,
                               locator_type=By.XPATH)

    def drop_down_in_exp_month(self, index=None):
        self._drop_down_in_dropdown(
            self.driver, self.credit_card_exp_month_dropdown, index)
        sleep(0.5)

    def drop_down_in_exp_month_by_value(self, value=None):
        self._drop_down_in_dropdown_by_value(
            self.driver, self.credit_card_exp_month_dropdown, value)

    def drop_down_in_exp_year_by_value(self, value=None):
        self._drop_down_in_dropdown_by_value(
            self.driver, self.credit_card_exp_year_dropdown, value)

    def drop_down_in_exp_year(self, index=None):
        self._drop_down_in_dropdown(
            self.driver, self.credit_card_exp_year_dropdown, index)
        sleep(0.5)

    def get_text_of_selected_in_exp_month(self):
        sel = self._get_selected_from_dropdown(
            self.driver, self.credit_card_exp_month_dropdown)
        return self.helper.get_text(sel)

    def get_text_of_selected_in_exp_year(self):
        sel = self._get_selected_from_dropdown(
            self.driver, self.credit_card_exp_year_dropdown)
        return self.helper.get_text(sel)

    def get_paypal_button(self, timeout=20):
        ppbtns = self.helper.get_list(self.paypal_button, timeout)
        timestamp = time()
        while len(ppbtns) < 2:
            sleep(5)
            ppbtns = self.helper.get_list(self.paypal_button, timeout)
            if time() - timestamp > timeout:
                raise TimeoutException(
                    "Timeout was hit looking for Paypal button!")
        return ppbtns[1]

    def get_text_of_cc_number_input(self):
        return self.helper.get_attribute(self.credit_card_input, "value")

    def get_text_label_credit_card_number(self):
        return self.helper.get_text(self.label_credit_card_number)

    def get_text_of_credit_card_holder_input(self):
        return self.helper.get_attribute(
            self.credit_card_holder_input, "value")

    def get_text_step_name(self):
        return self.helper.get_text(self.step_name_h3)

    def get_text_of_legal_message(self):
        return self.helper.get_text(self.legal_message)

    def get_color_of_legal_message(self):
        return self.helper.get_element_css_property(self.legal_message)

    def get_color_of_legal_withdraw_link(self):
        return self.helper.get_element_css_property(
            self.legal_message_withdraw_link)

    def get_text_decoration_of_legal_withdraw_link(self):
        return self.helper.get_element_css_property(
            self.legal_message_withdraw_link, css_property="text-decoration")

    def get_text_of_cc_exp_month_selected_option(self):
        return self.helper.get_text(self.credit_card_exp_month_selected)

    def get_text_of_cc_exp_year_selected_option(self):
        return self.helper.get_text(self.credit_card_exp_year_selected)

    def get_cc_tab(self):
        return self.helper.get(self.cc_tab)

    def get_paypal_tab(self):
        return self.helper.get(self.paypal_tab)

    def get_text_of_cvv_label(self):
        return self.helper.get_text(self.credit_card_cvv_label)

    def get_text_of_cvv_input(self):
        return self.helper.get_attribute(self.credit_card_cvv_input, "value")

    def get_text_of_cc_holder_label(self):
        return self.helper.get_text(self.label_creditcard_holder)

    def get_text_of_pp_checkout_email(self):
        return self.helper.get_text(self.pp_checkout_email_text)

    def get_location_of_cc_number_label(self, timeout=5):
        return self.helper.get_location(self.label_credit_card_number, timeout)

    def get_location_of_cc_number_label_error(self, timeout=5):
        return self.helper.get_location(self.credit_card_input_error, timeout)

    def is_payment_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.payment_header, timeout)

    def is_payment_frame_displayed(self, timeout=10):
        return self.helper.is_visible(self.payment_frame, timeout=timeout) \
            and self.helper.is_visible(self.payment_submit_button,
                                       timeout=timeout)

    def is_cc_input_displayed(self, timeout=4):
        return self.helper.is_visible(self.credit_card_input, timeout)

    def is_cc_date_month_selector_displayed(self, timeout=4):
        return self.helper.is_visible(
            self.credit_card_exp_month_dropdown, timeout)

    def is_cc_date_year_selector_displayed(self, timeout=4):
        return self.helper.is_visible(
            self.credit_card_exp_year_dropdown, timeout)

    def is_cc_cvv_input_displayed(self, timeout=4):
        return self.helper.is_visible(self.credit_card_cvv_input, timeout)

    def is_cc_cardholder_input_displayed(self, timeout=4):
        return self.helper.is_visible(self.credit_card_holder_input, timeout)

    def is_label_credit_card_number_displayed(self, timeout=5):
        return self.helper.is_visible(self.label_credit_card_number, timeout)

    def is_label_card_expiration_displayed(self, timeout=5):
        return self.helper.is_visible(self.label_card_expiration, timeout)

    def is_label_cc_holder_displayed(self, timeout=5):
        return self.helper.is_visible(self.label_creditcard_holder, timeout)

    def is_cvv_image_displayed(self):
        return self.helper.is_visible(self.cvv_image)

    def is_legal_message_displayed(self):
        return self.helper.is_visible(self.legal_message)

    def is_card_image_visa_displayed(self):
        # It's not seen as visible
        return self.helper.is_visible(self.card_image_visa)

    def is_card_image_mastercard_displayed(self):
        return self.helper.is_visible(self.card_image_master)

    def is_paypal_modal_displayed(self, timeout=5):
        return self.helper.is_visible(self.paypal_modal, timeout)

    def is_paypal_submit_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.paypal_submit_button, timeout)

    def is_paypal_button_displayed(self, timeout=5):
        pp = self.get_paypal_button()
        return self.helper.is_visible(pp, timeout)

    def is_cvv_image_preview_displayed(self, timeout=5):
        return self.helper.is_visible(self.cvv_image_preview, timeout)

    def is_cc_visa_active(self, timeout=2):
        return self.helper.is_visible(self.card_image_visa_active, timeout)

    def is_cc_master_active(self, timeout=2):
        return self.helper.is_visible(self.card_image_master_active, timeout)

    def is_pp_checkout_sub_type_text_displayed(self):
        return self.helper.is_visible(self.pp_checkout_sub_type_text)

    def is_pp_checkout_logo_displayed(self):
        return self.helper.is_visible(self.paypal_checkout_logo)

    def is_pp_checkout_change_payment_button_displayed(self):
        return self.helper.is_visible(self.pp_checkout_change_payment_button)

    def is_credit_card_cvv_label_displayed(self, timeout=5):
        return self.helper.is_visible(self.credit_card_cvv_label, timeout)

    def is_credit_card_input_error_displayed(self, timeout=5):
        return self.helper.is_visible(self.credit_card_input_error, timeout)

    def is_credit_card_exp_error_displayed(self, timeout=5):
        return self.helper.is_visible(self.credit_card_exp_error, timeout)

    def is_credit_card_cvv_error_displayed(self, timeout=5):
        return self.helper.is_visible(
            self.credit_card_cvv_input_error, timeout)

    def is_credit_card_holder_input_error_displayed(self, timeout=5):
        return self.helper.is_visible(
            self.credit_card_holder_input_error, timeout)

    def is_alert_snackbar_error_displayed(self, timeout=5):
        return self.helper.is_visible(self.alert_snackbar, timeout)

    def are_non_interactive_payment_elements_outside_iframe_visible(self):
        return self.helper.is_visible(self.step_name_h3) and \
            self.helper.is_visible(self.legal_message)

    def clear_text_on_cc_number(self):
        self.helper.clear_text(self.credit_card_input)

    def wait_until_payment_submit_button_displayed(self, timeout=40):
        visible = self.helper.wait_until_visible(
            self.payment_submit_button, timeout=timeout)
        sleep(1)
        return visible

    def wait_until_paypal_submit_button_clickable(self, timeout=20):
        clickable = self.helper.wait_until_clickable(
            self.paypal_submit_button, timeout=timeout)
        # Clicking too soon often causes an error
        sleep(5)
        return clickable

    def wait_until_paypal_checkout_overlay_gone(self, timeout=10):
        try:
            self.enter_paypal_checkout_iframe()
            visible = self.helper.wait_until_not_visible(
                self.paypal_checkout_logo, timeout)
            self.exit_paypal_checkout_iframe()
            return visible
        except TimeoutException:
            return True

    def hover_over_cvv_image(self):
        img = self.helper.get(self.cvv_image)
        self.driver.helper.move_mouse_to(img)

    def hover_over_legal_message_withdraw_link(self):
        link = self.helper.get(self.legal_message_withdraw_link)
        self.driver.helper.move_mouse_to(link)
        sleep(0.5)  # For animation

    def _drop_down_in_dropdown(self, driver, locator_or_element,
                               dropdown_index=None):
        sel_element = Select(self.helper.get(locator_or_element))
        if dropdown_index:
            index = dropdown_index
        else:
            index = len(sel_element.options) - 1
        sel_element.select_by_index(index)

    def _drop_down_in_dropdown_by_value(self, driver, locator_or_element,
                                        dropdown_value=None):
        sel_element = Select(self.helper.get(locator_or_element))
        if dropdown_value:
            val = dropdown_value
            sel_element.select_by_value(val)
        else:
            val = len(sel_element.options) - 1
            sel_element.select_by_index(val)

    def _get_selected_from_dropdown(self, driver, locator_or_element):
        sel_element = Select(self.helper.get(locator_or_element))
        return sel_element.first_selected_option


class Paypal(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.email_field = {"locator": "email", "type": By.ID}
        self.password_field = {"locator": "password", "type": By.ID}
        self.login_button = {"locator": "btnLogin", "type": By.ID}
        self.next_button = {"locator": "btnNext", "type": By.ID}
        self.approve_proceed_button = {"locator": "confirmButtonTop",
                                       "type": By.ID}
        self.loader_spinner = {"locator": "preloaderSpinner", "type": By.ID}
        self.message_banner = "//span[@data-test-id='message']"
        self.cc_input = "//input[@data-test-id='ccNumberInput']"
        self.add_card_button = "//input[@data-test-id='addCardButton']"
        self.cookie_banner = dict(locator="gdprCookieBanner", type=By.ID)
        self.cookie_accept_button = dict(locator="acceptAllButton", type=By.ID)

    def enter_text_on_email(self, email, timeout=15):
        self.helper.input_text(self.email_field.get("locator"), email,
                               timeout, self.email_field.get("type"))

    def enter_text_on_password(self, password):
        self.helper.input_text(self.password_field.get("locator"), password,
                               locator_type=self.password_field.get("type"))

    def click_on_login_button(self, timeout=5):
        self.helper.click(self.login_button.get("locator"), timeout,
                          self.login_button.get("type"))

    def click_on_next_button(self, timeout=5):
        self.helper.click(self.next_button.get("locator"), timeout,
                          self.next_button.get("type"))

    def click_on_approve_proceed_button(self, timeout=5):
        self.driver.helper.scroll_to_bottom()
        self.helper.click(self.approve_proceed_button.get("locator"), timeout,
                          self.approve_proceed_button.get("type"))

    def click_on_cookies_accept_button(self, timeout=3):
        self.helper.click(self.cookie_accept_button, timeout)

    def is_next_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.next_button.get("locator"), timeout,
                                      self.next_button.get("type"))

    def is_approve_proceed_button_displayed(self, timeout=5):
        return self.helper.is_visible(
            self.approve_proceed_button.get("locator"),
            timeout, self.approve_proceed_button.get("type"))

    def is_loader_spinner_displayed(self, timeout=5):
        return self.helper.is_visible(
            self.loader_spinner.get("locator"), timeout,
            self.loader_spinner.get("type"))

    def is_message_banner_displayed(self, timeout=5):
        return self.helper.is_visible(self.message_banner, timeout)

    def is_cc_input_displayed(self, timeout=5):
        return self.helper.is_visible(self.cc_input, timeout)

    def is_add_card_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.add_card_button, timeout)

    def is_cookie_banner_displayed(self, timeout=3):
        return self.helper.is_visible(self.cookie_banner, timeout)

    def wait_for_loading_spinner_to_disappear(self, timeout=20):
        return self.helper.wait_until_not_visible(
            self.loader_spinner.get("locator"),
            self.loader_spinner.get("type"), timeout)


class WithDrawalRight(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.withdrawal_right_header = dict(
            locator="h1._1C_5k", type=By.CSS_SELECTOR)
        self.close_button = dict(
            locator="button[data-automation='modal-close']",
            type=By.CSS_SELECTOR)
        self.terms_and_conditions_link = dict(
            locator="p._1SYrc p a", type=By.CSS_SELECTOR)

    def is_withdrawal_page(self, timeout=5):
        return self.is_withdrawal_right_header_displayed(timeout)

    def is_withdrawal_right_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.withdrawal_right_header, timeout)

    def is_terms_and_conditions_link_displayed(self, timeout=3):
        return self.helper.is_visible(self.terms_and_conditions_link, timeout)

    def click_on_close_button(self, timeout=3):
        self.helper.click(self.close_button, timeout)

    def click_on_terms_and_conditions_link(self, timeout=5):
        self.helper.click(self.terms_and_conditions_link, timeout)
