from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter
from apps.hbonweb.pages.productbox_partial import ProductBox

# TODO: Merge parts of Movie and Series into an Asset page


class Movie(Navigation, ProductBox, MoreInfoFooter, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.assets_title = "//h1[@data-automation='title']"
        self.assets_movie_poster_label = \
            "//div[contains(@class, 'thumbnail-image')]"
        self.assets_rating =  \
            "//span[@class='_3QyUi _2R_OM']"
        self.assets_genre = \
            "//div[@class='_1Su-r']//span[@class='_3OYTZ _2WKMQ']"
        self.assets_synopsis = "//p[@data-automation='synopsis']"
        self.assets_duration = "//div[@data-automation='meta_duration']//dd"
        self.assets_cast = "//div[@data-automation='meta_actor']//dd"
        self.assets_director = "//div[@data-automation='meta_director']//dd"
        self.assets_year = "//div[@data-automation='meta_year']//dd"
        self.add_to_watchlist_button = \
            "//button[@data-automation='toggle-watchlist-button']"
        self.assets_play_button = "//a[@data-automation='play-button']"
        self.lock_button = "//button[@data-automation='family-lock-button']"
        # Subscription is not active
        self.product_box = "//div[@data-automation='product-box-copy']"
        self.free_trial_button = \
            "{box}/div/a[contains(@class,'button-blue')]" \
            .format(box=self.product_box)

    def is_asset_title_displayed(self, timeout=10):
        return self.helper.is_visible(self.assets_title, timeout=timeout)

    def get_movies_title(self):
        return self.helper.get_text(self.assets_title)

    def get_movies_poster_label(self):
        return self.helper.get_attribute(self.assets_movie_poster_label,
                                         'aria-label')

    def get_movies_year(self):
        return self.helper.get_text(self.assets_year)

    def is_movies_rating_displayed(self):
        return self.helper.is_visible(self.assets_rating)

    def is_movies_genre_displayed(self):
        return self.helper.is_visible(self.assets_genre)

    def is_movies_synopsis_displayed(self):
        return self.helper.is_visible(self.assets_synopsis)

    def is_movies_duration_displayed(self):
        return self.helper.is_visible(self.assets_duration)

    def get_movies_displayed_duration(self):
        return self.helper.get_text(self.assets_duration)

    def get_movies_duration_location(self):
        return self.helper.get_location(self.assets_duration)

    def is_movies_cast_displayed(self):
        return self.helper.is_visible(self.assets_cast)

    def get_movies_cast_location(self):
        return self.helper.get_location(self.assets_cast)

    def is_movies_director_displayed(self):
        return self.helper.is_visible(self.assets_director)

    def get_movies_director_location(self):
        return self.helper.get_location(self.assets_director)

    def is_movies_year_displayed(self):
        return self.helper.is_visible(self.assets_year)

    def get_movies_year_location(self):
        return self.helper.get_location(self.assets_year)

    def is_movies_add_to_watchlist_button_displayed(self):
        return self.helper.is_visible(self.add_to_watchlist_button)

    def click_on_add_to_watchlist_button(self, hover=None):
        # NOTE: 'hover' is just for series compatability
        self.helper.click(self.add_to_watchlist_button)

    def is_movies_play_button_displayed(self):
        return self.helper.is_visible(self.assets_play_button)

    def is_movies_lock_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.lock_button, timeout=timeout)

    def is_product_box_displayed(self, timeout=10):
        return self.helper.is_visible(self.product_box, timeout=timeout)

    def click_on_free_trial_button(self):
        self.helper.click(self.free_trial_button)

    def click_on_play_button(self, timeout=10):
        for _ in range(30):
            self.helper.click(self.assets_play_button, timeout)
            # TODO: Look for Maximum streams error specifically
            # (once bug fixed)
            if self.is_error_toast_displayed(4):
                sleep(30)
            else:
                break

    def is_play_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.assets_play_button, timeout)

    def get_link_of_play_button(self, timeout=10):
        return self.helper.get_link(self.assets_play_button, timeout)

    def scroll_to_add_to_watchlist_button(self, timeout=5):
        loc = self.helper.get_location(self.add_to_watchlist_button, timeout)
        self.driver.helper.scroll(y=loc["y"] - 200)
