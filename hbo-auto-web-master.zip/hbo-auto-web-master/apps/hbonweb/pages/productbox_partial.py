from apps.hbonweb.pages.base.page import BasePageObject as Page


class ProductBox(Page):
    """Partial page. A 'start free trial' box seen in Series, Movies,
    WhyHBO & Home (if unauthenticated)
    """

    def __init__(self, driver):
        super().__init__(driver)
        # Unauth
        self.header_intro = "//div/h2[contains(@class,'_2Z34r')]"
        self.product_box = "//div[@data-automation='product-box-copy']"
        self.pb_free_trial_button = \
            "{box}/div/a[contains(@class,'button-blue')]" \
            .format(box=self.product_box)
        self.bullet_points_list = "//div[@class='jMAZ1']/ul/li"
        self.description = "//div[@class='A6nEz']/p/p"

    def is_pb_header_intro_displayed(self, timeout=5):
        return self.helper.is_visible(self.header_intro, timeout)

    def is_product_box_displayed(self, timeout=10):
        return self.helper.is_visible(self.product_box, timeout=timeout)

    def is_pb_description_displayed(self, timeout=5):
        return self.helper.is_visible(self.description, timeout)

    def is_pb_free_trial_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.pb_free_trial_button, timeout)

    def is_text_displayed_on_product_box(self, timeout=10):
        for bullet_point_text in self.get_bullet_points_texts_list():
            if len(bullet_point_text) < 3:
                return False
        if len(self.get_text_of_pb_description()) < 3:
            return False
        return True

    def click_on_pb_free_trial_button(self):
        loc = self.helper.get_location(self.pb_free_trial_button)
        self.driver.helper.scroll(loc["x"], loc["y"] - 250)
        self.helper.click(self.pb_free_trial_button)

    def get_text_of_pb_description(self, timeout=5):
        return self.helper.get_text(self.description, timeout)

    def get_location_of_product_box(self, timeout=5):
        return self.helper.get_location(self.product_box, timeout)

    def get_location_of_description(self, timeout=5):
        return self.helper.get_location(self.description, timeout)

    def get_locations_of_bullet_points(self, timeout=5):
        return [self.helper.get_location(x) for x
                in self.get_bullet_points_list(timeout)]

    def get_bullet_points_list(self, timeout=5):
        return self.helper.get_list(self.bullet_points_list, timeout)

    def get_bullet_points_texts_list(self, timeout=5):
        return [self.helper.get_text(x) for x in self.get_bullet_points_list()]

    def scroll_to_product_box(self, timeout=5):
        loc = self.helper.get_location(self.header_intro, timeout)
        self.driver.helper.scroll(y=loc["y"] - 250)
