from selenium.webdriver.common.by import By

from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter


class TermsAndConditions(Navigation, MoreInfoFooter, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.terms_conditions_header = dict(
            locator="h1._2AMrA", type=By.CSS_SELECTOR)

    def is_terms_and_conditions_page(self, timeout=10):
        return self.is_terms_and_conditions_header_displayed(timeout)

    def is_terms_and_conditions_header_displayed(self, timeout=10):
        return self.helper.is_visible(self.terms_conditions_header, timeout)
