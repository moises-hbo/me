from helpers.sleeper import Sleeper as sleep

from selenium.webdriver.common.by import By

from apps.hbonweb.pages.navigation_partial import NavigationLogo


class Search(NavigationLogo):
    def __init__(self, driver):
        super().__init__(driver)
        self.name = "Search Overlay Page"

        self.no_search_result_text = \
            "//div[@data-automation='search-no-results']"
        self.search_enter_more_text = \
            "//div[@data-automation='search-enter-more-text']"
        self.recent_search_text = "//div[@class='_1HHGl bGzAP']"
        self.search_result_grid = "//ul[@class='_2DTxb Gmc0o']"
        self.search_result_row = "//ul[@class='_2DTxb Gmc0o']/li"
        self.search_field = "//input[@data-automation='search-input']"
        self.search_close_button = \
            "//button[@data-automation='search-close-button']"
        # Mobile view
        self.mobile_search_result_list = dict(
            locator="ul figure.zeLA7", type=By.CSS_SELECTOR)

    def have_search_results_returned(self):
        searched = self.is_search_result_grid_displayed(5) \
            or self.is_mobile_search_result_list_displayed(0) \
            or self.is_no_search_result_displayed(0) \
            or self.is_search_result_row_displayed(0) \
            or self.is_search_more_input_displayed(0)
        sleep(1)
        return searched

    def get_exact_search_result_item_path(self, item_name):
        return f'//div[@data-analytics-search-item="{item_name}"]'

    def is_no_search_result_displayed(self, timeout=10):
        return self.helper.is_visible(self.no_search_result_text, timeout)

    def is_search_more_input_displayed(self, timeout=10):
        return self.helper.is_visible(self.search_enter_more_text, timeout)

    def is_recent_search_result_displayed(self):
        return self.helper.is_visible(self.recent_search_text)

    def hover_on_result_item(self, index=0):
        self.driver.helper.move_mouse_to(
            self.helper.get(self.get_search_result_path(index)))

    def click_on_first_search_result(self):
        self.click_on_search_result()
        sleep(1)

    def play_first_search_result(self):
        self.helper.click(self.play_button)

    def get_search_result_path(self, index=0):
        return f"//figure[@data-automation='search-result-{index}']"

    def get_search_recent_result_path(self, index=0):
        return f"//figure[@data-automation='recent-search-result-{index}']"

    def is_search_result_grid_displayed(self, timeout=10):
        return self.helper.is_visible(self.search_result_grid, timeout)

    def is_mobile_search_result_list_displayed(self, timeout=5):
        return self.helper.is_visible(self.mobile_search_result_list, timeout)

    def is_search_result_row_displayed(self, timeout=10):
        return self.helper.is_visible(self.search_result_row, timeout)

    def click_on_search_result(self, index=0):
        self.hover_on_result_item(index)
        self.helper.click(self.get_search_result_path(index))

    def click_on_mobile_search_result(self, index=0, timeout=5):
        results = self.get_mobile_search_results_list(timeout)
        self.helper.click(results[index])

    def click_on_close_search_button(self, timeout=3):
        self.helper.click(self.search_close_button, timeout)

    def get_title_of_search_result(self, index=0):
        return self.helper.get_text(
            self.get_search_result_path(index) + "/figcaption")

    def get_title_of_recent_search_result(self, index=0):
        return self.helper.get_text(
            self.get_search_recent_result_path(index) + "/figcaption")

    def get_searchbox_text(self):
        return self.helper.get(self.search_field).get_attribute('placeholder')

    def get_mobile_search_results_list(self, timeout=5):
        return self.helper.get_list(self.mobile_search_result_list, timeout)

    def input_text_on_search(self, text):
        self.helper.wait_until_visible(self.search_field)
        self.helper.input_text(self.search_field, text)
