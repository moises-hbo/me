from selenium.webdriver.common.by import By
from helpers.enums import Region
from apps.hbonweb.pages.navigation_partial import NavigationLogo


class InsideEU(NavigationLogo):
    def __init__(self, driver):
        super().__init__(driver)
        self.hbo_logo = "//img[@class='_2KLZ9']"  # TODO: Bad Xpath
        self.sign_in_button = "//div/div/button" \
            "[@data-automation='geoblock-sign-in']"
        # TODO: Bad Xpath
        self.hbo_subscriber_within_eu_message = \
            "//p[contains(@class,'_2jmAQ')]"
        self.contact_link = "//a[contains(@class,'_2eKzS')]"  # TODO: Bad Xpath

    def get_hbo_logo_region(self, timeout=10):
        src = self.helper.get_attribute(self.hbo_logo, "src", timeout=timeout)
        espana = True if src.endswith("hboe-main.svg") else False
        nordic = True if src.endswith("hbon-main.svg") else False
        if espana and not nordic:
            return Region.ESPANA
        elif nordic and not espana:
            return Region.NORDIC
        else:
            return Region.UNSUPPORTED

    def get_text_of_hbo_subscriber_within_eu_message(self, timeout=10):
        return self.helper.get_text(
            self.hbo_subscriber_within_eu_message, timeout)

    def click_on_sign_in_link(self, timeout=10):
        self.helper.click(self.sign_in_button,
                          timeout=timeout, locator_type=By.XPATH)

    def click_on_contact_link(self, timeout=10):
        self.helper.click(self.contact_link, timeout=timeout)
