from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter


class ShelfDetails(Navigation, MoreInfoFooter, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.header = "//h1[@class='j1e32 LD_c1 _3M_lL']"
        self.assets_list = "//li[@class='_1hK_f _3-U5Z']"

    def get_assets_list(self, timeout=5):
        return self.helper.get_list(self.assets_list, timeout)

    def are_assets_displayed(self, timeout=5):
        assets = self.get_assets_list(timeout)
        return False not in (self.helper.is_visible(x) for x in assets)
