from selenium.webdriver.common.by import By

from helpers.configmanager import ConfigManager
from helpers.enums import Region

from apps.hbonweb.pages.base.page import BasePageObject as Page
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter
from apps.hbonweb.pages.navigation_partial import NavigationLogo, \
    NavigationSignIn

cm = ConfigManager()


class LoginProductBox(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.product_box = dict(
            locator="div[data-automation='sign-in-product-box']",
            type=By.CSS_SELECTOR)
        self.pb_image = dict(
            locator="div[data-automation='product-box-image']",
            type=By.CSS_SELECTOR)
        self.pb_description = dict(
            locator="div.A6nEz", type=By.CSS_SELECTOR)
        self.pb_usps_list = dict(
            locator="div.jMAZ1 ul li", type=By.CSS_SELECTOR)
        self.pb_start_free_trial_button = dict(
            locator="a[data-automation='sign-in-free-trial-link']",
            type=By.CSS_SELECTOR)
        self.pb_mobile_show_more_less_button = dict(
            locator="button._3aPf6 span", type=By.CSS_SELECTOR)

    def is_product_box_displayed(self, timeout=5):
        return self.helper.is_visible(self.product_box, timeout)

    def is_pb_image_displayed(self, timeout=5):
        return self.helper.is_visible(self.pb_image, timeout)

    def is_pb_description_displayed(self, timeout=5):
        return self.helper.is_visible(self.pb_description, timeout=5)

    def is_pb_free_trial_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.pb_start_free_trial_button, timeout)

    def are_pb_usps_items_displayed(self, timeout=5):
        usps_list = self.get_pb_usps_list(timeout)
        for item in usps_list:
            if not self.helper.is_visible(item):
                return False
        return True

    def click_on_pb_mobile_show_more_less_button(self, timeout=5):
        self.driver.helper.scroll_to_bottom()
        self.helper.click(self.pb_mobile_show_more_less_button, timeout)

    def get_pb_usps_list(self, timeout=5):
        return self.helper.get_list(self.pb_usps_list, timeout=5)


class LoginForm(NavigationLogo, LoginProductBox):
    def __init__(self, driver):
        super().__init__(driver)
        self.name = "Login Page"

        self.sign_in_header = dict(
            locator="h1[data-automation='sign-in-page-title']",
            type=By.CSS_SELECTOR)
        self.email_text_field = \
            "//input[@data-automation='sign-in-email-input-input']"
        self.password_text_field = \
            "//input[@data-automation='sign-in-password-input-input']"
        self.password_text_toggle = "//button[@class='password-toggle']"
        self.remember_me_label = dict(
            locator="//label"
            "[@data-automation='sign-in-remember-me-input-label-element']",
            type=By.XPATH)
        self.remember_me_checkbox = dict(
            locator="//input"
            "[@data-automation='sign-in-remember-me-input-input']",
            type=By.XPATH)
        self.submit_button = \
            "//button[@data-automation='sign-in-submit-button']"
        self.forgot_password_link = dict(
            locator="sign-in-forgot-password-link", type=By.ID)
        self.wrong_credentials_alert_text = \
            "//div[@id='sign-in-server-error']" \
            "//div[@data-automation='form-server-error']"
        self.email_required_alert = \
            "//div[@data-automation='sign-in-email-input-label'" \
            "and contains(@class,'form-label-error')]"
        self.password_required_alert = \
            "//div[@data-automation='sign-in-password-input-label'" \
            "and contains(@class,'form-label-error')]"
        self.free_trial_link = \
            "//a[@data-automation='sign-in-free-trial-link']"
        self.log_in_header_text = "//h1[@data-automation='sign-in-page-title']"
        self.outside_region_text = "//p[contains(@class, 'ZF-4o')]"
        self.loading_pulse_inactive = \
            "//body[contains(@class,'ui-overlay-inactive')]"
        self.is_loaded()

    def is_loaded(self):
        if cm.region is Region.INSIDE_EU:
            return self.helper.is_visible(self.outside_region_text)
        return self.helper.is_visible(self.log_in_header_text)

    def is_loginform_page(self, timeout=5):
        return self.helper.is_visible(self.log_in_header_text)

    def input_text_on_email(self, email):
        self.helper.input_text(self.email_text_field, email)

    def clear_text_on_email(self):
        self.helper.clear_text(self.email_text_field)

    def input_text_on_password(self, password):
        self.helper.input_text(self.password_text_field, password)

    def clear_text_on_password(self):
        self.helper.clear_text(self.password_text_field)

    def click_on_password_input(self, timeout=5):
        self.helper.click(self.password_text_field, timeout)

    def click_on_submit_button(self):
        self.helper.click(self.submit_button)

    def click_on_password_show_toggle(self):
        self.helper.click(self.password_text_field)
        element = self.helper.get(self.password_text_toggle)
        # Firefox workaround
        if cm.driver_name == "firefox":
            self.driver.execute_script(
                "arguments[0].style.display = 'block'; return arguments[0];",
                element)
        element.click()

    def click_on_remember_me_checkbox(self, timeout=5):
        self.helper.click(self.remember_me_label, timeout)

    def click_on_signin_free_trial_link(self):
        self.helper.click(self.free_trial_link)

    def click_on_forgot_password_link(self, timeout=5):
        self.helper.click(self.forgot_password_link)

    def is_wrong_credentials_alert_displayed(self):
        return self.helper.is_visible(self.wrong_credentials_alert_text)

    def is_forgot_password_link_displayed(self, timeout=5):
        return self.helper.is_visible(self.forgot_password_link, timeout)

    def is_email_warning_displayed(self, timeout=5):
        return self.helper.is_visible(self.email_required_alert, timeout)

    def is_password_warning_displayed(self, timeout=5):
        return self.helper.is_visible(self.password_required_alert, timeout)

    def is_sign_in_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.sign_in_header, timeout)

    def is_remember_me_checked(self, timeout=5):
        return self.helper.is_selected(self.remember_me_checkbox, timeout)

    def wait_for_loading_pulse_to_disappear(self):
        if self.helper.wait_until_visible(self.loading_pulse_inactive,
                                          timeout=2):
            return self.helper.wait_until_not_visible(
                self.loading_pulse_inactive, timeout=10)
        return False


class ForgotPassword(NavigationSignIn, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.fp_header = dict(
            locator="//h1[@data-automation='forgot-password-page-title']",
            type=By.XPATH)
        self.fp_instructions = dict(
            locator="//p"
            "[@data-automation='forgot-password-user-instructions']",
            type=By.XPATH)
        self.email_input = dict(locator="email", type=By.ID)
        self.send_email_button = dict(
            locator="//button"
            "[@data-automation='forgot-password-submit-button']",
            type=By.XPATH)

    def is_forgot_password_page(self, timeout=5):
        return self.is_forgot_password_header_displayed(timeout) and \
            self.is_send_email_button_displayed(timeout)

    def is_forgot_password_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.fp_header, timeout)

    def is_send_email_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.send_email_button, timeout)

    def is_email_input_displayed(self, timeout=5):
        return self.helper.is_visible(self.email_input, timeout)

    def is_fp_instructions_displayed(self, timeout=5):
        return self.helper.is_visible(self.fp_instructions, timeout)

    def get_text_of_fp_instructions(self, timeout=5):
        return self.helper.get_text(self.fp_instructions, timeout)

    def get_location_of_fp_instructions(self, timeout=5):
        return self.helper.get_location(self.fp_instructions, timeout)

    def get_location_of_email_input(self, timeout=5):
        return self.helper.get_location(self.email_input, timeout)

    def get_location_of_send_email_button(self, timeout=5):
        return self.helper.get_location(self.send_email_button, timeout)


class AdultKidsSelection(CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.series_movies_button = \
            "//button[@data-automation='adult-profile-button']"
        self.kids_button = "//button[@data-automation='family-profile-button']"

    def click_on_series_movies_button(self, timeout=10):
        self.helper.click(self.series_movies_button, timeout)

    def click_on_kids_button(self, timeout=10):
        self.helper.click(self.kids_button, timeout)

    def is_series_movies_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.series_movies_button,
                                      timeout)

    def is_kids_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.kids_button, timeout)

    def get_series_movies_button(self, timeout=10):
        return self.helper.get(self.series_movies_button, timeout)


class UpdatePolicy(CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.updated_policy_header = "//div/div/h1[contains(@class,'_1ZFGE')]"
        self.user_policy_link = \
            "//div[contains(@class,'_2j82T')]/span"\
            "/a[contains(@href,'/terms-and-conditions')]"
        self.i_understand_button = \
            "//div[contains(@class,'pulse-button')]"\
            "/button[contains(@class,'button-blue-anim')]"

    def is_update_policy_page(self):
        return self.is_updated_policy_header_displayed(timeout=5) \
            and self.is_user_policy_link_displayed(timeout=5)

    def is_updated_policy_header_displayed(self, timeout=10):
        return self.helper.is_visible(self.updated_policy_header, timeout)

    def is_user_policy_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.user_policy_link, timeout)

    def click_on_user_policy_link(self):
        self.helper.click(self.user_policy_link)

    def click_on_i_understand_button(self):
        self.helper.click(self.i_understand_button)
