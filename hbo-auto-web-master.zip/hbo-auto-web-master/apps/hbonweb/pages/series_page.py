from helpers.sleeper import Sleeper as sleep

from selenium.webdriver.common.by import By

from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter
from apps.hbonweb.pages.productbox_partial import ProductBox

# TODO: Merge parts of Movie and Series into an Asset page


class Series(Navigation, ProductBox, MoreInfoFooter, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.__link_active = "and contains(@class, 'active')]"
        self.assets_title = "//h1[@class='_1YoH- LD_c1']"
        self.episode_title = "//h1[@data-automation='title']"
        self.episode_poster_label = \
            "//div[contains(@class, 'thumbnail-image')]"
        self.assets_rating = "//span[@class='_1KTsC _2R_OM']"
        self.episode_rating = "//span[@class='_3QyUi _2R_OM']"
        self.assets_genre = \
            "//div[@class='_1fzpM']//span[@class='azoai _2WKMQ']"
        self.episode_genre = "//span[@class='_3OYTZ _2WKMQ']"
        self.assets_synopsis = "//p[@data-automation='synopsis']"
        self.assets_duration = "//div[@data-automation='meta_duration']//dd"
        self.assets_cast = "//div[@data-automation='meta_actor']//dd"
        self.assets_creator = "//div[@data-automation='meta_creator']//dd"
        self.assets_year = "//div[@data-automation='meta_year']//dd"
        self.add_to_watchlist_button = "//button[@data-automation=" \
            "'toggle-watchlist-button']"
        self.assets_play_button = "//a[@data-automation='play-button']"
        self.assets_preview_block = "//div[@class='preview _1v20p']"
        self.assets_episode_name = "//span[@class='_3HhQi _3icqI ea_Q3']"
        self.assets_season_episode_mark = "//div[@class='_34PHF _1N1Iu']//span"
        self.assets_seasons_links_list = "//ul[@class='_3d8o9']" \
            "/li[contains(@class, '_1KV1E')]/a[@href]"
        self.episode_grid_links_list = "//ul[@class='_2JJQI Gmc0o']" \
            "//li//figcaption//a[@href]"
        self.show_more_button = \
            "//button[contains(@class,'_3aPf6')]"
        self.overview_tab_active = "//ul[@class='_3d8o9']" \
            "/li[1][contains(@class, 'active')]"
        self.assets_year = "//div[@data-automation='meta_year']//dd"
        self.start_watching_img = "//div[@tabindex='0'] \
            //div[contains(@class,'thumbnail-image')]"
        self.start_watching_play_button = \
            "//div[@class='f0RPe']/a[@data-automation='play-button']"
        # Unauth
        self.season_episode_number = "//div[@class='KCc80']" \
            "/span[contains(@class,'_3mUkd')]"
        self.product_box = "//div[@data-automation='product-box-copy']"
        self.free_trial_button = "{box}/div/a[contains(@class,'button-blue')]"\
            .format(box=self.product_box)
        # Mobile view
        self.season_dropdown = dict(
            locator="button[data-automation='season-list-dropdown-button']",
            type=By.CSS_SELECTOR)
        self.season_dropdown_options_list = dict(
            locator="ul li.dropdown-menu-item", type=By.CSS_SELECTOR)
        self.mobile_episodes_list = dict(
            locator="ul figure.p-UAk", type=By.CSS_SELECTOR)
        self.mobile_episodes_titles_list = dict(
            locator=self.mobile_episodes_list.get("locator") + " span._1SjNn",
            type=By.CSS_SELECTOR)

    def is_series_page(self, timeout=5):
        return self.helper.is_visible(self.assets_seasons_links_list, timeout)

    def is_asset_title_displayed(self, timeout=10):
        return self.helper.is_visible(self.assets_title, timeout=timeout)

    def is_episode_title_displayed(self, timeout=10):
        return self.helper.is_visible(self.episode_title, timeout=timeout)

    def is_series_rating_displayed(self):
        return self.helper.is_visible(self.assets_rating)

    def is_episode_rating_displayed(self):
        return self.helper.is_visible(self.episode_rating)

    def is_series_genre_displayed(self):
        return self.helper.is_visible(self.assets_genre)

    def is_episode_genre_displayed(self):
        return self.helper.is_visible(self.episode_genre)

    def is_series_synopsis_displayed(self, timeout=10):
        return self.helper.is_visible(self.assets_synopsis, timeout=timeout)

    def is_series_duration_displayed(self):
        return self.helper.is_visible(self.assets_duration)

    def is_episode_add_to_watchlist_button_displayed(self):
        return self.helper.is_visible(self.add_to_watchlist_button)

    def is_series_play_button_displayed(self):
        self.hover_on_start_watching_element()
        sleep(0.5)
        return self.helper.is_visible(self.assets_play_button)

    def is_episode_play_button_displayed(self):
        return self.helper.is_visible(self.assets_play_button)

    def is_series_episode_name_displayed(self):
        return self.helper.is_visible(self.assets_episode_name)

    def is_series_season_episode_mark_displayed(self):
        return self.helper.is_visible(self.assets_season_episode_mark)

    def is_series_cast_displayed(self, timeout=10):
        return self.helper.is_visible(self.assets_cast, timeout=timeout)

    def is_series_creator_displayed(self, timeout=10):
        return self.helper.is_visible(self.assets_creator, timeout=timeout)

    def is_series_year_displayed(self, timeout=10):
        return self.helper.is_visible(self.assets_year, timeout=timeout)

    def is_series_add_to_watchlist_button_displayed(self, hover=True):
        if hover:
            self.hover_on_start_watching_element()
            sleep(0.5)
        return self.helper.is_visible(self.add_to_watchlist_button)

    def is_season_episode_number_displayed(self):
        return self.helper.is_visible(self.season_episode_number)

    def is_show_more_button_displayed(self, timeout=2):
        return self.helper.is_visible(self.show_more_button, timeout)

    def is_overview_tab_landing_page(self):
        return self.helper.is_visible(self.overview_tab_active)

    def is_product_box_displayed(self, timeout=10):
        return self.helper.is_visible(self.product_box, timeout=timeout)

    def is_play_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.start_watching_play_button, timeout)

    def get_series_cast_location(self):
        return self.helper.get_location(self.assets_cast)

    def get_series_title(self):
        return self.helper.get_text(self.assets_title)

    def get_episode_poster_label(self):
        return self.helper.get_attribute(
            self.episode_poster_label, 'aria-label')

    def get_episode_title(self):
        return self.helper.get_text(self.episode_title)

    def get_series_creator_location(self):
        return self.helper.get_location(self.assets_creator)

    def get_series_year_location(self):
        return self.helper.get_location(self.assets_year)

    def get_episode_displayed_duration(self):
        return self.helper.get_text(self.assets_duration)

    def get_series_year(self):
        return self.helper.get_text(self.assets_year)

    def get_seasons_list(self):
        return self.helper.get_list(self.assets_seasons_links_list)

    def get_episode_grid_list(self):
        return self.helper.get_list(self.episode_grid_links_list)

    def get_season_episode_number_text(self):
        return self.helper.get_text(self.season_episode_number)

    def get_seasons_navbar_location(self):
        return self.helper.get_location(self.assets_seasons_links_list)

    def get_episode_location(self, episode):
        return self.helper.get_location(episode)

    def get_link_of_play_button(self):
        return self.helper.get_link(self.assets_play_button)

    def get_location_of_show_more_button(self):
        return self.helper.get_location(self.show_more_button)

    def get_mobile_season_dropdown_options_list(self, timeout=5):
        return self.helper.get_list(self.season_dropdown_options_list, timeout)

    def get_mobile_episodes_list(self, timeout=5):
        return self.helper.get_list(self.mobile_episodes_list, timeout)

    def get_mobile_episodes_titles_list(self, timeout=5):
        return self.helper.get_list(self.mobile_episodes_titles_list, timeout)

    def click_on_season_link(self, link):
        self.helper.click(link)

    def click_on_episode_link(self, link):
        self.helper.click(link)

    def click_on_mobile_season_dropdown(self, timeout=5):
        self.helper.click(self.season_dropdown, timeout)

    def click_on_mobile_season_option(self, season, timeout=5):
        seasons = self.get_mobile_season_dropdown_options_list(timeout)
        for s in seasons:
            stext = self.helper.get_text(s)
            if stext.endswith(f" {season}"):
                self.helper.click(s)
                break

    def click_on_mobile_episode(self, ep_name, timeout=5, scroll=True):
        episodes = self.get_mobile_episodes_list()
        episodes_titles = self.get_mobile_episodes_titles_list()

        for ep_ele, ep_title in zip(episodes, episodes_titles):
            ep_title_txt = self.helper.get_text(ep_title)
            if ep_title_txt == ep_name:
                if scroll:
                    ep_loc = self.helper.get_location(ep_ele)
                    self.driver.helper.scroll(y=ep_loc["y"] - 200)
                self.helper.click(ep_ele)
                break

    def click_on_free_trial_button(self):
        self.helper.click(self.free_trial_button)

    def click_on_play_button(self, timeout=10):
        for _ in range(30):
            self.helper.click(self.assets_play_button, timeout)
            # TODO: Look for Maximum streams error specifically
            # (once bug fixed)
            if self.is_error_toast_displayed(4):
                sleep(30)
            else:
                break

    def click_on_show_more_button(self):
        self.helper.click(self.show_more_button)

    def click_on_add_to_watchlist_button(self, hover=True):
        if hover:
            self.hover_on_start_watching_element()
            sleep(1)
        self.helper.click(self.add_to_watchlist_button)

    def hover_on_start_watching_element(self, timeout=5):
        # Element appears to get found, but is initially not
        # able to interact with, which causes errors.
        sleep(2)
        self.driver.helper.move_mouse_to(
            self.helper.get(self.assets_preview_block, timeout))

    def scroll_to_add_to_watchlist_button(self, timeout=5):
        loc = self.helper.get_location(self.add_to_watchlist_button, timeout)
        self.driver.helper.scroll(y=loc["y"] - 200)

    def wait_until_asset_preview_is_displayed(self, timeout=8):
        return self.helper.wait_until_visible(
            self.assets_preview_block, timeout=timeout)
