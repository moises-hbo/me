from apps.hbonweb.pages.base.page import BasePageObject as Page


class Devices(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.devices_header_intro = \
            "//div/h2[@data-automation='how-to-watch-title-text']"
        self.devices_list = "//ul/li[contains(@class,'_1KV1E _1RLYk')]"
        self.devices_names_list = self.devices_list + \
            "//figcaption/div[@class='vmLp- _3C5GD']"
        # Mobile view
        self.devices_left_button = "//button[@class='_1nyku _3VxrN']"
        self.devices_right_button = "//button[@class='_27DPy _3VxrN']"

    def is_devices_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.devices_header_intro, timeout)

    def is_device_displayed(self, index, timeout=3):
        devices = self.get_devices_list(timeout)
        return self.helper.is_visible(devices[index])

    def click_on_device(self, index, timeout=5):
        devices = self.get_devices_list(timeout)
        self.helper.click(devices[index])

    def click_on_devices_left_button(self, timeout=5):
        self.helper.click(self.devices_left_button, timeout=5)

    def click_on_devices_right_button(self, timeout=5):
        self.helper.click(self.devices_right_button, timeout)

    def get_text_of_device_name(self, index, timeout=5):
        devices_names = self.get_texts_of_devices_names_list(timeout)
        return devices_names[index]

    def get_devices_list(self, timeout=5):
        return self.helper.get_list(self.devices_list, timeout)

    def get_texts_of_devices_names_list(self, timeout=5):
        devices_names = self.helper.get_list(self.devices_names_list)
        return [self.helper.get_text(x) for x in devices_names]

    def scroll_to_devices(self, timeout=5):
        loc = self.helper.get_location(self.devices_header_intro, timeout)
        self.driver.helper.scroll(y=loc["y"] - 200)
