from helpers.sleeper import Sleeper as sleep
from selenium.webdriver.common.by import By

from apps.hbonweb.pages.base.page import BasePageObject as Page


class NavigationLogo(Page):
    """Header/Navigation partial page with HBO Logo."""

    def __init__(self, driver):
        super().__init__(driver)
        self.play_button = "//a[@data-automation='play-button']"
        self.hbo_logo_image = "//a[@data-automation='header-home-button']/img"

    def click_on_hbo_logo_img(self):
        self.helper.click(self.hbo_logo_image)

    def click_on_play_button(self):
        self.helper.click(self.play_button)

    def is_hbo_logo_img_displayed(self):
        return self.helper.is_visible(self.hbo_logo_image)

    def is_play_button_displayed(self):
        return self.helper.is_visible(self.play_button)

    def wait_for_hbo_logo_to_appear(self, timeout=20):
        return self.helper.wait_until_visible(
            self.hbo_logo_image, timeout=timeout)


class NavigationSignIn(NavigationLogo):
    """Header/Navigation partial page with Sign In."""

    def __init__(self, driver):
        super().__init__(driver)
        self.sign_in_link = "//a[@data-automation='header-sign-in-button']"

    def click_on_sign_in_link(self):
        self.helper.click(self.sign_in_link)

    def is_sign_in_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.sign_in_link, timeout)

    def wait_for_signin_button_to_disappear(self, timeout=10):
        return self.helper.wait_until_not_visible(
            self.sign_in_link, timeout=timeout)


class Navigation(NavigationSignIn):
    """Header/Navigation partial page object.
    Seen in the top with links to main sections."""

    def __init__(self, driver):
        super().__init__(driver)
        # check for highlighted nav menu item
        self.__link_active = "and contains(@class, 'active')]"

        self.why_hbo_link = "//a[@data-automation='header-why-hbo-link']"
        self.why_hbo_link_active = "{why_hbo_link} {active}" \
            .format(why_hbo_link=self.why_hbo_link[:-1],
                    active=self.__link_active)
        self.kids_link = "//a[@data-automation='header-family-link']"
        self.kids_link_active = "{kids_link} {active}" \
            .format(kids_link=self.kids_link[:-1], active=self.__link_active)
        self.search_button = dict(
            locator="button[data-automation='header-search-button'] svg",
            type=By.CSS_SELECTOR)
        self.complete_registration_banner = \
            "//div[@data-automation='account-state-error-banner']"
        # Unauth specific
        self.HomeUnauth_link = "//a[@data-automation='header-unauthed-home']"
        self.HomeUnauth_link_active = "{HomeUnauth_link} {active}" \
            .format(HomeUnauth_link=self.HomeUnauth_link[:-1],
                    active=self.__link_active)
        self.free_trial_button = \
            "//a[@data-automation='header-free-trial-button']"
        # Mobile
        self.mobile_free_trial_button = dict(
            locator="div.q7p25", type=By.CSS_SELECTOR)
        # Auth specific
        self.my_account_link = "//a[@data-automation='my-account']"
        self.watchlist_link = "//a[@data-automation='header-watchlist-link']"
        self.watchlist_link_active = "{watchlist_link} {active}" \
            .format(watchlist_link=self.watchlist_link[:-1],
                    active=self.__link_active)
        self.HomeAuth_link = "//a[@data-automation='header-discover-link']"
        self.HomeAuth_link_active = "{HomeAuth_link} {active}" \
            .format(HomeAuth_link=self.HomeAuth_link[:-1],
                    active=self.__link_active)

    def click_on_home_logged_out_link(self):
        self.helper.click(self.HomeUnauth_link)

    def click_on_home_logged_in_link(self):
        self.helper.click(self.HomeAuth_link)

    def click_on_kids_link(self, timeout=10):
        self.helper.click(self.kids_link, timeout=timeout)

    def click_on_watchlist_link(self):
        self.helper.click(self.watchlist_link)

    def click_on_my_account_link(self):
        self.helper.click(self.my_account_link)

    def click_on_why_hbo_link(self):
        self.helper.click(self.why_hbo_link)

    def click_on_free_trial_button(self, timeout=10):
        self.helper.click(self.free_trial_button, timeout)

    def click_on_mobile_free_trial_button(self, timeout=5):
        self.helper.click(self.mobile_free_trial_button, timeout)

    def click_on_search_button(self, timeout=10):
        self.helper.click(self.search_button, timeout)

    def is_home_logged_out_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.HomeUnauth_link, timeout)

    def is_home_logged_out_active_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.HomeUnauth_link_active, timeout)

    def is_home_logged_in_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.HomeAuth_link, timeout)

    def is_home_logged_in_active_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.HomeAuth_link_active, timeout)

    def is_kids_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.kids_link, timeout)

    def is_kids_active_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.kids_link_active, timeout)

    def is_watchlist_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.watchlist_link, timeout)

    def is_watchlist_active_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.watchlist_link_active, timeout)

    def is_my_account_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.my_account_link, timeout)

    def is_why_hbo_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.why_hbo_link, timeout)

    def is_why_hbo_active_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.why_hbo_link_active, timeout)

    def is_free_trial_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.free_trial_button, timeout)

    def is_mobile_free_trial_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.mobile_free_trial_button, timeout)

    def is_search_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.search_button, timeout)

    def is_complete_registration_banner_displayed(self, timeout=10):
        return self.helper.is_visible(self.complete_registration_banner,
                                      timeout)

    def is_feedback_toast_displayed(self):
        return self.helper.is_visible(self.ok_toast)

    def get_color_of_myaccount_button(self):
        return self.helper.get_element_css_property(
            self.my_account_link, css_property="color")

    def get_text_decoration_of_myaccount_button(self):
        return self.helper.get_element_css_property(
            self.my_account_link, css_property="text-decoration")

    def get_location_of_mobile_free_trial_button(self, timeout=5):
        return self.helper.get_location(self.mobile_free_trial_button, timeout)

    def get_size_of_mobile_free_trial_button(self, timeout=5):
        return self.helper.get_size(self.mobile_free_trial_button, timeout)

    def hover_over_myaccount_button(self):
        myaccount = self.helper.get(self.my_account_link)
        self.driver.helper.move_mouse_to(myaccount)
        sleep(0.5)
