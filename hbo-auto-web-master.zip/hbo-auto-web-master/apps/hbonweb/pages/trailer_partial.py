from apps.hbonweb.pages.base.page import BasePageObject as Page


class Trailer(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.trailer_frame = "//div[@class='_3F0Yt']"
        self.trailer_img = self.trailer_frame + "//img"
        self.trailer_play_button = self.trailer_frame + \
            "//a[@data-automation='play-button']"
        # Modal
        # Unauth
        self.trailer_modal = "//div[@class='D1bCY']"
        self.tm_close_button = self.trailer_modal + \
            "//button[@data-automation='modal-close']"
        self.tm_pb_description = self.trailer_modal + \
            "//span[@class='_156Hp']/p"
        self.tm_pb_start_free_trial = self.trailer_modal + \
            "//a[contains(@class,'button-blue')]"

    def is_trailer_image_displayed(self, timeout=5):
        return self.helper.is_visible(self.trailer_img, timeout)

    def is_trailer_play_button_displayed(self, timeout=5, hover=True,
                                         scroll=True):
        if hover:
            self.hover_over_trailer_image(timeout, scroll)
        return self.helper.is_visible(self.trailer_play_button, timeout)

    def is_trailer_modal_pb_description_displayed(self, timeout=5):
        return self.helper.is_visible(self.tm_pb_description, timeout)

    def is_trailer_modal_pb_start_free_trial_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.tm_pb_start_free_trial, timeout)

    def click_on_trailer_play_button(self, timeout=5, hover=True, scroll=True):
        if hover:
            self.hover_over_trailer_image(timeout, scroll)
        self.helper.click(self.trailer_play_button, timeout)

    def click_on_trailer_modal_close_button(self, timeout=5):
        self.helper.click(self.tm_close_button, timeout)

    def click_on_trailer_modal_pb_start_free_trial_button(self, timeout=5):
        self.helper.click(self.tm_pb_start_free_trial, timeout)

    def get_location_of_trailer_frame(self, timeout=5):
        return self.helper.get_location(self.trailer_frame, timeout)

    def hover_over_trailer_image(self, timeout=5, scroll=True):
        if scroll:
            self.scroll_to_trailer(timeout)
        self.driver.helper.move_mouse_to(self.helper.get(
            self.trailer_img, timeout))

    def scroll_to_trailer(self, timeout=5):
        loc = self.helper.get_location(self.trailer_frame, timeout)
        self.driver.helper.scroll(y=loc["y"])
