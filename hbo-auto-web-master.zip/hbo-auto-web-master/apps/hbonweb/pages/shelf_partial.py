from apps.hbonweb.pages.base.page import BasePageObject as Page

from apps.hbonshared.resourcesmanager import ResourcesManager as RM


class Shelf(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.shelves = "//div[@data-automation='shelf']"
        self.shelf_titles = self.shelves + \
            "//span[@class='_2pWgq bGzAP _3M_lL']"
        self.character_shelves = "//div[@data-automation='character-shelf]"
        self.shelf_items = "//div[@data-automation='shelf-item']"
        self.shelf_item_titles = self.shelf_items + \
            "//span[@class='_3HhQi _3icqI ea_Q3']"
        self.item_add_to_watchlist = "//button[@data-automation=" \
            "'toggle-watchlist-button']"

    def get_shelves(self, timeout=10):
        return self.helper.get_list(self.shelves, timeout)

    def get_character_shelves(self, timeout=10):
        return self.helper.get_list(self, timeout)

    def get_shelf_titles(self, as_text=True, timeout=5):
        shelf_titles = self.helper.get_list(self.shelf_titles, timeout)
        return [x.text.upper() for x in shelf_titles] if as_text \
            else shelf_titles

    def get_shelf_items(self, shelf_index, timeout=5):
        shelf = self.get_shelves(timeout)[shelf_index]
        items = shelf.find_elements_by_xpath(
            ".{si}".format(si=self.shelf_items))
        return items

    def get_shelf_item(self, shelf_index, item_index, timeout=5):
        return self.get_shelf_items(shelf_index, timeout)[item_index]

    def get_shelf_item_titles(self, shelf_index, timeout=5):
        shelf = self.get_shelves(timeout)[shelf_index]
        return [x.text for x in shelf.find_elements_by_xpath(
                self.shelf_item_titles)]

    def get_title_of_asset_in_shelf(self, shelf_index, asset_index, timeout=5):
        titles = self.get_shelf_item_titles(shelf_index, timeout)
        return titles[asset_index]

    def is_cw_shelf_displayed(self, timeout=5):
        shelf_name = RM.get_lang_text("cw_shelf_name")
        return shelf_name in self.get_shelf_titles()

    def is_cw_shelf_at_top(self, timeout=5):
        shelf_name = RM.get_lang_text("cw_shelf_name")
        return self.get_shelf_titles()[0] == shelf_name

    def is_see_all_button_displayed(self, shelf_index, timeout=5):
        shelf = self.get_shelves(timeout)[shelf_index]
        see_all = shelf.find_element_by_xpath(
            "//div[@class='_1XK-t']/a[contains(@class,'button-outline-pill')]")
        return self.helper.is_visible(see_all)

    def is_add_to_watchlist_displayed(self, shelf_index, item_index,
                                      scroll=True, timeout=5):
        item = self.hover_over_shelf_item(
            shelf_index, item_index, scroll, timeout)
        atw = item.find_element_by_xpath(f".{self.item_add_to_watchlist}")
        self.dh.move_mouse_to(atw)
        return self.helper.is_visible(atw)

    def hover_over_shelf_item(self, shelf_index, item_index, scroll=True,
                              timeout=5):
        item = self.get_shelf_item(shelf_index, item_index, timeout)
        if scroll:
            loc = self.helper.get_location(item)
            size = self.helper.get_size(item)
            self.dh.scroll(y=int(loc["y"] + size["height"]))
        self.dh.move_mouse_to(item, timeout)
        return item

    def hover_over_shelf_title(self, shelf_index, scroll=True, timeout=5):
        if scroll:
            self.scroll_to_shelf(shelf_index)
        title = self.get_shelf_titles(False, timeout)[shelf_index]
        self.dh.move_mouse_to(title)

    def click_on_shelf_title(self, shelf_index, scroll=True, timeout=5):
        if scroll:
            self.scroll_to_shelf(shelf_index)
        shelf = self.get_shelf_titles(False, timeout)[shelf_index]
        self.helper.click(shelf)

    def scroll_to_shelf(self, shelf_index, timeout=5):
        shelf = self.get_shelves(timeout)[shelf_index]
        loc = self.helper.get_location(shelf)
        self.driver.helper.scroll(0, loc["y"] - 250)
