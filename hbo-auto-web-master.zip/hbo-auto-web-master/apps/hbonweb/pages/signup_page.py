from helpers.sleeper import Sleeper as sleep

from selenium.webdriver.common.by import By

from apps.hbonweb.pages.base.page import BasePageObject as Page
from apps.hbonweb.pages.navigation_partial import NavigationSignIn, \
    NavigationLogo
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class RegistrationSteps(Page):
    """Partial page seen in SignUp and Payment
    Showing the registration steps, and which is active
    """

    def __init__(self, driver):
        super().__init__(driver)
        self.steps_list = "//h1[contains(@class,'_1ap8C')]"
        self.active_step = "//h1[contains(@class,'_2KWHU')]"

    def get_steps_list(self):
        return self.helper.get_list(self.steps_list)

    def get_active_step(self):
        return self.helper.get(self.active_step)

    def is_step_1_active(self, timeout=3):
        return self.helper.get_text(self.active_step, timeout) == "1"

    def is_step_2_active(self, timeout=3):
        return self.helper.get_text(self.active_step, timeout) == "2"

    def is_step_3_active(self, timeout=3):
        return self.helper.get_text(self.active_step, timeout) == "3"


class SignUpProductBox(Page):
    """Partial page seen in CreateAccount and PaymentDetails both
    Product Box
    """

    def __init__(self, driver):
        super().__init__(driver)
        self.product_box = "//div[@data-automation='sign-upproduct-box']"
        self.__bullet_points_list = self.product_box + \
            "/div[@data-automation='product-box-copy']/div[@class='jMAZ1']/ul"
        self.bullet_points_texts = self.__bullet_points_list + "/li"
        self.bullet_points_subtexts = self.__bullet_points_list + "/ul/li"

    def is_product_box_displayed(self, timeout=5):
        return self.helper.is_visible(self.product_box, timeout)

    def is_bullet_points_list_populated(self):
        return len(self.get_bullet_points_texts()) > 0

    def get_bullet_points_texts(self):
        texts = self.helper.get_list(
            self.bullet_points_texts)
        return [x.text for x in texts] if texts else []

    def get_bullet_points_subtexts(self):
        subtexts = self.helper.get_list(
            self.bullet_points_subtexts)
        return [x.text for x in subtexts] if subtexts else []


class SignUp(NavigationSignIn, RegistrationSteps, CopyrightLanguageFooter,
             SignUpProductBox):
    """Page object for SignUp (step 1 of 2)"""

    def __init__(self, driver):
        super().__init__(driver)
        self.name = "SignUp Page"

        self.email_field = \
            "//input[@data-automation='sign-up-email-input-input']"
        self.email_label = \
            "//div[@data-automation='sign-up-email-input-label']"
        self.email_warning_text = \
            "//div[@data-automation='sign-up-email-input-label' and " \
            "contains(@class,'form-label-error')]"
        self.password_field = \
            "//input[@data-automation='sign-up-password-input-input']"
        self.password_label = \
            "//div[@data-automation='sign-up-password-input-label']"
        self.password_warning_text = \
            "//div[@data-automation='sign-up-password-input-label' and " \
            "contains(@class,'form-label-error')]"
        self.password_text_toggle = "//button[@class='password-toggle']"
        self.no_news_offers_checkbox = "//label" \
            "[@data-automation='sign-up-email-offers-input-label-element']"
        self.no_news_offers_text = "//div[@data-automation=" \
            "'sign-up-email-offers-input-label']/span"
        self.error_alert = "//div[@data-automation='form-server-error']"
        self.tc_box = "//div[@class='_36V56']"
        self.terms_and_conditions_link = self.tc_box + \
            "//a[@href='/terms-and-conditions']"
        self.data_policy_link = self.tc_box + "//a[@href='/data-policy']"
        self.continue_signup_button = self.tc_box + \
            "//button[@data-automation='sign-up-button']"
        self.learn_more_box = "//div[@class='_1FbFQ']"
        self.gdpr_learn_more_button = self.learn_more_box + \
            "//button[@id='gdpr-learn-more-link']"
        self.voucher_box = "//button[@data-automation='sign-up-add-voucher']"
        self.add_voucher_button = self.voucher_box + "/span"
        self.add_voucher_tooltip_icon = self.voucher_box + \
            "/div[@data-automation='voucher-help-icon']"

    def is_signup_page(self):
        return self.is_step_1_active()

    def input_text_on_email_field(self, email):
        self.helper.input_text(self.email_field, email)

    def input_text_on_password_field(self, password):
        self.helper.input_text(self.password_field, password)

    def clear_text_on_email_field(self):
        self.helper.clear_text(self.email_field)

    def clear_text_on_password_field(self):
        self.helper.clear_text(self.password_field)

    def click_on_no_news_offers_checkbox(self):
        self.helper.click(self.no_news_offers_checkbox)

    def click_on_continue_button(self):
        self.helper.click(self.continue_signup_button)

    def click_on_add_voucher_button(self):
        loc = self.helper.get_location_when_visible(self.add_voucher_button)
        self.driver.helper.scroll(loc["x"], loc["y"])
        self.helper.click(self.add_voucher_button)

    def click_on_email_field(self):
        self.helper.click(self.email_field)

    def click_on_password_field(self):
        self.helper.click(self.password_field)

    def click_on_terms_and_conditions_link(self):
        loc = self.helper.get_location_when_visible(
            self.terms_and_conditions_link)
        self.driver.helper.scroll(loc["x"], loc["y"])
        self.helper.click(self.terms_and_conditions_link)

    def click_on_data_policy_link(self):
        loc = self.helper.get_location_when_visible(self.data_policy_link)
        self.driver.helper.scroll(loc["x"], loc["y"])
        self.helper.click(self.data_policy_link)

    def click_on_password_show_toggle(self):
        self.helper.click(self.password_field)
        element = self.helper.get(self.password_text_toggle)
        if cm.driver_name.lower() == "firefox":  # Firefox
            self.driver.execute_script(
                "arguments[0].style.display = 'block'; return arguments[0];",
                element)
        element.click()

    def is_email_label_displayed(self):
        return self.helper.is_visible(self.email_label)

    def is_email_warning_displayed(self):
        return self.helper.is_visible(self.email_warning_text)

    def is_email_input_displayed(self):
        return self.helper.is_visible(self.email_field)

    def is_password_field_masked(self):
        return "password" in self.helper.get_attribute(self.password_field,
                                                       "type")

    def is_password_field_cleartext(self):
        return "text" in self.helper.get_attribute(self.password_field, "type")

    def is_password_label_displayed(self):
        return self.helper.is_visible(self.password_label)

    def is_password_warning_displayed(self):
        return self.helper.is_visible(self.password_warning_text)

    def is_password_input_displayed(self):
        return self.helper.is_visible(self.password_field)

    def is_error_alert_displayed(self):
        return self.helper.is_visible(self.error_alert)

    def is_no_news_offers_checkbox_displayed(self):
        return self.helper.is_visible(self.no_news_offers_checkbox)

    def is_terms_and_conditions_link_displayed(self):
        return self.helper.is_visible(self.terms_and_conditions_link)

    def is_terms_conditions_box_displayed(self):
        return self.helper.is_visible(self.tc_box)

    def is_data_policy_link_displayed(self):
        return self.helper.is_visible(self.data_policy_link)

    def is_accept_and_continue_button_displayed(self):
        return self.helper.is_visible(self.continue_signup_button)

    def is_learn_more_box_displayed(self):
        return self.helper.is_visible(self.learn_more_box)

    def is_gdpr_learn_more_button_displayed(self):
        return self.helper.is_visible(self.gdpr_learn_more_button)

    def is_voucher_box_displayed(self):
        return self.helper.is_visible(self.voucher_box)

    def is_add_voucher_button_displayed(self):
        return self.helper.is_visible(self.add_voucher_button)

    def is_add_voucher_tooltip_icon_displayed(self):
        return self.helper.is_visible(self.add_voucher_tooltip_icon)

    def is_no_news_offers_checkbox_active(self):
        return self.helper.is_selected(self.no_news_offers_checkbox + "/input")

    def get_text_of_email_label(self):
        return self.helper.get_text(self.email_label)

    def get_text_of_password_label(self):
        return self.helper.get_text(self.password_label)

    def get_text_of_email_warning(self):
        return self.helper.get_text(self.email_warning_text)

    def get_text_of_password_warning(self):
        return self.helper.get_text(self.password_warning_text)

    def get_text_of_no_news_offers(self):
        return self.helper.get_text(self.no_news_offers_text)

    def get_text_of_tc_box(self):
        return self.helper.get_text(self.tc_box)

    def get_color_of_email_warning(self):
        return self.helper.get_element_css_property(self.email_warning_text)

    def get_color_of_password_warning(self):
        return self.helper.get_element_css_property(self.password_warning_text)

    def get_color_of_tc_box_text(self):
        return self.helper.get_element_css_property(self.tc_box)

    def get_color_of_terms_and_conditions_link(self):
        return self.helper.get_element_css_property(
            self.terms_and_conditions_link)

    def get_color_of_data_policy_link(self):
        return self.helper.get_element_css_property(self.data_policy_link)

    def get_text_decoration_of_terms_and_conditions_link(self):
        return self.helper.get_element_css_property(
            self.terms_and_conditions_link, css_property="text-decoration")

    def get_text_decoration_of_data_policy_link(self):
        return self.helper.get_element_css_property(
            self.data_policy_link, css_property="text-decoration")

    def hover_over_terms_and_conditions_link(self):
        tc_link = self.helper.get(self.terms_and_conditions_link)
        self.driver.helper.move_mouse_to(tc_link)
        sleep(0.5)

    def hover_over_data_policy_link(self):
        dp_link = self.helper.get(self.data_policy_link)
        self.driver.helper.move_mouse_to(dp_link)
        sleep(0.5)

    def hover_over_voucher_help_icon(self):
        v_icon = self.helper.get(self.add_voucher_tooltip_icon)
        self.driver.helper.move_mouse_to(v_icon)


class Voucher(Page):
    """Voucher page, for adding voucher during signup"""

    def __init__(self, driver):
        super().__init__(driver)
        self.voucher_field = "//input[@data-automation='voucher-input-input']"
        self.voucher_label = "//div[@data-automation='voucher-input-label']"
        self.voucher_warning_text = \
            "//div[@data-automation='voucher-input-error']"
        self.add_voucher_button = dict(
            locator="//button[@class='button-blue-anim _12Pxq c-zS9']",
            type=By.XPATH)

    def input_text_on_voucher_field(self, voucher_code):
        self.helper.input_text(self.voucher_field, voucher_code)

    def click_on_add_voucher_button(self):
        self.helper.click(self.add_voucher_button)

    def is_voucher_label_displayed(self):
        return self.helper.is_visible(self.voucher_label)

    def is_voucher_code_warning_displayed(self):
        return self.helper.is_visible(self.voucher_warning_text)


class VoucherFailed(NavigationLogo):
    """ Page for when you create account with used voucher during signup """

    def __init__(self, driver):
        super().__init__(driver)
        self.header = dict(
            locator="//h1[@class='_3Ke76 LD_c1']", type=By.XPATH)
        self.go_to_myaccount_button = dict(
            locator="//button[@class='button-blue-anim ke8Fl c-zS9']",
            type=By.XPATH)

    def is_voucher_failed_page(self):
        return self.helper.is_visible(self.header)

    def click_on_myaccount_button(self, timeout=5):
        self.helper.click(self.go_to_myaccount_button, timeout)


class GetStarted(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.get_started_header_text = "//div[contains(@class,'h43E5')]" \
            "/h1[contains(@class,'_3hd3Q')]"  # TODO: Bad locator
        self.data_policy_link = "//div[contains(@class,'IR7_U')]/span" \
            "/a[@href='/data-policy']"
        self.accept_button = "//div[@data-phase='default']" \
            "/button[contains(@class,'button-blue-anim')]"
        self.show_alternatives_button = \
            "//div/button[contains(@class,'_1QBvj')]"  # TODO: Bad locator

    def is_get_started_page(self, timeout=30):
        return self.is_get_started_header_displayed(timeout)

    def click_on_data_policy_link(self):
        self.helper.click(self.data_policy_link)

    def click_on_accept_button(self, timeout=10):
        self.helper.click(self.accept_button, timeout)

    def click_on_show_alternatives_button(self):
        self.helper.click(self.show_alternatives_button)

    def is_get_started_header_displayed(self, timeout=10):
        return self.helper.is_visible(self.get_started_header_text, timeout)

    def wait_until_get_started_header_displayed(self, timeout=20):
        return self.helper.wait_until_visible(
            self.get_started_header_text, timeout=timeout)


class CantSubscribe(NavigationLogo):
    def __init__(self, driver):
        super().__init__(driver)
        self.cant_subscribe_header = "//h1[@class='_3UNBY LD_c1']"
        self.cant_subscribe_text = dict(
            locator="div._8EHGl p", type=By.CSS_SELECTOR)
        self.change_payment_button = "//div[@class='_161YM']/div" \
            "/button[contains(@class,'button-blue-anim')]"
        self.need_help_text = dict(
            locator="p._2_S_8", type=By.CSS_SELECTOR)
        self.customer_service_link = "//a[@href='/contact']"
        self.change_payment_button = dict(
            locator="div button.c-zS9", type=By.CSS_SELECTOR)

    def is_cant_subscribe_page(self):
        return self.is_cant_subscribe_header_displayed() \
            and self.is_change_payment_button_displayed() \
            and self.is_customer_service_link_displayed()

    def is_cant_subscribe_header_displayed(self):
        return self.helper.is_visible(self.cant_subscribe_header)

    def is_cant_subscribe_text_displayed(self, timeout=5):
        return self.helper.is_visible(self.cant_subscribe_text, timeout)

    def is_change_payment_button_displayed(self):
        return self.helper.is_visible(self.change_payment_button)

    def is_customer_service_link_displayed(self):
        return self.helper.is_visible(self.customer_service_link)

    def click_on_change_payment_button(self, timeout=5):
        self.helper.click(self.change_payment_button, timeout)

    def click_on_customer_service_link(self, timeout=5):
        self.helper.click(self.customer_service_link, timeout)
