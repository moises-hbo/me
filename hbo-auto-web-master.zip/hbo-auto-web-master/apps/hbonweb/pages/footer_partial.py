from apps.hbonweb.pages.base.page import BasePageObject as Page


class CopyrightLanguageFooter(Page):
    def __init__(self, driver):
        super().__init__(driver)
        # Bad locator
        self.copyright_text = "//footer//div[contains(text(), " \
            "'Home Box Office, Inc. All Rights Reserved.')]"
        self.language_button = "//footer//" \
            "button[@data-automation='language-select-dropdown-button']"
        self.en_language_button = "//footer//" \
            "li[@data-automation='language-select-option-0']"
        self.dk_language_button = "//footer//" \
            "li[@data-automation='language-select-option-1']"
        self.no_language_button = "//footer//" \
            "li[@data-automation='language-select-option-2']"
        self.fi_language_button = "//footer//" \
            "li[@data-automation='language-select-option-3']"
        self.se_language_button = "//footer//" \
            "li[@data-automation='language-select-option-4']"
        self.language_options = "//footer//" \
            "li[contains(@data-automation,'language-select-option')]"
        self.language_options_texts = \
            self.language_options + "/a[contains(@hreflang,'')]"
        self.active_language = \
            "//div[@data-automation='language-select-dropdown-selected']"

    def is_copyright_text_displayed(self, timeout=10):
        return self.helper.is_visible(self.copyright_text, timeout)

    def is_language_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.language_button, timeout)

    def click_on_language_button(self):
        self.helper.click(self.language_button)

    def select_language_nr(self, nr):
        self.helper.click("//footer//li[@data-automation="
                          f"'language-select-option-{nr}']")

    def select_english_language(self):
        self.click_on_language_button()
        self.helper.click(self.en_language_button)

    def select_danish_language(self):
        self.click_on_language_button()
        self.helper.click(self.dk_language_button)

    def select_norwegian_language(self):
        self.click_on_language_button()
        self.helper.click(self.no_language_button)

    def select_finish_language(self):
        self.click_on_language_button()
        self.helper.click(self.fi_language_button)

    def select_swedish_language(self):
        self.click_on_language_button()
        self.helper.click(self.se_language_button)

    def select_spanish_language(self):
        self.click_on_language_button()
        self.helper.click(self.dk_language_button)

    def get_language_button(self):
        return self.helper.get(self.language_button)

    def get_language_options(self):
        return self.helper.get_list(self.language_options)

    def get_text_of_language_options(self):
        return [
            self.helper.get_text(x) for x in
            self.helper.get_list(self.language_options_texts)]

    def get_text_of_active_language_option(self):
        return self.helper.get_text(self.active_language)


class MoreInfoFooter(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.how_to_watch_link = "//footer//a[@href='/how-to-watch']"
        self.about_link = "//footer//a[@href='/about']"
        self.faq_link = "//footer//a[@href='/faq']"
        self.contact_link = "//footer//a[@href='/contact']"
        self.press_link = "//footer//a[@href='/press']"
        self.terms_and_conditions_link = "//footer//" \
            "a[@href='/terms-and-conditions']"
        self.data_policy_link = "//footer//a[@href='/data-policy']"
        self.start_free_trial_button = "//footer//a[@href='/sign-up']"

    def click_on_how_to_watch_link(self):
        self.helper.click(self.how_to_watch_link)

    def click_on_about_link(self):
        self.helper.click(self.about_link)

    def click_on_faq_link(self):
        self.helper.click(self.faq_link)

    def click_on_press_link(self):
        self.helper.click(self.press_link)

    def click_on_terms_and_conditions_link(self):
        self.helper.click(self.terms_and_conditions_link)

    def click_on_footer_data_policy_link(self):
        self.helper.click(self.data_policy_link)

    def click_on_footer_start_free_trial_button(self):
        self.driver.helper.scroll_to_bottom()
        self.helper.click(self.start_free_trial_button)

    def click_on_contact_link(self):
        self.driver.helper.scroll_to_bottom()
        self.helper.click(self.contact_link)

    def is_how_to_watch_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.how_to_watch_link, timeout=timeout)

    def is_about_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.about_link, timeout=timeout)

    def is_faq_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.faq_link, timeout=timeout)

    def is_contact_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.contact_link, timeout=timeout)

    def is_press_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.press_link, timeout=timeout)

    def is_terms_and_conditions_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.terms_and_conditions_link,
                                      timeout=timeout)

    def is_data_policy_link_displayed(self, timeout=10):
        return self.helper.is_visible(self.data_policy_link, timeout)

    def is_footer_start_free_trial_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.start_free_trial_button, timeout)

    # TODO: Social media buttons
