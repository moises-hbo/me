from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter, \
    MoreInfoFooter


class DataPolicy(Navigation, CopyrightLanguageFooter, MoreInfoFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.header_text = "//div[@class='push-below-header']" \
            "/h1[contains(@class,'_2AMrA')]"

    def is_data_policy_page(self):
        return self.is_header_text_displayed()

    def is_header_text_displayed(self):
        return self.helper.is_visible(self.header_text)
