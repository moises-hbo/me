from selenium.webdriver.common.by import By

from apps.hbonweb.pages.base.page import BasePageObject as Page


class Carousel(Page):
    """Carousel item grid seen on WhyHBO/Home/Kids"""

    def __init__(self, driver):
        super().__init__(driver)
        self.carousel = "//div[@data-automation='carousel']"
        self.carousel_list = "//ul[@class='_2Ss8p']" \
            "/div[@class='carousel-tile _1pQSk']"
        self.intro_text = "//div[@class='_2ICe- _17NST']"
        self.start_free_trial = dict(
            locator=self.carousel + "//a[@data-automation='start-free-trial']",
            type=By.XPATH)

    def click_on_carousel_start_free_trial_button(self):
        self.helper.click(self.start_free_trial)

    def get_carousel_list(self, timeout=10):
        return self.helper.get_list(self.carousel_list, timeout)

    def get_location_of_carousel(self, timeout=10):
        return self.helper.get_location(self.carousel, timeout)

    def is_carousel_list_displayed(self, timeout=10):
        carousel = self.get_carousel_list(timeout)
        return len(carousel) > 0

    def is_carousel_intro_text_displayed(self):
        # Visibility is false, just looking if element can be found
        return self.helper.get(self.carousel + self.intro_text)

    def is_carousel_start_free_trial_button_displayed(self):
        return self.helper.is_visible(self.start_free_trial)

    def is_carousel_intro_text_in_first_item(self):
        items = self.get_carousel_list()
        intro = items[0].find_element_by_xpath(self.intro_text)
        # visibility is false for some reason
        return intro

    def get_carousel_start_free_trial_button(self, timeout=5):
        return self.helper.get(self.start_free_trial)

    def get_carousel_start_free_trial_button_from_first_item(self):
        items = self.get_carousel_list()
        sft = items[0].find_element_by_xpath(
            self.start_free_trial["locator"].replace(self.carousel, ""))
        return sft
