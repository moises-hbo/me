from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support.color import Color

from helpers.driverhelper import DriverHelper
from helpers.pagehelper import PageHelper
from helpers.logger import Log


class BasePageObject(object):
    """Base Page for all other pages to inherit from.
    Holds shared functions used by all, or most."""

    def __init__(self, driver):
        self.helper: PageHelper = PageHelper(driver)
        self.ph: PageHelper = self.helper
        self.driver: WebDriver = driver
        self.dh: DriverHelper = driver.helper
        self.log = Log()

        # Green toast if something was successful
        self.ok_toast = "//div[@data-automation='success-toast']"
        # Red toast for an error
        self.error_toast = "//div[@data-automation='error-toast']"
        # Loading pulse
        self.loading_pulse = "//div[@data-automation='loading-pulse']"

    def get_app_version(self):
        source = self.driver.page_source
        start = source.find("Version: ") + 9
        stop = source[start:].find("\n") + start
        version = source[start:stop]
        return version

    def get_app_player_version(self):
        source = self.driver.page_source
        start = source.find("Player Version: ") + 16
        stop = source[start:].find("\n") + start
        version = source[start:stop]
        return version

    def get_background_color(self):
        body = self.helper.get("//html")
        return Color.from_string(
            f"{body.value_of_css_property('background-color')}").hex

    def is_ok_toast_displayed(self, timeout=5):
        return self.helper.is_visible(self.ok_toast, timeout)

    def get_text_of_ok_toast(self, timeout=2):
        return self.helper.get_text(self.ok_toast, timeout)

    def is_error_toast_displayed(self, timeout=5):
        return self.helper.is_visible(self.error_toast, timeout)

    def get_text_of_error_toast(self, timeout=2):
        return self.helper.get_text(self.error_toast, timeout)

    def wait_for_loading_pulse_to_appear(self, timeout=5):
        return self.helper.wait_until_visible(
            self.loading_pulse, "xpath", timeout)

    def wait_for_loading_pulse_to_disappear(self, timeout=60):
        return self.helper.wait_until_not_visible(
            self.loading_pulse, "xpath", timeout)
