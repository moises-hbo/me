from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.base.page import BasePageObject as Page

from tools.computer import convert_to_seconds
from tools.image import ImageOCR


class Player(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.video = "//video"
        self.back_button = "//div[contains(@class, 'BzaxQ')]" \
            "/button[@class='_2GZ-w']"
        self.title = "//div[@class='m13rs']/span[contains(@class, 'h8xJG')]"
        self.season_episode_list = "//div[@class='m13rs']" \
            "/span[@class='_3Jdv0']"
        self.play_button = "//button[contains(@class, 'vjs-paused')]"
        self.pause_button = "//button[contains(@class, 'vjs-playing')]"
        self.viewport_play_button = "//button[@class='vjs-big-play-button']"
        self.viewport_loading_spinner = "//div[@class='vjs-loading-spinner']"
        self.skip_back_button = "//button[contains(@class, 'backward-button')]"
        self.skip_forward_button = "//button" \
            "[contains(@class, 'forward-button')]"
        self.elapsed_time = "//div[@class='vjs-current-time-display']"
        self.duration_time = "//div[@class='vjs-duration-display']"
        self.progress_bar = "//div[contains(@class, 'vjs-progress-control')]"
        self.elapsed_progress = "//div[contains(@class, 'vjs-play-progress')]"
        self.tracks_button = "//div[contains(@class, 'tracks-button')]"
        self.tracks_submenu_list = self.tracks_button + \
            "//ul/li[@class='tracks-submenu']"
        self.tracks_submenu_options_list = ".//ul/li" \
            "[contains(@class,'vjs-menu-item')]"
        self.tracks_submenu_selected_option = ".//ul/li" \
            "[contains(@class,'vjs-selected')]"
        self.volume_button = \
            "//div[contains(@class, 'vjs-volume-menu-button')]"
        self.chromecast_button = "//google-cast-launcher"
        self.fullscreen_button = \
            "//button[contains(@class, 'vjs-fullscreen-control')" \
            " and @type='button']"
        # Chainplay
        self.cp_cw_button = "//button[@class='_1joWo']"
        self.cp_play_next_ep_button = "//a[@data-automation='play-button'" \
            " and @class='ZkC1a Xlbkc TKCzG']"
        self.cp_countdown = "//div[@class='_1DEw4']"
        self.cp_next_ep_title = "//h1[contains(@class,'_1oXwi')]"
        self.cp_next_ep_info = "//div[@class='_3E-pz _2WKMQ _3M_lL']"

    def is_player_controls_displayed(self, timeout=5):
        return self.is_back_button_displayed(timeout) \
            and self.is_subtitles_audio_button_displayed(0) \
            and self.is_volume_button_displayed(0) \
            and self.is_fullscreen_button_displayed(0)

    def is_chainplay_displayed(self, timeout=5):
        return self.is_cp_next_episode_header_displayed(timeout)

    def is_back_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.back_button, timeout)

    def is_play_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.play_button, timeout)

    def is_pause_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.pause_button, timeout)

    def is_viewport_play_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.viewport_play_button, timeout)

    def is_viewport_loading_spinner_displayed(self, timeout=1):
        return self.helper.is_visible(self.viewport_loading_spinner, timeout)

    def is_skip_back_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.skip_back_button, timeout)

    def is_skip_forward_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.skip_forward_button, timeout)

    def is_subtitles_audio_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.tracks_button, timeout)

    def is_volume_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.volume_button, timeout)

    def is_chromecast_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.chromecast_button, timeout)

    def is_fullscreen_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.fullscreen_button, timeout)

    def is_elapsed_time_displayed(self, timeout=3):
        return self.helper.is_visible(self.elapsed_time, timeout)

    def is_duration_time_displayed(self, timeout=3):
        return self.helper.is_visible(self.duration_time, timeout)

    def is_player_playing(self, timeout=3, wait=3, checks=5):
        el = self.get_elapsed_in_seconds(timeout)
        for i in range(checks):
            sleep(wait)
            if self.get_elapsed_in_seconds(timeout) > el:
                return True
        return False

    def is_cp_continue_watching_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.cp_cw_button, timeout)

    def is_cp_countdown_displayed(self, timeout=3):
        return self.helper.is_visible(self.cp_countdown, timeout)

    def is_cp_next_episode_header_displayed(self, timeout=3):
        return self.helper.is_visible(self.cp_next_ep_title, timeout)

    def is_cp_play_next_episode_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.cp_play_next_ep_button, timeout)

    def are_subtitle_options_displayed(self, timeout=5):
        subtitle_list = self.get_subtitles_track_list(timeout)
        for sub_opt in subtitle_list:
            vis = self.helper.is_visible(sub_opt)
            if not vis:
                return False
        return True

    def click_on_viewport_play_button(self, timeout=10):
        self.make_player_controls_appear()
        self.helper.click(self.viewport_play_button, timeout)

    def click_on_back_button(self, timeout=5):
        self.make_player_controls_appear()
        self.helper.click(self.back_button, timeout)

    def click_on_play_button(self, timeout=10):
        self.make_player_controls_appear()
        self.helper.click(self.play_button, timeout)

    def click_on_pause_button(self, timeout=10):
        self.make_player_controls_appear()
        self.helper.click(self.pause_button, timeout)

    def click_on_skip_back_button(self, timeout=10):
        self.make_player_controls_appear()
        self.helper.click(self.skip_back_button, timeout)

    def click_on_skip_forward_button(self, timeout=10):
        self.make_player_controls_appear()
        self.helper.click(self.skip_forward_button, timeout)

    def click_on_chromecast_button(self, timeout=10):
        self.make_player_controls_appear()
        self.helper.click(self.chromecast_button, timeout)

    def click_on_fullscreen_button(self, timeout=10):
        self.make_player_controls_appear()
        self.helper.click(self.fullscreen_button, timeout)

    def click_on_progress_bar(self, percent=50, timeout=1):
        if not self.is_player_controls_displayed(0):
            self.make_player_controls_appear()
        bar = self.helper.get(self.progress_bar, timeout)
        bar_size = self.helper.get_size(bar, timeout)
        bar_w_per = int(bar_size["width"] / 100)
        self.driver.helper.move_mouse_to_and_about(
            bar, bar_w_per, int(bar_size["height"] / 2))
        self.driver.helper.move_mouse_about(bar_w_per * percent, 0)
        self.driver.helper.click_on_screen()

    def click_on_cp_continue_watching_button(self, timeout=3):
        self.helper.click(self.cp_cw_button, timeout)
        sleep(2)  # Animation

    def click_on_cp_play_next_ep_button(self, timeout=3):
        self.helper.click(self.cp_play_next_ep_button, timeout)

    def click_on_subtitle_option(self, index, timeout=3):
        subtitle_list = self.get_subtitles_track_list(timeout)
        self.helper.click(subtitle_list[index])

    def click_on_subtitle_option_with_text(self, text, timeout=3):
        subtitle_list = self.get_subtitles_track_list(timeout)
        for so in subtitle_list:
            if so.text.upper() == text.upper():
                so.click()
                return
        raise ValueError(f"No subtitle option with {text} was found!")

    def hover_over_video(self, timeout=5):
        self.driver.helper.move_mouse_to(self.helper.get(
            self.video, timeout))

    def hover_over_tracks_button(self, timeout=10):
        self.make_player_controls_appear()
        self.driver.helper.move_mouse_to(self.helper.get(
                                         self.tracks_button, timeout))

    def hover_over_volume_button(self, timeout=10):
        self.make_player_controls_appear()
        self.driver.helper.move_mouse_about(self.helper.get(
                                            self.volume_button, timeout))

    def get_size_of_video(self, timeout=3):
        return self.helper.get_size(self.video, timeout)

    def get_size_of_cp_cw_video(self, timeout=1):
        return self.helper.get_size(self.cp_cw_button, timeout)

    def get_text_of_title(self, timeout=10):
        return self.helper.get_text(self.title, timeout)

    def get_season_episode_list(self, timeout=10):
        return self.helper.get_list(self.season_episode_list, timeout)

    def get_text_of_season(self, timeout=10):
        self.make_player_controls_appear()
        return self.helper.get_text(self.get_season_episode_list()[0], timeout)

    def get_text_of_episode(self, timeout=10):
        self.make_player_controls_appear()
        return self.helper.get_text(self.get_season_episode_list()[1], timeout)

    def get_text_of_elapsed_time(self, timeout=3, tries=3):
        self.make_player_controls_appear()
        elapsed = self.helper.get_text(self.elapsed_time, timeout).split("\n")
        if len(elapsed) == 2:
            return elapsed[1]
        else:
            if not tries:
                raise ValueError("Failed to retrieve elapsed time")
            self.get_text_of_elapsed_time(tries=tries - 1)

    def get_elapsed_in_seconds(self, timeout=3):
        return convert_to_seconds(self.get_text_of_elapsed_time(timeout))

    def get_text_of_duration_time(self, timeout=3):
        return self.helper.get_text(self.duration_time, timeout).split("\n")[1]

    def get_text_of_cp_next_ep_title(self, timeout=3):
        return self.helper.get_text(self.cp_next_ep_title, timeout)

    def get_text_of_cp_next_ep_info(self, timeout=3):
        return self.helper.get_text(self.cp_next_ep_info, timeout)

    def get_text_of_cp_cw(self, timeout=3):
        return self.helper.get_text(self.cp_countdown, timeout)

    def get_cp_cw_in_secs(self, timeout=1):
        cw_text = self.get_text_of_cp_cw(timeout).split(" ")
        for block in cw_text:
            try:
                return int(block)
            except ValueError:
                pass
        raise ValueError("Unable to convert chainplay countdown to int")

    def get_cp_play_next_button(self, timeout=1):
        return self.helper.get(self.cp_play_next_ep_button, timeout)

    def get_duration_in_seconds(self, timeout=3):
        return convert_to_seconds(self.get_text_of_duration_time(timeout))

    def get_elapsed_progress_bar(self, timeout=3):
        return self.helper.get(self.elapsed_progress, timeout)

    def get_elapsed_in_percent(self, timeout=10):
        pb = self.get_elapsed_progress_bar(timeout)
        style = self.helper.get_attribute(pb, "style")
        return float(style.split(" ")[1].split("%")[0])

    def get_location_of_title_text(self, timeout=3):
        return self.helper.get_location(self.title, timeout)

    def get_location_of_season_text(self, timeout=3):
        return self.helper.get_location(self.get_season_episode_list()[0],
                                        timeout)

    def get_location_of_episode_text(self, timeout=3):
        return self.helper.get_location(self.get_season_episode_list()[1],
                                        timeout)

    def get_location_of_back_button(self, timeout=3):
        return self.helper.get_location(self.back_button, timeout)

    def get_location_of_video_window(self, timeout=3):
        return self.helper.get_location(self.video, timeout)

    def get_location_of_cp_cw_video_window(self, timeout=3):
        return self.helper.get_location(self.cp_cw_button, timeout)

    def get_tracks_list(self, timeout=10):
        return self.helper.get_list(self.tracks_submenu_list, timeout=timeout)

    def get_audio_track_list(self, timeout=10):
        audio = self.get_tracks_list(timeout)[0]
        return audio.find_elements_by_xpath(
            self.tracks_submenu_options_list)

    def get_subtitles_track_list(self, timeout=10):
        sub = self.get_tracks_list(timeout)[1]
        return sub.find_elements_by_xpath(
            self.tracks_submenu_options_list)

    def get_selected_subtitle_option(self, timeout=10):
        sub = self.get_tracks_list(timeout)[1]
        return sub.find_element_by_xpath(
            self.tracks_submenu_selected_option)

    def get_text_of_selected_subtitle_option(self, timeout=10):
        opt = self.get_selected_subtitle_option(timeout)
        return self.helper.get_text(opt).split("\n")[0]

    def get_subtitle_text_options(self, timeout=10):
        sub_track = self.get_subtitles_track_list(timeout)
        return [x.text.split("\n")[0] for x in sub_track]

    def get_subtitles_text_of_video(self, screenshot_path, lang=None,
                                    timeout=5):
        img = ImageOCR(screenshot_path)
        img.crop(top=77)
        return img.scan_text(lang=lang)

    def make_player_controls_appear(self, timeout=1, tries=3):
        while not self.is_player_controls_displayed(timeout):
            bb = self.helper.get(self.back_button)
            self.driver.helper.move_mouse_to(bb)
            self.driver.helper.move_mouse_about(100, 100)
            sleep(0.3)
            self.driver.helper.move_mouse_about(100, 100)
            sleep(1)
            tries -= 1
            if not tries:
                return False
        return True

    def wait_for_player_controls_to_disappear(self, timeout=10):
        return self.helper.wait_until_not_visible(
            self.back_button, timeout=timeout)

    def wait_for_chainplay_to_appear(self, timeout=200):
        visible = self.helper.wait_until_visible(
            self.cp_next_ep_title, timeout=timeout)
        sleep(2)  # Animation
        return visible

    def take_screenshot_of_video(self, filepath, timeout=5):
        self.helper.take_screenshot(self.video, filepath, timeout)
        return filepath
