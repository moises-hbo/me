from apps.hbonweb.pages.base.page import BasePageObject as Page


class HowToWatch(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.header = "//h1[contains(@class,'_3j8Kk')]"
        self.devices_list = "//ul/li[contains(@class,'_1KV1E _1RLYk')]"
        self.devices_names_list = self.devices_list + \
            "//figcaption/div[@class='vmLp- _3C5GD']"
        self.device_description = \
            "//div[@class='_18rf9 _3EhPv _8tZJP et3Mg _2rDTG _29eeG']"
        # Mobile
        self.device_list_dropdown = \
            "//button[@data-automation='how-to-watch-dropdown-button']"

    def is_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.header)

    def is_device_description_displayed(self, timeout=5):
        return self.helper.is_visible(self.device_description, timeout)

    def is_device_active(self, index, timeout=5):
        return "active" in self.helper.get_attribute(
            self.get_device(index), "class", timeout)

    def click_on_device(self, index, timeout=5):
        devices = self.get_devices_list(timeout)
        self.helper.click(devices[index])

    def get_device(self, index, timeout=5):
        devices = self.get_devices_list(timeout)
        return devices[index]

    def get_text_of_device_list_dropdown(self, timeout=5):
        return self.helper.get_text(self.device_list_dropdown, timeout)

    def get_text_of_device_name(self, index, timeout=5):
        devices_names = self.get_texts_of_devices_names_list(timeout)
        return devices_names[index]

    def get_devices_list(self, timeout=5):
        return self.helper.get_list(self.devices_list, timeout)

    def get_devices_names_list(self, timeout=5):
        return self.helper.get_list(self.devices_names_list, timeout)

    def get_texts_of_devices_names_list(self, timeout=5):
        devices_names = self.get_devices_names_list(timeout)
        return [self.helper.get_text(x) for x in devices_names]
