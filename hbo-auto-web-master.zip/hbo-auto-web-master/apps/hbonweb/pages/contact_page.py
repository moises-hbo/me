from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter


class Contact(Navigation, MoreInfoFooter, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.contact_header = "//h1[contains(@class,'_2M1D5')]"

    def is_contact_page(self, timeout=5):
        return self.is_contact_header_displayed(timeout)

    def is_contact_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.contact_header, timeout)

    def get_text_of_contact_header(self, timeout=10):
        return self.helper.get_text(self.contact_header, timeout=timeout)
