from selenium.webdriver.common.by import By

from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter
from apps.hbonweb.pages.productbox_partial import ProductBox
from apps.hbonweb.pages.carousel_partial import Carousel
from apps.hbonweb.pages.trailer_partial import Trailer
from apps.hbonweb.pages.devices_partial import Devices
from apps.hbonweb.pages.shelf_partial import Shelf
from apps.hbonweb.pages.base.page import BasePageObject as Page


class Welcome(Page):
    """ Welcome partial seen on Home page
        after creating a new account
    """

    def __init__(self, driver):
        super().__init__(driver)
        self.welcome_header = "//h2[@class='_2KrKO LD_c1']"
        self.welcome_intro_text = "//p[@class='Z2s4u _39OU4']/p"
        self.devices_list = dict(
            locator="//a[@class='_2yqaA']", type=By.XPATH)

    def is_welcome_header_displayed(self):
        return self.helper.is_visible(self.welcome_header)

    def is_welcome_intro_text_displayed(self):
        return self.helper.is_visible(self.welcome_intro_text)

    def get_devices_list(self, scroll=True):
        if scroll:
            first = self.helper.get_list(self.devices_list)[0]
            loc = self.helper.get_location(first)
            self.driver.helper.scroll(0, loc["y"] - 100)
        return self.helper.get_list(self.devices_list)

    def get_text_of_welcome_header(self):
        return self.helper.get_text(self.welcome_header)

    def get_location_of_welcome_header(self):
        return self.helper.get_location(self.welcome_header)


class Home(Navigation, CopyrightLanguageFooter, MoreInfoFooter, ProductBox,
           Welcome, Carousel, Shelf):
    def __init__(self, driver):
        super().__init__(driver)
        self.name = "Home Page" if self.is_my_account_link_displayed(1) \
            else "Home Page (Unauth)"


class WhyHBO(Navigation, CopyrightLanguageFooter, MoreInfoFooter, ProductBox,
             Trailer, Devices, Carousel, Shelf):
    def __init__(self, driver):
        super().__init__(driver)
        self.name = "WhyHBO Page"

        self.whybo_free_trial_button = \
            "//a[@data-automation='start-free-trial']"

    def is_loaded(self, timeout=10):
        return self.is_why_hbo_active_link_displayed(timeout)

    def click_on_whbo_free_trial_button(self):
        loc = self.helper.get_location_when_visible(
            self.whybo_free_trial_button)
        self.driver.helper.scroll(loc["x"], loc["y"])
        self.helper.click(self.whbo_free_trial_button)
