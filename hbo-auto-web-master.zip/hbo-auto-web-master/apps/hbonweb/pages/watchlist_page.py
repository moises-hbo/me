from helpers.sleeper import Sleeper as sleep

from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter


class Watchlist(Navigation, MoreInfoFooter, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.no_content_message = \
            "//span[@data-automation='no-content-message']"
        self.explore_shows_button = "//a[@data-automation='explore-shows']"
        self.only_kids_assets_text = \
            "//div[contains(@class,'_3rtPu')]"
        self.watchlist_results = "//ul//figure[contains" \
            "(@data-automation, 'watchlist-results-')]"
        self.watchlist_results_links = self.watchlist_results + \
            "//figcaption[@class='caption']//a[@href]"
        self.sort_dropdown_button = \
            "//button[@data-automation='watchlist-sort-dropdown-button']"
        self.recently_added_sort_option = "//ul" \
            "//li[@data-automation='watchlist-sort-option-0']"
        self.a_z_sort_option = "//ul" \
            "//li[@data-automation='watchlist-sort-option-1']"
        self.release_date_sort_option = "//ul" \
            "//li[@data-automation='watchlist-sort-option-2']"
        self.hide_toonix_content_button = \
            "//div[@class='_1KnMa gW7s3']"
        self.hide_toonix_content_button_activated = "//div" \
            "//input[@data-automation='watchlist-filter-input' " \
            "and contains(@checked, '')]"
        self.product_box = "//div[@data-automation='product-box-copy']"

    def is_no_content_message_displayed(self, timeout=5):
        return self.helper.is_visible(self.no_content_message, timeout)

    def is_explore_shows_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.explore_shows_button, timeout)

    def click_on_explore_shows_button(self):
        self.helper.click(self.explore_shows_button)

    def is_only_kids_assets_text_displayed(self, timeout=10):
        return self.helper.is_visible(self.only_kids_assets_text, timeout)

    def is_watchlist_results_displayed(self, timeout=10):
        return self.helper.is_visible(self.watchlist_results, timeout=timeout)

    def get_watchlist_results(self):
        return self.helper.get_list(self.watchlist_results)

    def open_asset_in_watchlist(self, asset):
        self.helper.click(asset)

    def click_on_remove_from_watchlist_button(self, i=0):
        wasset_remove = "//button[@data-automation=" \
            f"'watchlist-results-{i}-toggle-watchlist-button']"
        self.helper.click(wasset_remove)

    def remove_asset(self, i=0):
        wasset = f"//ul//figure[@data-automation='watchlist-results-{i}']" \
            "//div[contains(@class, 'preview')]"
        self.driver.helper.move_mouse_to(self.helper.get(wasset))
        sleep(1)
        wasset_remove = "//button[@data-automation=" \
            f"'watchlist-results-{i}-toggle-watchlist-button']"
        self.helper.click(wasset_remove)
        sleep(3)

    def is_sort_dropdown_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.sort_dropdown_button, timeout)

    def click_on_sort_dropdown_button(self):
        self.helper.click(self.sort_dropdown_button)

    def click_on_watchlist_asset(self, i):
        element = self.helper.get(
            "//ul//figure[contains(@data-automation, "
            f"'watchlist-results-{i}')]//figcaption[@class='caption']")
        loc = self.helper.get_location(element)
        self.driver.helper.scroll(0, loc["y"] - 300)
        self.helper.click(element)

    def recently_added_sort(self):
        self.click_on_sort_dropdown_button()
        self.helper.click(self.recently_added_sort_option)

    def a_z_sort(self):
        self.click_on_sort_dropdown_button()
        self.helper.click(self.a_z_sort_option)
        sleep(3)

    def release_date_sort(self):
        self.click_on_sort_dropdown_button()
        self.helper.click(self.release_date_sort_option)

    def get_asset_title(self, asset):
        return self.helper.get_text(asset)

    def is_hide_toonix_content_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.hide_toonix_content_button, timeout)

    def click_on_hide_toonix_content_button(self):
        self.helper.click(self.hide_toonix_content_button)

    def is_hide_toonix_content_button_activated(self, timeout=10):
        # It's never visible for some reason
        # We're just looking if the element exists instead
        return self.helper.get(self.hide_toonix_content_button_activated,
                               timeout)

    def is_product_box_displayed(self, timeout=10):
        return self.helper.is_visible(self.product_box, timeout=timeout)
