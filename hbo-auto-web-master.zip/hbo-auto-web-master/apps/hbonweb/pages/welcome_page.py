from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter


class Welcome(CopyrightLanguageFooter):
    """ Page object for Welcome page
    (when SignIn first time from different region)
    """

    def __init__(self, driver):
        super().__init__(driver)
        self.welcome_button = "//button[@data-automation='welcome-got-it']"

    def click_on_welcome_button(self):
        self.helper.click(self.welcome_button)

    def is_welcome_page_displayed(self, timeout=10):
        return self.helper.is_visible(self.welcome_button, timeout=timeout)
