from helpers.sleeper import Sleeper as sleep

from selenium.webdriver.common.by import By

from apps.hbonweb.pages.base.page import BasePageObject as Page
from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import MoreInfoFooter, \
    CopyrightLanguageFooter


class MyAccount(Navigation, MoreInfoFooter, CopyrightLanguageFooter):
    def __init__(self, driver):
        super().__init__(driver)
        self.error_alert = "//div[@data-automation='form-server-error']"
        # My Account Navbar
        self.__myaccount_nav_selected_prefix = \
            "//ul/li[contains(@class, 'selected')]"
        self.personal_information_link = \
            "//a[@data-automation='my-account/personal-information-link']"
        self.personal_information_link_selected = \
            f"{self.__myaccount_nav_selected_prefix}" \
            f"{self.personal_information_link}"
        self.change_password_link = \
            "//a[@data-automation='my-account/change-password-link']"
        self.change_password_link_selected = \
            f"{self.__myaccount_nav_selected_prefix}" \
            f"{self.change_password_link}"
        self.subscription_link = \
            "//a[@data-automation='my-account/subscription-link']"
        self.subscription_link_selected = \
            f"{self.__myaccount_nav_selected_prefix}{self.subscription_link}"
        self.payment_history_link = \
            "//a[@data-automation='my-account/payment-history-link']"
        self.payment_history_link_selected = \
            f"{self.__myaccount_nav_selected_prefix}" \
            f"{self.payment_history_link}"
        self.manage_devices_link = \
            "//a[@data-automation='my-account/manage-devices-link']"
        self.manage_devices_link_selected = \
            f"{self.__myaccount_nav_selected_prefix}{self.manage_devices_link}"
        self.parental_controls_link = \
            "//a[@data-automation='my-account/parental-controls-link']"
        self.parental_controls_link_selected = \
            f"{self.__myaccount_nav_selected_prefix}" \
            f"{self.parental_controls_link}"
        self.cookie_settings_link = \
            "//a[@data-automation='my-account/cookie-settings-link']"
        self.cookie_settings_link_selected = \
            f"{self.__myaccount_nav_selected_prefix}" \
            "{self.cookie_settings_link}"
        self.sign_out_link = "//a[@data-automation='sign-out']"
        # Personal Information
        self.first_name_input = "//input[@data-automation='first-name-input']"
        self.first_name_error_text = \
            "//div[@data-automation='first-name-error']"
        self.last_name_input = "//input[@data-automation='last-name-input']"
        self.last_name_error_text = "//div[@data-automation='last-name-error']"
        self.email_input = "//input[@data-automation='email-input']"
        self.email_error_text = "//div[@data-automation='email-error']"
        self.no_news_offers_button = \
            "//label[@data-automation='email-offers-label-element']"
        self.save_changes_button = \
            "//button[@data-automation='personal-info-submit-button']"
        # Change Password
        self.current_password_input = \
            "//input[@data-automation='current-password-input']"
        self.current_password_toggle = \
            "//button[@data-automation='current-password-visibility-toggle']"
        self.current_password_error = \
            "//div[@data-automation='current-password-error']"
        self.new_password_input = \
            "//input[@data-automation='new-password-input']"
        self.new_password_toggle = \
            "//button[@data-automation='new-password-visibility-toggle']"
        self.new_password_error = \
            "//div[@data-automation='new-password-error']"
        self.confirm_password_input = \
            "//input[@data-automation='confirm-password-input']"
        self.confirm_password_toggle = \
            "//button[@data-automation='confirm-password-visibility-toggle']"
        self.confirm_password_error = \
            "//div[@data-automation='confirm-password-error']"
        self.change_password_button = \
            "//button[@data-automation='change-password-submit-button']"
        # Subscription
        self.payment_type = "//fieldset[@class='bj9Qg _3Hnra']" \
            "/legend[@class='JNc1-']/span"
        self.buy_voucher_button_list = "//fieldset[@class='_3Hnra']/button"
        self.cancelled_sub_message = "//form/p[@class='_1D8P1 _2WKMQ']"
        # Sub active
        self.cancel_subscription_link = \
            "//a[@href='/my-account/cancel-subscription']"
        self.change_payment_button = \
            "//a[@data-automation='change-payment-info']"
        self.card_number = "//span[@data-automation='card-number']"
        self.paypal_active_img = \
            "//img[@data-automation='paypal-icon-active-subscription']"
        self.next_billing_date = dict(
            locator="//div[@data-automation='billing-date/currency']/div/p[1]",
            type=By.XPATH)
        self.billing_price = dict(
            locator="//div[@data-automation='billing-date/currency']/div/p[2]",
            type=By.XPATH)
        # Sub cancelled
        self.account_quitted_header = "//form/h2[@class='_28XLH']"
        self.reactivate_voucher_sub_buttons = "\
            //form/div[@data-phase='default']" \
            "/button[contains(@class,'button-blue-anim')]"
        # Sub closed:
        self.enter_payment_button = dict(
            locator="//fieldset/button[@data-automation='purchase-button']",
            type=By.XPATH)
        # Manage Devices
        self.add_device_button = \
            "//button[@data-automation='manage-devices-submit-button']"
        # Parental Controls
        self.set_pin_button = "//button[@data-automation='set-pin-button']"
        self.reset_pin_button = "//button[@data-automation='reset-pin-button']"
        self.turn_off_pin_button = \
            "//button[@data-automation='turn-off-pin-button']"

    def click_on_personal_info_link(self):
        self.helper.click(self.personal_information_link)

    def click_on_change_password_link(self):
        self.helper.click(self.change_password_link)

    def click_on_subscription_link(self):
        self.helper.click(self.subscription_link)

    def click_on_payment_history_link(self):
        self.helper.click(self.payment_history_link)

    def click_on_manage_devices_link(self):
        self.helper.click(self.manage_devices_link)

    def click_on_parental_controls_link(self):
        self.helper.click(self.parental_controls_link)

    def click_on_cookie_settings_link(self):
        self.helper.click(self.cookie_settings_link)

    def click_on_sign_out_link(self):
        self.helper.click(self.sign_out_link)
        # Give a sec for the page refresh
        sleep(2)

    def click_on_first_name_input(self, timeout=5):
        self.helper.click(self.first_name_input, timeout)

    def click_on_save_changes_button(self):
        self.helper.click(self.save_changes_button)

    def click_on_newsletter_button(self):
        self.helper.click(self.no_news_offers_button)

    def click_on_change_password_button(self):
        self.helper.click(self.change_password_button)

    def click_on_current_password_input(self):
        self.helper.click(self.current_password_input)

    def click_on_new_password_input(self):
        self.helper.click(self.new_password_input)

    def click_on_confirm_password_input(self):
        self.helper.click(self.confirm_password_input)

    def click_on_cancel_subscription_link(self, timeout=30):
        self.helper.click(self.cancel_subscription_link, timeout=timeout)

    def click_on_change_payment_button(self, timeout=10):
        self.helper.click(self.change_payment_button, timeout)

    def click_on_enter_payment_button(self, timeout=10):
        self.helper.click(self.enter_payment_button, timeout)

    def click_on_sub_buy_button(self, timeout=10):
        button_list = self.get_sub_buy_voucher_button_list(timeout)
        self.helper.click(button_list[0])

    def click_on_sub_add_voucher_button(self, timeout=10):
        button_list = self.get_sub_buy_voucher_button_list(timeout)
        self.helper.click(button_list[1])

    def click_on_sub_reactivate_button(self, timeout=10):
        btn = self.get_sub_reactivate_button()
        self.helper.click(btn)

    def click_on_set_pin_button(self):
        self.helper.click(self.set_pin_button)

    def click_on_reset_pin_button(self, timeout=5):
        self.helper.click(self.reset_pin_button, timeout)

    def click_on_turn_off_pin_button(self, timeout=5):
        self.helper.click(self.turn_off_pin_button, timeout)

    def clear_text_on_first_name(self, timeout=5):
        self.helper.clear_text(self.first_name_input, timeout)

    def clear_text_on_last_name(self, timeout=5):
        self.helper.clear_text(self.last_name_input, timeout)

    def clear_text_of_email(self, timeout=5):
        self.helper.clear_text(self.email_input, timeout)

    def input_text_on_first_name(self, text):
        self.helper.clear_text(self.first_name_input)
        self.helper.input_text(self.first_name_input, text)

    def input_text_on_last_name(self, text):
        self.helper.clear_text(self.last_name_input)
        self.helper.input_text(self.last_name_input, text)

    def input_text_on_email(self, text):
        self.helper.clear_text(self.email_input)
        self.helper.input_text(self.email_input, text)

    def input_text_on_current_password(self, text):
        self.helper.clear_text(self.current_password_input)
        self.helper.input_text(self.current_password_input, text)

    def input_text_on_new_password(self, text):
        self.helper.clear_text(self.new_password_input)
        self.helper.input_text(self.new_password_input, text)

    def input_text_on_confirm_password(self, text):
        self.helper.clear_text(self.confirm_password_input)
        self.helper.input_text(self.confirm_password_input, text)

    def get_text_of_first_name(self):
        return self.helper.get_attribute(self.first_name_input, "value")

    def get_text_of_last_name(self):
        return self.helper.get_attribute(self.last_name_input, "value")

    def get_text_of_email(self):
        return self.helper.get_attribute(self.email_input, "value")

    def get_placeholder_of_firstname_input(self):
        return self.helper.get_attribute(self.first_name_input, "placeholder")

    def get_placeholder_of_lastname_input(self):
        return self.helper.get_attribute(self.last_name_input, "placeholder")

    def is_updated_changes_success_alert_displayed(self):
        return self.helper.is_visible(self.ok_toast)

    def is_personal_information_link_selected_displayed(self, timeout=10,
                                                        locator_type=By.XPATH):
        return self.helper.is_visible(
            self.personal_information_link_selected, timeout, locator_type)

    def is_change_password_link_selected_displayed(self, timeout=10,
                                                   locator_type=By.XPATH):
        return self.helper.is_visible(
            self.change_password_link_selected, timeout, locator_type)

    def is_subscription_link_selected_displayed(self, timeout=10,
                                                locator_type=By.XPATH):
        return self.helper.is_visible(
            self.subscription_link_selected, timeout, locator_type)

    def is_payment_history_link_selected_displayed(self, timeout=10,
                                                   locator_type=By.XPATH):
        return self.helper.is_visible(
            self.payment_history_link_selected, timeout, locator_type)

    def is_manage_devices_link_selected_displayed(self, timeout=10,
                                                  locator_type=By.XPATH):
        return self.helper.is_visible(
            self.manage_devices_link_selected, timeout, locator_type)

    def is_parental_controls_link_selected_displayed(self, timeout=10,
                                                     locator_type=By.XPATH):
        return self.helper.is_visible(
            self.parental_controls_link_selected, timeout, locator_type)

    def is_save_changes_button_displayed(self):
        return self.helper.is_visible(self.save_changes_button)

    def is_firstname_error_displayed(self, timeout=10,
                                     locator_type=By.XPATH):
        return self.helper.is_visible(
            self.first_name_error_text, timeout, locator_type)

    def is_lastname_error_displayed(self, timeout=10,
                                    locator_type=By.XPATH):
        return self.helper.is_visible(
            self.last_name_error_text, timeout, locator_type)

    def is_email_error_displayed(self, timeout=10, locator_type=By.XPATH):
        return self.helper.is_visible(
            self.email_error_text, timeout, locator_type)

    def is_newsletter_checkbox_active(self, timeout=10,
                                      locator_type=By.XPATH):
        # TODO: 'checked' attribute is bugged and won't show the
        # first time you enter My Account
        # Disable and Re-enable to make it appear, if in Enabled state
        checkbox = self.no_news_offers_button + "/input"
        if self.helper.get_attribute(checkbox, "checked",
                                     timeout,
                                     locator_type) == "true":
            return True
        return False

    def is_error_alert_displayed(self, timeout=10):
        return self.helper.is_visible(self.error_alert, timeout)

    def is_change_password_button_displayed(self):
        return self.helper.is_visible(self.change_password_button)

    def is_current_password_toggle_displayed(self):
        return self.helper.is_visible(self.current_password_toggle)

    def is_new_password_toggle_displayed(self):
        return self.helper.is_visible(self.new_password_toggle)

    def is_confirm_password_toggle_displayed(self):
        return self.helper.is_visible(self.confirm_password_toggle)

    def is_current_password_error_displayed(self, timeout=5):
        return self.helper.is_visible(self.current_password_error, timeout)

    def is_new_password_error_displayed(self, timeout=5):
        return self.helper.is_visible(self.new_password_error, timeout)

    def is_confirm_password_error_displayed(self, timeout=5):
        return self.helper.is_visible(self.confirm_password_error, timeout)

    def is_subscription_cancelled_header_displayed(self):
        return self.helper.is_visible(self.account_quitted_header)

    def is_reactivate_subscription_button_displayed(self, timeout=30):
        btn = self.get_sub_reactivate_button(timeout)
        return self.helper.is_visible(btn)

    def is_add_voucher_button_displayed(self, timeout=10):
        btn = self.get_sub_add_voucher_button(timeout)
        return self.helper.is_visible(btn)

    def is_add_device_button_displayed(self):
        return self.helper.is_visible(self.add_device_button)

    def is_set_pin_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.set_pin_button, timeout)

    def is_reset_pin_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.reset_pin_button, timeout)

    def is_turn_off_pin_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.turn_off_pin_button, timeout)

    def is_card_number_displayed(self, timeout=10):
        return self.helper.is_visible(self.card_number, timeout)

    def is_paypal_active_img_displayed(self, timeout=10):
        return self.helper.is_visible(self.paypal_active_img, timeout)

    def is_sub_buy_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.get_sub_buy_voucher_button_list(timeout)[0])

    def is_sub_reactivate_button_displayed(self, timeout=10):
        btn = self.get_sub_reactivate_button(timeout)
        return self.helper.is_visible(btn)

    def is_change_payment_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.change_payment_button, timeout)

    def is_cancel_subscription_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.cancel_subscription_link, timeout)

    def get_payment_text(self, timeout=10):
        return self.helper.get_text(self.payment_type, timeout)

    def get_text_of_cancelled_sub_message(self, timeout=5):
        return self.helper.get_text(self.cancelled_sub_message, timeout)

    def get_text_of_next_billing_date(self, timeout=10):
        return self.helper.get_text(self.next_billing_date, timeout)

    def get_text_of_billing_amount(self, timeout=10):
        return self.helper.get_text(self.billing_price, timeout)

    def get_text_of_error_alert(self, timeout=5):
        return self.helper.get_text(self.error_alert, timeout)

    def get_sub_buy_voucher_button_list(self, timeout=5):
        return self.helper.get_list(self.buy_voucher_button_list, timeout)

    def get_cancelled_sub_buttons(self, timeout=5):
        return self.helper.get_list(
            self.reactivate_voucher_sub_buttons, timeout)

    def get_sub_reactivate_button(self, timeout=5):
        reactivate_btn = self.get_cancelled_sub_buttons(timeout)[0]
        return reactivate_btn

    def get_sub_add_voucher_button(self, timeout=5):
        voucher_btn = self.get_cancelled_sub_buttons(timeout)[1]
        return voucher_btn

    def wait_until_cancel_sub_link_is_displayed(self, timeout=10):
        return self.helper.wait_until_visible(
            self.cancel_subscription_link, timeout=timeout)


class UpdatePersonalInformation(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.error_alert = "//div[@data-automation='form-server-error']"
        self.update_information_header = dict(
            locator="//p[@class='_3IrhE _3UNBY LD_c1']", type=By.XPATH)
        self.password_field = "//div[@class='form-input-password']" \
            "/input[@type='password']"
        self.password_show_button = "//div[@class='form-input-password]/button"
        self.password_error = "//div[@data-automation='undefined-error']"
        self.submit_button = "//button[@data-automation='submit']"
        self.close_view_button = "//button[@data-automation='modal-close']"
        self.forgotten_password_link = "//div/a[@href='/forgot-password']"
        self.contact_customer_service_link = "//div/a[@href='/contact']"

    def is_update_personal_information_page(self, timeout=5):
        return self.helper.is_visible(self.update_information_header, timeout)

    def is_error_alert_displayed(self, timeout=10):
        return self.helper.is_visible(self.error_alert, timeout)

    def is_close_view_button_displayed(self):
        return self.helper.is_visible(self.close_view_button)

    def is_password_error_displayed(self, timeout=5):
        return self.helper.is_visible(self.password_error, timeout)

    def input_text_on_password(self, text):
        self.helper.clear_text(self.password_field)
        self.helper.input_text(self.password_field, text)

    def get_text_of_error_alert(self, timeout=5):
        return self.helper.get_text(self.error_alert, timeout)

    def click_on_submit_button(self):
        self.helper.click(self.submit_button)

    def click_on_forgotten_password_link(self):
        self.helper.click(self.forgotten_password_link)

    def click_on_contact_customer_service_link(self):
        self.helper.click(self.contact_customer_service_link)


class AuthForgotPassword(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.fp_header = dict(
            locator="//h1[@data-automation='forgot-password-page-title']",
            type=By.XPATH)
        self.email_to_send_reset_text = "//p[@class='a88wN']"
        self.send_reset_password_button = \
            "//form/div/div[@data-phase='default']/button"

    def is_auth_forgot_password_page(self, timeout=5):
        return self.helper.is_visible(self.fp_header, timeout)

    def get_email_to_send_reset_text(self):
        return self.helper.get_text(self.email_to_send_reset_text)

    def is_send_reset_password_button_displayed(self):
        return self.helper.is_visible(self.send_reset_password_button)


class CancelSubscription(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.watch_now_button = "//div[@class='pull-below-header']" \
            "//a[@class='button-outline-pill']"
        self.keep_subscription_button = \
            "//li/a[@data-analytics='keep-subscription']"
        self.cancel_subscription_button = \
            "//li/button[@data-analytics='cancel-subscription']"

    def is_page_active(self):
        return self.is_watch_now_button_displayed() and \
            self.is_cancel_subscription_button_displayed() and \
            self.is_keep_subscription_button_displayed()

    def click_on_watch_now_button(self):
        self.helper.click(self.watch_now_button)

    def click_on_cancel_subscription_button(self):
        self.helper.click(self.cancel_subscription_button)

    def click_on_keep_subscription_button(self):
        self.helper.click(self.keep_subscription_button)

    def is_watch_now_button_displayed(self):
        return self.helper.is_visible(self.watch_now_button)

    def is_cancel_subscription_button_displayed(self):
        return self.helper.is_visible(self.cancel_subscription_button)

    def is_keep_subscription_button_displayed(self):
        return self.helper.is_visible(self.keep_subscription_button)

    def get_link_of_watch_now_button(self, timeout=5):
        return self.helper.get_link(self.watch_now_button, timeout)
