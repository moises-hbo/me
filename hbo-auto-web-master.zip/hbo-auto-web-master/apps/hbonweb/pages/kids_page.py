from helpers.sleeper import Sleeper as sleep
from apps.hbonweb.pages.navigation_partial import Navigation
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter, \
    MoreInfoFooter
from apps.hbonweb.pages.productbox_partial import ProductBox
from apps.hbonweb.pages.shelf_partial import Shelf


class Kids(Navigation, MoreInfoFooter, CopyrightLanguageFooter, ProductBox,
           Shelf):
    def __init__(self, driver):
        super().__init__(driver)
        self.name = "Kids Page" if self.is_my_account_link_displayed(1) \
            else "Kids Page (Unauth)"
        if self.is_kids_mode_locked():
            self.name += " (Locked)"

        self.got_it_alert_button = "//button[@data-automation='family-got-it']"
        self.lock_button = "//button[@data-automation='family-lock-button']"

    def click_on_got_it_alert_button(self):
        self.helper.click(self.got_it_alert_button)
        # Give overlay time to disappear
        sleep(1)

    def click_on_lock_button(self):
        self.helper.click(self.lock_button)
        sleep(1)

    def is_kids_mode_locked(self):
        return self.get_background_color() == "#ffffff"

    def is_got_it_alert_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.got_it_alert_button, timeout)

    def is_kids_lock_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.lock_button, timeout)
