from selenium.webdriver.common.by import By
from apps.hbonweb.pages.base.page import BasePageObject as Page


class StartWatchingNow(Page):
    """Popup page when trying to play a movie asset as unauthenticated"""

    def __init__(self, driver):
        super().__init__(driver)
        self.start_watching_header = \
            "//h1[@data-automation='start-watching-page-title']"
        self.product_box = dict(
            locator="div[data-automation='start-watchingproduct-box']",
            type=By.CSS_SELECTOR)
        self.free_trial_button = "//div/button[contains(@class,'button-blue') \
            and contains(@class,'_908pO')]"
        self.have_account_p = dict(
            locator="div._2OiG7 p", type=By.CSS_SELECTOR)
        self.sign_in_button = dict(
            locator="div._2OiG7 button", type=By.CSS_SELECTOR)
        self.close_button = dict(
            locator="button[data-automation='modal-close']",
            type=By.CSS_SELECTOR)
        # Mobile
        self.mobile_free_trial_button = dict(
            locator="div.q7p25", type=By.CSS_SELECTOR)

    def is_start_watching_header_displayed(self, timeout=10):
        return self.helper.is_visible(self.start_watching_header, timeout)

    def is_product_box_displayed(self, timeout=5):
        return self.helper.is_visible(self.product_box, timeout)

    def is_free_trial_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.free_trial_button, timeout)

    def is_mobile_free_trial_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.mobile_free_trial_button, timeout)

    def is_have_account_text_displayed(self, timeout=5):
        return self.helper.is_visible(self.have_account_p, timeout)

    def is_sign_in_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.sign_in_button, timeout)

    def is_close_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.close_button, timeout)

    def click_on_free_trial_button(self):
        self.helper.click(self.free_trial_button)

    def click_on_sign_in_button(self, timeout=5):
        return self.helper.click(self.sign_in_button, timeout)

    def click_on_close_button(self, timeout=5):
        self.helper.click(self.close_button, timeout)
