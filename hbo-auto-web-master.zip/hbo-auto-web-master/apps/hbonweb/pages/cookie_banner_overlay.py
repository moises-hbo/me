from apps.hbonweb.pages.base.page import BasePageObject as Page
from apps.hbonweb.pages.footer_partial import CopyrightLanguageFooter


class CookieBanner(Page):
    """Cookie Banner partial seen in bottom on most pages if cookies not set"""

    def __init__(self, driver):
        super().__init__(driver)
        self.cookies_banner = "//div[@class='q7p25']"
        self.__cbadd = self.cookies_banner + \
            "/div[@data-automation='cookies-banner']"
        self.info_text = self.__cbadd + "/div/div/span"
        self.data_policy_link = self.info_text + \
            "/a[@href='/data-policy']"
        self.accept_button = self.__cbadd + \
            "//a[contains(@class, 'gqchY')]"
        self.read_more_button = self.__cbadd + "//a[@href='/read-more']"

    def click_on_accept_button(self):
        self.helper.click(self.accept_button)

    def click_on_read_more_button(self):
        self.helper.click(self.read_more_button)

    def click_on_data_policy_link(self):
        self.helper.click(self.data_policy_link)

    def is_cookies_banner_displayed(self, timeout=10):
        return self.helper.is_visible(self.cookies_banner, timeout)

    def is_accept_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.accept_button, timeout)

    def is_read_more_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.read_more_button, timeout)


class CookieReadMore(CopyrightLanguageFooter):
    """Cookie Read More partial page.
    Seen from Read More in Cookie Banner,
    Show alternatives in Get Started
    and cookie settings in My Account"""

    def __init__(self, driver):
        super().__init__(driver)
        self.policy_header = "//h1[contains(@class,'_3hd3Q')]"
        self.data_policy_link = "//a[@href='/data-policy']"
        self.select_data_policy_list = "//li[@class='list-element']"
        self.select_data_policy_option_label = \
            self.select_data_policy_list + "/label"
        self.select_data_policy_option_checkbox = \
            self.select_data_policy_option_label + "/input"
        self.select_data_policy_option_header_text = \
            self.select_data_policy_option_label + "/div/div/h2"
        self.select_data_policy_option_description_text = \
            self.select_data_policy_option_label + "/div/div/span"
        self.save_button = "//div[contains(@class,'pulse-button')]"\
            "/button[contains(@class,'button-blue-anim')]"
        # Individual options
        self.facebook_option_label = self.select_data_policy_list + \
            "/label[@data-automation='facebookAds-setting-label-element']"
        self.facebook_option_checkbox = self.facebook_option_label + "/input"
        self.google_option_label = self.select_data_policy_list + \
            "/label[@data-automation='googleAds-setting-label-element']"
        self.google_option_checkbox = self.google_option_label + "/input"
        self.twitter_option_label = self.select_data_policy_list + \
            "/label[@data-automation='twitterAds-setting-label-element']"
        self.twitter_option_checkbox = self.twitter_option_label + "/input"
        self.bing_option_label = self.select_data_policy_list + \
            "/label[@data-automation='bing-setting-label-element']"
        self.bing_option_checkbox = self.bing_option_label + "/input"
        self.thirdparty_option_label = self.select_data_policy_list + \
            "/label[@data-automation='thirdParty-setting-label-element']"
        self.thirdparty_option_checkbox = \
            self.thirdparty_option_label + "/input"
        # Read More / Show Alternatives only
        self.select_all_label = \
            "//label[@data-automation='select_all-setting-label-element']"
        self.select_all_checkbox = self.select_all_label + \
            "/input[@data-automation='select_all-setting-input']"

    def click_on_select_all_checkbox(self):
        self.helper.click(self.select_all_label)

    def click_on_facebook_option_checkbox(self):
        self.helper.click(self.facebook_option_label)

    def click_on_google_option_checkbox(self):
        self.helper.click(self.google_option_label)

    def click_on_twitter_option_checkbox(self):
        self.helper.click(self.twitter_option_label)

    def click_on_bing_option_checkbox(self):
        self.helper.click(self.bing_option_label)

    def click_on_thirdparty_option(self):
        self.helper.click(self.thirdparty_option_label)

    def click_on_save_button(self):
        self.driver.helper.scroll_to_bottom()
        self.helper.click(self.save_button)

    def is_cookie_banner_read_more_page(self):
        return self.is_policy_header_displayed() \
            and self.is_data_policy_link_displayed()

    def is_policy_header_displayed(self):
        return self.helper.is_visible(self.policy_header)

    def is_data_policy_link_displayed(self):
        return self.helper.is_visible(self.data_policy_link)

    def is_select_all_checkbox_checked(self):
        return self.helper.is_selected(self.select_all_checkbox)

    def is_data_policy_option_checked(self, checkbox_element):
        return self.helper.is_selected(checkbox_element)

    def is_facebook_option_checked(self):
        return self.helper.is_selected(self.facebook_option_checkbox)

    def is_google_option_checked(self):
        return self.helper.is_selected(self.google_option_checkbox)

    def is_twitter_option_checked(self):
        return self.helper.is_selected(self.twitter_option_checkbox)

    def is_bing_option_checked(self):
        return self.helper.is_selected(self.bing_option_checkbox)

    def is_thirdparty_option_checked(self):
        return self.helper.is_selected(self.thirdparty_option_checkbox)

    def get_data_policy_options(self):
        return self.helper.get_list(self.select_data_policy_list)

    def get_data_policy_option_labels(self):
        return self.helper.get_list(self.select_data_policy_option_label)

    def get_data_policy_option_checkboxes(self):
        return self.helper.get_list(self.select_data_policy_option_checkbox)

    def get_data_policy_option_headers(self):
        return self.helper.get_list(self.select_data_policy_option_header_text)

    def get_data_policy_option_descriptions(self):
        return self.helper.get_list(
            self.select_data_policy_option_description_text)

    def get_data_policy_option_headers_and_descs(self):
        return zip(
            self.get_data_policy_option_headers(),
            self.get_data_policy_option_descriptions())
