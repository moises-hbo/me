from selenium.webdriver.common.keys import Keys
from apps.hbonweb.pages.navigation_partial import NavigationLogo


class Pin(NavigationLogo):
    def __init__(self, driver):
        super().__init__(driver)
        self._pre_set_pin = "//div[@id='set-pin-screen']"
        self._pre_confirm_pin = "//div[@id='confirm-pin-screen']"
        self.set_pin_title = self._pre_set_pin + \
            "//h1[@data-automation='set-pin-title']"
        self.confirm_pin_title = self._pre_confirm_pin + \
            "//h1[@data-automation='set-pin-title']"
        self.exit_kids_page_title = \
            "//h1[@data-automation='exit-family-page-title']"
        self.maybe_later_link = "//a[@data-automation='maybe-later']"
        self.dont_ask_me_again_button = \
            "//button[@data-automation='dont-ask-me-again']"

    def get_digit_path(self, index=1):
        return f"//input[contains(@data-automation, 'pin-digit-{index}')]"

    def get_text_of_set_pin_title(self, timeout=2):
        return self.helper.get_text(self.set_pin_title, timeout)

    def get_text_of_confirm_pin_title(self, timeout=2):
        return self.helper.get_text(self.confirm_pin_title, timeout)

    def get_text_of_pin_digit(self, digit, confirm=False, timeout=2):
        digit = self.get_digit_path(digit)
        return self.helper.get_attribute(digit, "value", timeout)

    def click_on_maybe_later_link(self):
        self.helper.click(self.maybe_later_link)

    def click_on_dont_ask_again_link(self):
        self.helper.click(self.dont_ask_me_again_button)

    def is_set_pin_title_displayed(self, timeout=10):
        return self.helper.is_visible(self.set_pin_title, timeout)

    def is_confirm_pin_title_displayed(self, timeout=10):
        return self.helper.is_visible(self.confirm_pin_title, timeout)

    def is_exit_kids_page_title_displayed(self, timeout=10):
        return self.helper.is_visible(self.exit_kids_page_title, timeout)

    def enter_pin_number(self, number, digit=1, confirm=False):
        digit = self.get_digit_path(digit)
        self.helper.input_text(digit, str(number))

    def enter_backspace_on_pin_number(self, digit=1, confirm=False):
        digit = self.get_digit_path(digit)
        self.helper.input_text(digit, Keys.BACKSPACE)

    def enter_pin(self, pin, confirm=False):
        pin = str(pin)
        for i in range(1, 5):
            self.enter_pin_number(pin[i-1], i, confirm)

    def clear_text_of_pin_digit(self, digit, confirm=False, timeout=2):
        digit = self.get_digit_path(digit)
        self.helper.clear_text(digit, timeout)

    def wait_until_confirm_pin_is_displayed(self, timeout=5):
        return self.helper.wait_until_visible(
            self.confirm_pin_title, timeout=timeout)
