import pytest

from apps.hbonweb.pages.base.page import BasePageObject as Page

from apps.hbonshared.fixtures import *

from helpers.logger import Log


@pytest.fixture
def driver(driver):
    page = Page(driver)
    page.wait_for_loading_pulse_to_appear(3)
    page.wait_for_loading_pulse_to_disappear()

    app_version = page.get_app_version()
    player_version = page.get_app_player_version()

    log = Log(loglevel=Log.INFO)
    log(f"App Version: {app_version}")
    log(f"Player Version: {player_version}")

    yield driver
