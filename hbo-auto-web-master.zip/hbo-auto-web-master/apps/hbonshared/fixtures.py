import pytest
import random
from helpers.configmanager import ConfigManager

from apps.hbonshared.resourcesmanager import ResourcesManager, User, \
    SpecialUser

from tools.computer import get_date

cm = ConfigManager()


@pytest.fixture()
def user():
    """Return relevant standard user for suite."""
    user = ResourcesManager.get_user()
    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api
    return user


@pytest.fixture()
def user_change_password():
    """
    Change Password User.
    For changing password.
    Added extra attribute 'tmp_password'.
    """
    user = ResourcesManager.get_special_user(SpecialUser.CHANGE_PASSWORD)
    # Reset password
    reset_pass = ResourcesManager.get_api(user.email, user.tmp_password)
    reset_pass.change_user_info(
        old_password=user.tmp_password, new_password=user.password)

    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    yield user

    user.api.change_user_info(
        old_password=user.tmp_password, new_password=user.password)


@pytest.fixture()
def user_change_pin():
    """
    Change PIN User
    For changing PIN.
    Added extra attribute 'tmp_pin'.
    """
    user = ResourcesManager.get_special_user(SpecialUser.CHANGE_PIN)
    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    user.api.reset_pin(remove=True)

    yield user

    user.api.reset_pin(remove=True)


@pytest.fixture()
def user_change_email():
    """
    Change Email User.
    For changing email.
    Added extra attribute 'tmp_email'.
    """
    user = ResourcesManager.get_special_user(SpecialUser.CHANGE_EMAIL)
    # Reset mail to original
    reset_mail = ResourcesManager.get_api(user.tmp_email, user.password)
    reset_mail.change_user_info(username=user.email)

    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    yield user

    user.api.change_user_info(username=user.email)


@pytest.fixture()
def user_change_info():
    """
    Change Info User.
    For Changing user info.
    Added extra attributes tmp_firstname & tmp_lastname.
    """
    user = ResourcesManager.get_special_user(SpecialUser.CHANGE_INFO)
    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    user.api.change_user_info(firstname=user.firstname, lastname=user.lastname)

    yield user

    user.api.change_user_info(firstname=user.firstname, lastname=user.lastname)


@pytest.fixture()
def user_full_watchlist():
    user = ResourcesManager.get_special_user(SpecialUser.FULL_WATCHLIST)
    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    return user


@pytest.fixture()
def user_playback():
    """Gives user which should have valid subscription,
    so that playback works"""
    user = ResourcesManager.get_special_user(
        random.choice(
            (SpecialUser.PLAYBACK, SpecialUser.PLAYBACK2,
             SpecialUser.PLAYBACK3)))
    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    return user


@pytest.fixture()
def user_no_cw():
    """Gives user which should not have any items in continue watching shelf"""
    user = ResourcesManager.get_special_user(SpecialUser.NO_CW)
    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    return user


@pytest.fixture()
def user_download():
    """Gives user which should be used related to temporary downloads"""
    user = ResourcesManager.get_special_user(SpecialUser.DOWNLOAD)
    api = ResourcesManager.get_api(user.email, user.password)
    user.api = api

    return user


@pytest.fixture()
def user_tmp():
    """Give you random user info (user doesn't exist)"""
    firstname = "Auto"
    lastname = "Test"
    password = "asdfasdf"
    pin = "1111"
    region = cm.country_id
    date = get_date()
    email = "auto.qa.{r}.{date}.{rando}@qa.hbo.eu" \
        .format(r=region,
                date=date,
                rando=random.randint(0, 9999))
    return User(email, password, firstname, lastname, pin, region)


@pytest.fixture()
def user_tmp_ss(user_tmp):
    """Same as user_tmp, but with QA email, for tracking
    successful creation of subscription of user
    """
    user_tmp.email = user_tmp.email \
        .replace("auto.", "ss.")
    user_tmp.firstname = "Successful"
    user_tmp.lastname = "Subscription"
    return user_tmp


@pytest.fixture()
def user_tmp_cs(user_tmp):
    """Same as user_tmp_ss, but with the expectation
    additional steps to cancel a subscription will
    be taken, after registration
    """
    user_tmp.email = user_tmp.email \
        .replace("auto.", "cs.")
    user_tmp.firstname = "Cancelled"
    user_tmp.lastname = "Subscription"
    return user_tmp


@pytest.fixture()
def cc():
    """Get credit card information for standard user"""
    return ResourcesManager.get_active_credit_card()


@pytest.fixture()
def wrong_cc():
    """Get a credit card from nonactive country"""
    country_codes = ResourcesManager.get_countries()
    nextcc = country_codes.index(cm.country_id) + 1
    wrong_cc = country_codes[0] if nextcc == len(country_codes) \
        else country_codes[nextcc + 1]
    return ResourcesManager.get_credit_card("VISA", wrong_cc)


@pytest.fixture()
def paypal_user():
    return ResourcesManager.get_paypal_user()


@pytest.fixture()
def paypal_user_nocc():
    return ResourcesManager.get_paypal_user(cc_country_id="none")


@pytest.fixture()
def languages(languages_all):
    langs = languages_all
    return langs["nordic"] if cm.region == "nordic" else langs["espana"]


@pytest.fixture()
def languages_all():
    langs = {
        "nordic": {"se": "SVENSKA", "fi": "SUOMI", "dk": "DANSK",
                   "no": "NORSK", "en": "ENGLISH"},
        "spain": {"es": "ESPAÑOL", "en": "ENGLISH"}}
    return langs


@pytest.fixture()
def movie():
    return ResourcesManager.get_special_asset("movie")


@pytest.fixture()
def kids_movie():
    return ResourcesManager.get_special_asset("kids_movie")


@pytest.fixture()
def episode():
    return ResourcesManager.get_special_asset("episode")


@pytest.fixture()
def kids_episode():
    return ResourcesManager.get_special_asset("kids_episode")


@pytest.fixture()
def last_episode():
    return ResourcesManager.get_special_asset("last_episode")


@pytest.fixture()
def has_chainplay():
    return ResourcesManager.get_special_asset("has_chainplay")


@pytest.fixture()
def movie_special_characters():
    return ResourcesManager.get_special_asset("movie_special_characters")


@pytest.fixture()
def long_series_first_episode():
    return ResourcesManager.get_special_asset("long_series_first_episode")


@pytest.fixture()
def long_series_last_episode():
    return ResourcesManager.get_special_asset("long_series_last_episode")


@pytest.fixture()
def downloadable_movie():
    return ResourcesManager.get_special_asset("downloadable_movie")


@pytest.fixture()
def downloadable_movie_kids():
    return ResourcesManager.get_special_asset("downloadable_movie_kids")


@pytest.fixture()
def downloadable_episode():
    return ResourcesManager.get_special_asset("downloadable_episode")


@pytest.fixture()
def downloadable_episode_next():
    return ResourcesManager.get_special_asset("downloadable_episode_next")


@pytest.fixture()
def downloadable_episode_kids():
    return ResourcesManager.get_special_asset("downloadable_episode_kids")


@pytest.fixture()
def downloadable_episode_kids_next():
    return ResourcesManager.get_special_asset("downloadable_episode_kids_next")


@pytest.fixture()
def used_voucher():
    return ResourcesManager.get_voucher("invalid_used")