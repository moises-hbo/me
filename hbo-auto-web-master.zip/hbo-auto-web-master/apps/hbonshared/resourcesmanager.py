import json
from pathlib import Path

from helpers.configmanager import ConfigManager
from helpers.logger import Log
from helpers.enums import Country, Region, Url, Environment, Language, \
    CreditCardType
from helpers.utility_functions import match_list_values


from hboapi.ibm import WebLanguage, ApiCalls as Api

cm = ConfigManager()
log = Log(logname="test.framework")


class ResourcesManager(object):

    @classmethod
    def get_asset_title(cls, asset_type, asset_attribute="assets",
                        is_original_title=False):
        resource = cls.match_asset(asset_type, asset_attribute)
        return resource["referenceName"] if is_original_title \
            else resource["title"]

    @classmethod
    def get_special_asset(cls, asset_type):
        resource = cls.match_special_asset(asset_type)
        if resource:
            return SpecialAsset(resource["title"], resource["referenceName"],
                                resource["type"],
                                resource["section"],
                                resource.get("season")
                                if resource["type"] == "series" else 0,
                                resource.get("episode")
                                if resource["type"] == "series" else 0,
                                resource.get("ep_name")
                                if resource["type"] == "series" else "")
        return resource

    @classmethod
    def get_user(cls, status=None, country=None):
        env = cm.environment

        if not country:
            country = cls.get_country(cm.country_id)

        resources_file = cls.read_resources_file()
        users_records = []
        for resource in resources_file["users"]:
            users_records.append(resource)
            if resource["env"] == env \
                    and cls.get_country(resource["country"]) == country:
                if status:
                    if resource["status"] == status:
                        return cls.get_user_instance(resource)
                else:
                    return cls.get_user_instance(resource)

        Log("Available users: \n", *users_records, sep="\n", loglevel=Log.INFO)
        raise NameError(f"User wasn't found in file!")

    @classmethod
    def get_special_user(cls, user_type):
        env = cm.environment
        country = cls.get_country(cm.country_id)

        resources_file = cls.read_resources_file()
        users_records = []
        for resource in resources_file["special_users"][user_type]:
            users_records.append(resource)
            if resource["env"] == env \
                    and cls.get_country(resource["country"]) == country:
                user = cls.get_user_instance(resource)
                if "tmp_password" in resource.keys():
                    setattr(user, "tmp_password", resource.get("tmp_password"))
                if "tmp_pin" in resource.keys():
                    setattr(user, "tmp_pin", resource.get("tmp_pin"))
                if "tmp_email" in resource.keys():
                    setattr(user, "tmp_email", resource.get("tmp_email"))
                if "tmp_firstname" in resource.keys():
                    setattr(user, "tmp_firstname",
                            resource.get("tmp_firstname"))
                if "tmp_lastname" in resource.keys():
                    setattr(user, "tmp_lastname", resource.get("tmp_lastname"))
                return user

        raise NameError(f"User wasn't found in file!")

    @classmethod
    def get_paypal_user(cls, country_id=None, cc_country_id=None):
        """
            Read resources.json file, and return a Paypal
            user that match current environment & country
            as well as credit card country
        """
        env = cm.environment
        country = country_id if country_id else cm.country_id
        cc_country = cc_country_id if cc_country_id else country

        resources_file = cls.read_resources_file()
        for ppuser in resources_file["paypal_users"]:
            if ppuser["env"] == env \
                    and ppuser["country"] == country \
                    and ppuser["cc_country"] == cc_country:
                return PayPalUser(
                    ppuser["email"], ppuser["password"],
                    ppuser["firstname"], ppuser["lastname"],
                    ppuser["cc_country"])
        raise NameError(
            f"No Paypal user with env '{env}' and country '{country}' found!")

    @staticmethod
    def get_user_instance(resource_json):
        return User(resource_json["email"], resource_json["password"],
                    resource_json["firstname"], resource_json["lastname"],
                    resource_json["pin"], resource_json["country"])

    @staticmethod
    def get_country(country_id=None):
        if not country_id:
            country_id = cm.country_id

        if country_id == "se":
            return Country.SE
        elif country_id == "fi":
            return Country.FI
        elif country_id == "no":
            return Country.NO
        elif country_id == "dk":
            return Country.DK
        elif country_id == "es":
            return Country.ES
        else:
            return Country.UNSUPPORTED

    @staticmethod
    def get_region(region_id=None):
        if not region_id:
            region_id = cm.region

        if region_id == "nordic":
            return Region.NORDIC
        elif region_id == "spain":
            return Region.ESPANA
        elif region_id == "inside_eu":
            return Region.INSIDE_EU
        elif region_id == "outside_eu":
            return Region.OUTSIDE_EU
        else:
            return Region.UNSUPPORTED

    @staticmethod
    def get_url(current=False, env=None, region=None, lang=None):
        if current:
            return cm.url

        if [x for x in [env, region, lang] if not x]:
            raise ValueError("env, region nor lang cannot be None")

        if env == Environment.PROD:
            if region == Region.NORDIC:
                if lang == Language.SE:
                    url_id = Url.PROD_NORDIC_SE
                elif lang == Language.FI:
                    url_id = Url.PROD_NORDIC_FI
                elif lang == Language.DK:
                    url_id = Url.PROD_NORDIC_DK
                elif lang == Language.NO:
                    url_id = Url.PROD_NORDIC_NO
                elif lang == Language.EN:
                    url_id = Url.PROD_NORDIC_EN
            elif region == Region.ESPANA:
                if lang == Language.ES:
                    url_id = Url.PROD_ESPANA_ES
                elif lang == Language.EN:
                    url_id = Url.PROD_ESPANA_EN
        elif env == Environment.PREPROD:
            if region == Region.NORDIC:
                if lang == Language.SE:
                    url_id = Url.PP_NORDIC_SE
                elif lang == Language.FI:
                    url_id = Url.PP_NORDIC_FI
                elif lang == Language.DK:
                    url_id = Url.PP_NORDIC_DK
                elif lang == Language.NO:
                    url_id = Url.PP_NORDIC_NO
                elif lang == Language.EN:
                    url_id = Url.PP_NORDIC_EN
            elif region == Region.ESPANA:
                if lang == Language.ES:
                    url_id = Url.PP_ESPANA_ES
                elif lang == Language.EN:
                    url_id = Url.PP_ESPANA_EN
        else:
            url_id = Url.UNSUPPORTED

        if url_id == Url.UNSUPPORTED:
            raise ValueError(f"Url id wasn't available!")

        return cm.read_json_file(f"apps/{cm.app_name}/urls.json", url_id)

    @staticmethod
    def get_lang_code(language=None):
        if not language:
            language = cm.lang_id

        if language == "swedish":
            return Language.SE
        elif language == "finnish":
            return Language.FI
        elif language == "norwegian":
            return Language.NO
        elif language == "danish":
            return Language.DK
        elif language == "spanish":
            return Language.ES
        else:
            return Language.EN

    @classmethod
    def get_active_credit_card(cls):
        return cls.get_credit_card(
            CreditCardType.Visa, cls.get_country(cm.country_id))

    @classmethod
    def get_credit_card(cls, issuer, country):
        resources_file = cls.read_resources_file()
        credit_cards = []
        for resource in resources_file["credit_cards"]:
            credit_cards.append(resource)
            if resource["type"].lower() in str(issuer).lower() \
                    and resource["country"] == country:
                return cls.get_credit_card_instance(resource)

        raise NameError(f"Credit card issued by {issuer} \
                        for {country} wasn't found in file!")

    @staticmethod
    def get_credit_card_instance(resource):
        return CreditCard(
            resource["number"], resource["name"], resource["cvv"],
            resource["month"], resource["year"], resource["country"])

    @classmethod
    def get_api(cls, email, password):
        """Log user in to IBM api for later use."""
        region = Region.NORDIC if cls.get_country(
            cm.country_id) != Country.ES else Region.ESPANA
        env = cm.environment
        weblang = convert_language(cls.get_lang_code())
        return Api(
            email, password, region.upper(), env.upper(), weblang)

    @classmethod
    def get_lang_text(cls, text_key: str, language: str or None = None):
        lang = cls.get_lang_code(language)
        r = cm.region
        texts = cls.read_texts_file()[text_key]

        # If we have a separate english translation from spain
        if texts.get("en_es") and lang == Language.EN and r == "spain":
            lang = "en_es"

        return texts.get(lang)

    @classmethod
    def get_countries(cls):
        return [Country.SE, Country.DK, Country.FI, Country.NO, Country.ES]

    @classmethod
    def get_billing_price(cls, country=None):
        prices = cls.read_resources_file()["prices"]
        country = country if country is not None else cm.country_id
        for p in prices:
            if p["country"] == country and p["env"] == cm.environment:
                return Price(p["amount"], p["currency"], country)

        raise ValueError(f"No price with country {country} and "
                         f"env {cm.environment} found!")

    @classmethod
    def get_voucher(cls, voucher_type: str):
        vouchers = cls.read_resources_file()["vouchers"][voucher_type]
        for v in vouchers:
            if v["country"] == cm.country_id and v["env"] == cm.environment:
                return v["number"]

        raise ValueError(f"No voucher with country {cm.country} and "
                         f"env {cm.environment} found!")

    @staticmethod
    def read_resources_file(return_json=True):
        with open(Path("apps/hbonshared/resources.json"), "r",
                  encoding="utf-8") as f:
            if return_json:
                return json.load(f)
            return f

    @staticmethod
    def read_texts_file(return_json=True):
        with open(Path("apps/hbonshared/texts.json"), "r",
                  encoding="utf-8") as f:
            if return_json:
                return json.load(f)
            return f

    @staticmethod
    def read_file(path, return_json=True):
        with open(Path(path), "r", encoding="utf-8") as f:
            return json.load(f) if return_json else f

    @classmethod
    def match_asset(cls, asset_type, asset_attribute="assets"):
        env = cm.environment
        lang = cm.lang_id
        region = cm.region.lower()

        resources_file = cls.read_resources_file()
        for resource in resources_file[asset_attribute]:
            if resource["env"] == env \
                    and resource["lang"] == lang \
                    and resource["type"] == asset_type \
                    and resource["region"].lower() == region:
                return resource

        raise NameError(
            f"{asset_type} on {env} in {lang} for {region} wasn't found"
            "in file!")

    @classmethod
    def match_special_asset(cls, asset_type):
        env = cm.environment
        lang = cm.lang_id
        region = cm.region.lower()

        resource_file = cls.read_resources_file()["special_assets"]
        for resource in resource_file[asset_type]:
            if resource["env"] == env \
                    and resource["lang"] == lang \
                    and resource["region"].lower() == region:
                if resource.get("@use"):
                    chain_resource = cls.match_special_asset(resource["@use"])
                    return chain_resource
                return resource

        log(f"{asset_type} wasn't found for environment {env} with "
            f"language {lang} and region {region}!")
        return None

    @classmethod
    def detect_language(cls, words: list or str, lang: str = ""):
        if isinstance(words, str):
            words = words.split(" ")

        wordlist = cls.read_file("apps/hbonshared/wordlist.json")
        if lang:
            Log(f"Comparing words against language: {lang}, in wordlist")
            if match_list_values(words, wordlist[lang]):
                Log(f"Match found!")
                return lang
        else:
            Log("Comparing words to all languages in wordlist")
            for key in wordlist.keys():
                if match_list_values(words, wordlist[key]):
                    Log(f"Matched against {key}!")
                    return key
        return None


class CreditCard(object):
    def __init__(self, number, name, cvv, month, year, country):
        self.number = number
        self.name = name
        self.cvv = cvv
        self.month = month
        self.year = year
        self.country = country


class User(object):
    def __init__(self, email, password, firstname, lastname, pin, country,
                 api=None):
        self.email = email
        self.password = password
        self.firstname = firstname
        self.lastname = lastname
        self.pin = pin
        self.country = country
        self.api = api


class PayPalUser(object):
    def __init__(self, email, password, firstname, lastname, cc_country):
        self.email = email
        self.password = password
        self.firstname = firstname
        self.lastname = lastname
        self.cc_country = cc_country


class SpecialAsset(object):
    def __init__(self, title, original_title, _type, section,
                 season, episode, episode_name):
        self.title = title
        self.original_title = original_title
        self.type = _type
        self.section = section
        self.season = season
        self.episode = episode
        self.ep_name = episode_name

    def str(self):
        return self.title


class Price(object):
    def __init__(self, amount, currency, country):
        self.amount = amount
        self.currency = currency
        self.country = country


def convert_language(language):
    if Language.EN == language:
        return WebLanguage.ENGLISH if cm.region \
            == Region.NORDIC else WebLanguage.ENGLISH_ES
    elif Language.DK == language:
        return WebLanguage.DANISH
    elif Language.ES == language:
        return WebLanguage.SPANISH
    elif Language.FI == language:
        return WebLanguage.FINNISH
    elif Language.NO == language:
        return WebLanguage.NORWEGIAN
    elif Language.SE == language:
        return WebLanguage.SWEDISH
    else:
        raise ValueError("Unknown language")


class SpecialUser(object):
    CHANGE_PASSWORD = "change_password"
    CHANGE_PIN = "change_pin"
    CHANGE_EMAIL = "change_email"
    CHANGE_INFO = "change_info"
    FULL_WATCHLIST = "full_watchlist"
    PLAYBACK = "playback"
    PLAYBACK2 = "playback2"
    PLAYBACK3 = "playback3"
    NO_CW = "no_cw"
    DOWNLOAD = "download"
