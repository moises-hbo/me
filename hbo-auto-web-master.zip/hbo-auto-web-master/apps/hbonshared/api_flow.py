from apps.hbonshared.resourcesmanager import User, SpecialAsset, \
    ResourcesManager as RM

from helpers.configmanager import ConfigManager
from helpers.logger import Log

from hboapi.ibm import ApiCalls as Api

cm = ConfigManager()


def get_api(email: str, password: str):
    return RM.get_api(email, password)


def get_asset_guid(user: User, asset: SpecialAsset or str,
                   use_original_title: bool = False,
                   api: Api or None = None):
    api = api if api else get_api(user.email, user.password)
    asset = RM.get_special_asset(asset) if isinstance(asset, str) else asset
    title = asset.original_title if use_original_title else asset.title
    _type = "SERIES" if asset.season and asset.episode else "MOVIE"

    guid = api.get_asset_guid(_type, title.upper(),
                              str(asset.season) if asset.season else "",
                              str(asset.episode) if asset.episode else "")

    return guid


def get_asset_metadata(user: User, asset: SpecialAsset or str,
                       use_original_title: bool = False,
                       api: Api or None = None):
    api = api if api else get_api(user.email, user.password)
    asset = RM.get_special_asset(asset) if isinstance(asset, str) else asset
    title = asset.original_title if use_original_title else asset.title
    _type = "SERIES" if asset.season and asset.episode else "MOVIE"

    meta = api.get_asset_metadata(_type, title.upper(),
                                  str(asset.season) if asset.season else "",
                                  str(asset.episode) if asset.episode else "")

    return meta


def get_asset_duration(user: User, asset: SpecialAsset or str,
                       use_original_title: bool = False,
                       api: Api or None = None):
    api = api if api else get_api(user.email, user.password)
    asset = RM.get_special_asset(asset) if isinstance(asset, str) else asset
    title = asset.original_title if use_original_title else asset.title
    _type = "SERIES" if asset.season and asset.episode else "MOVIE"

    for _ in range(15):
        duration = api.get_asset_duration(
            _type, title.upper(),
            str(asset.season) if asset.season else "",
            str(asset.episode) if asset.episode else "")
        if isinstance(duration, str):
            continue
        return int(duration)
    return None


def get_bookmark(user: User, asset: SpecialAsset or str,
                 use_original_title=False,
                 api: Api or None = None):
    log = Log()
    api = api if api else get_api(user.email, user.password)
    title = asset.original_title if use_original_title else asset.title
    for _ in range(15):
        log(f"Getting bookmark for {title}")
        bookmark = api.get_bookmark(
            title.upper(), "" if not asset.season else str(asset.season),
            "" if not asset.episode else str(asset.episode))
        if isinstance(bookmark, str):
            log(f"Failed getting bookmark: {bookmark}", loglevel=log.WARNING)
            continue
        log(f"Bookmark is {bookmark}")
        return int(bookmark)
    log("Unable to get bookmark. Returning 'None'", loglevel=log.ERROR)
    return None


def get_episodes_of_season(user: User, asset: SpecialAsset or str,
                           use_original_title=False, api: None or Api = None):
    api = api if api else get_api(user.email, user.password)
    title = asset.original_title if use_original_title else asset.title
    for _ in range(15):
        episodes = api.get_asset_metadata(
            "SERIES", title.upper(), str(asset.season))
        if not isinstance(episodes, str):
            break
    return episodes


def set_bookmark(user: User, asset: SpecialAsset or str, bookmark: int,
                 subtract_from_end: bool = False,
                 use_original_title: bool = False,
                 api: None or Api = None):
    """ Set bookmark of an episode/movie
    subtract_from_end: If true, will subtract 'bookmark' from asset total
        length and bookmark the result. False will set 'bookmark' directly.
    """
    log = Log()
    api = api if api else get_api(user.email, user.password)
    asset = RM.get_special_asset(asset) if isinstance(asset, str) else asset
    title = asset.original_title if use_original_title else asset.title

    api.set_asset_as_played(asset.type.upper(), title.upper(),
                            str(asset.season) if asset.season else "",
                            str(asset.episode) if asset.episode else "")
    if subtract_from_end:
        for _ in range(15):
            duration = api.get_asset_duration(
                asset.type.upper(), title.upper(),
                str(asset.season) if asset.season else "",
                str(asset.episode) if asset.episode else "")
            if not isinstance(duration, str):
                break
        bookmark = int((duration / 60)) - bookmark

    for _ in range(15):
        log(f"Setting bookmark of '{title}' to {bookmark} mins")
        api.set_bookmark(
            str(bookmark), asset.type.upper(), title.upper(),
            season=str(asset.season) if asset.season else "",
            episode=str(asset.episode) if asset.episode else "")
        got_book = get_bookmark(user, asset, use_original_title, api)
        if got_book is None:
            continue
        log(f"Bookmark is {got_book} mins")
        if got_book / 60 == bookmark:
            break


def reset_bookmark(user: User, asset: SpecialAsset,
                   use_original_title: bool = True,
                   api: Api or None = None):
    set_bookmark(user, asset, 0, False, use_original_title, api=api)


def create_account(user: User):
    api = get_api("", "")
    api.create_account(user.firstname, user.lastname,
                       user.email, user.password, cm.country_id)


def add_to_watchlist(user: User, asset: SpecialAsset):
    api = get_api(user.email, user.password)
    api.add_to_watchlist(
        asset.type.upper(), asset.title.upper(),
        str(asset.season) if asset.type == "series" else '',
        str(asset.episode) if asset.type == "series" else '')
