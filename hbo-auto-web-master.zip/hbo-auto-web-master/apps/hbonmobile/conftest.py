import pytest

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager

from apps.hbonshared.fixtures import *

cm = ConfigManager()


@pytest.fixture
def driver(driver):
    if cm.platform == "ios":
        page = Page(driver)
        if page.is_push_noti_allow_button_displayed(0):
            page.click_on_push_noti_allow_button(0)

    yield driver
