from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.series_page import Series
from apps.hbonmobile.pages.episode_page import Episode
from apps.hbonmobile.pages.movie_page import Movie

from apps.hbonmobile.flows.search_flow import search_and_enter
from apps.hbonmobile.flows.series_flow import go_to_season, go_to_episode


def start_download_of_episode_from_season(driver, asset, from_page=Home):
    search_and_enter(driver, asset.title, from_page=from_page)
    go_to_season(driver, asset.season)
    page = go_to_episode(driver, asset.ep_name, enter=False)

    page.click_on_dl_ep_button(asset.ep_name)
    return Series(driver)


def start_download_of_episode_from_episode(driver, asset, from_page=Home):
    search_and_enter(driver, asset.title, from_page=from_page)
    go_to_season(driver, asset.season)
    page = go_to_episode(driver, asset.ep_name)

    page.click_on_download_button()
    return Episode(driver)


def start_download_of_movie(driver, asset, from_page=Home):
    search_and_enter(driver, asset.title, from_page=from_page)

    page = Movie(driver)
    page.click_on_download_button()
    return page
