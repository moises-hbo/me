from time import time

from apps.hbonmobile.pages.login_page import Login
from apps.hbonmobile.pages.adultkidsselection_page import AdultKidsSelection
from apps.hbonmobile.pages.privacypolicy_page import PrivacyPolicyUpdates
from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.kids_page import Kids
from apps.hbonmobile.pages.pin_page import Pin

from helpers.configmanager import ConfigManager
from apps.hbonshared.resourcesmanager import ResourcesManager
from helpers.enums import Country, Section

cm = ConfigManager()


def choose_section(driver, go_to_section=Section.ADULT):
    """Flow to choose section after successful login. Defaults to adult.
    'go_to_section' is the section we choose after successful login."""
    page = AdultKidsSelection(driver)
    if go_to_section is Section.ADULT:
        page.click_on_series_movies_button()
        page = Home(driver)
    elif go_to_section is Section.KIDS:
        page.click_on_kids_button()
        page = Kids(driver)

    return page


def login_without_section(driver, email, password, from_page=Login):
    """Flow to login. Does not choose section as part of function
    after trying to login. 'from_page' is the page object we are supposed
    to be on when we press the login button.
    """
    page = from_page(driver)
    page.clear_email_input()
    page.input_text_on_email(email)
    page.clear_password_input()
    page.input_text_on_password(password)

    page.click_on_signin_button()

    return AdultKidsSelection(driver)


def type_and_remove_login_information(driver, email, password,
                                      from_page=Login):
    page = from_page(driver)

    page.input_text_on_email(email)
    page.input_text_on_password(password)

    page.clear_email_input()
    page.clear_password_input()


def login(driver, email, password, from_page=Login,
          go_to_section=Section.ADULT, click_away_pin=False):
    """Flow to login. Logs in and chooses section to enter
    after successful login. 'from_page' is the page object we are
    supposed to be on when we press the login button.
    'go_to_section' is the section we choose after successful login."""
    login_without_section(driver, email, password, from_page)
    page = choose_section(driver, go_to_section)

    pin = Pin(driver)
    if click_away_pin and pin.is_dont_ask_me_again_button_displayed(5):
        pin.click_on_dont_ask_me_again_button()

    if cm.platform == "ios":
        if page.is_push_noti_allow_button_displayed():
            page.click_on_push_noti_allow_button()
    click_on_got_it(driver, 5)
    return page


def is_login_page_displayed(driver, from_page=Login):
    page = from_page(driver)
    return page.is_email_input_displayed() and \
        page.is_password_input_displayed()


def is_privacy_policy_updates_page_displayed(driver,
                                             from_page=PrivacyPolicyUpdates):
    page = from_page(driver)
    return page.is_gdpr_logo_displayed() and page.is_got_it_button_displayed()


def is_selection_page_displayed(driver, from_page=AdultKidsSelection):
    page = from_page(driver)
    return page.is_series_movies_button_displayed() and \
        page.is_kids_button_displayed()


def is_region_change_page_displayed(driver):
    page = Login(driver)
    return page.is_change_hbo_espana_button_displayed() and \
        page.is_change_hbo_nordic_button_displayed()


def select_region_if_displayed(driver):
    page = Login(driver)
    if is_region_change_page_displayed(driver):
        country = ResourcesManager.get_country()
        if country == Country.ES:
            page.click_on_hbo_espana_region()
        else:
            page.click_on_hbo_nordic_region()


def is_webbrowser_opened(driver):
    page = Login(driver)
    current_activity = driver.current_activity
    return current_activity == page.chrome_webbrowser


def is_web_signup_opened(driver):
    page = Login(driver)
    current_url = page.get_webbrowser_url()
    expected_site = cm.read_url(
        "prod_" + cm.country_id)
    signup_link = "sign-up"
    return expected_site in current_url and signup_link in current_url


def click_on_become_subscriber(driver):
    page = Login(driver)
    page.click_on_become_subscriber()
    if page.is_browsers_list_poped():
        page.click_on_first_browser_on_the_list()
        page.click_on_browsers_list_confirm_button()


def click_on_got_it(driver, timeout=20, from_page=Home, extra_wait=5):
    page = from_page(driver)
    then = time()
    if page.is_got_it_button_displayed(10):
        # If entering Kids with a Chromecast connected
        # you get 2 'Got it' popups
        got_it_buttons = page.get_got_it_buttons(timeout)
        while len(got_it_buttons) < 2:
            got_it_buttons = page.get_got_it_buttons(timeout)
            if time() - then >= extra_wait:
                break
        # And you can never be sure in what order they're at
        for button in got_it_buttons[::-1]:
            if page.is_got_it_button_displayed(0):
                page.helper.click(button)
        for button in got_it_buttons:
            if page.is_got_it_button_displayed(0):
                page.helper.click(button)
