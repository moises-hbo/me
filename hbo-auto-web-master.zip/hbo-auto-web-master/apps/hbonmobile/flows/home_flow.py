from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.kids_page import Kids

from helpers.enums import MobilePlatform

from hboapi.ibm import ContentSet
from hboapi.shelves import are_any_continue_watching_assets, \
    get_continue_watching_label, get_dynamic_shelves


def is_home_displayed(driver):
    page = Home(driver)
    return page.is_home_bar_displayed(timeout=45) and \
        page.is_toolbar_displayed(timeout=1) and \
        page.is_content_displayed(timeout=1)


def is_carousel_displayed(driver):
    page = Home(driver)
    return page.is_carousel_list_displayed() and \
        page.is_carousel_scroll_indicator_displayed()


def is_carousel_on_the_top(driver):
    page = Home(driver)
    platform = driver.helper.get_platform()
    top_content = page.get_top_element_id()
    # Android
    if platform == MobilePlatform.Android:
        return top_content == page.carousel_list
    # iOS
    elif platform == MobilePlatform.Ios:
        return top_content.find_elements_by_xpath("./*")[1].get_attribute(
            "type") == "XCUIElementTypeProgressIndicator"


def is_continue_watching_displayed(driver, api):
    if are_any_continue_watching_assets(api):
        label = get_continue_watching_label(api)
        page = Home(driver)
        return page.is_shelf_title_displayed(label)
    return True


def are_dynamics_shelves_displayed_in_delivered_order(driver, api):
    dynamic_shelves = get_dynamic_shelves(api)
    dynamic_shelves_v3 = list(
        filter(lambda x: x.keywords.lower() not in
               ["featured_shelf", "carousel", ""], dynamic_shelves))
    page = Home(driver)
    for dynamic_shelf in dynamic_shelves_v3:
        if dynamic_shelf.title.upper() != "CHARACTER SHELF":
            if not page.is_shelf_title_displayed(dynamic_shelf.title.upper()):
                return False
    return True


def are_kids_shelves_displayed_in_delivered_order(driver, api):
    dynamic_shelves = get_dynamic_shelves(api, ContentSet.FAMILY)
    dynamic_shelves_v3 = list(
        filter(lambda x: x.keywords.lower() == "shelf", dynamic_shelves))
    page = Kids(driver)
    for dynamic_shelf in dynamic_shelves_v3:
        if not page.is_shelf_title_displayed(dynamic_shelf.title.upper()):
            return False
    return True
