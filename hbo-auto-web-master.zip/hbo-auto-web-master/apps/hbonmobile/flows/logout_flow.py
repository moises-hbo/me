from apps.hbonmobile.pages.login_page import Login
from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.player_page import Player
from apps.hbonmobile.pages.episode_page import Episode

from helpers.configmanager import ConfigManager
from helpers.enums import MobilePlatform

cm = ConfigManager()


def logout(driver):
    page = Home(driver)
    for i in range(0, 2):
        page.click_on_home_button()
    go_to_logout(driver)
    page.click_on_confirm_sign_out_button()
    return Login(driver)


def go_to_logout(driver):
    page = Home(driver)
    platform = driver.helper.get_platform()

    if platform == MobilePlatform.Android:
        page.click_on_more_options_button()
        page.click_on_more_options_sign_out_button()
    elif platform == MobilePlatform.Ios:
        for _ in range(3):
            page.scroll_to_sign_out_button()
            if page.is_sign_out_button_displayed(0, wait=3):
                break
        page.click_on_sign_out_button()


def logout_from_playback(driver):
    page = Player(driver)
    if cm.platform == MobilePlatform.Ios:
        page.click_on_back_button()
    else:
        driver.helper.go_back()
    page = Episode(driver)
    page.click_on_home_button()
    logout(driver)
