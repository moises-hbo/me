from helpers.sleeper import Sleeper as sleep

from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.movie_page import Movie
from apps.hbonmobile.pages.series_page import Series
from apps.hbonmobile.pages.player_page import Player

from apps.hbonmobile.flows.search_flow import search_and_enter
from apps.hbonmobile.flows.series_flow import go_to_season, go_to_episode


def start_playback_of_asset(driver, asset, time_to_play=15, from_page=Home):
    if asset.type == "movie":
        return start_playback_of_movie(
            driver, asset.title, time_to_play, from_page)
    elif asset.type == "series":
        return start_playback_of_series(
            driver, asset.title, asset.season, asset.ep_name)
    raise AttributeError("'asset.type' was neither 'movie' nor 'series'")


def start_playback_of_movie(driver, movie_title, time_to_play=30,
                            from_page=Home):
    search_and_enter(driver, movie_title, 0, from_page)

    page = Movie(driver)
    page.click_on_play_button(5)

    if page.is_play_overlay_displayed():
        page.click_on_play_stream_button()

    sleep(time_to_play)

    return Player(driver)


def start_playback_of_series(driver, series_title, season_number,
                             episode_name, time_to_play=30,
                             from_page=Home):
    search_and_enter(driver, series_title, 0, from_page)

    page = Series(driver)
    go_to_season(driver, season_number)
    page = go_to_episode(driver, episode_name)

    page.click_on_play_button()

    if page.is_play_overlay_displayed():
        page.click_on_play_stream_button()

    sleep(time_to_play)

    return Player(driver)
