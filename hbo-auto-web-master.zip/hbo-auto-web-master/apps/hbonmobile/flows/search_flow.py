from helpers.sleeper import Sleeper as sleep

from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.search_page import Search


def search(driver, search_term, from_page=Home):
    page = from_page(driver)

    page.click_on_search_button()

    page = Search(driver)
    if not page.is_search_page(1):
        from_page(driver).click_on_search_button()

    page.clear_text_on_search()
    page.enter_text_on_search(search_term)

    return page


def search_and_enter(driver, search_term, index=0, from_page=Home):
    page = search(driver, search_term, from_page)
    sleep(2)  # May enter recent result if we don't let it reload results
    page.click_on_search_result(index=index, timeout=30)

    # At least preprod does some weird reloading
    sleep(2)
