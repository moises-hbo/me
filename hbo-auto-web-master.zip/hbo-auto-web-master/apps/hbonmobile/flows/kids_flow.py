from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.kids_page import Kids

from helpers.enums import MobilePlatform
from helpers.configmanager import ConfigManager

cm = ConfigManager()


def is_kids_lock_intro_text_displayed(driver):
    page = Kids(driver)
    return len(page.get_kids_lock_intro_text()) > 10


def exit_kids(driver, from_page=Kids):
    page = from_page(driver)
    page.click_on_home_button() if cm.platform == "ios" \
        else page.click_on_kids_button()

    page = Kids(driver)
    page.click_on_exit_kids_button()

    if cm.platform == MobilePlatform.Ios:
        page = Home(driver)
        if page.is_push_noti_allow_button_displayed():
            page.click_on_push_noti_allow_button()
