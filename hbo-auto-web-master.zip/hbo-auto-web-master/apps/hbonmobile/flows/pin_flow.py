from helpers.sleeper import Sleeper as sleep

from apps.hbonmobile.pages.pin_page import Pin
from helpers.enums import MobilePlatform


def enter_pin(driver, pin, confirm=True, click_set_pin=True):
    page = Pin(driver)
    if click_set_pin:
        page.click_on_set_pin_button()
    page.wait_until_pin_numbers_are_visible()
    # Enter PIN
    for n in str(pin):
        eval(f"page.click_on_pin_nr_{n}()")
    if confirm:
        confirm_pin(driver, pin)


def confirm_pin(driver, pin):
    # Confirm PIN
    page = Pin(driver)
    page.wait_until_pin_numbers_are_visible()
    for n in str(pin):
        eval(f"page.click_on_pin_nr_{n}()")


def back_out_from_pin(driver):
    page = Pin(driver)
    platform = driver.helper.get_platform()
    if platform == MobilePlatform.Android:
        driver.back()
    elif platform == MobilePlatform.Ios:
        page.wait_until_pin_back_button_is_visible()
        page.click_on_pin_back_button()


def close_pin_from_kids(driver):
    page = Pin(driver)
    platform = driver.helper.get_platform()
    if platform == MobilePlatform.Android:
        sleep(2)
        driver.back()
    elif platform == MobilePlatform.Ios:
        page.click_on_pin_close_button()
