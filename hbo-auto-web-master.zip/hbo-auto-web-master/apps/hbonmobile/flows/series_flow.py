from helpers.sleeper import Sleeper as sleep

from selenium.common.exceptions import NoSuchElementException

from apps.hbonmobile.pages.series_page import Series
from apps.hbonmobile.pages.episode_page import Episode

from apps.hbonshared.api_flow import get_episodes_of_season

from apps.hbonmobile.flows.search_flow import search_and_enter

from helpers.enums import MobilePlatform


def get_episodes(user, asset, api=None):
    episodes = dict()
    meta_ep = get_episodes_of_season(user, asset, api=api)
    [episodes.update({x["episodeInSeason"]: x["episode"]})
     for x in meta_ep]

    return episodes


def go_to_season(driver, season_nr, max_seasons=10):
    page = Series(driver)
    platform = driver.helper.get_platform()
    passed_seasons = []

    for _ in range(max_seasons):
        seasons = [x for x in page.get_seasons_list()
                   if x not in passed_seasons]
        for s in seasons:
            page.helper.click(s)
            passed_seasons.append(s)
            stext = page.helper.get_text(
                # Android
                s.find_element_by_class_name("android.widget.TextView")
                if platform == MobilePlatform.Android
                # iOS
                else s.find_element_by_xpath(
                    "./XCUIElementTypeOther"
                    "/XCUIElementTypeStaticText"))

            if stext.endswith(f" {season_nr}"):
                sleep(5)
                return page
    raise AttributeError(f"Season wasn't found after {max_seasons} attempts!")


def go_to_episode(driver, episode_name, max_swipes=10, enter=True):
    page = Series(driver)
    platform = driver.helper.get_platform()

    done = False
    while not done:

        episodes = page.get_episodes_list()
        if not episodes:  # if screen resolution too small to see first ep
            driver.helper.swipe()
            episodes = page.get_episodes_list()

        for ep in episodes:
            try:        # Android
                title = page.helper.get_text(
                    ep.find_element_by_id("title")
                    if platform == MobilePlatform.Android
                    # iOS
                    else ep)
            except NoSuchElementException:
                # Do nothing.
                title = ""

            if episode_name in title:
                # Swipe if we can't see duration
                # assume we only see top bit of asset info
                try:
                    if platform == MobilePlatform.Android:
                        ep.find_element_by_id("metadata")
                    elif platform == MobilePlatform.Ios:
                        # TODO: Do same for iOS
                        pass
                except NoSuchElementException:
                    driver.helper.swipe()

                if enter:
                    page.helper.click(ep)
                done = True
                break

        if not done:
            driver.helper.swipe()

        max_swipes -= 1
        if not max_swipes:
            done = True

    return Episode(driver) if enter else Series(driver)


def search_and_navigate_to_episode(driver, asset, max_swipes=10,
                                   enter=True):
    search_and_enter(driver, asset.title)
    go_to_season(driver, asset.season)
    page = go_to_episode(driver, asset.ep_name, max_swipes, enter)
    return page
