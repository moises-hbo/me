import pytest

from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.movie_page import Movie
from apps.hbonmobile.pages.watchlist_page import Watchlist
from apps.hbonmobile.pages.player_page import Player

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.search_flow import search_and_enter

from apps.hbonshared.api_flow import set_bookmark


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1042", "C785")
def test_empty_watchlist(driver, user):
    user.api.clear_watchlist()

    page = login(driver, user.email, user.password)
    page.click_on_watchlist_button()
    page = Watchlist(driver)
    assert page.is_watchlist_page()
    assert page.is_explore_shows_button_displayed()

    page.click_on_explore_shows_button()
    page = Home(driver)
    assert page.is_home_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1256004", "C1440784")
def test_add_to_watchlist(driver, user, movie):
    user.api.clear_watchlist()

    assert not Watchlist(driver).is_watchlist_page(0)

    page = login(driver, user.email, user.password)
    search_and_enter(driver, movie.title)

    page = Movie(driver)
    assert page.is_add_to_watchlist_button_unchecked()
    page.click_on_add_to_watchlist_button()
    assert page.is_add_to_watchlist_button_checked()
    # assert not page.is_error_displayed()

    page.click_on_watchlist_button()
    page = Watchlist(driver)
    assert page.is_watchlist_page()
    assert not page.is_explore_shows_button_displayed(3)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1256004", "C1440784")
def test_remove_from_watchlist(driver, user, movie, episode):
    user.api.clear_watchlist()
    user.api.add_to_watchlist(movie.type.upper(), movie.title.upper())

    assert not Watchlist(driver).is_watchlist_page(0)

    page = login(driver, user.email, user.password)
    page.click_on_watchlist_button()

    page = Watchlist(driver)
    assert page.get_asset_title(0) == movie.title
    page.click_on_asset(0)

    page = Movie(driver)
    assert page.is_add_to_watchlist_button_checked()
    page.click_on_remove_from_watchlist_button()
    assert page.is_add_to_watchlist_button_unchecked()
    # assert not page.is_error_displayed()

    page.click_on_watchlist_button()
    page = Watchlist(driver)
    assert page.is_explore_shows_button_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1256004", "C1440784")
def test_play_watchlisted_asset_to_finish(driver, user, movie):
    """ There's nothing really specified to verify against here """
    user.api.clear_watchlist()
    user.api.add_to_watchlist(movie.type.upper(), movie.title.upper())

    assert not Watchlist(driver).is_watchlist_page(0)

    set_bookmark(user, movie, 2, True)

    page = login(driver, user.email, user.password)
    page.click_on_watchlist_button()

    page = Watchlist(driver)
    assert len(page.get_assets_list()) == 1
    page.click_on_asset()

    page = Movie(driver)
    page.click_on_play_button()

    page = Player(driver)
    page.is_player_playing()
    page.wait_for_player_to_finish(180)

    page = Movie(driver)
    page.click_on_watchlist_button()

    page = Watchlist(driver)
    assert len(page.get_assets_list()) == 1
