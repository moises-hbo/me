from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbonmobile.pages.kids_page import Kids

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.home_flow import is_carousel_displayed, \
    are_kids_shelves_displayed_in_delivered_order

from helpers.enums import Section, MobilePlatform


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1074", "C865")
def test_carousel_and_shelves_appear_on_kids(driver, user):
    page = login(driver, user.email, user.password, go_to_section=Section.KIDS)

    assert is_carousel_displayed(driver)
    assert are_kids_shelves_displayed_in_delivered_order(driver, user.api)
    page.scroll_up_to_carousel()
    assert page.is_carousel_list_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("ios", "android")
@pytest.mark.category()
@pytest.mark.id("C1074", "C865")
def test_recently_watched_shelf_available_kids(driver, user_playback):
    user = user_playback

    page = login(driver, user.email, user.password)

    page.click_on_kids_button()
    page = Kids(driver)
    page.click_on_got_it_button()

    assert not page.is_recently_watched_shelf_title_displayed(2)

    page.click_on_lock_kids_button()

    sleep(10)  # Loads dynamically, after some time
    assert page.is_recently_watched_shelf_title_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1075", "C866")
def test_kids_lock_intro(driver, user):
    page = login(driver, user.email, user.password)

    page.click_on_kids_button()
    page = Kids(driver)

    # Assumed to be Kids intro
    assert page.is_got_it_button_displayed()

    # Click outside intro shouldn't do anything
    # But Appium for iOS doesn't care about shouldas
    if driver.helper.get_platform == MobilePlatform.Android:
        page.click_on_home_button()

    assert page.is_got_it_button_displayed()

    page.click_on_got_it_button()
    # login() should've dealt with CC intro
    assert not page.is_got_it_button_displayed(2)

    page.click_on_home_button()
    page.click_on_kids_button()
    # Should only see intro once per session
    assert not page.is_got_it_button_displayed(3)
    # Unlocked button should be displayed
    assert page.is_kids_unlocked_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1075", "C866")
def test_no_lock_button_down_hierarchy(driver, user):
    page = login(driver, user.email, user.password)

    page.click_on_kids_button()
    page = Kids(driver)
    page.click_on_got_it_button()

    sleep(5)
    page.click_on_asset_in_shelf(2, 0)

    # No lock/unlock button further down the hierarchy
    assert not page.is_kids_unlocked_page(2) and not \
        page.is_kids_locked_page(2)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1075", "C866")
def test_reduced_navigation_when_locked(driver, user):
    page = login(driver, user.email, user.password)

    page.click_on_kids_button()
    page = Kids(driver)

    page.click_on_got_it_button()
    page.click_on_kids_button()

    assert page.is_kids_button_displayed()
    assert page.is_search_button_displayed()
    assert page.is_home_button_displayed()
    assert page.is_watchlist_button_displayed()

    page.click_on_lock_kids_button()

    platform = driver.helper.get_platform()
    if platform == MobilePlatform.Android:
        assert page.is_kids_button_displayed(20)
        assert not page.is_home_button_displayed(1)
    elif platform == MobilePlatform.Ios:
        # Locator for Kids button is Home while locked
        assert page.is_home_button_displayed(30)
        assert not page.is_kids_button_displayed(1)
    assert page.is_search_button_displayed()
    assert not page.is_watchlist_button_displayed(1)
