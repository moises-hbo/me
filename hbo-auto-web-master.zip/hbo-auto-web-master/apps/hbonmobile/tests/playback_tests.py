from helpers.sleeper import Sleeper as sleep

import pytest

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.logout_flow import logout
from apps.hbonmobile.flows.playback_flow import (start_playback_of_movie,
                                                 start_playback_of_series)
from apps.hbonmobile.flows.series_flow import get_episodes
from apps.hbonmobile.pages.episode_page import Episode
from apps.hbonmobile.pages.movie_page import Movie
from apps.hbonmobile.pages.player_page import Player
from apps.hbonshared.api_flow import get_asset_duration, set_bookmark, \
    reset_bookmark

from helpers.configmanager import ConfigManager
from helpers.enums import MobilePlatform

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1015", "C743")
def test_player_controls_fade_out_in(driver, user_playback, movie):
    user = user_playback
    reset_bookmark(user, movie, api=user.api)

    page = login(driver, user.email, user.password)

    page = start_playback_of_movie(driver, movie.title, 1)

    assert page.get_text_of_title(tap=True) == movie.title

    sleep(20)

    # Verify we have playing view
    assert page.is_player_page()

    # Progress bar should be hidden
    assert not page.is_player_controls_displayed(1)
    # Tap once, should be seen
    page.click_within_player()
    assert page.is_player_controls_displayed()

    page.wait_for_controls_to_disappear()

    page.click_within_player()  # Show
    assert page.wait_for_controls_to_appear(3)

    page.click_within_player()  # Hide
    assert page.wait_for_controls_to_disappear(3)
    assert not page.is_player_controls_displayed(1)

    page.exit_player(tap=True)

    page = Movie(driver)
    assert page.is_movie_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1016", "C744")
def test_player_exits_when_finished(driver, user_playback, movie):
    user = user_playback
    set_bookmark(user, movie, 2, True, api=user.api)

    login(driver, user.email, user.password)

    page = start_playback_of_movie(driver, movie.title)

    assert page.wait_for_player_to_finish(240)

    page = Movie(driver)
    assert page.is_movie_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("ios", "android")
@pytest.mark.category("playback")
@pytest.mark.id("C744", "C1016")
@pytest.mark.xfail(cm.platform == MobilePlatform.Android,
                   reason="Playback starts immediately after unlock")
@pytest.mark.skipif(cm.platform == "android", reason="Appium is unable "
                    "to unlock newer devices, causing issues")
def test_lock_device_during_playback(driver, user_playback, movie):
    """
    Verify playback gets and stays paused during lock/unlocking of device
    """
    user = user_playback
    dur_min = get_asset_duration(user, movie, api=user.api) / 60
    set_bookmark(user, movie, int((dur_min / 60) / 2), api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_movie(driver, movie.title)

    # Lock device
    page = Player(driver)
    driver.helper.lock_device(5)

    # Should return in paused state
    sleep(1)
    tap = True if cm.platform == MobilePlatform.Android else False
    assert page.is_play_button_displayed(tap=tap)
    page.click_on_play_button()

    assert page.is_player_playing()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1016", "C744")
@pytest.mark.xfail(cm.platform == MobilePlatform.Android,
                   reason="Playback starts immediately after un-backgrounding")
def test_background_app_during_playback(driver, user_playback, movie):
    user = user_playback
    dur_min = get_asset_duration(user, movie, api=user.api) / 60
    set_bookmark(user, movie, int((dur_min / 60) / 2), api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_movie(driver, movie.title)

    # Background app
    page = Player(driver)
    driver.helper.background_app(5)

    # Should return in paused state
    assert page.is_play_button_displayed(2)

    page.click_on_play_button()
    assert page.is_player_playing()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1018", "C746")
def test_player_play_pause(driver, user_playback, movie):
    user = user_playback
    reset_bookmark(user, movie, api=user.api)

    page = login(driver, user.email, user.password)

    start_playback_of_movie(driver, movie.title)

    page = Player(driver)
    page.click_on_pause_button(tap=True)

    elapsed = page.get_elapsed_time_in_percent()
    sleep(2)
    assert elapsed == page.get_elapsed_time_in_percent()

    page.click_on_play_button()

    page.wait_for_controls_to_disappear()
    while page.get_elapsed_time_in_percent(tap=True) <= 2:
        sleep(30)
    page.wait_for_controls_to_disappear()

    assert not elapsed == page.get_elapsed_time_in_percent(tap=True)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C12519", "C266966")
def test_playback_from_bookmarked_pos(driver, user_playback, movie):
    user = user_playback
    reset_bookmark(user, movie, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_movie(driver, movie.title)

    page = Player(driver)

    from_start = page.get_elapsed_time_in_percent(tap=True)
    assert from_start <= 3

    page.wait_for_controls_to_disappear()
    page.click_on_back_button(tap=True)

    logout(driver)

    # Now re-do with bookmark set
    dur = get_asset_duration(user, movie, api=user.api)
    bookmark = int((dur / 2) / 60)
    set_bookmark(user, movie, bookmark, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_movie(driver, movie.title)

    bookmarked = page.get_elapsed_time_in_percent(tap=True)
    assert bookmarked >= 49 and bookmarked <= 51


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C12519", "C266966")
def test_playback_with_bookmarked_heartbeat(driver, user_playback, movie):
    user = user_playback
    reset_bookmark(user, movie, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_movie(driver, movie.title)

    page = Player(driver)
    from_start = page.get_elapsed_time_in_percent(tap=True)
    assert from_start <= 3

    page.wait_for_controls_to_disappear()

    # Continually probe to avoid appium timing out
    while page.get_elapsed_time_in_percent(tap=True) < 5:
        page.wait_for_controls_to_disappear()
    page.wait_for_controls_to_disappear()

    # Go back out
    page.click_on_back_button(tap=True)

    page = Movie(driver)

    is_android = driver.helper.get_platform() == MobilePlatform.Android
    if is_android:
        # Can only test against android atm
        assert page.is_bookmark_displayed()

    page.click_on_play_button()

    page = Player(driver)
    sleep(10)

    heartbeat = page.get_elapsed_time_in_percent(tap=True)
    assert heartbeat >= 4 and heartbeat <= 6


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C12519", "C266966")
def test_playback_after_cuepoint(driver, user_playback, movie):
    user = user_playback
    set_bookmark(user, movie, 2, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_movie(driver, movie.title)
    page = Player(driver)

    while page.get_elapsed_time_in_percent(tap=True) < 99:
        page.wait_for_controls_to_disappear()

    page.wait_for_controls_to_disappear()

    page.click_on_back_button(tap=True)
    page = Movie(driver)
    page.click_on_play_button()

    page = Player(driver)
    assert page.is_player_playing()
    assert page.get_elapsed_time_in_percent(tap=True) <= 3


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C12519", "C266966")
def test_playback_of_series_after_cuepoint(driver, user_playback, episode):
    user = user_playback
    ep = episode
    episodes = get_episodes(user, ep)
    set_bookmark(user, ep, 3, True)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, ep.title, str(ep.season),
                             episodes.get(str(ep.episode)))

    page = Player(driver)
    page.wait_for_chainplay_to_appear()
    assert page.is_cp_countdown_displayed()

    if cm.platform == MobilePlatform.Android:
        driver.helper.go_back()
    elif cm.platform == MobilePlatform.Ios:
        page.click_on_cp_back_button()
    page = Episode(driver)
    page.click_on_play_button()

    page = Player(driver)
    assert not page.is_cp_countdown_displayed(30)

    assert page.get_elapsed_time_in_percent(tap=True) <= 3
