from helpers.sleeper import Sleeper as sleep
import copy
import pytest

from apps.hbonmobile.pages.player_page import Player
from apps.hbonmobile.pages.episode_page import Episode

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.logout_flow import logout_from_playback
from apps.hbonmobile.flows.series_flow import get_episodes
from apps.hbonmobile.flows.playback_flow import start_playback_of_series

from apps.hbonshared.api_flow import set_bookmark

from helpers.configmanager import ConfigManager
from helpers.enums import MobilePlatform

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1020", "C736")
def test_chainplay_view(driver, user_playback, has_chainplay):
    """
    Verify different elements can be seen in chainplay view
    """
    user = user_playback
    cp = has_chainplay
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    assert page.wait_for_chainplay_to_appear()
    assert page.is_cp_title_displayed()
    assert page.is_cp_season_ep_displayed()
    assert page.is_cp_play_button_displayed()
    if cm.platform == MobilePlatform.Ios:
        assert page.is_cp_back_button_displayed()
    # Can't locate img element on iOS
    if driver.helper.get_platform() == MobilePlatform.Android:
        assert page.is_cp_image_displayed()

    logout_from_playback(driver)

    # Re-initialize Api by not providing it
    # maybe we've been kicked out due to time
    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    pvs = page.get_size_of_playing_view()
    page.wait_for_chainplay_to_appear()

    # Assuming same season
    next_episode = cp.episode + 1
    assert page.get_text_of_cp_title() == episodes.get(str(next_episode))
    assert page.get_text_of_cp_season_ep() == \
        f"{cp.title}: S{cp.season} / E{next_episode}"
    cp_pvs = page.get_size_of_cp_playing_view()
    assert pvs.get("width") > cp_pvs.get("width") and \
        pvs.get("height") > cp_pvs.get("height")


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1020", "C736")
def test_chainplay_after_background_app(driver, user_playback, has_chainplay):
    """
    Verify chainplay view enters paused state when backgrounding app
    """
    user = user_playback
    cp = has_chainplay
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    assert page.wait_for_chainplay_to_appear()

    cp_cd = page.get_cp_countdown_timer()

    driver.helper.background_app(5)

    assert page.is_chainplay_displayed(3)

    cp_cd_ab = page.get_cp_countdown_timer()
    assert cp_cd >= cp_cd_ab  # timer at least same before/after background
    assert cp_cd_ab > cp_cd - 7  # difference shouldn't be too big


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1021", "C737")
def test_chainplay_countdown_counts_down(driver, user_playback, has_chainplay):
    user = user_playback
    cp = has_chainplay
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    assert page.wait_for_chainplay_to_appear()

    # Get countdown time
    cd1 = page.get_cp_countdown_timer()
    sleep(1.5)
    # Get countdown time again
    cd2 = page.get_cp_countdown_timer()
    sleep(1.5)
    cd3 = page.get_cp_countdown_timer()

    # Verify countdown has been counting down
    assert cd1 > cd2
    assert cd2 > cd3


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1021", "C737")
def test_chainplay_ignore_bookmark(driver, user_playback, has_chainplay):
    user = user_playback
    cp = has_chainplay
    cpn = copy.deepcopy(has_chainplay)
    cpn.episode += 1
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)
    # Bookmarks episode after the one we will start
    set_bookmark(user, cpn, 30, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, str(cp.season),
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    assert page.wait_for_chainplay_to_appear()

    # Let chainplay run its course and next ep start
    sleep(30)

    assert not page.is_cp_countdown_displayed(3)
    # Verify next ep after chainplay starts from beginning
    # despite bookmark
    assert page.get_elapsed_time_in_percent(tap=True) <= 3


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1022", "C738")
def test_continue_watching_after_chainplay(driver, user_playback,
                                           has_chainplay):
    user = user_playback
    cp = has_chainplay
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    # Click on playing view when chainplay triggers
    page = Player(driver)
    assert page.wait_for_chainplay_to_appear()
    page.click_on_cp_playing_view()
    # Let it trigger again, and verify we see a second cp trigger
    assert page.wait_for_chainplay_to_appear()

    # Click on playing view again
    page.click_on_cp_playing_view()
    assert not page.is_chainplay_displayed(2)

    platform = driver.helper.get_platform()
    # Verify elapsed time is at the end of stream
    if platform == MobilePlatform.Android:
        duration = page.get_text_of_total_duration_time()
        elapsed = page.get_text_of_elapsed_time()
        assert elapsed == duration
    assert page.get_elapsed_time_in_percent() == 100


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1022", "C738")
def test_exit_chainplay(driver, user_playback, has_chainplay):
    user = user_playback
    cp = has_chainplay
    platform = cm.platform
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    assert page.wait_for_chainplay_to_appear()
    if platform == MobilePlatform.Android:
        driver.helper.go_back()
    else:
        page.click_on_back_button()

    assert not page.is_chainplay_displayed(0)
    page = Episode(driver)
    assert page.is_episode_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1022")
def test_exit_chainplay_android_back(driver, user_playback, has_chainplay):
    user = user_playback
    cp = has_chainplay
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    assert page.wait_for_chainplay_to_appear(240)
    driver.back()

    assert not page.is_chainplay_displayed(3)
    page = Episode(driver)
    assert page.is_episode_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("playback")
@pytest.mark.id("C1022", "C738")
def test_play_next_ep_during_chainplay(driver, user_playback, has_chainplay):
    user = user_playback
    cp = has_chainplay
    episodes = get_episodes(user, cp, api=user.api)

    set_bookmark(user, cp, 3, True, api=user.api)

    login(driver, user.email, user.password)

    start_playback_of_series(driver, cp.title, cp.season,
                             episodes.get(str(cp.episode)))

    page = Player(driver)
    assert page.wait_for_chainplay_to_appear()

    chainplay_title = page.get_text_of_cp_season_ep()
    page.click_on_cp_play_button()
    playing_title = page.get_text_of_title()

    assert chainplay_title.endswith(playing_title)
