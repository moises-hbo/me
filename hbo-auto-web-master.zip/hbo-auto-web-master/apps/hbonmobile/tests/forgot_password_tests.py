import pytest

from apps.hbonmobile.pages.login_page import Login
from apps.hbonmobile.pages.forgot_password_page import ForgotPassword

from helpers.enums import MobilePlatform


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C990", "C721")
def test_user_has_access_to_forgot_password(driver):
    page = Login(driver)
    assert page.is_forgot_password_button_displayed()

    page.click_on_forgot_password_button()

    page = ForgotPassword(driver)
    assert page.is_forgot_password_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C994", "C728")
def test_enter_and_leave_forgot_password_page(driver):
    page = Login(driver)

    page.click_on_forgot_password_button()

    page = ForgotPassword(driver)
    assert page.is_forgot_password_page()

    page.click_on_back_button()

    page = Login(driver)
    assert page.is_login_page()

    page.click_on_forgot_password_button()

    page = ForgotPassword(driver)
    assert page.is_forgot_password_page()

    if driver.helper.get_platform() == MobilePlatform.Android:
        if driver.helper.is_keyboard_displayed():
            driver.helper.go_back()
        driver.helper.go_back()

        page = Login(driver)
        assert page.is_login_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C994", "C728")
def test_valid_email_prefilled(driver):
    email = "valid@email.com"

    page = Login(driver)
    page.input_text_on_email(email)

    login_email = page.get_text_of_email_input()

    page.click_on_forgot_password_button()

    page = ForgotPassword(driver)
    forgot_password_email = page.get_text_of_email_input()

    assert forgot_password_email == login_email
    assert forgot_password_email == email


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C994", "C728")
def test_invalid_email_prefilled(driver):
    email = "ioadnfvjiasdehuy9erwbvuierbvouwreawjfy7df5ew2"

    page = Login(driver)
    page.input_text_on_email(email)

    login_email = page.get_text_of_email_input()

    page.click_on_forgot_password_button()

    page = ForgotPassword(driver)
    forgot_password_email = page.get_text_of_email_input()

    assert forgot_password_email == login_email
    assert forgot_password_email == email

    # This one shouldn't be needed as per test case
    # BUT IT IIIS
    page.click_on_send_email_button()

    assert page.is_error_text_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C994", "C728")
def test_clear_edit_email(driver):
    email = "valid@email.com"
    email2 = "another@email.com"

    page = Login(driver)
    page.click_on_forgot_password_button()

    page = ForgotPassword(driver)
    assert page.get_text_of_email_input() == str()

    page.input_text_on_email_input(email)
    assert page.get_text_of_email_input() == email

    page.clear_text_on_email_input()
    assert page.get_text_of_email_input() == str()

    page.input_text_on_email_input(email2)
    assert page.get_text_of_email_input() == email2
