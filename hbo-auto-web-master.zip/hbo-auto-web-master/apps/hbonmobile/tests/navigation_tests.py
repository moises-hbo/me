import pytest

from apps.hbonmobile.pages.kids_page import Kids

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.logout_flow import logout
from apps.hbonmobile.flows.home_flow import \
    is_carousel_displayed, \
    is_continue_watching_displayed, \
    are_dynamics_shelves_displayed_in_delivered_order
from apps.hbonmobile.flows.kids_flow import is_kids_lock_intro_text_displayed

from apps.hbonshared.api_flow import set_bookmark, get_asset_duration

from helpers.enums import MobilePlatform


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C12368", "C939")
def test_lock_intro(driver, user):
    """C12368: Lock intro (auto)

    Introduced to Kids lock mode. Should see popup giving introduction.
    Should not be able to interact with anything other than popup while up.
    """
    # Login
    page = login(driver, user.email, user.password)

    # Verify Kids popup intro
    page.click_on_kids_button()
    assert page.is_kids_button_selected()

    page = Kids(driver)
    assert page.is_got_it_button_displayed()  # Assumed Kids popup
    assert page.is_kids_lock_overlay_button_displayed()
    assert is_kids_lock_intro_text_displayed(driver)

    # iOS can hit Home with overlay (using automation) - removes overlay
    if driver.helper.get_platform() == MobilePlatform.Android:
        page.click_on_home_button()  # Nothing should happen
    assert not page.is_home_button_selected(timeout=1)

    assert page.is_got_it_button_displayed()  # Popup still displayed
    assert page.is_kids_lock_overlay_button_displayed()
    assert is_kids_lock_intro_text_displayed(driver)

    page.click_on_got_it_button()
    assert page.is_kids_lock_button_displayed()

    # No second intro on same session
    page.click_on_home_button()
    page.click_on_kids_button()
    assert not page.is_got_it_button_displayed(timeout=2)
    assert page.is_kids_lock_button_displayed()

    # Logout
    logout(driver)
    # Login
    login(driver, user.email, user.password)

    # Verify Kids popup intro
    page.click_on_kids_button()
    assert page.is_got_it_button_displayed()
    assert is_kids_lock_intro_text_displayed(driver)

    page.click_on_got_it_button()
    assert page.is_kids_lock_button_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C998", "C727")
def test_carousel_and_shelves_appear_on_home_view(driver, user, movie):
    # Populate continue watching, just in case
    api = user.api
    dur_min = get_asset_duration(user, movie, api=api) / 60
    set_bookmark(user, movie, int((dur_min / 60) / 2), api=api)

    login(driver, user.email, user.password)

    # NOTE: People tell me the hard requirement for carousel
    # to be at top is not supposed to be there.. or something
    # assert is_carousel_on_the_top(driver)

    assert is_carousel_displayed(driver)
    assert is_continue_watching_displayed(driver, api)
    assert are_dynamics_shelves_displayed_in_delivered_order(driver, api)
