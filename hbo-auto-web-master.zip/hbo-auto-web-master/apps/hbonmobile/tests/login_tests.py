import pytest

from apps.hbonmobile.pages.login_page import Login
from apps.hbonmobile.pages.home_page import Home

from apps.hbonmobile.flows.login_flow import login, login_without_section, \
    is_selection_page_displayed, type_and_remove_login_information, \
    is_login_page_displayed
from apps.hbonmobile.flows.logout_flow import logout, go_to_logout

from apps.hbonshared.resourcesmanager import ResourcesManager as RM
from helpers.configmanager import ConfigManager
from helpers.drivermanager import DriverManager as DM
from helpers.enums import MobilePlatform, Country
from apps.hbonmobile.appresourcesmanager import AppResourcesManager as ARM

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C991", "C724")
def test_login(driver, user):
    """C991: User can successfully sign into valid account"""
    login(driver, user.email, user.password)

    assert Home(driver).is_home_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C991", "C724")
def test_selection_page_displayed_after_login(driver, user):
    """C991: User sees Selection page after login"""
    login_without_section(driver, user.email, user.password)

    assert is_selection_page_displayed(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C991", "724")
def test_input_and_clear_login_information(driver, user):
    """C991: User can enter and clear email and password """
    type_and_remove_login_information(driver, user.email, user.password)

    page = Login(driver)
    assert page.is_email_input_empty()
    assert page.is_password_input_empty()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C991", "C724")
def test_user_stays_logged_in_within_the_session(driver, user):
    """C991: Signed in status is persisted indefinitely"""
    hbo_app = "com.hbonordic.hbonordic"
    settings_app = "settings"

    page = login(driver, user.email, user.password)
    assert page.is_home_page()

    # iOS
    if driver.helper.get_platform() == MobilePlatform.Ios:
        driver = DM.init_driver(override_mobile_app=settings_app)
        driver = DM.init_driver(override_mobile_app=hbo_app)
    # Android
    elif driver.helper.get_platform() == MobilePlatform.Android:
        google_play = ARM.get_app_activity("google-play")
        driver.start_activity(google_play.app, google_play.activity)

        hbo_app = ARM.get_app_activity("hbo-startup")
        driver.start_activity(hbo_app.app, hbo_app.activity)

    assert Home(driver).is_home_page(timeout=60)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C993", "C720")
def test_logout(driver, user):
    """C993: User can successfully sign out"""
    page = login(driver, user.email, user.password)
    assert page.is_home_page()

    go_to_logout(driver)
    assert page.is_confirm_sign_out_text_displayed()
    assert user.email in \
        page.get_confirm_sign_out_acc_text()

    page.click_on_confirm_sign_out_button()
    assert is_login_page_displayed(driver)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category()
@pytest.mark.id("C997")
def test_overflow_button(driver, user):
    page = login(driver, user.email, user.password)
    assert page.is_home_page()
    assert page.is_more_options_button_displayed()

    page.click_on_more_options_button()
    assert page.is_more_options_sign_out_button_displayed()

    # Just tap somewhere to remove sign out option
    driver.helper.tap_on_screen([(50, 500)])
    assert not page.is_more_options_sign_out_button_displayed()


# TODO: Merge this with the 2 android below
@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("ios")
@pytest.mark.category()
@pytest.mark.id("C726")
def test_hbo_logo_between_regions(driver):
    # Arrange
    user_se = RM.get_user(country=Country.SE)
    user_es = RM.get_user(country=Country.ES)

    page = login(driver, user_se.email, user_se.password)
    assert page.is_home_page()
    assert page.is_hbon_logo_displayed()

    logout(driver)

    page = login(driver, user_es.email, user_es.password)
    assert page.is_home_page()
    assert page.is_hboe_logo_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("")  # TODO: add Test Rail test case ID
def test_nordic_user_can_login(driver):
    """C990: User can change the region and Sign In both in Nordic"""
    user = RM.get_user(country=Country.SE)
    page = login(driver, user.email, user.password)

    assert page.is_home_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("")  # TODO: add Test Rail test case ID
def test_spanish_user_can_login(driver):
    """C990: User can change the region and Sign In both in Nordic"""
    user = RM.get_user(country=Country.ES)
    page = login(driver, user.email, user.password)

    assert page.is_home_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1091808", "C725")
def test_email_or_password_field_blank(driver):
    """ Sign In - Invalid credentials
    Checks:
    #1: That we get a password warning if we leave field blank
    #2: That we get an email warning if we leave field blank
    """
    page = Login(driver)

    # 1
    page.input_text_on_email("only@em.ail")
    page.click_on_signin_button()
    assert page.is_password_warning_displayed()

    page.clear_email_input()

    # 2
    page.input_text_on_password("wöröpnörtd")
    page.click_on_signin_button()
    assert page.is_email_warning_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1091808", "C725")
def test_wrong_formatted_email(driver):
    """ Sign In - Invalid credentials
    Checks:
    #1: That we get an email warning if we format email wrongly
    """
    page = Login(driver)

    page.input_text_on_password("asdfasdf")
    page.click_on_signin_button()
    empty_email_warning = page.get_text_of_email_warning()

    # 1
    page.input_text_on_email("$$$")
    if cm.platform == MobilePlatform.Android:
        page.click_on_password_input_button()
    assert page.is_email_warning_displayed()
    assert page.get_text_of_email_warning() != empty_email_warning


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1091808", "C725")
def test_wrong_user_password(driver, user):
    """ Sign In - Invalid credentials
    Checks:
    #1: That we get an error trying to login with bad user
    #2: That the error message is wrong email/password
    #3: That we get an error trying to login with bad password
    """
    page = Login(driver)

    # 1
    page.input_text_on_email("totally@wrong.com")
    page.input_text_on_password("HELVEETA")
    page.click_on_signin_button()
    assert page.is_error_banner_displayed()

    # 2
    error_text = page.get_text_of_error_banner()
    assert RM.get_lang_text("wrong_email_password") == error_text

    # 3
    page.clear_email_input()
    page.input_text_on_email(user.email)
    page.click_on_signin_button()
    assert page.is_error_banner_displayed()

    # 2
    error_text = page.get_text_of_error_banner()
    assert RM.get_lang_text("wrong_email_password") == error_text


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android")
@pytest.mark.category()
@pytest.mark.id("C1479307")
def test_password_is_masked(driver):
    """ Sign In - Fields validation
    Checks:
    #1: That toggle password button is not visible by default
    #2: -||- is visible when password input is active
    #3: That password is masked by default
    #4: That password is unmasked when toggling password mask
    #5: That password remains unmasked when entering more text
    #6: That password remains unmasked when deselecting password input
    #7: That password is masked when toggling password mask
    """
    page = Login(driver)

    # 1
    assert not page.is_toggle_password_button_displayed(1)

    # 2
    page.click_on_password_input_button()
    assert page.is_toggle_password_button_displayed()

    # 3
    pwd = "asdfasdfasdf"
    page.input_text_on_password(pwd)
    assert page.is_password_input_hidden()

    # 4
    page.click_on_toggle_password_button()
    pass_field = page.get_text_of_password_input()
    assert page.is_password_input_showing()
    assert pass_field == pwd

    # 5
    pwd_add = "hello"
    page.input_text_on_password(pwd_add)
    assert page.is_password_input_showing()

    # 6
    page.click_on_email_input_button()
    assert page.is_password_input_showing()

    # 7
    page.click_on_toggle_password_button()
    pass_field = page.get_text_of_password_input()
    assert page.is_password_input_hidden()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1479307", "C724")
def test_enter_and_clear_input(driver):
    """ Sign In - Fields validation
    Checks:
    #1: Fields empty by default
    #2: That you can input many letters in fields
    #3: That you can clear input fields
    """
    long_str = str()
    for _ in range(64):
        long_str += "$"

    page = Login(driver)

    # 1
    assert page.is_email_input_empty()
    assert page.is_password_input_empty()

    # 2
    page.input_text_on_email(long_str)
    page.input_text_on_password(long_str)
    assert page.get_text_of_email_input() == long_str
    assert len(page.get_text_of_password_input()) == len(long_str)
    if cm.platform == MobilePlatform.Android:
        page.click_on_toggle_password_button()
        assert page.get_text_of_password_input() == long_str

    # 3
    page.clear_email_input()
    page.clear_password_input()
    assert page.is_email_input_empty()
    assert page.is_password_input_empty()
