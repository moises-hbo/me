import pytest

from apps.hbonmobile.pages.error_page import Error
from apps.hbonmobile.pages.login_page import Login

from apps.hbonmobile.flows.login_flow import login_without_section

from apps.hbonshared.resourcesmanager import ResourcesManager
from helpers.configmanager import ConfigManager
from helpers.enums import Country, Region

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("outside_eu")
@pytest.mark.id("")  # TODO: add ID from Test Rail
@pytest.mark.skipif(cm.region != Region.OUTSIDE_EU,
                    reason="Needs to be outside EU to test")
def test_geoblocking_after_signin_outside_eu(driver):
    page = Login(driver)
    user = ResourcesManager.get_user(country=Country.SE)
    login_without_section(driver, user.email, user.password)

    page = Error(driver)
    assert page.is_error_image_displayed()
    assert page.is_logo_image_displayed()
    assert page.is_error_title_displayed()
    assert page.is_error_message_displayed()
    assert page.is_retry_button_displayed()
