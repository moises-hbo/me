import copy
import pytest
from helpers.sleeper import Sleeper as sleep

from apps.hbonmobile.pages.asset_page import Asset
from apps.hbonmobile.pages.episode_page import Episode
from apps.hbonmobile.pages.movie_page import Movie
from apps.hbonmobile.pages.player_page import Player

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.playback_flow import start_playback_of_asset
from apps.hbonshared.api_flow import reset_bookmark, get_bookmark, \
    set_bookmark, get_asset_duration, get_asset_metadata

from apps.hbonshared.resourcesmanager import ResourcesManager as RM


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1079025")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("episode"),
    RM.get_special_asset("kids_movie"),
    RM.get_special_asset("kids_episode")
])
def test_player_overview(driver, user_playback, asset):
    """ Player overview
    Checks:
    #1: That 'title' is correct depending on movie or series
    #2: That Back, Sub/Dub, Elapsed, Duration, Progress Bar, Pause
        elements are all visible
    #3: That orientation while playing is Landscape
    """
    user = user_playback
    reset_bookmark(user, asset, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, asset, 1)

    # assert page.is_loading_pulse_displayed(1) // disappears too quickly

    # 1
    title = page.get_text_of_title(tap=True)
    if asset.type == "series":
        assert f"{asset.season} / " in title
        assert title.endswith(str(asset.episode))
    else:
        assert title == asset.title

    # 2
    assert page.is_back_button_displayed(tap=True)
    assert page.is_tracks_button_displayed(tap=True)
    assert page.is_elapsed_time_displayed(tap=True)
    assert page.is_duration_time_displayed(tap=True)
    assert page.is_progress_bar_displayed(tap=True)
    assert page.is_pause_button_displayed(tap=True)
    assert page.is_chromecast_button_displayed(tap=True)

    # 3
    orientation = driver.helper.get_orientation()
    assert orientation == "LANDSCAPE"


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1079355")
def test_player_controls_visibility(driver, user_playback, movie):
    """ Player Control Visibility
    Checks:
    #1: That player controls and pause button can be seen by default
    #2: That player controls disappear after a (5sec after loaded) while
    #3: That all common elements appear when the player controls does
    #4: That player controls again disappear if we wait
    #5: That we can force controls to disappear by tapping screen when visible
    """
    user = user_playback
    reset_bookmark(user, movie, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, movie)

    # 1
    assert page.is_player_controls_displayed(tap=True)
    assert page.is_pause_button_displayed(tap=True)

    # 2
    sleep(10)
    assert not page.is_player_controls_displayed(0)

    # 3
    assert page.get_text_of_title(tap=True) == movie.title
    assert page.is_rewind_10sec_button_displayed(tap=True)
    assert page.is_forward_10sec_button_displayed(tap=True)
    assert page.is_back_button_displayed(tap=True)
    assert page.is_tracks_button_displayed(tap=True)
    assert page.is_elapsed_time_displayed(tap=True)
    assert page.is_duration_time_displayed(tap=True)
    assert page.is_progress_bar_displayed(tap=True)
    assert page.is_pause_button_displayed(tap=True)
    assert page.is_chromecast_button_displayed(tap=True)
    assert page.is_pause_button_displayed(tap=True)

    # 4
    sleep(8)
    assert not page.is_player_controls_displayed(0)

    # 5
    assert page.is_player_controls_displayed(tap=True)
    page.click_within_player()
    assert not page.is_player_controls_displayed(0)


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id()
@pytest.mark.skip(reason="Locking starts to mess with other tests")
def test_player_pause(driver, user_playback, movie):
    """ Pause playback
    Checks:
    #1: Clicking on Pause button pauses playback and
        Play button becomes visible
    #2: Bookmark gets updated to match Elapsed time
    #3: Playback resumes when Play button is pressed
    #4: After locking and unlocking device, Player will
        be in paused state
    #5: See #2
    #6: See #3
    """
    user = user_playback
    set_bookmark(user, movie, 10, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, movie)

    # 1
    page.click_on_pause_button(tap=True)
    assert page.is_player_paused()
    assert page.is_play_button_displayed()

    # 2
    elapsed = page.get_elapsed_time_in_sec()
    bookmark = get_bookmark(user, movie, api=user.api)
    assert elapsed >= bookmark - 1
    assert elapsed <= bookmark + 1

    # 3
    page.click_on_play_button()
    assert page.is_pause_button_displayed()
    assert page.is_player_playing(wait=0)

    # 4
    driver.helper.lock_device(5)

    assert page.is_player_paused()
    assert page.is_play_button_displayed()

    # 5
    elapsed = page.get_elapsed_time_in_sec()
    bookmark = get_bookmark(user, movie, api=user.api)
    assert elapsed >= bookmark - 1
    assert elapsed <= bookmark + 1

    # 6
    page.click_on_play_button()
    assert page.is_pause_button_displayed()
    assert page.is_player_playing(wait=0)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1079026")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("last_episode")
])
def test_player_exiting_playback(driver, user_playback, asset):
    """ End playback
    Checks:
    #1: We can exit player playback by clicking Android 'back' button
    #2: We can exit player playback by clicking player 'back' button
    """
    user = user_playback
    dur = get_asset_duration(user, asset, api=user.api)
    set_bookmark(user, asset, int((dur / 60) / 2), api=user.api)

    login(driver, user.email, user.password)

    page = start_playback_of_asset(driver, asset)
    assert page.is_player_playing(wait=0)

    # 1
    driver.helper.go_back()
    page = Asset(driver)
    assert page.is_play_button_displayed()

    page.click_on_play_button()
    page = Player(driver)
    assert page.is_player_playing(wait=15)

    # 2
    page.click_on_back_button(tap=True)
    page = Asset(driver)
    assert page.is_play_button_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1079026")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("movie"),
    RM.get_special_asset("last_episode")
])
def test_player_playback_ends(driver, user_playback, asset):
    """ End playback
    Checks:
    #1: Player closes when playback is finished
    """
    user = user_playback
    set_bookmark(user, asset, 3, True, api=user.api)

    login(driver, user.email, user.password)

    page = start_playback_of_asset(driver, asset)
    assert page.is_player_playing(wait=0)

    # 1
    page.wait_for_player_to_finish(300)

    page = Asset(driver)
    assert page.is_play_button_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1082921")
def test_chainplay_view(driver, user_playback, has_chainplay):
    """ Transition to Chain play
    Checks:
    #1: That chainplay triggers on cuepoint
    #2: Next Title, series name, season and ep number shown
    #3: Playing view size-reduced upon chainplay
    #4: There is a timer counting down
    """
    user = user_playback
    cp, ne = has_chainplay, copy.deepcopy(has_chainplay)
    ne.episode += 1
    set_bookmark(user, cp, 3, True, api=user.api)
    next_ep_meta = get_asset_metadata(user, ne, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, cp, 0)
    assert page.is_player_playing()

    playback_view = page.get_size_of_playing_view()
    # 1
    assert page.wait_for_chainplay_to_appear(300)

    # 2
    title = page.get_text_of_cp_title()
    assert title == next_ep_meta["title"]
    series_seasn_epn = page.get_text_of_cp_season_ep(1)
    assert f"{cp.title}: " in series_seasn_epn
    assert f"{next_ep_meta['season']} / " in series_seasn_epn
    assert series_seasn_epn.endswith(next_ep_meta['episodeInSeason'])
    assert page.is_cp_image_displayed()

    # 3
    cp_playback_view = page.get_size_of_cp_playing_view()
    assert cp_playback_view["width"] < playback_view["width"]
    assert cp_playback_view["height"] < playback_view["height"]

    # 4
    assert page.is_cp_countdown_counting_down()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1090669")
def test_exit_during_chainplay(driver, user_playback, has_chainplay):
    """ Exiting Chain play
    Checks:
    #1: That we can go back during chain play
    #2: We return to the page we were on
    """
    user = user_playback
    cp = has_chainplay
    set_bookmark(driver, cp, 3, True, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, cp, 0)
    assert page.is_player_playing()

    assert page.wait_for_chainplay_to_appear()

    # 1
    driver.helper.go_back()
    page = Episode(driver)
    assert page.is_episode_page(2)

    # 2
    series_season_episode = page.get_text_of_series_season_ep()
    assert series_season_episode.startswith(f"{cp.title}: ")
    assert str(cp.season) in series_season_episode
    assert series_season_episode.endswith(str(cp.episode))


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1090669")
def test_continuewatching_during_chainplay(driver, user_playback,
                                           has_chainplay):
    """ Exiting Chain play
    Checks:
    #1: We can continue watching past cuepoint. Going before cuepoint and
        reaching it again won't trigger chainplay
    #2: Chainplay will trigger at the end of stream
    #3: Chainplay countdown will start over (from 15sec)
    #4: Continue watching again will leave us at the end of asset
        without any playback running
    """
    user = user_playback
    cp = has_chainplay
    set_bookmark(driver, cp, 3, True, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, cp, 0)
    assert page.is_player_playing()

    assert page.wait_for_chainplay_to_appear()

    while page.get_cp_countdown_timer(1) > 10:
        sleep(1)

    # 1
    page.click_on_cp_playing_view()
    for _ in range(3):
        sleep(1.5)
        page.click_on_rewind_10sec_button()
    assert not page.wait_for_chainplay_to_appear(45)

    # 2
    assert page.wait_for_chainplay_to_appear()

    # 3
    assert page.get_cp_countdown_timer() > 10

    # 4
    page.click_on_cp_playing_view()
    assert page.get_elapsed_time_in_sec() == page.get_duration_time_in_sec()
    sleep(5)
    assert page.get_elapsed_time_in_sec() == page.get_duration_time_in_sec()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1090669")
def test_playnext_during_chainplay(driver, user_playback, has_chainplay):
    """ Exiting Chain play
    Checks:
    #1: That next episode starts when clicking play next, ignoring bookmark
    """
    user = user_playback
    cp, ne = has_chainplay, copy.deepcopy(has_chainplay)
    ne.episode += 1
    set_bookmark(user, cp, 3, True, api=user.api)
    ne_dur = get_asset_duration(user, ne, api=user.api)
    set_bookmark(user, ne, int((ne_dur / 60) / 2), api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, cp, 0)
    assert page.is_player_playing(wait=5)
    assert page.wait_for_chainplay_to_appear()

    # 1
    page.click_on_cp_play_button()
    assert page.is_player_playing()
    assert page.get_elapsed_time_in_percent(tap=True) < 5
    assert page.get_text_of_title(tap=True).endswith(str(ne.episode))


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1090669")
def test_countdown_finishes_during_chainplay(driver, user_playback,
                                             has_chainplay):
    """ Exiting Chain play
    Checks:
    #1: That next episode begins after countdown has counted down,
        ignoring bookmark
    """
    user = user_playback
    cp, ne = has_chainplay, copy.deepcopy(has_chainplay)
    ne.episode += 1
    set_bookmark(user, cp, 3, True, api=user.api)
    ne_dur = get_asset_duration(user, ne, api=user.api)
    set_bookmark(user, ne, int((ne_dur / 60) / 2), api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, cp, 0)
    assert page.is_player_playing()
    assert page.wait_for_chainplay_to_appear()

    # 1
    assert page.is_cp_countdown_counting_down()
    assert page.is_player_playing(wait=25)
    assert page.get_elapsed_time_in_percent(tap=True) < 5
    assert page.get_text_of_title(tap=True).endswith(str(ne.episode))


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1079357")
def test_bookmarking(driver, user_playback, movie):
    """ Bookmarking
    Checks:
    #1: Bookmark is updated during continous playback (heartbeat)
    #2: Bookmark is updated when pause button is pressed
    #3: Bookmark is updated after seeking/scrubbing in timeline
    #4: Bookmark is updated when we exit the player (by back button)
    #5: Bookmark is updated when we exit the player (by back functionality)
    """
    user = user_playback
    dur = get_asset_duration(user, movie, api=user.api)
    set_bookmark(user, movie, int((dur / 60) / 2), api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, movie, 0)
    assert page.is_player_playing()

    # 1
    cur_book = get_bookmark(user, movie, api=user.api)
    sleep(35)
    heartbeat = get_bookmark(user, movie, api=user.api)
    assert heartbeat > cur_book

    assert page.is_player_playing()

    # 2
    sleep(35)
    page.click_on_pause_button(tap=True)
    elapsed = page.get_elapsed_time_in_sec()
    sleep(5)
    pause_book = get_bookmark(user, movie, api=user.api)
    assert pause_book in [elapsed, elapsed + 1, elapsed - 1]  # +-1

    page.click_on_play_button()
    assert page.is_player_playing(wait=20)

    # 3
    page.click_and_drag_on_progress_bar(35)
    elapsed = page.get_elapsed_time_in_sec()
    sleep(5)
    seeked_book = get_bookmark(user, movie, api=user.api)
    assert seeked_book in [elapsed, elapsed + 1, elapsed - 1]  # +-1

    # 4
    sleep(25)
    elapsed = page.get_elapsed_time_in_sec(tap=True)
    page.click_on_back_button()
    sleep(5)
    back_button = get_bookmark(user, movie, api=user.api)
    assert back_button is elapsed <= 2 or elapsed >= 2  # +-2

    page = Movie(driver)
    page.click_on_play_button()
    page = Player(driver)
    assert page.is_player_playing(wait=30)

    # 5
    elapsed = page.get_elapsed_time_in_sec(tap=True)
    driver.helper.go_back()
    sleep(5)
    back_func = get_bookmark(user, movie, api=user.api)
    assert back_func in [elapsed, elapsed + 1, elapsed - 1]  # +-1
    assert back_func > back_button


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1079357")
def test_bookmark_after_cuepoint(driver, user_playback, movie):
    """ Bookmarking
    Checks:
    #1: That asset starts from beginning with bookmark set
        after cuepoint/within 2mins of end
    """
    user = user_playback
    # 1a
    set_bookmark(user, movie, 1, True, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, movie, 0)
    assert page.is_player_playing(wait=5)

    # 1b
    assert page.get_elapsed_time_in_percent() < 3


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android")
@pytest.mark.category("playback")
@pytest.mark.id("C1079357")
def test_no_bookmark(driver, user_playback, movie):
    """ Bookmarking
    Checks:
    #1: That asset starts from beginning with bookmark reset
    """
    user = user_playback
    # 1a
    reset_bookmark(user, movie, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, movie, 0)
    assert page.is_player_playing(wait=5)

    # 1b
    assert page.get_elapsed_time_in_percent() < 3


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category("long_playback", "playback")
@pytest.mark.excluded()
@pytest.mark.id("C1082920")
def test_long_playback(driver, user_playback, long_series_first_episode,
                       long_series_last_episode):
    user = user_playback
    lsfe = long_series_first_episode
    lsle = long_series_last_episode

    page = login(driver, user.email, user.password)
    page = start_playback_of_asset(driver, lsfe)

    play = True
    while play:
        assert page.is_player_playing(wait=0)
        if page.wait_for_chainplay_to_appear(180):
            ni = page.get_text_of_cp_season_ep()
            ni_title = ni.startswith(f"{lsle.title}: ")
            ni_season = str(lsle.season) in ni
            ni_episode = ni.endswith(f"{lsle.episode}")
            if ni_title and ni_season and ni_episode:
                play = False
        else:
            continue
    # Success
