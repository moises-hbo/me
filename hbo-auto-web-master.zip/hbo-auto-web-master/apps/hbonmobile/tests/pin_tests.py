import pytest

from apps.hbonmobile.pages.pin_page import Pin
from apps.hbonmobile.pages.kids_page import Kids
from apps.hbonmobile.pages.home_page import Home

from apps.hbonmobile.flows.login_flow import login, click_on_got_it
from apps.hbonmobile.flows.logout_flow import logout
from apps.hbonmobile.flows.pin_flow import enter_pin, confirm_pin, \
    back_out_from_pin, close_pin_from_kids

from helpers.enums import Section, MobilePlatform
from helpers.configmanager import ConfigManager

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1085", "C807")
def test_set_pin_prompt(driver, user_change_pin):
    """C1085: Verify set pin is shown
    verify it is shown after re-login when chosen "maybe later"
    verify it is not shown after re-login when chosen "don't ask again"
    """
    user_change_pin.api.reset_pin()

    login(driver, user_change_pin.email, user_change_pin.password)

    page = Pin(driver)
    # Verify we see pin page
    assert page.is_pin_page()

    page.click_on_maybe_later_button()

    page = Home(driver)

    if cm.platform == MobilePlatform.Ios:
        page.click_on_push_noti_allow_button()
    click_on_got_it(driver)

    assert page.is_home_page()

    logout(driver)
    login(driver, user_change_pin.email, user_change_pin.password)

    # Verify we see pin page after previously chosen "maybe later"
    page = Pin(driver)
    assert page.is_pin_page()

    page.click_on_dont_ask_me_again_button()
    click_on_got_it(driver)

    page = Home(driver)
    assert page.is_home_page()

    logout(driver)
    login(driver, user_change_pin.email, user_change_pin.password)

    # Verify pin page is skipped after previous "don't ask again"
    assert page.is_home_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1085", "C807")
def test_set_pin_prompt_exit_kids(driver, user_change_pin):
    """C1085: Verify set pin is shown when exit'ing Kids page"""
    user_change_pin.api.reset_pin()

    login(driver, user_change_pin.email, user_change_pin.password,
          go_to_section=Section.KIDS)

    Kids(driver).click_on_exit_kids_button()
    assert Pin(driver).is_pin_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1086", "C810")
def test_enter_new_pin(driver, user_change_pin):
    """C1086: Verify we can set & confirm PIN
    Verify we can back from setting PIN page"""
    user_change_pin.api.reset_pin()

    login(driver, user_change_pin.email, user_change_pin.password)

    page = Pin(driver)
    assert page.is_pin_page()

    page.click_on_set_pin_button()

    # Verify we can back pin options
    back_out_from_pin(driver)
    assert page.is_pin_page()

    enter_pin(driver, 1111, confirm=False)

    # Verify we can back out of Confirm PIN
    back_out_from_pin(driver)
    back_out_from_pin(driver)
    assert page.is_pin_page()

    enter_pin(driver, 1234)

    page = Home(driver)

    if cm.platform == MobilePlatform.Ios:
        page.click_on_push_noti_allow_button()
    click_on_got_it(driver)

    assert page.is_home_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1087", "C812")
def test_set_pin_prompt_wrong_confirm(driver, user_change_pin):
    """C1087: Verify wrong confirm PIN"""
    # Arrange
    user_change_pin.api.reset_pin()

    login(driver, user_change_pin.email, user_change_pin.password)
    enter_pin(driver, 1234, confirm=False)
    confirm_pin(driver, 1235)

    page = Pin(driver)
    assert page.is_pin_doesnt_match_visible()
    assert page.get_text_of_pin_doesnt_match_error().startswith("PIN")

    back_out_from_pin(driver)
    assert page.is_pin_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1088", "C816")
def test_enter_pin_when_exit_kids(driver, user_change_pin):
    user_change_pin.api.set_pin(1234)

    page = login(driver, user_change_pin.email, user_change_pin.password,
                 go_to_section=Section.KIDS)

    # Exit, then dismiss PIN
    page.click_on_exit_kids_button()
    close_pin_from_kids(driver)
    assert page.is_kids_locked_page()

    # Exit, then input wrong PIN
    page.click_on_exit_kids_button()
    enter_pin(driver, 9876, confirm=False, click_set_pin=False)
    assert not Home(driver).is_home_page(timeout=2) \
        and not Kids(driver).is_kids_locked_page(timeout=1)

    # Try again, with correct PIN
    enter_pin(driver, 1234, confirm=False, click_set_pin=False)
    assert Home(driver).is_home_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1091", "C830")
def test_reset_pin_when_exit_kids(driver, user_change_pin):
    user_change_pin.api.set_pin(1111)

    page = login(driver, user_change_pin.email, user_change_pin.password,
                 go_to_section=Section.KIDS)

    page.click_on_exit_kids_button()

    page = Pin(driver)
    page.click_on_forgot_pin_button()
    page.enter_text_on_forgot_pin_entry(user_change_pin.password)
    page.click_on_forgot_pin_continue_button()

    enter_pin(driver, 5967)

    assert Home(driver).is_home_page()
