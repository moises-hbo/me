import pytest

from apps.hbonmobile.pages.movie_page import Movie

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.search_flow import search_and_enter

from apps.hbonshared.api_flow import set_bookmark


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android")
@pytest.mark.category()
@pytest.mark.id("C12519")
def test_bookmark_in_movie_details(driver, user_playback, movie):
    user = user_playback
    set_bookmark(user, movie, 20, api=user.api)

    login(driver, user.email, user.password)
    search_and_enter(driver, movie.title, 0)

    page = Movie(driver)
    assert page.is_bookmark_displayed()
