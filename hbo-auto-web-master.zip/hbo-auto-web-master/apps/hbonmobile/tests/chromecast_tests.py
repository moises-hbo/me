import pytest

from apps.hbonmobile.pages.adultkidsselection_page import AdultKidsSelection
from apps.hbonmobile.pages.home_page import Home

from apps.hbonmobile.flows.login_flow import login_without_section

from helpers.configmanager import ConfigManager

cm = ConfigManager()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1028", "C780")
def test_chromecast_intro_view(driver, user):
    login_without_section(driver, user.email, user.password)

    page = AdultKidsSelection(driver)
    page.click_on_series_movies_button()
    page = Home(driver)

    if cm.platform == "ios":
        if page.is_push_noti_allow_button_displayed():
            page.click_on_push_noti_allow_button()

    assert page.is_chromecast_intro_layer_displayed()
    assert page.is_chromecast_intro_description_displayed()
    assert page.is_got_it_button_displayed()

    page.click_on_got_it_button()

    assert not page.is_chromecast_intro_layer_displayed(1)
    assert not page.is_chromecast_intro_description_displayed(1)
    assert not page.is_got_it_button_displayed(1)
