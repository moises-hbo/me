import pytest

from apps.hbonmobile.flows.login_flow import login

from helpers.configmanager import ConfigManager
from helpers.enums import Section

cm = ConfigManager()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("ios")
@pytest.mark.category()
@pytest.mark.id("C758")
@pytest.mark.parametrize("section", [
    Section.ADULT,
    Section.KIDS
])
def test_carousel_progress_bar(driver, user, section):
    """ Scrolling Carousel
    Checks:
    #1: Progress bar is visible near (over) carousel
    #2: Can't go further left than we start with (value of 0)
    #3: Can scroll right
    #4: Can scroll left after first scrolling right
    #5: Can't go further right than to the carousels' end (value of 100)
    """
    page = login(driver, user.email, user.password, go_to_section=section)

    assert page.is_carousel_list_displayed()
    # 1
    assert page.is_carousel_scroll_indicator_displayed()

    carousel = page.get_carousel()
    cc = page.get_carousel_center()

    # 2
    # Get progress. Should be 0
    pre_progress = page.get_carousel_progress_bar_progress()

    # Swipe right (go left)
    driver.helper.press_and_drag(carousel, (cc[0] + 100, cc[1]))

    # Can't go further left, progress should still be 0
    go_left_progress = page.get_carousel_progress_bar_progress()
    assert go_left_progress == pre_progress

    # 3
    # Swipe left (go right)
    driver.helper.press_and_drag(carousel, (cc[0] - 100, cc[1]))

    post_progress = page.get_carousel_progress_bar_progress()
    assert post_progress > pre_progress

    # Swipe left (go right)
    driver.helper.press_and_drag(carousel, (cc[0] - 100, cc[1]))

    post_post_progress = page.get_carousel_progress_bar_progress()
    assert post_post_progress > post_progress

    # 4
    # Swipe back right
    driver.helper.press_and_drag(carousel, (cc[0] + 100, cc[1]))

    back_left_progress = page.get_carousel_progress_bar_progress()
    assert back_left_progress < post_post_progress

    # 5
    # Swipe left to the end
    while page.get_carousel_progress_bar_progress() < 100:
        driver.helper.press_and_drag(carousel, (cc[0] - 100, cc[1]))
    driver.helper.press_and_drag(carousel, (cc[0] - 100, cc[1]))

    end_progress = page.get_carousel_progress_bar_progress()
    assert end_progress == 100
