import pytest

from apps.hbonshared.resourcesmanager import ResourcesManager
from helpers.enums import Region

from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.kids_page import Kids
from apps.hbonmobile.pages.watchlist_page import Watchlist
from apps.hbonmobile.pages.search_page import Search
from apps.hbonmobile.pages.navigation_partial import Navigation

from apps.hbonmobile.flows.login_flow import login

from helpers.enums import MobilePlatform, Section


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C239", "C241")
def test_menu_unauth(driver):
    """C241: Verify lack of menu items when unauthenticated"""
    page = Navigation(driver)
    assert not page.is_adult_menu_displayed(1)
    assert not page.is_kids_menu_displayed(1)


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C240", "C242")
def test_menu_auth(driver, user):
    """C242: Verify menu items,
    Home, Kids, Watchlist, Search"""
    login(driver, user.email, user.password)
    assert Home(driver).is_adult_menu_displayed()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C248", "C249")
def test_kids_for_region(driver, user):
    """C249: Verify Toonix branding in Nordic,
    and Kids in España"""
    page = login(driver, user.email, user.password, go_to_section=Section.KIDS)

    region = ResourcesManager.get_region()
    # Android
    if driver.helper.get_platform() == MobilePlatform.Android:
        if region == Region.NORDIC:
            # Nordic
            assert page.get_header_text().startswith("Toonix")
        elif region == Region.ESPANA:
            # Espana
            assert page.get_header_text() == "Kids"
    # iOS
    elif driver.helper.get_platform() == MobilePlatform.Ios:
        if region == Region.NORDIC:
            # Nordic
            assert page.get_text_of_home_button().startswith("Toonix")
            assert page.is_toonix_logo_displayed()
        elif region == Region.ESPANA:
            # Espana
            assert page.get_text_of_home_button() == "Kids"


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C253", "C254")
def test_highlight_menu_items(driver, user):
    """C254: Verify menu items get highlighted when active"""
    page = login(driver, user.email, user.password)

    assert page.is_home_page()
    assert page.is_home_button_selected()

    page.click_on_kids_button()
    page = Kids(driver)
    page.click_on_got_it_button()
    assert page.is_kids_unlocked_page()
    assert page.is_kids_button_selected()

    page.click_on_watchlist_button()
    page = Watchlist(driver)
    assert page.is_watchlist_button_selected()

    page.click_on_search_button()
    page = Search(driver)
    assert page.is_search_page()
    assert page.is_search_button_selected()

    page.click_on_home_button()
    page = Home(driver)
    assert page.is_home_page()
    assert page.is_home_button_selected()
