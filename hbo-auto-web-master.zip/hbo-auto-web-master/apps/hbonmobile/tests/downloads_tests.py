import pytest
from helpers.sleeper import Sleeper as sleep

from apps.hbonmobile.pages.asset_page import Asset
from apps.hbonmobile.pages.movie_page import Movie
from apps.hbonmobile.pages.series_page import Series
from apps.hbonmobile.pages.episode_page import Episode
from apps.hbonmobile.pages.player_page import Player
from apps.hbonmobile.pages.downloads_page import Downloads
from apps.hbonmobile.pages.home_page import Home
from apps.hbonmobile.pages.kids_page import Kids

from apps.hbonmobile.flows.login_flow import login
from apps.hbonmobile.flows.logout_flow import logout
from apps.hbonmobile.flows.search_flow import search_and_enter
from apps.hbonmobile.flows.series_flow import go_to_season, go_to_episode, \
    search_and_navigate_to_episode
from apps.hbonmobile.flows.temp_download_flow import \
    start_download_of_episode_from_episode, \
    start_download_of_episode_from_season, \
    start_download_of_movie
from apps.hbonmobile.flows.playback_flow import start_playback_of_asset
from apps.hbonmobile.flows.kids_flow import exit_kids
from apps.hbonshared.api_flow import get_bookmark, reset_bookmark, \
    create_account

from apps.hbonshared.resourcesmanager import ResourcesManager as RM

from helpers.configmanager import ConfigManager
from helpers.enums import MobilePlatform, Section
from helpers.logger import Log

cm = ConfigManager()
log = Log()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C2759739", "C2773221")
@pytest.mark.parametrize("dm", [
    RM.get_special_asset("downloadable_movie"),
    RM.get_special_asset("downloadable_movie_kids")
])
def test_download_movie(driver, user_download, dm):
    """ Users in OK state can download content
        In progress status for movie detail screen
    Checks:
    #1: Download button is available for valid movie with status 'Download'
    #2: Changes to In Progress shortly
    #3: Download button changes look as the download status does
    #4: Download status progresses once started
    """
    user = user_download

    page = login(driver, user.email, user.password)
    search_and_enter(driver, dm.title)

    # 1
    page = Movie(driver)
    assert page.is_download_button_displayed()
    assert page.is_asset_downloadable()
    img_dl_download = page.get_screenshot_of_download_button_base64()

    # 2
    page.click_on_download_button()
    assert page.is_asset_downloading()
    img_dl_inprogress = page.get_screenshot_of_download_button_base64()

    # 3
    assert img_dl_download != img_dl_inprogress

    # 4
    assert page.is_asset_download_progressing(120)

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C2759739")
@pytest.mark.parametrize("de", [
    (RM.get_special_asset("downloadable_episode"),
     RM.get_special_asset("downloadable_episode_next")),
    (RM.get_special_asset("downloadable_episode_kids"),
     RM.get_special_asset("downloadable_episode_kids_next"))
])
def test_download_episode(driver, user_download, de):
    """ Users in OK state can download content
    Checks:
    #1: Downloadable label exists in Series overview
    #2: Downloadable label exists in Season overview
    #3: Download button is available for valid episode with status 'Download'
    #4: Clicking on download starts download shortly
    #5: Check episode detail view of another episode that's not downloading
    #6: Episode should stay 'Queued' as episode before is still downloading
    """
    user = user_download
    ep1, ep2 = de[0], de[1]

    page = login(driver, user.email, user.password)
    search_and_enter(driver, ep1.title)

    # 1
    page = Series(driver)
    assert page.is_download_label_displayed()

    # 2
    go_to_season(driver, ep1.season)
    assert page.is_download_label_displayed()

    go_to_episode(driver, ep1.ep_name)

    # 3
    page = Episode(driver)
    assert page.is_download_button_displayed()
    assert page.is_asset_downloadable()

    # 4
    page.click_on_download_button()
    assert page.is_asset_downloading()

    # 5
    page.click_on_back_button()
    go_to_episode(driver, ep2.ep_name)
    assert page.is_download_button_displayed()
    assert page.wait_for_download_status_to_be_downloadable()

    # 6
    page.click_on_download_button()
    assert page.wait_for_download_status_to_be_queued()
    assert not page.is_asset_downloading(3)

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C2773124")
def test_progress_in_season_and_episode_details(tmp_path, driver,
                                                user_download):
    """  In progress status for season and episode detail screens
    NOTE: Have inverted kids and adult episode contrary to test case
    Checks:
    #1: Start download of kids episode from season view. verify it downloads
    #2: Go to episode detail view and verify download status there
    #3: Go to another episode and verify it's not downloading
    #4: Go back and cancel downloading episode
    #5: Start download of a series episode
    #6: Go to Series overview and verify 'Download' label exists
    """
    user = user_download
    kids_ep = RM.get_special_asset("downloadable_episode_kids")
    kids_ep_next = RM.get_special_asset("downloadable_episode_kids_next")
    adult_ep = RM.get_special_asset("downloadable_episode")

    page = login(driver, user.email, user.password)

    # 1
    page = start_download_of_episode_from_season(driver, kids_ep)
    assert page.is_episode_downloading(kids_ep.ep_name, tmp_path)

    # 2
    page.click_on_ep(kids_ep.ep_name)
    page = Episode(driver)
    assert page.is_asset_downloading()

    # 3
    page.click_on_back_button()
    page = go_to_episode(driver, kids_ep_next.ep_name)
    assert not page.is_asset_downloading(2)

    # 4
    page.click_on_back_button()
    page = Series(driver)
    page.click_on_dl_ep_button(kids_ep.ep_name)
    page.click_on_stop_download_button()
    assert not page.is_episode_downloading(kids_ep.ep_name, tmp_path, 2)

    # 5
    page = start_download_of_episode_from_episode(driver, adult_ep, Series)
    assert page.is_asset_downloading()

    # 6
    search_and_enter(driver, adult_ep.title, from_page=Episode)
    page = Series(driver)
    assert page.get_text_of_download_label() == "Download"

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C2773225")
@pytest.mark.parametrize("movies", [
    [RM.get_special_asset("downloadable_movie"),
     RM.get_special_asset("downloadable_movie_kids")],
    [RM.get_special_asset("downloadable_movie_kids"),
     RM.get_special_asset("downloadable_movie")],
])
def test_movie_queued_status(driver, user_download, movies):
    """ Queued status for movie detail screen
    Checks:
    #1: That download status stay queued on movie if there's
        already something downloading
    """
    user = user_download

    page = login(driver, user.email, user.password)
    page = start_download_of_movie(driver, movies[0])
    assert page.is_asset_downloading()

    # 1
    page = start_download_of_movie(driver, movies[1])
    assert page.wait_for_download_status_to_be_queued()
    sleep(10)
    assert page.is_asset_queued()

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C2773224")
@pytest.mark.parametrize("asset", [
    [RM.get_special_asset("downloadable_movie"),
     RM.get_special_asset("downloadable_episode"),
     RM.get_special_asset("downloadable_episode_next")],
    [RM.get_special_asset("downloadable_movie_kids"),
     RM.get_special_asset("downloadable_episode_kids"),
     RM.get_special_asset("downloadable_episode_kids_next")]
])
def test_series_queued_status(tmp_path, driver, user_download, asset):
    """  Queued status for season and episode detail screens
    Checks:
    #1: Episode is queued in season view
    #2: Queued status reflected in episode detail view
    #3: Go to another episode and verify it's "downloadable"
    #4: Click on download and verify it gets queued
    #5: Go to series overview and verify the "downloadable" label
    """
    user = user_download
    movie, ep1, ep2 = asset[0], asset[1], asset[2]

    page = login(driver, user.email, user.password)

    # movie - just to keep others queued
    page = start_download_of_movie(driver, movie)

    # 1
    # ep1
    page = search_and_navigate_to_episode(driver, ep1, enter=False)

    if cm.platform == MobilePlatform.Android:
        dl_btn_dlable = page.get_screenshot_of_episode_download_button_base64(
            ep1.ep_name)

    page.click_on_dl_ep_button(ep1.ep_name)
    assert page.is_episode_queued(ep1.ep_name, tmp_path)

    if cm.platform == MobilePlatform.Android:
        dl_btn_queued = page.get_screenshot_of_episode_download_button_base64(
            ep1.ep_name)
        assert dl_btn_dlable != dl_btn_queued

    # 2
    page.click_on_ep(ep1.ep_name)
    page = Episode(driver)
    assert page.is_asset_queued()

    # 3
    page.click_on_back_button()
    # ep2
    page = go_to_episode(driver, ep2.ep_name)

    if cm.platform == MobilePlatform.Android:
        dl_btn_dlable = page.get_screenshot_of_download_button_base64()
    assert not page.is_asset_queued(1)
    assert not page.is_asset_downloading(2)

    # 4
    page.click_on_download_button()
    assert page.wait_for_download_status_to_be_queued()
    if cm.platform == MobilePlatform.Android:
        dl_btn_queued = page.get_screenshot_of_download_button_base64()
        assert dl_btn_dlable != dl_btn_queued

    # 5
    search_and_enter(driver, ep1.title)
    page = Series(driver)
    assert page.is_download_label_displayed(3)

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C3112607")
def test_start_downloadable_episodes_exit_and_reenter(
        tmp_path, driver, user_download,
        downloadable_episode, downloadable_episode_next):
    """ Labels and icons persist when reopening season detail
    Checks:
    #1: From season details; First episode starts downloading, second is queued
    #2: Exit'ing and re-entering season details; the status of episodes remain
    #3: Entering episode detail and download status remains "correct"
    """
    user = user_download
    de, den = downloadable_episode, downloadable_episode_next

    page = login(driver, user.email, user.password)

    # 1
    page = start_download_of_episode_from_season(driver, de)
    go_to_episode(driver, den.ep_name, 1, enter=False)
    page.click_on_dl_ep_button(den.ep_name)
    assert page.is_episode_downloading(de.ep_name, tmp_path)
    assert page.is_episode_queued(den.ep_name, tmp_path)

    # 2
    search_and_enter(driver, den.title)
    page = go_to_season(driver, den.season)
    page = go_to_episode(driver, den.ep_name, enter=False)
    assert page.is_episode_downloading(de.ep_name, tmp_path)
    assert page.is_episode_queued(den.ep_name, tmp_path)

    # 3
    page = go_to_episode(driver, de.ep_name)
    assert page.is_asset_downloading()
    page.click_on_back_button()
    page = go_to_episode(driver, den.ep_name)
    assert page.wait_for_download_status_to_be_queued()

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("downloadable")
@pytest.mark.platform("android", "ios")
@pytest.mark.id("C2773227")
@pytest.mark.parametrize("movie", [
    RM.get_special_asset("downloadable_movie"),
    RM.get_special_asset("downloadable_movie_kids")
])
def test_download_complete_movie(driver, user_download, movie):
    """ Download completed status for movie detail screen
    Checks:
    #1: Can download to completion. Download status changes to valid
    #2: Download button changes icon to reflect change in download status
    """
    user = user_download

    page = login(driver, user.email, user.password)
    page = start_download_of_movie(driver, movie)
    assert page.is_asset_downloading()
    if cm.platform == MobilePlatform.Android:
        downloading_img = page.get_screenshot_of_download_button_base64()

    # 1
    assert page.wait_for_asset_download_to_complete()

    # 2
    if cm.platform == MobilePlatform.Android:
        downloaded_img = page.get_screenshot_of_download_button_base64()
        assert downloading_img != downloaded_img

    page = logout(driver)


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("downloadable")
@pytest.mark.platform("android", "ios")
@pytest.mark.id("2773226")
@pytest.mark.parametrize("ep", [
    RM.get_special_asset("downloadable_episode"),
    RM.get_special_asset("downloadable_episode_kids")
])
def test_download_complete_episode_from_season(tmp_path, driver,
                                               user_download, ep):
    """ Download completed status for season and episode detail screens
    Checks:
    #1: Can download to completion in season view. Download status changes to
        valid
    #2: Download button in season view changes icon to reflect change in
        download status
    #3: Same download status is reflected in episode view
    #4: Clicking on download button will open sheet/overlay to play or
        remove download
    #5: Download status of series overview will just be "Download"
    """
    user = user_download

    page = login(driver, user.email, user.password)

    page = start_download_of_episode_from_season(driver, ep)
    assert page.is_episode_downloading(ep.ep_name, tmp_path, timeout=60)
    if cm.platform == MobilePlatform.Android:
        dling_img = page.get_screenshot_of_episode_download_button_base64(
            ep.ep_name)

    # 1
    assert page.wait_for_episode_download_to_complete(ep.ep_name, tmp_path)

    # 2
    if cm.platform == MobilePlatform.Android:
        downloaded_img = page.get_screenshot_of_episode_download_button_base64(
            ep.ep_name)
        assert dling_img != downloaded_img

    # 3
    page.click_on_ep(ep.ep_name)
    page = Episode(driver)
    assert page.is_asset_download_complete()

    # 4
    page.open_download_overlay()
    assert page.is_play_download_button_displayed()
    assert page.is_remove_download_button_displayed()
    if cm.platform == MobilePlatform.Android:
        assert not page.is_stop_download_button_displayed(1)

    # Get rid of bottom sheet overlay
    win_cen_x, win_cen_y = driver.helper.get_window_center()
    driver.helper.tap_on_screen([(win_cen_x, win_cen_y)])

    # 5
    search_and_enter(driver, ep.title)
    page = Series(driver)
    assert page.get_text_of_download_status() == "Download"

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.category("downloadable")
@pytest.mark.platform("android", "ios")
@pytest.mark.id("2773226")
@pytest.mark.parametrize("ep", [
    RM.get_special_asset("downloadable_episode"),
    RM.get_special_asset("downloadable_episode_kids")
])
def test_download_complete_episode_from_episode(driver, user_download, ep):
    """ Download completed status for season and episode detail screens
    Checks:
    #1: Can download to completion in ep view. Download status changes to valid
    #2: Download button in ep view changes icon to reflect change in download
        status
    #3: Clicking on download button will open sheet/overlay to play or
        remove download
    #4: Download status of series overview will just be "Download"
    """
    user = user_download

    page = login(driver, user.email, user.password)
    page = start_download_of_episode_from_episode(driver, ep)
    assert page.is_asset_downloading()
    if cm.platform == MobilePlatform.Android:
        downloading_img = page.get_screenshot_of_download_button_base64()

    # 1
    assert page.wait_for_asset_download_to_complete()

    # 2
    if cm.platform == MobilePlatform.Android:
        downloaded_img = page.get_screenshot_of_download_button_base64()
        assert downloading_img != downloaded_img

    # 3
    page.open_download_overlay()
    assert page.is_play_download_button_displayed()
    assert page.is_remove_download_button_displayed()
    if cm.platform == MobilePlatform.Android:
        assert not page.is_stop_download_button_displayed(1)

    # Get rid of bottom sheet overlay
    win_cen_x, win_cen_y = driver.helper.get_window_center()
    driver.helper.tap_on_screen([(win_cen_x, win_cen_y)])

    # 4
    search_and_enter(driver, ep.title)
    page = Series(driver)
    assert page.get_text_of_download_status() == "Download"

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C2843536")
@pytest.mark.parametrize("asset", [
    RM.get_special_asset("downloadable_movie"),
    RM.get_special_asset("downloadable_movie_kids"),
    RM.get_special_asset("downloadable_episode"),
    RM.get_special_asset("downloadable_episode_kids")])
def test_48h_after_playback_of_downloaded_asset(driver, user_download, asset):
    """ User has 48 hours to finish playback
    Checks:
    #1: Asset appears downloaded after download completes
    #2: Playback can be started and stopped repeatedly
    #3: After first playback, the window to play asset will be lowered to 48h
    """
    user = user_download

    page = login(driver, user.email, user.password)

    page = start_download_of_episode_from_episode(driver, asset) \
        if asset.type == "series" \
        else start_download_of_movie(driver, asset)

    assert page.wait_for_asset_download_to_complete()

    # 1
    assert page.get_text_of_download_status() == "Downloaded"

    # 2
    for _ in range(5):
        page.open_play_overlay()
        page.click_on_play_download_button()

        page = Player(driver)
        assert page.is_player_playing(20)

        page.click_on_back_button(tap=True)

        page = Asset(driver)
        # 3
        dl_status = page.get_text_of_download_status()
        assert "Expires" in dl_status
        assert "48" or "47" in dl_status

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android")
@pytest.mark.category("downloadable", "dl_playback")
@pytest.mark.id("C3201434")
def test_48h_details_screen_episode(tmp_path, driver, user_download,
                                    downloadable_episode):
    """ 48 hours remaining notice - Detail screens
    Checks:
    #1: There's no expiry notice for a newly downloaded/unplayed episode
        in series details
    #2: Neither is it in episode details
    #3: Start playback
    #4: Back out from playback, back to Series details. There's a expiry notice
    #5: Go into Episode details. Expiry notice there as well
    """
    de = downloadable_episode
    user = user_download

    page = login(driver, user.email, user.password)

    # 1
    page = start_download_of_episode_from_season(driver, de)
    assert page.wait_for_episode_download_to_complete(de.ep_name, tmp_path)
    assert not page.get_text_of_episode_download_status(de.ep_name, tmp_path)

    # 2
    page.click_on_ep(de.ep_name)

    page = Episode(driver)
    assert "Expires" not in page.get_text_of_download_status()

    # 3
    page.click_on_play_button()
    page.click_on_play_download_button()

    page = Player(driver)
    assert page.is_player_playing(wait=15)
    page.click_on_back_button(tap=True)

    page = Episode(driver)
    sleep(1)
    page.click_on_back_button()

    page = Series(driver)
    assert "Expires in" in page.get_text_of_episode_download_status(
        de.ep_name, tmp_path)

    page.click_on_ep(de.ep_name)

    page = Episode(driver)
    assert "Expires soon" in page.get_text_of_download_status()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android")
@pytest.mark.category("downloadable", "dl_playback")
@pytest.mark.id("C3201434")
def test_48h_details_screen_movie(driver, user_download,
                                  downloadable_movie):
    """ 48 hours remaining notice - Detail screens
    Checks:
    #1: There's no expiry notice for a newly downloaded/unplayed movie
        in movie details
    #2: Start playback
    #3: Back out into Movie details. There's an expiry notice
    """
    dm = downloadable_movie
    user = user_download

    page = login(driver, user.email, user.password)

    page = start_download_of_movie(driver, dm)
    page.wait_for_asset_download_to_complete()

    assert "Expires" not in page.get_text_of_download_status()

    # 2
    page.click_on_play_button()
    page.click_on_play_download_button()

    page = Player(driver)
    assert page.is_player_playing(wait=15)
    page.click_on_back_button(tap=True)

    # 3
    page = Episode(driver)
    assert "Expires soon" in page.get_text_of_download_status()


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable", "playback", "dl_playback")
@pytest.mark.id("C2793866")
def test_setting_local_bookmark(driver, user_download,
                                downloadable_movie, downloadable_movie_kids):
    """ Setting local bookmarks
    Checks:
    #1: Starting playback of downloaded asset starts from beginning
    #2: Progress bar / bookmark will be displayed on played asset
    #3: No bookmark for Asset details since Stream and Local bookmarks differ
    #4: Returning to Downloads, playing asset again will continue from bookmark
    #5: Play stream of asset and verify it starts from the beginning
    #6: Delete and re-download assets.
    #7: Verify downloaded assets plays back from the beginning again
    """
    dm, dmk = downloadable_movie, downloadable_movie_kids
    user = user_download

    reset_bookmark(user, dm, api=user.api)
    reset_bookmark(user, dmk, api=user.api)

    page = login(driver, user.email, user.password)
    page = start_download_of_movie(driver, dm)
    page = start_download_of_movie(driver, dmk, from_page=Movie)

    page.click_on_downloads_button()

    page = Downloads(driver)
    assert page.are_assets_downloading()
    assert page.wait_for_asset_downloads_to_complete()

    # first adult, then kids movie
    for asset in (dm, dmk):
        # 1
        page.click_on_play_button(asset)
        page = Player(driver)
        assert page.get_elapsed_time_in_percent(timeout=15) <= 1

        # 2
        assert page.wait_for_elapsed_time_in_percent_to_be_over(2)
        page.click_on_back_button(tap=True)
        page = Downloads(driver)
        assert page.is_progress_bar_displayed(asset)

        # 3
        search_and_enter(driver, asset.title, from_page=Downloads)
        page = Movie(driver)
        assert get_bookmark(user, asset) == 0
        if cm.platform == MobilePlatform.Android:
            assert not page.is_bookmark_displayed(1)

        # 4
        page.click_on_downloads_button()
        page = Downloads(driver)
        page.click_on_play_button(asset)
        page = Player(driver)
        assert page.get_elapsed_time_in_percent(tap=True) >= 2

        page.click_on_back_button(tap=True)

        # 5
        page = start_playback_of_asset(driver, asset, time_to_play=5,
                                       from_page=Downloads)
        assert page.get_elapsed_time_in_percent(tap=True) <= 1

        page.click_on_back_button(tap=True)
        page = Movie(driver)

        page.click_on_downloads_button()
        page = Downloads(driver)

    # 6
    page.delete_asset(dm, done=False)
    page.delete_asset(dmk)

    page = start_download_of_movie(driver, dm)
    page = start_download_of_movie(driver, dmk, from_page=Movie)

    page.click_on_downloads_button()

    page = Downloads(driver)
    assert page.are_assets_downloading()
    assert page.wait_for_asset_downloads_to_complete()

    # 7
    for asset in (dm, dmk):
        page.click_on_play_button(asset)

        page = Player(driver)
        assert page.get_elapsed_time_in_percent(timeout=15) <= 1

        page.click_on_back_button(tap=True)
        page = Downloads(driver)

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("ios", "android")
@pytest.mark.category("downloadable")
@pytest.mark.id("C7482944")
@pytest.mark.parametrize("movie", [
    RM.get_special_asset("downloadable_movie"),
    RM.get_special_asset("downloadable_movie_kids")
])
def test_pending_cannot_download_movie(driver, user_tmp, movie):
    """ User In Pending/Overdue/Closed state cannot download content
    Checks:
    #1: At Movie details, Downloadable status is displayed
    #2: Clicking on download button will give a popup, saying subscription
        is inactive
    """
    create_account(user_tmp)

    page = login(driver, user_tmp.email, user_tmp.password,
                 click_away_pin=True)

    # 1
    page.click_on_search_button()
    search_and_enter(driver, movie.title)
    page = Movie(driver)
    assert page.is_download_status_displayed()

    # 2
    page.click_on_download_button()
    assert page.is_sub_inactive_header_displayed()

    page.click_on_sub_inactive_ok_button()

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("ios", "android")
@pytest.mark.category("downloadable")
@pytest.mark.id("C7482944")
@pytest.mark.parametrize("ep", [
    RM.get_special_asset("downloadable_episode"),
    RM.get_special_asset("downloadable_episode_kids")
])
def test_pending_cannot_download_episode(driver, user_tmp, ep):
    """ User In Pending/Overdue/Closed state cannot download content
    Checks:
    #1: At Series page, Downloadable status is displayed
    #2: In season page, Downloadable status is displayed
    #3: Clicking on download button of episode, in season, will give a
        popup, saying subscription is inactive
    #4: Going into episode details page, downloadable status is displayed
    #5: Clicking on download button will again give inactive sub popup
    """
    create_account(user_tmp)

    page = login(driver, user_tmp.email, user_tmp.password,
                 click_away_pin=True)
    page.click_on_search_button()

    # 1
    search_and_enter(driver, ep.title)
    page = Series(driver)
    assert page.is_download_status_displayed()

    # 2
    go_to_season(driver, ep.season)
    assert page.is_download_status_displayed()

    # 3
    page.click_on_dl_ep_button(ep.ep_name)
    assert page.is_sub_inactive_header_displayed()

    page.click_on_sub_inactive_ok_button()

    # 3
    go_to_episode(driver, ep.ep_name)
    page = Episode(driver)
    assert page.is_download_status_displayed()

    # 4
    page.click_on_download_button()
    assert page.is_sub_inactive_header_displayed()

    page.click_on_sub_inactive_ok_button()

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C7482945")
def test_no_downloadable_movie_seen_in_kids(driver, user_playback,
                                            downloadable_movie_kids):
    """ TD in the kids-locked mode
    Checks:
    #1: Navigating to Movie asset in kids locked mode will not show
        it as downloadable
    """
    movie = downloadable_movie_kids

    page = login(driver, user_playback.email, user_playback.password,
                 go_to_section=Section.KIDS)
    page.click_on_search_button()
    search_and_enter(driver, movie.title, from_page=Kids)

    page = Movie(driver)
    assert not page.is_download_status_displayed(1)

    exit_kids(driver, from_page=Movie)

    page = logout(driver)
    assert page.is_login_page()


@pytest.mark.env("prod", "preprod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category("downloadable")
@pytest.mark.id("C7482945")
def test_no_downloadable_ep_seen_in_kids(driver, user_playback,
                                         downloadable_episode_kids):
    """ TD in the kids-locked mode
    Checks:
    #1: Navigating to Series in kids locked mode will not show
        it as downloadable
    #2: Navigating into Season page will also not show downloadable
    #3: Download button will not be seen next to dl'able episodes
    """
    ep = downloadable_episode_kids

    page = login(driver, user_playback.email, user_playback.password,
                 go_to_section=Section.KIDS)
    page.click_on_search_button()
    search_and_enter(driver, ep.title)

    # 1
    page = Series(driver)
    assert not page.is_download_status_displayed(0)

    # 2
    go_to_season(driver, ep.season)
    assert not page.is_download_status_displayed(0)

    # 3 - Android only
    go_to_episode(driver, ep.ep_name, enter=False)
    if cm.platform == MobilePlatform.Android:
        assert not page.is_ep_dl_button_displayed(ep.ep_name, 0)

    exit_kids(driver, from_page=Series)

    page = logout(driver)
    assert page.is_login_page()
