import pytest

from apps.hbonmobile.pages.login_page import Login


@pytest.mark.env("preprod", "prod")
@pytest.mark.platform("android", "ios")
@pytest.mark.category()
@pytest.mark.id("C1462143", "C1524456")
def test_splash_view(driver):
    """ Splash View
    Checks:
    #1 That we start in Login page with an app without cached data
    """
    page = Login(driver)
    assert page.is_login_page()
