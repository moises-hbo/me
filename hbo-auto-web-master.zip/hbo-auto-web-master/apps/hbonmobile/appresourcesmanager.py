import json
from pathlib import Path


class AppResourcesManager(object):

    @classmethod
    def get_app_activity(cls, app_id):
        with open(Path("apps/hbonmobile/apps.json"), "r", encoding="utf-8") \
                as f:
            apps_file = json.load(f)
            apps = []
            for app_activity in apps_file["android_apps"]:
                apps.append(app_activity)
                if app_activity["id"].lower() == app_id.lower():
                    return cls.get_app_activity_resource_instance(app_activity)

        raise NameError(f"App with id {app_id} wasn't found in file!")

    @staticmethod
    def get_app_activity_resource_instance(resource):
        return AppActivity(resource["id"], resource["app"],
                           resource["activity"])


class AppActivity(object):
    def __init__(self, id, app, activity):
        self.id = id
        self.app = app
        self.activity = activity
