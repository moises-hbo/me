from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.navigation_partial import Navigation

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class SearchAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.search_input = {"locator": "com.hbo.android.app:id/search",
                             "type": MobileBy.ID}
        self.search_results_list = {"locator": "com.hbo.android.app:id/item",
                                    "type": MobileBy.ID}


class SearchiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.search_input = {"locator": "Search.TextField",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.search_results_list = {
            "locator": "//XCUIElementTypeCell[@name='Search.SearchItem']",
            "type": MobileBy.XPATH}


class Search(Navigation, SearchAndroid, SearchiOS):
    def __init__(self, driver):
        Navigation.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            SearchAndroid.__init__(self, driver)
        elif platform == "ios":
            SearchiOS.__init__(self, driver)

    def is_search_page(self, timeout=5):
        return self.helper.is_visible(self.search_input, timeout)

    def enter_text_on_search(self, text, timeout=10):
        self.helper.input_text(
            self.search_input.get("locator"), text, timeout,
            self.search_input.get("type"))

    def clear_text_on_search(self, timeout=5):
        self.helper.clear_text(self.search_input, timeout)

    def click_on_search_result(self, index, timeout=10):
        search_result = self.get_search_results_list(timeout)[index]
        self.helper.click(search_result)

    def get_search_results_list(self, timeout=10):
        return self.helper.get_list(
            self.search_results_list.get("locator"), timeout,
            self.search_results_list.get("type"))
