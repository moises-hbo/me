from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class ErrorAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.error_image = {"locator": "com.hbo.android.app:id/error_image",
                            "type": MobileBy.ID}
        self.logo_image = {"locator": "com.hbo.android.app:id/logo",
                           "type": MobileBy.ID}
        self.error_title = {"locator": "com.hbo.android.app:id/error_title",
                            "type": MobileBy.ID}
        self.error_message = {
            "locator": "com.hbo.android.app:id/error_message",
            "type": MobileBy.ID}
        self.retry_button = {"locator": "com.hbo.android.app:id/error_retry",
                             "type": MobileBy.ID}

    def is_error_image_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.error_image.get("locator"), timeout,
            self.error_image.get("type"))

    def is_logo_image_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.logo_image.get("locator"), timeout,
            self.logo_image.get("type"))

    def is_error_title_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.error_title.get("locator"), timeout,
            self.error_title.get("type"))


class ErroriOS(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.error_image = {"locator": "imageErrorMain",
                            "type": MobileBy.ACCESSIBILITY_ID}
        self.logo_image = {"locator": "logo",
                           "type": MobileBy.ACCESSIBILITY_ID}
        self.error_title = {"locator": "Out of Region",
                            "type": MobileBy.ACCESSIBILITY_ID}
        self.error_message = {
            "locator": "//XCUIElementTypeStaticText"
            "[contains(@name, 'Sorry,')]",
            "type": MobileBy.XPATH}
        self.retry_button = {
            "locator": "//XCUIElementTypeButton[@name='Refresh']",
            "type": MobileBy.XPATH}

    def is_error_image_displayed(self, timeout=10):
        # Invisible
        return self.helper.get(
            self.error_image.get("locator"), timeout,
            self.error_image.get("type"))

    def is_logo_image_displayed(self, timeout=10):
        # Invisible
        return self.helper.get(
            self.logo_image.get("locator"), timeout,
            self.logo_image.get("type"))


class Error(ErrorAndroid, ErroriOS):
    def __init__(self, driver):
        platform = cm.platform
        if platform == "android":
            ErrorAndroid.__init__(self, driver)
        elif platform == "ios":
            ErroriOS.__init__(self, driver)

    def is_error_message_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.error_message.get("locator"), timeout,
            self.error_message.get("type"))

    def is_retry_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.retry_button.get("locator"), timeout,
            self.retry_button.get("type"))

    def is_geoblocking_page_displayed(self):
        return self.is_error_image_displayed() and \
            self.is_error_message_displayed() and \
            self.is_error_title_displayed() and \
            self.is_logo_image_displayed() and \
            self.is_retry_button_displayed()
