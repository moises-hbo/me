from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager
from helpers.enums import SwipeDirection

cm = ConfigManager()


class NavigationAndroid(Page):
    """Partial page containing upper part (Chromecast, Lock icons etc)
    and lower part (the navigation part)
    """

    def __init__(self, driver):
        Page.__init__(self, driver)
        self.header = {
            "locator": "//android.view.ViewGroup"
            "[@resource-id='com.hbo.android.app:id/toolbar']"
            "/android.widget.TextView",
            "type": MobileBy.XPATH}
        self.home_button = {"locator": "Home",
                            "type": MobileBy.ACCESSIBILITY_ID}
        self.kids_button = dict(locator="Toonix Kids", locator_es="Kids",
                                type=MobileBy.ACCESSIBILITY_ID)
        self.watchlist_button = {
            "locator": "Watchlist", "type": MobileBy.ACCESSIBILITY_ID}
        self.search_button = {"locator": "Search",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.downloads_button = dict(locator="Downloads",
                                     type=MobileBy.ACCESSIBILITY_ID)
        self.chromecast_icon_disconnected = {
            "locator": "Cast button. Disconnected",
            "type": MobileBy.ACCESSIBILITY_ID}
        # Chromecast
        self.got_it_button = {
            "locator": "com.hbo.android.app:id/got_it_button",
            "type": MobileBy.ID}
        self.chromecast_intro_layer = {
            "locator": "com.hbo.android.app:id/intro_frame",
            "type": MobileBy.ID}
        self.chromecast_intro_description = {
            "locator": "com.hbo.android.app:id/tv_lock_intro",
            "type": MobileBy.ID}
        self.carousel_list = {
            "locator": "com.hbo.android.app:id/carousel_list",
            "type": MobileBy.ID}
        self.carousel_scroll_indicator = {
            "locator": "com.hbo.android.app:id/carousel_scroll_indicator",
            "type": MobileBy.ID}
        self.carousel_series_list = {
            "locator": "com.hbo.android.app:id/list",
            "type": MobileBy.ID}
        self.top_item_on_page = {
            "locator": "//androidx.recyclerview.widget.RecyclerView",
            "type": MobileBy.ID}
        self.shelves = {
            "locator": "//androidx.recyclerview.widget.RecyclerView"
            "[@resource-id='com.hbo.android.app:id/list']",
            "type": MobileBy.XPATH}
        self.error = {
            "locator": "com.hbo.android.app:id/snackbar_text",
            "type": MobileBy.ID}

    def is_shelf_title_displayed(self, text):
        locator = f"//android.widget.TextView[@text='{text}']"
        self.driver.helper.swipe_until_found_element(
            locator, 15,
            SwipeDirection.Up)
        return self.helper.is_visible(locator, locator_type=MobileBy.XPATH)

    def is_home_button_selected(self, timeout=10):
        return self.helper.is_selected(self.home_button.get("locator"),
                                       timeout,
                                       self.home_button.get("type"))

    def is_kids_button_selected(self, timeout=10):
        return self.helper.is_selected(self.kids_button.get("locator"),
                                       timeout,
                                       self.kids_button.get("type"))

    def is_watchlist_button_selected(self, timeout=10):
        return self.helper.is_selected(
            self.watchlist_button.get("locator"), timeout,
            self.watchlist_button.get("type"))

    def is_search_button_selected(self, timeout=10):
        return self.helper.is_selected(self.search_button.get("locator"),
                                       timeout,
                                       self.search_button.get("type"))

    def is_kids_button_displayed(self, timeout=10):
        locator = self.kids_button.get("locator_es") if cm.region == "spain" \
            else self.kids_button.get("locator")
        return self.helper.is_visible(locator, timeout,
                                      self.kids_button.get("type"))

    def is_kids_lock_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.kids_lock_button.get("locator"), timeout,
            self.kids_lock_button.get("type"))

    def is_carousel_list_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.carousel_list.get("locator"), timeout,
            self.carousel_list.get("type"))

    def is_carousel_series_list_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.carousel_series_list.get("locator"), timeout,
            self.carousel_series_list.get("type"))

    def is_error_displayed(self, timeout=8):
        return self.helper.is_visible(self.error, timeout)

    def click_on_kids_button(self, timeout=10):
        locator = self.kids_button.get("locator_es") if cm.region == "spain" \
            else self.kids_button.get("locator")
        self.helper.click(locator, timeout, self.kids_button.get("type"))

    def get_header_text(self, timeout=10):
        return self.helper.get_text(self.header.get("locator"), timeout,
                                    self.header.get("type"))

    def get_top_element_id(self, timeout=10):
        _list = self.helper.get_list(self.top_item_on_page.get("locator"))
        return self.helper.get_attribute(_list[1], "resourceId")

    def get_assets_of_shelf(self, shelf_index, timeout=10, swipes=3):
        for i in range(swipes):
            try:
                shelf = self.get_shelves(timeout)[shelf_index]
                return shelf.find_elements_by_id(
                    "com.hbo.android.app:id/content")
            except IndexError:
                self.driver.helper.swipe()
        raise IndexError


class NavigationiOS(Page):
    """Partial page containing upper part (Chromecast, Lock icons etc)
    and lower part (the navigation section)
    """

    def __init__(self, driver):
        Page.__init__(self, driver)
        self.home_button = {"locator": "Navbar.Home",
                            "type": MobileBy.ACCESSIBILITY_ID}
        self.kids_button = {"locator": "Navbar.Family",
                            "type": MobileBy.ACCESSIBILITY_ID}
        self.watchlist_button = {
            "locator": "Navbar.Watchlist", "type": MobileBy.ACCESSIBILITY_ID}
        self.search_button = {"locator": "Navbar.Search",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.downloads_button = {"locator": "Downloads",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.hbon_logo_img = {"locator": "HBON_logo",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.hboe_logo_img = {"locator": "HBOE_logo",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.toonix_logo_img = {
            "locator": "logoToonixNav", "type": MobileBy.ACCESSIBILITY_ID}
        # Both Chromecast and Kids popup
        self.chromecast_icon_disconnected = {"locator": "GCKUICastButton",
                                             "type": MobileBy.ACCESSIBILITY_ID}
        self.got_it_button = {"locator": "Got it",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.kids_lock_intro_text = {
            "locator": "//XCUIElementTypeStaticText"
            "[contains(@name, 'In the Toonix section')]",
            "type": MobileBy.XPATH}
        # TODO: WOW BAD XPATH
        self.chromecast_intro_layer = dict(
            locator="//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther[1]/XCUIElementTypeOther[3]",
            type=MobileBy.XPATH)
        self.chromecast_intro_description = {
            "locator": "//XCUIElementTypeStaticText[contains(@name, 'TV')]",
            "type": MobileBy.XPATH}
        # TODO: there's not a single unique XPATH to find for carousel
        # It will always match with a shelf if scrolled further down
        self.carousel_list = {
            "locator": "//XCUIElementTypeCollectionView/XCUIElementTypeCell"
            "/XCUIElementTypeOther/XCUIElementTypeCollectionView",
            "type": MobileBy.XPATH}
        self.carousel_scroll_indicator = {
            "locator": "(//XCUIElementTypeProgressIndicator"
            "[@name='Progress'])[1]",
            "type": MobileBy.XPATH}
        # TODO: holy sheet
        self.home_items_container = {
            "locator": "//XCUIElementTypeApplication[@name='HBO']"
            "/XCUIElementTypeWindow[1]/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther[1]/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeCollectionView"
            "/XCUIElementTypeCell",
            "type": MobileBy.XPATH}
        self.shelves = {
            "locator": "//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeCollectionView/XCUIElementTypeCell",
            "type": MobileBy.XPATH}
        self.error_header = dict(
            locator="An Error Occurred",
            type=MobileBy.ACCESSIBILITY_ID)
        self.error_button = dict(
            locator="ConfirmButton", type=MobileBy.ACCESSIBILITY_ID)

    def click_on_error_ok_button(self, timeout=5):
        self.helper.click(self.error_button, timeout)

    def is_shelf_title_displayed(self, text):
        self.driver.helper.swipe_until_found_element(
            text, direction=SwipeDirection.Up,
            locator_type=MobileBy.ACCESSIBILITY_ID)
        # One more to be safe (needed sometimes)
        if not self.helper.is_visible(
                text, locator_type=MobileBy.ACCESSIBILITY_ID):
            self.driver.helper.swipe()
        return self.helper.is_visible(
                text, locator_type=MobileBy.ACCESSIBILITY_ID)

    def click_on_kids_button(self, timeout=10):
        self.helper.click(self.kids_button, timeout)

    def is_home_button_selected(self, timeout=10):
        return self.helper.get_attribute(
            self.home_button.get("locator"), "value", timeout,
            self.home_button.get("type")) == "1"

    def is_kids_button_selected(self, timeout=10):
        return self.helper.get_attribute(
            self.kids_button.get("locator"), "value", timeout,
            self.kids_button.get("type")) == "1"

    def is_watchlist_button_selected(self, timeout=10):
        return self.helper.get_attribute(
            self.watchlist_button.get("locator"), "value", timeout,
            self.watchlist_button.get("type")) \
            == "1"

    def is_search_button_selected(self, timeout=10):
        return self.helper.get_attribute(
            self.search_button.get("locator"), "value", timeout,
            self.search_button.get("type")) \
            == "1"

    def is_hbon_logo_displayed(self, timeout=10):
        return self.helper.is_visible(self.hbon_logo_img.get("locator"),
                                      timeout, self.hbon_logo_img.get("type"))

    def is_hboe_logo_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.hboe_logo_img.get("locator"), timeout,
            self.hboe_logo_img.get("type"))

    def is_toonix_logo_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.toonix_logo_img.get("locator"), timeout,
            self.toonix_logo_img.get("type"))

    def is_carousel_list_displayed(self):
        carousel = self.helper.get_list(self.carousel_list.get("locator"))[0]
        return self.helper.is_visible(carousel)

    def is_kids_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.kids_button, timeout)

    def is_error_displayed(self, timeout=8):
        header = self.helper.is_visible(self.error_header, timeout)
        button = self.helper.is_visible(self.error_button, 0)
        return header and button

    def get_text_of_home_button(self, timeout=10):
        return self.helper.get_attribute(
            self.home_button.get("locator"), "label", timeout,
            self.home_button.get("type"))

    def get_text_of_kids_button(self, timeout=10):
        return self.helper.get_attribute(
            self.kids_button.get("locator"), "label", timeout,
            self.kids_button.get("type"))

    def get_top_element_id(self, timeout=10):
        items = self.helper.get_list(
            self.home_items_container.get("locator"), timeout,
            self.home_items_container.get("type"))
        return items[0].find_element_by_xpath(".//XCUIElementTypeOther")

    def get_assets_of_shelf(self, shelf_index, timeout=10):
        shelf = self.get_shelves(timeout)[shelf_index]
        assets = shelf.find_elements_by_xpath(
            ".//XCUIElementTypeCollectionView/XCUIElementTypeCell")
        return assets

    def get_carousel_location(self, timeout=5):
        return self.helper.get_location(
            self.carousel_list.get("locator"), timeout,
            self.carousel_list.get("type"))

    def get_carousel_size(self, timeout=5):
        return self.helper.get_size(
            self.carousel_list.get("locator"), timeout,
            self.carousel_list.get("type"))

    def get_carousel_center(self, timeout=5):
        loc = self.get_carousel_location(timeout)
        size = self.get_carousel_size(timeout)
        x = int((loc["x"] + size["width"]) / 2)
        y = int((loc["y"] + size["height"]) / 2)
        return (x, y)

    def get_carousel_progress_bar_progress(self, timeout=5):
        percent = self.helper.get_attribute(
            self.carousel_scroll_indicator, "value")
        return int(percent.split("%")[0].strip())


class Navigation(NavigationAndroid, NavigationiOS):
    def __init__(self, driver):
        platform = cm.platform
        if platform == "android":
            NavigationAndroid.__init__(self, driver)
            self.nav = NavigationAndroid
        elif platform == "ios":
            NavigationiOS.__init__(self, driver)
            self.nav = NavigationiOS

    def is_home_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.home_button.get("locator"),
                                      timeout, self.home_button.get("type"))

    def is_watchlist_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.watchlist_button.get("locator"), timeout,
            self.watchlist_button.get("type"))

    def is_search_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.search_button.get("locator"),
                                      timeout,
                                      self.search_button.get("type"))

    def is_disconnected_chromecast_icon_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.chromecast_icon_disconnected.get("locator"), timeout,
            self.chromecast_icon_disconnected.get("type"))

    def is_chromecast_intro_description_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.chromecast_intro_description.get("locator"),
            timeout, self.chromecast_intro_description.get("type"))

    def is_chromecast_intro_layer_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.chromecast_intro_layer.get("locator"), timeout,
            self.chromecast_intro_layer.get("type"))

    def is_got_it_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.got_it_button.get("locator"), timeout,
            self.got_it_button.get("type"))

    def is_adult_menu_displayed(self, timeout=10):
        return self.is_home_button_displayed(timeout=timeout) and \
            self.is_kids_button_displayed(timeout=timeout) and \
            self.is_watchlist_button_displayed(timeout=timeout) and \
            self.is_search_button_displayed(timeout=timeout)

    def is_kids_menu_displayed(self, timeout=10):
        return self.is_kids_button_displayed(timeout=timeout) and \
            self.is_search_button_displayed(timeout=timeout) and \
            not self.is_home_button_displayed(timeout=1) and \
            not self.is_watchlist_button_displayed(timeout=1)

    def is_carousel_scroll_indicator_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.carousel_scroll_indicator.get("locator"), timeout,
            self.carousel_scroll_indicator.get("type"))

    def click_on_home_button(self, timeout=10):
        self.helper.click(self.home_button.get("locator"), timeout,
                          self.home_button.get("type"))

    def click_on_watchlist_button(self, timeout=10):
        self.helper.click(self.watchlist_button.get("locator"), timeout,
                          self.watchlist_button.get("type"))

    def click_on_search_button(self, timeout=10):
        self.helper.click(self.search_button.get("locator"), timeout,
                          self.search_button.get("type"))

    def click_on_downloads_button(self, timeout=10):
        self.helper.click(self.downloads_button, timeout)

    def click_on_got_it_button(self, timeout=10):
        self.helper.click(self.got_it_button.get("locator"), timeout,
                          self.got_it_button.get("type"))

    def click_on_asset_in_shelf(self, shelf_index, asset_index, timeout=10):
        asset = self.get_assets_of_shelf(shelf_index, timeout)[asset_index]
        self.helper.click(asset, timeout)

    def get_kids_lock_intro_text(self, timeout=10):
        return self.helper.get_text(
            self.kids_lock_intro_text.get("locator"), timeout,
            self.kids_lock_intro_text.get("type"))

    def get_shelves(self, timeout=10):
        return self.helper.get_list(self.shelves.get("locator"), timeout,
                                    self.shelves.get("type"))

    def get_got_it_buttons(self, timeout=10):
        return self.helper.get_list(self.got_it_button.get("locator"), timeout,
                                    self.got_it_button.get("type"))

    def get_carousel(self, timeout=5):
        return self.helper.get(self.carousel_list.get("locator"), timeout,
                               self.carousel_list.get("type"))

    def get_carousel_progress_bar(self, timeout=5):
        return self.helper.get(
            self.carousel_scroll_indicator.get("locator"), timeout,
            self.carousel_scroll_indicator.get("type"))

    def get_screenshot_of_carousel_progress_bar_base64(self, timeout=10):
        pb = self.get_carousel_progress_bar()
        pbshot = pb.screenshot_as_base64
        return pbshot

    # Delegator method

    def is_shelf_title_displayed(self, shelf_name):
        return self.nav.is_shelf_title_displayed(self, shelf_name)

    def is_home_button_selected(self, timeout=10):
        return self.nav.is_home_button_selected(self, timeout)

    def is_kids_button_selected(self, timeout=10):
        return self.nav.is_kids_button_selected(self, timeout)

    def is_watchlist_button_selected(self, timeout=10):
        return self.nav.is_watchlist_button_selected(self, timeout)

    def is_search_button_selected(self, timeout=10):
        return self.nav.is_search_button_selected(self, timeout=10)

    def is_kids_button_displayed(self, timeout=10):
        return self.nav.is_kids_button_displayed(self, timeout)

    def is_error_displayed(self, timeout=8):
        return self.nav.is_error_displayed(self, timeout)

    def click_on_kids_button(self, timeout=10):
        self.nav.click_on_kids_button(self, timeout)

    def get_assets_of_shelf(self, shelf_index, timeout=10):
        return self.nav.get_assets_of_shelf(self, shelf_index, timeout)

    def get_carousel_progress_bar_progress(self, timeout=5):
        return self.nav.get_carousel_progress_bar_progress(self, timeout)
