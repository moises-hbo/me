from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.navigation_partial import Navigation

from helpers.configmanager import ConfigManager
from helpers.enums import SwipeDirection

cm = ConfigManager()


class KidsAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.exit_kids_button = {
            "locator": "com.hbo.android.app:id/unlock_btn",
            "type": MobileBy.ID}
        self.lock_kids_button = {"locator": "Lock",
                                 "type": MobileBy.ACCESSIBILITY_ID}
        self.recently_watched_shelf_title = {
            "locator": "//android.widget.TextView[@text='RECENTLY WATCHED' "
            "or @text='CONTINUE WATCHING']",
            "type": MobileBy.XPATH}
        self.kids_lock_intro_text = {
            "locator": "com.hbo.android.app:id/tv_lock_intro",
            "type": MobileBy.ID}
        self.kids_lock_button = {
            "locator": "com.hbo.android.app:id/action_lock",
            "type": MobileBy.ID}
        self.kids_lock_overlay_button = self.kids_lock_button


class KidsiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.lock_kids_button = {"locator": "Family.LockButton",
                                 "type": MobileBy.ACCESSIBILITY_ID}
        self.exit_kids_button = {"locator": "Family.UnlockButton",
                                 "type": MobileBy.ACCESSIBILITY_ID}
        self.recently_watched_shelf_title = {"locator": "RECENTLY WATCHED",
                                             "type": MobileBy.ACCESSIBILITY_ID}
        # TODO: Bad XPATH
        self.kids_lock_overlay_button = dict(
            locator="//XCUIElementTypeWindow[1]/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther[2]",
            type=MobileBy.XPATH)


class Kids(Navigation, KidsAndroid, KidsiOS):
    def __init__(self, driver):
        Navigation.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            KidsAndroid.__init__(self, driver)
        elif platform == "ios":
            KidsiOS.__init__(self, driver)

    def is_kids_locked_page(self, timeout=10):
        return self.helper.is_visible(
            self.exit_kids_button.get("locator"), timeout,
            self.exit_kids_button.get("type"))

    def is_kids_unlocked_page(self, timeout=10):
        return self.is_kids_lock_button_displayed(timeout)

    def is_kids_lock_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.lock_kids_button.get("locator"),
                                      timeout,
                                      self.lock_kids_button.get("type"))

    def is_recently_watched_shelf_title_displayed(self, timeout=2, swipes=2):
        for i in range(swipes):
            visible = self.helper.is_visible(
                self.recently_watched_shelf_title.get("locator"),
                timeout, self.recently_watched_shelf_title.get("type"))
            return True if visible else self.driver.helper.swipe()
        return False

    def is_kids_lock_overlay_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.kids_lock_overlay_button.get("locator"), timeout,
            self.kids_lock_overlay_button.get("type"))

    def click_on_lock_kids_button(self, timeout=10):
        self.helper.click(self.lock_kids_button.get("locator"), timeout,
                          self.lock_kids_button.get("type"))

    def click_on_exit_kids_button(self, timeout=10):
        self.helper.click(self.exit_kids_button.get("locator"), timeout,
                          self.exit_kids_button.get("type"))

    def scroll_up_to_carousel(self):
        for _ in range(5):
            self.driver.helper.swipe(SwipeDirection.Down)
        self.driver.helper.swipe_until_found_element(
            self.carousel_list.get("locator"),
            30, SwipeDirection.Down, self.carousel_list.get("type"))
        return self.helper.is_visible(self.carousel_list,
                                      locator_type=MobileBy.ID)
