from appium.webdriver.common.mobileby import MobileBy

from helpers.enums import MobilePlatform
from helpers.pagehelper import PageHelper
from helpers.configmanager import ConfigManager
from helpers.logger import Log

cm = ConfigManager()


class BasePageObjectAndroid(object):
    def __init__(self, driver):
        self.back_button = dict(
            locator="Navigate up", type=MobileBy.ACCESSIBILITY_ID)


class BasePageObjectiOS(object):
    def __init__(self, driver):
        self.back_button = dict(
            locator="Back", type=MobileBy.ACCESSIBILITY_ID)
        self.push_noti_allow = dict(locator="Allow", type=MobileBy.NAME)

    def is_push_noti_allow_button_displayed(self, timeout=5):
        return self.helper.is_visible(
            self.push_noti_allow.get("locator"), timeout,
            self.push_noti_allow.get("type"))

    def click_on_push_noti_allow_button(self, timeout=10):
        self.helper.click(
            self.push_noti_allow.get("locator"), timeout,
            self.push_noti_allow.get("type"))


class BasePageObject(BasePageObjectAndroid, BasePageObjectiOS):
    """Base Page for all other pages to inherit from.
    Holds shared functions used by all, or most.
    """

    def __init__(self, driver):
        self.driver = driver
        self.helper = PageHelper(driver)
        self.ph = self.helper
        self.log = Log()

        if cm.platform == MobilePlatform.Android:
            BasePageObjectAndroid.__init__(self, driver)
        elif cm.platform == MobilePlatform.Ios:
            BasePageObjectiOS.__init__(self, driver)

    def click_on_back_button(self, timeout=5):
        self.helper.click(self.back_button, timeout)
