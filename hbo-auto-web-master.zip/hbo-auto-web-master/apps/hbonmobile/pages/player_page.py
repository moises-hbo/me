from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager
from helpers.sleeper import Sleeper as sleep

from tools.computer import convert_to_seconds

cm = ConfigManager()


class PlayerAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.title = {
            "locator": "//android.view.ViewGroup"
            "[@resource-id='com.hbo.android.app:id/toolbar']"
            "/android.widget.TextView",
            "type": MobileBy.XPATH}
        self.back_button = dict(
            locator="Navigate up", type=MobileBy.ACCESSIBILITY_ID)
        self.playing_view = {
            "locator": "com.hbo.android.app:id/exo_content_frame",
            "type": MobileBy.ID}
        self.play_button = {
            "locator": "Play", "type": MobileBy.ACCESSIBILITY_ID}
        self.pause_button = {
            "locator": "Pause", "type": MobileBy.ACCESSIBILITY_ID}
        self.rewind_10sec_button = {
            "locator": "com.hbo.android.app:id/exo_rew",
            "type": MobileBy.ID}
        self.forward_10sec_button = {
            "locator": "com.hbo.android.app:id/exo_ffwd",
            "type": MobileBy.ID
        }
        self.tracks_button = {"locator": "Tracks",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.time_elapsed = {
            "locator": "com.hbo.android.app:id/exo_position",
            "type": MobileBy.ID}
        self.time_duration = {
            "locator": "com.hbo.android.app:id/exo_duration",
            "type": MobileBy.ID}
        self.progress_bar = {
            "locator": "com.hbo.android.app:id/exo_progress",
            "type": MobileBy.ID}
        # Chainplay
        self.cp_countdown = {"locator": "com.hbo.android.app:id/countdown",
                             "type": MobileBy.ID}
        self.cp_title = {"locator": "com.hbo.android.app:id/title",
                         "type": MobileBy.ID}
        self.cp_season_ep = {"locator": "com.hbo.android.app:id/subtitle",
                             "type": MobileBy.ID}
        self.cp_image = {"locator": "com.hbo.android.app:id/image",
                         "type": MobileBy.ID}
        self.cp_play_button = self.cp_image
        self.cp_playing_view = self.playing_view
        self.cc_button = {
            "locator": "Cast button. Disconnected",
            "type": MobileBy.ACCESSIBILITY_ID}
        self.loading_pulse = {
            "locator": "com.hbo.android.app:id/exo_buffering",
            "type": MobileBy.ID
        }

    def is_player_playing(self, wait=10):
        sleep(wait)
        elapsed = self.get_elapsed_time_in_sec(tap=True)
        for _ in range(5):
            new_elapsed = self.get_elapsed_time_in_sec(tap=True)
            if new_elapsed > elapsed:
                return True
        return False

    def is_player_paused(self):
        if not self.is_player_controls_displayed(0):
            self.click_within_player()
        el1 = self.get_elapsed_time_in_sec()
        sleep(2)
        el2 = self.get_elapsed_time_in_sec()
        return True if el1 == el2 else False

    def is_loading_pulse_displayed(self, timeout=2):
        return self.helper.is_visible(
            self.loading_pulse.get("locator"), timeout,
            self.loading_pulse.get("type"))

    def is_rewind_10sec_button_displayed(self, timeout=5, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.rewind_10sec_button.get("locator"), timeout,
            self.rewind_10sec_button.get("type"))

    def is_forward_10sec_button_displayed(self, timeout=5, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.forward_10sec_button.get("locator"), timeout,
            self.forward_10sec_button.get("type"))

    def click_on_rewind_10sec_button(self, timeout=5, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.click(
            self.rewind_10sec_button.get("locator"), timeout,
            self.rewind_10sec_button.get("type"))

    def click_on_forward_10sec_button(self, timeout=5, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.click(
            self.forward_10sec_button.get("locator"), timeout,
            self.forward_10sec_button.get("type"))

    def get_text_of_elapsed_time(self, timeout=5, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.get_text(self.time_elapsed.get("locator"), timeout,
                                    self.time_elapsed.get("type"))

    def get_elapsed_time_in_sec(self, timeout=5, tap=False):
        return convert_to_seconds(self.get_text_of_elapsed_time(timeout, tap))

    def get_elapsed_time_in_percent(self, timeout=5, tap=False):
        elapsed_text = self.get_text_of_elapsed_time(timeout, tap)
        if tap:
            self.wait_for_controls_to_disappear()
        elapsed_total = self.get_text_of_total_duration_time(timeout, tap)
        return int((
            convert_to_seconds(elapsed_text) / convert_to_seconds(
                elapsed_total)) * 100)

    def get_text_of_total_duration_time(self, timeout=5, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.get_text(self.time_duration.get("locator"), timeout,
                                    self.time_duration.get("type"))

    def get_duration_time_in_sec(self, timeout=5, tap=False):
        return convert_to_seconds(
            self.get_text_of_total_duration_time(timeout, tap))


class PlayeriOS(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.title = {
            "locator": "//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeStaticText",  # Bad xpath
            "type": MobileBy.XPATH}
        self.playing_view = {"locator": "Video",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.play_button = {
            "locator": "//XCUIElementTypeButton[@name='play']",
            "type": MobileBy.XPATH}
        self.pause_button = {
            "locator": "//XCUIElementTypeButton[@name='pause']",
            "type": MobileBy.XPATH}
        self.progress_bar = {
            "locator": "//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeSlider",  # Bad xpath
            "type": MobileBy.XPATH}
        self.back_button = {"locator": "back",
                            "type": MobileBy.ACCESSIBILITY_ID}
        # Chainplay
        self.cp_countdown = dict(
            locator="//XCUIElementTypeStaticText"
            "[contains(@name,'Up next in ')]",  # Bad xpath
            type=MobileBy.XPATH)
        self.cp_title = {
            "locator": "//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeStaticText[1]",  # Bad xpath
            "type": MobileBy.XPATH}
        self.cp_season_ep = {
            "locator": "//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeStaticText[2]",  # Bad xpath
            "type": MobileBy.XPATH}
        self.cp_play_button = {"locator": "Play Next Video",
                               "type": MobileBy.ACCESSIBILITY_ID}
        self.cp_back_button = self.back_button
        self.cp_playing_view = {"locator": "Current Video",
                                "type": MobileBy.ACCESSIBILITY_ID}

    def is_player_playing(self, wait=10):
        sleep(wait)
        elapsed = self.get_elapsed_time_in_percent(tap=True)
        for _ in range(5):
            new_elapsed = self.get_elapsed_time_in_percent(tap=True)
            if new_elapsed > elapsed:
                return True
            sleep(wait)
        return False

    def get_text_of_progress_bar(self, timeout=5, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.get_attribute(
            self.progress_bar.get("locator"), "value",
            timeout, self.progress_bar.get("type"))

    def get_elapsed_time_in_percent(self, timeout=5, tap=False):
        return int(self.get_text_of_progress_bar(timeout, tap)
                   .replace("%", ""))


class Player(PlayerAndroid, PlayeriOS):
    def __init__(self, driver):
        platform = cm.platform
        if platform == "android":
            PlayerAndroid.__init__(self, driver)
            self.player = PlayerAndroid
        elif platform == "ios":
            PlayeriOS.__init__(self, driver)
            self.player = PlayeriOS

    def is_player_page(self, timeout=10):
        return self.is_playing_view_displayed()

    def is_back_button_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.back_button.get("locator"), timeout,
            self.back_button.get("type"))

    def click_on_play_button(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        self.helper.click(self.play_button.get("locator"),
                          timeout, self.play_button.get("type"))

    def click_on_pause_button(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        self.helper.click(self.pause_button.get("locator"),
                          timeout, self.pause_button.get("type"))

    def click_on_back_button(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        self.helper.click(self.back_button, timeout)

    def click_within_player(self):
        x, y = self.driver.helper.get_window_center()
        # offsetting to avoid clicking play/pause button
        x = (x - 250) if (x - 250) > 50 else 50
        y = (y - 250) if (y - 250) > 50 else 50
        self.driver.helper.tap_on_screen([(x, y)])

    def click_on_cp_play_button(self, timeout=10):
        self.helper.click(self.cp_play_button.get("locator"), timeout,
                          self.cp_play_button.get("type"))

    def click_on_cp_back_button(self, timeout=5):
        self.helper.click(self.cp_back_button.get("locator"), timeout,
                          self.cp_back_button.get("type"))

    def click_on_cp_playing_view(self, timeout=5):
        self.helper.click(self.cp_playing_view.get("locator"), timeout,
                          self.cp_playing_view.get("type"))

    def click_and_drag_on_progress_bar(self, percent, timeout=2, tap=False):
        if tap:
            self.make_controls_appear()
        pb = self.helper.get(self.progress_bar)
        pb_loc = self.helper.get_location(pb)
        pb_size = self.helper.get_size(pb)
        start_x, start_y = pb_loc["x"], pb_loc["y"] + (pb_size["height"] / 2)
        pos_x = start_x + (pb_size["width"] * float(f"0.{percent}"))
        self.driver.helper.press_and_drag(pb, (pos_x, start_y))

    def get_text_of_title(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.get_text(self.title.get("locator"), timeout,
                                    self.title.get("type"))

    def get_text_of_cp_title(self, timeout=5):
        return self.helper.get_text(self.cp_title.get("locator"), timeout,
                                    self.cp_title.get("type"))

    def get_text_of_cp_season_ep(self, timeout=5):
        return self.helper.get_text(self.cp_season_ep.get("locator"), timeout,
                                    self.cp_season_ep.get("type"))

    def get_size_of_progress_bar(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.get_size(self.progress_bar.get("locator"), timeout,
                                    self.progress_bar.get("type"))

    def get_size_of_playing_view(self, timeout=10):
        return self.helper.get_size(self.playing_view.get("locator"), timeout,
                                    self.playing_view.get("type"))

    def get_size_of_cp_playing_view(self, timeout=10):
        return self.helper.get_size(self.cp_playing_view.get("locator"),
                                    timeout,
                                    self.cp_playing_view.get("type"))

    def get_cp_countdown_timer(self, timeout=10):
        countdown_text = self.helper.get_text(self.cp_countdown.get("locator"),
                                              timeout,
                                              self.cp_countdown.get("type"))
        for word in countdown_text.split(" "):
            try:
                return int(word)
            except ValueError:
                # log.warning(f"{word} wasn't a number")
                pass

    def is_player_controls_displayed(self, timeout=10, tap=False):
        return self.is_progress_bar_displayed(timeout, tap)

    def is_playing_view_displayed(self, timeout=10):
        return self.helper.is_visible(self.playing_view.get("locator"),
                                      timeout, self.playing_view.get("type"))

    def is_play_button_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.play_button.get("locator"), timeout,
            self.play_button.get("type"))

    def is_pause_button_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.pause_button.get("locator"), timeout,
            self.pause_button.get("type"))

    def is_elapsed_time_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.time_elapsed.get("locator"), timeout,
            self.time_elapsed.get("type"))

    def is_duration_time_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.time_elapsed.get("locator"), timeout,
            self.time_elapsed.get("type"))

    def is_progress_bar_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(self.progress_bar.get("locator"),
                                      timeout, self.progress_bar.get("type"))

    def is_tracks_button_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.tracks_button.get("locator"), timeout,
            self.tracks_button.get("type"))

    def is_cp_countdown_displayed(self, timeout=10):
        return self.helper.is_visible(self.cp_countdown.get("locator"),
                                      timeout, self.cp_countdown.get("type"))

    def is_cp_title_displayed(self, timeout=10):
        return self.helper.is_visible(self.cp_title.get("locator"), timeout,
                                      self.cp_title.get("type"))

    def is_cp_season_ep_displayed(self, timeout=10):
        return self.helper.is_visible(self.cp_season_ep.get("locator"),
                                      timeout,
                                      self.cp_season_ep.get("type"))

    def is_cp_image_displayed(self, timeout=10):
        return self.helper.is_visible(self.cp_image.get("locator"), timeout,
                                      self.cp_image.get("type"))

    def is_cp_play_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.cp_play_button.get("locator"),
                                      timeout,
                                      self.cp_play_button.get("type"))

    def is_cp_back_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.cp_back_button.get("locator"),
                                      timeout,
                                      self.cp_back_button.get("type"))

    def is_cp_countdown_counting_down(self, timeout=1):
        cd = self.get_cp_countdown_timer(timeout)
        sleep(1.5)
        cdn = self.get_cp_countdown_timer(timeout)
        return cdn < cd

    def is_chainplay_displayed(self, timeout=10):
        return self.is_cp_countdown_displayed(timeout)

    def is_chromecast_button_displayed(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        return self.helper.is_visible(
            self.cc_button.get("locator"), timeout, self.cc_button.get("type"))

    def exit_player(self, timeout=10, tap=False):
        if tap:
            self.make_controls_appear()
        self.click_on_back_button(timeout)

    def wait_for_controls_to_disappear(self, timeout=20):
        return self.helper.wait_until_not_visible(
            self.back_button, timeout=timeout)

    def wait_for_controls_to_appear(self, timeout=5):
        return self.helper.wait_until_visible(
            self.back_button, timeout=timeout)

    def wait_for_elapsed_time_in_percent_to_be_over(self, percent, timeout=5):
        while self.get_elapsed_time_in_percent(timeout, tap=True) <= percent:
            sleep(20)
        return self.get_elapsed_time_in_percent(timeout, tap=True) > percent

    def wait_for_chainplay_to_appear(self, timeout=200):
        return self.helper.wait_until_visible(self.cp_countdown,
                                              timeout=timeout)

    def wait_for_player_to_finish(self, timeout=200):
        return self.helper.wait_until_not_visible(
            self.playing_view.get("locator"), self.playing_view.get("type"),
            timeout)

    def make_controls_appear(self):
        for _ in range(5):
            self.wait_for_controls_to_disappear()
            self.click_within_player()
            if self.wait_for_controls_to_appear():
                return True
        return False

    # Delegator methods

    def is_player_playing(self, wait=10):
        return self.player.is_player_playing(self, wait)

    def get_text_of_progress_bar(self, timeout=5, tap=False):
        return self.player.get_text_of_progress_bar(self, timeout, tap)

    def get_elapsed_time_in_percent(self, timeout=5, tap=False):
        return self.player.get_elapsed_time_in_percent(self, timeout, tap)
