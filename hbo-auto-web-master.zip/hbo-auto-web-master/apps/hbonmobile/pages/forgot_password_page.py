from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class ForgotPasswordAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.email_input = {
            "locator": "com.hbo.android.app:id/forgot_password_email",
            "type": MobileBy.ID}
        self.send_email_button = {
            "locator": "//android.widget.Button"
            "[@resource-id='com.hbo.android.app:id/loading_button']",
            "type": MobileBy.XPATH}
        self.back_button = dict(
            locator="Navigate up", type=MobileBy.ACCESSIBILITY_ID)
        self.forgot_password_text = {
            "locator": "com.hbo.android.app:id/forgot_password_message",
            "type": MobileBy.ID}
        self.error_text = {"locator": "com.hbo.android.app:id/textinput_error",
                           "type": MobileBy.ID}

    def is_error_text_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.error_text.get("locator"), timeout,
            self.error_text.get("type"))

    def get_text_of_email_input(self, timeout=10):
        email = self.helper.get_text(
            self.email_input.get("locator"), timeout,
            self.email_input.get("type"))
        return str() if email == "Email" else email


class ForgotPasswordiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.email_input = {"locator": "Email ()",
                            "type": MobileBy.ACCESSIBILITY_ID}
        self.send_email_button = {
            "locator": "SignIn.SignInButton",
            "type": MobileBy.ACCESSIBILITY_ID}
        self.back_button = {
            "locator": "iconadultnavbarclose",
            "type": MobileBy.ACCESSIBILITY_ID}
        self.forgot_password_text = {
            "locator": "ForgotPassword.Message",
            "type": MobileBy.ACCESSIBILITY_ID}
        self.error_text = {
            "locator": "SignIn.EmailError",
            "type": MobileBy.ACCESSIBILITY_ID}

    def is_error_text_displayed(self, timeout=10):
        return self.helper.get(
            self.error_text.get("locator"), timeout,
            self.error_text.get("type"))

    def get_text_of_email_input(self, timeout=10):
        email = self.helper.get_text(
            self.email_input.get("locator"), timeout,
            self.email_input.get("type"))
        return str() if email == self.email_input.get("locator") else email


class ForgotPassword(ForgotPasswordAndroid, ForgotPasswordiOS):
    def __init__(self, driver):
        platform = cm.platform
        if platform == "android":
            ForgotPasswordAndroid.__init__(self, driver)
            self.fp = ForgotPasswordAndroid
        elif platform == "ios":
            ForgotPasswordiOS.__init__(self, driver)
            self.fp = ForgotPasswordiOS

    def is_forgot_password_page(self):
        return self.is_forgot_password_text_displayed() and \
            self.is_email_input_displayed() and \
            self.is_send_email_button_displayed()

    def is_forgot_password_text_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.forgot_password_text.get("locator"), timeout,
            self.forgot_password_text.get("type"))

    def is_email_input_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.email_input.get("locator"), timeout,
            self.email_input.get("type"))

    def is_send_email_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.send_email_button.get("locator"), timeout,
            self.send_email_button.get("type"))

    def click_on_send_email_button(self, timeout=10):
        self.helper.click(
            self.send_email_button.get("locator"), timeout,
            self.send_email_button.get("type"))

    def input_text_on_email_input(self, text, timeout=10):
        self.helper.input_text(
            self.email_input.get("locator"), text, timeout,
            self.email_input.get("type"))

    def clear_text_on_email_input(self, timeout=10):
        self.helper.clear_text(
            self.email_input.get("locator"), timeout,
            self.email_input.get("type"))

    # Delegator methods

    def is_error_text_displayed(self, timeout=10):
        return self.fp.is_error_text_displayed(self, timeout)

    def get_text_of_email_input(self, timeout=10):
        return self.fp.get_text_of_email_input(self, timeout)
