from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.asset_page import Asset

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class MovieAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)


class MovieiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)


class Movie(Asset, MovieAndroid, MovieiOS):
    def __init__(self, driver):
        Asset.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            MovieAndroid.__init__(self, driver)
        elif platform == "ios":
            MovieiOS.__init__(self, driver)

    def is_movie_page(self, timeout=10):  # Can give false positive on episode
        return self.helper.is_visible(
            self.play_button.get("locator"), timeout,
            self.play_button.get("type"))
