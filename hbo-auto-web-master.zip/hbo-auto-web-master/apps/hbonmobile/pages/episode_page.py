from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.asset_page import Asset

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class EpisodeAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.back_button = dict(
            locator="Navigate up", type=MobileBy.ACCESSIBILITY_ID)
        self.view_series_button = dict(
            locator="back_to_series", type=MobileBy.ID)
        self.series_season_ep = dict(
            locator="episode_number", type=MobileBy.ID)


class EpisodeiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.back_button = dict(
            locator="Series", type=MobileBy.ACCESSIBILITY_ID)
        self.view_series_button = dict(
            locator="iconArrowRight", type=MobileBy.ACCESSIBILITY_ID)


class Episode(Asset, EpisodeAndroid, EpisodeiOS):
    def __init__(self, driver):
        Asset.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            EpisodeAndroid.__init__(self, driver)
        elif platform == "ios":
            EpisodeiOS.__init__(self, driver)

    def is_episode_page(self, timeout=10):
        return self.helper.is_visible(
            self.view_series_button.get("locator"),
            timeout, self.view_series_button.get("type"))

    def get_text_of_series_season_ep(self, timeout=5):
        return self.helper.get_text(
            self.series_season_ep.get("locator"), timeout,
            self.series_season_ep.get("type"))
