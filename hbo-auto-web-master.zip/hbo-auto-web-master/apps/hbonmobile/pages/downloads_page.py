from time import time
from selenium.common.exceptions import NoSuchElementException
from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.navigation_partial import Navigation

from helpers.configmanager import ConfigManager
from helpers.sleeper import Sleeper as sleep

cm = ConfigManager()


class DownloadsAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.more_options_button = dict(
            locator="More options",
            type=MobileBy.ACCESSIBILITY_ID)
        self.mo_edit_button = dict(
            locator="//android.widget.LinearLayout[1]"
            "/android.widget.LinearLayout/android.widget.RelativeLayout"
            "/android.widget.TextView",
            type=MobileBy.XPATH)
        self.done_button = dict(
            locator="action_done", type=MobileBy.ID)
        self.dl_assets_list = dict(locator="root", type=MobileBy.ID)
        # Empty downloads
        self.dl_home_button = dict(
            locator="empty_downloads_btn", type=MobileBy.ID)

    def get_assets_title_list(self, timeout=5):
        assets = self.get_assets_list(timeout)
        return [self.helper.get_text(x.find_element_by_xpath(
                "//android.widget.TextView"
                "[@resource-id='com.hbo.android.app:id/title']"))
                for x in assets]

    def get_asset(self, asset, timeout=5):
        assets = self.get_assets_list(timeout)
        for a in assets:
            title = a.find_element_by_xpath(
                "//android.widget.TextView"
                "[@resource-id='com.hbo.android.app:id/title']")
            if asset.title == self.helper.get_text(title):
                return a
        raise NoSuchElementException(
            f"Asset with title {asset.title} not found!")

    def click_on_more_options_button(self, timeout=3):
        self.helper.click(self.more_options_button, timeout)

    def click_on_edit_button(self, timeout=3):
        self.helper.click(self.mo_edit_button, timeout)

    def click_on_done_button(self, timeout=3):
        self.helper.click(self.done_button, timeout)

    def click_on_play_button(self, asset, timeout=5):
        a = self.get_asset(asset, timeout)
        self.helper.click(a.find_element_by_id("play_button"))

    def is_more_options_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.more_options_button, timeout)

    def is_done_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.done_button, timeout)

    def is_progress_bar_displayed(self, asset, timeout=5):
        a = self.get_asset(asset, timeout)
        progress_bar = a.find_element_by_id("bookmark")
        return self.helper.is_visible(progress_bar)

    def delete_asset(self, asset, timeout=3, done=True):
        if self.is_more_options_button_displayed(timeout):
            self.click_on_more_options_button()
            self.click_on_edit_button()
        a = self.get_asset(asset)

        del_btn = a.find_element_by_id("delete_button")
        self.helper.click(del_btn)

        if done and self.is_done_button_displayed(0):
            self.click_on_done_button()

    def are_assets_downloading(self, timeout=5):
        assets = self.get_assets_list(timeout)
        dl_status = list()
        for asset in assets:
            try:
                asset.find_element_by_xpath(
                    "//android.widget.TextView"
                    "[@resource-id='com.hbo.android.app:id"
                    "/download_status']")
                dl_status.append(True)
            except NoSuchElementException:
                dl_status.append(False)
        return True in dl_status


class DownloadsiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.dl_assets_list = dict(
            locator="//XCUIElementTypeTable/XCUIElementTypeCell",
            type=MobileBy.XPATH)
        self.dl_assets_list_downloading = dict(
            locator=self.dl_assets_list["locator"] +
            "/XCUIElementTypeStaticText[3]", type=MobileBy.XPATH)
        self.edit_button = dict(locator="edit", type=MobileBy.ACCESSIBILITY_ID)
        self.done_button = dict(locator="Done", type=MobileBy.ACCESSIBILITY_ID)

    def is_progress_bar_displayed(self, asset, timeout=5):
        a = self.get_asset(asset, timeout)
        progress_bar = a.find_element_by_accessibility_id("Progress")
        return self.helper.is_visible(progress_bar)

    def is_edit_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.edit_button, timeout)

    def get_asset(self, asset, timeout=5):
        assets = self.get_assets_list(timeout)
        for a in assets:
            title = a.find_element_by_xpath("//XCUIElementTypeStaticText[1]")
            if asset.title == self.helper.get_text(title):
                return a
        raise NoSuchElementException(
            f"Asset with title {asset.title} not found!")

    def click_on_play_button(self, asset, timeout=5):
        a = self.get_asset(asset, timeout)
        self.helper.click(a.find_element_by_accessibility_id("play"))

    def click_on_edit_button(self, timeout=5):
        self.helper.click(self.edit_button, timeout)

    def click_on_done_button(self, timeout=5):
        self.helper.click(self.done_button, timeout)

    def are_assets_downloading(self, timeout=5):
        dl_list = self.helper.get_list(
            self.dl_assets_list_downloading, timeout)
        dl_status_list = list()
        for dl_status in dl_list:
            dl_status_list.append(False) if self.helper.get_text(dl_status) \
                == "" else dl_status_list.append(True)
        return True in dl_status_list

    def delete_asset(self, asset, timeout=3, done=True):
        if self.is_edit_button_displayed(timeout):
            self.click_on_edit_button(timeout)
        a = self.get_asset(asset, timeout)

        del_btn = a.find_element_by_xpath("//XCUIElementTypeButton[1]")
        self.helper.click(del_btn)

        confirm_del_btn = a.find_element_by_xpath("XCUIElementTypeButton[3]")
        self.helper.click(confirm_del_btn)

        if done:
            self.click_on_done_button(timeout)


class Downloads(Navigation, DownloadsAndroid, DownloadsiOS):
    def __init__(self, driver):
        Navigation.__init__(self, driver)
        if cm.platform == "android":
            DownloadsAndroid.__init__(self, driver)
            self.downloads = DownloadsAndroid
        elif cm.platform == "ios":
            DownloadsiOS.__init__(self, driver)
            self.downloads = DownloadsiOS

    def click_on_home_in_downloads_button(self, timeout=5):
        self.helper.click(self.dl_home_button, timeout)

    def get_assets_list(self, timeout=5):
        return self.helper.get_list(self.dl_assets_list, timeout)

    def wait_for_asset_downloads_to_complete(self, timeout=1000):
        then = time()
        while self.are_assets_downloading():
            if time() - then >= timeout:
                return False
            sleep(30)
        return True

    # Delegator methods
    def is_progress_bar_displayed(self, asset, timeout=5):
        return self.downloads.is_progress_bar_displayed(self, asset, timeout)

    def get_asset(self, asset, timeout=5):
        return self.downloads.get_asset(self, asset, timeout)

    def click_on_play_button(self, timeout=5):
        self.downloads.click_on_play_button(self, timeout)

    def click_on_edit_button(self, timeout=5):
        self.downloads.click_on_edit_button(self, timeout)

    def are_assets_downloading(self, timeout=5):
        return self.downloads.are_assets_downloading(self, timeout)

    def delete_asset(self, asset, timeout=2, done=True):
        self.downloads.delete_asset(self, asset, timeout, done)
