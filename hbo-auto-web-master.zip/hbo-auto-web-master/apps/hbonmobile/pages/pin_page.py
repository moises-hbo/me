from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class PinAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.set_pin_title = {
            "locator": "com.hbo.android.app:id/pin_onboarding_title",
            "type": MobileBy.ID}
        self.set_pin_button = {
            "locator": "com.hbo.android.app:id/pin_onboarding_set_pin_btn",
            "type": MobileBy.ID}
        self.maybe_later_button = {
            "locator": "com.hbo.android.app:id/pin_onboarding_later_btn",
            "type": MobileBy.ID}
        self.dont_ask_me_again_button = {
            "locator": "com.hbo.android.app:id/pin_onboarding_skip_btn",
            "type": MobileBy.ID}
        self.pin_number_0 = {"locator": "com.hbo.android.app:id/key_0",
                             "type": MobileBy.ID}
        self.pin_number_1 = {"locator": "com.hbo.android.app:id/key_1",
                             "type": MobileBy.ID}
        self.pin_number_2 = {"locator": "com.hbo.android.app:id/key_2",
                             "type": MobileBy.ID}
        self.pin_number_3 = {"locator": "com.hbo.android.app:id/key_3",
                             "type": MobileBy.ID}
        self.pin_number_4 = {"locator": "com.hbo.android.app:id/key_4",
                             "type": MobileBy.ID}
        self.pin_number_5 = {"locator": "com.hbo.android.app:id/key_5",
                             "type": MobileBy.ID}
        self.pin_number_6 = {"locator": "com.hbo.android.app:id/key_6",
                             "type": MobileBy.ID}
        self.pin_number_7 = {"locator": "com.hbo.android.app:id/key_7",
                             "type": MobileBy.ID}
        self.pin_number_8 = {"locator": "com.hbo.android.app:id/key_8",
                             "type": MobileBy.ID}
        self.pin_number_9 = {"locator": "com.hbo.android.app:id/key_9",
                             "type": MobileBy.ID}
        self.pin_del = {"locator": "Delete", "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_close_button = {"locator": "", "type": MobileBy.ID}
        self.pin_entry = {"locator": "com.hbo.android.app:id/pin_entry",
                          "type": MobileBy.ID}
        self.forgot_pin_button = {
            "locator": "com.hbo.android.app:id/forgot_pin_button",
            "type": MobileBy.ID}
        self.fp_password_input = {
            "locator": "com.hbo.android.app:id/forgot_pin_password",
            "type": MobileBy.ID}
        self.fp_continue_button = {
            "locator": "//android.widget.FrameLayout/"
            "android.widget.Button[@resource-id='com.hbo.android.app:id"
            "/loading_button']",
            "type": MobileBy.XPATH}
        self.pin_doesnt_match_error = {
            "locator": "com.hbo.android.app:id/snackbar_text",
            "type": MobileBy.ID}


class PiniOS(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.set_pin_title = {"locator": "PINSetupPrompt.title",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.maybe_later_button = {"locator":
                                   "PINSetupPrompt.button.maybeLater",
                                   "type": MobileBy.ACCESSIBILITY_ID}
        self.dont_ask_me_again_button = {"locator":
                                         "PINSetupPrompt.button.dontAskAgain",
                                         "type": MobileBy.ACCESSIBILITY_ID}
        self.set_pin_button = {"locator": "SET PIN CODE",
                               "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_0 = {"locator": "PinPad.button.0",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_1 = {"locator": "PinPad.button.1",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_2 = {"locator": "PinPad.button.2",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_3 = {"locator": "PinPad.button.3",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_4 = {"locator": "PinPad.button.4",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_5 = {"locator": "PinPad.button.5",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_6 = {"locator": "PinPad.button.6",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_7 = {"locator": "PinPad.button.7",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_8 = {"locator": "PinPad.button.8",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_number_9 = {"locator": "PinPad.button.9",
                             "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_del = {"locator": "PinPad.button.backspace",
                        "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_back_button = {"locator": "PINSetupEntry.button.back",
                                "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_close_button = {"locator": "PINEntry.close",
                                 "type": MobileBy.ACCESSIBILITY_ID}
        self.forgot_pin_button = {"locator": "PINEntry.forgotPIN",
                                  "type": MobileBy.ACCESSIBILITY_ID}
        self.fp_password_input = {"locator": "Password ()",
                                  "type": MobileBy.ACCESSIBILITY_ID}
        self.fp_continue_button = {"locator": "CONTINUE",
                                   "type": MobileBy.ACCESSIBILITY_ID}
        self.pin_doesnt_match_error = dict(locator="PIN codes did not match",
                                           type=MobileBy.ACCESSIBILITY_ID)

    def click_on_pin_back_button(self, timeout=10):
        self.helper.click(
            self.pin_back_button.get("locator"), timeout,
            self.pin_back_button.get("type"))

    def wait_until_pin_back_button_is_visible(self, timeout=5):
        return self.helper.wait_until_visible(
            self.pin_back_button, timeout=timeout)


class Pin(PinAndroid, PiniOS):
    def __init__(self, driver):
        platform = cm.platform
        if platform == "android":
            PinAndroid.__init__(self, driver)
            self.pin = PinAndroid
        elif platform == "ios":
            PiniOS.__init__(self, driver)
            self.pin = PiniOS

    def is_pin_page(self, timeout=10):
        return self.is_set_pin_code_title_displayed(timeout)

    def is_set_pin_code_title_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.set_pin_title.get("locator"), timeout,
            self.set_pin_title.get("type"))

    def is_set_pin_code_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.set_pin_button.get("locator"),
            timeout, self.set_pin_button.get("type"))

    def is_maybe_later_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.maybe_later_button.get("locator"),
            timeout, self.maybe_later_button.get("type"))

    def is_dont_ask_me_again_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.dont_ask_me_again_button.get("locator"),
            timeout, self.dont_ask_me_again_button.get("type"))

    def is_pin_doesnt_match_visible(self, timeout=4):
        return self.helper.is_visible(
            self.pin_doesnt_match_error.get("locator"),
            timeout, self.pin_doesnt_match_error.get("type"))

    def click_on_set_pin_button(self, timeout=10):
        self.helper.click(
            self.set_pin_button.get("locator"), timeout,
            self.set_pin_button.get("type"))

    def click_on_maybe_later_button(self, timeout=10):
        self.helper.click(
            self.maybe_later_button.get("locator"), timeout,
            self.maybe_later_button.get("type"))

    def click_on_dont_ask_me_again_button(self, timeout=10):
        self.helper.click(
            self.dont_ask_me_again_button.get("locator"), timeout,
            self.dont_ask_me_again_button.get("type"))

    def click_on_pin_nr_1(self, timeout=10):
        self.helper.click(
            self.pin_number_1.get("locator"), timeout,
            self.pin_number_1.get("type"))

    def click_on_pin_nr_2(self, timeout=10):
        self.helper.click(
            self.pin_number_2.get("locator"), timeout,
            self.pin_number_2.get("type"))

    def click_on_pin_nr_3(self, timeout=10):
        self.helper.click(
            self.pin_number_3.get("locator"), timeout,
            self.pin_number_3.get("type"))

    def click_on_pin_nr_4(self, timeout=10):
        self.helper.click(
            self.pin_number_4.get("locator"), timeout,
            self.pin_number_4.get("type"))

    def click_on_pin_nr_5(self, timeout=10):
        self.helper.click(
            self.pin_number_5.get("locator"), timeout,
            self.pin_number_5.get("type"))

    def click_on_pin_nr_6(self, timeout=10):
        self.helper.click(
            self.pin_number_6.get("locator"), timeout,
            self.pin_number_6.get("type"))

    def click_on_pin_nr_7(self, timeout=10):
        self.helper.click(
            self.pin_number_7.get("locator"), timeout,
            self.pin_number_7.get("type"))

    def click_on_pin_nr_8(self, timeout=10):
        self.helper.click(
            self.pin_number_8.get("locator"), timeout,
            self.pin_number_8.get("type"))

    def click_on_pin_nr_9(self, timeout=10):
        self.helper.click(
            self.pin_number_9.get("locator"), timeout,
            self.pin_number_9.get("type"))

    def click_on_pin_del(self, timeout=10):
        self.helper.click(
            self.pin_del.get("locator"), timeout,
            self.pin_del.get("type"))

    def click_on_forgot_pin_button(self, timeout=10):
        self.helper.click(
            self.forgot_pin_button.get("locator"), timeout,
            self.forgot_pin_button.get("type"))

    def click_on_forgot_pin_continue_button(self, timeout=10):
        self.helper.click(
            self.fp_continue_button.get("locator"), timeout,
            self.fp_continue_button.get("type"))

    def enter_text_on_forgot_pin_entry(self, password, timeout=10):
        self.helper.input_text(
            self.fp_password_input.get("locator"), password, timeout,
            self.fp_password_input.get("type"))

    def get_text_of_pin_doesnt_match_error(self, timeout=10):
        return self.helper.get_text(
            self.pin_doesnt_match_error.get("locator"), timeout,
            self.pin_doesnt_match_error.get("type"))

    def click_on_pin_close_button(self, timeout=10):
        self.helper.click(
            self.pin_close_button.get("locator"), timeout,
            self.pin_close_button.get("type"))

    def wait_until_pin_numbers_are_visible(self, timeout=5):
        return self.helper.wait_until_visible(
            self.pin_number_1, timeout=timeout)
