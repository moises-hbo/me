from helpers.sleeper import Sleeper as sleep
from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.navigation_partial import Navigation

from helpers.configmanager import ConfigManager
from helpers.enums import SwipeDirection

cm = ConfigManager()


class HomeAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.toolbar = {"locator": "com.hbo.android.app:id/toolbar",
                        "type": MobileBy.ID}
        self.content = {"locator": "com.hbo.android.app:id/content",
                        "type": MobileBy.ID}
        self.home_bar = {"locator": "com.hbo.android.app:id/home_bar",
                         "type": MobileBy.ID}
        self.more_options_button = {"locator": "More options",
                                    "type": MobileBy.ACCESSIBILITY_ID}
        self.more_options_sign_out_button = {
            "locator": "//android.widget.RelativeLayout"
            "/android.widget.TextView"
            "[@resource-id='com.hbo.android.app:id/title']",
            "type": MobileBy.XPATH}
        self.confirm_sign_out_button = {"locator": "android:id/button1",
                                        "type": MobileBy.ID}
        self.confirm_sign_out_account = dict(locator="account",
                                             type=MobileBy.ID)
        self.confirm_sign_out_text = dict(locator="sign_out_body",
                                          type=MobileBy.ID)
        self.cancel_sign_out_button = {"locator": "android:id/button2",
                                       "type": MobileBy.ID}

    def is_home_page(self, timeout=10):
        """Check to see if we're on this page"""
        return self.is_more_options_button_displayed(timeout=timeout)

    def is_toolbar_displayed(self, timeout=10):
        return self.helper.is_visible(self.toolbar.get("locator"), timeout,
                                      self.toolbar.get("type"))

    def is_content_displayed(self, timeout=10):
        return self.helper.is_visible(self.content.get("locator"), timeout,
                                      self.content.get("type"))

    def is_home_bar_displayed(self, timeout=10):
        return self.helper.is_visible(self.home_bar.get("locator"), timeout,
                                      self.home_bar.get("type"))

    def is_more_options_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.more_options_button.get("locator"),
                                      timeout,
                                      self.more_options_button.get("type"))

    def is_more_options_sign_out_button_displayed(self, timeout=3):
        return self.helper.is_visible(
            self.more_options_sign_out_button.get("locator"),
            timeout,
            self.more_options_sign_out_button.get("type"))

    def click_on_more_options_button(self, timeout=10):
        self.helper.click(self.more_options_button.get("locator"), timeout,
                          self.more_options_button.get("type"))

    def click_on_more_options_sign_out_button(self, timeout=10):
        self.helper.click(self.more_options_sign_out_button.get("locator"),
                          timeout,
                          self.more_options_sign_out_button.get("type"))

    def get_confirm_sign_out_acc_text(self, timeout=10):
        return self.helper.get_text(self.confirm_sign_out_account, timeout)

    def get_confirm_sign_out_text(self, timeout=10):
        return self.helper.get_text(self.confirm_sign_out_text, timeout)


class HomeiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.sign_out_button = {
            "locator": "//XCUIElementTypeButton[@name='Home.SignOut']",
            "type": MobileBy.XPATH}
        self.confirm_sign_out_button = {"locator": "ConfirmButton",
                                        "type": MobileBy.ACCESSIBILITY_ID}
        self.cancel_sign_out_button = {"locator": "CancelButton",
                                       "type": MobileBy.ACCESSIBILITY_ID}
        self.confirm_sign_out_account = dict(
            locator="//XCUIElementTypeStaticText[contains(@name,'Account: ')]",
            type=MobileBy.XPATH)
        self.confirm_sign_out_text = dict(
            locator="//XCUIElementTypeStaticText"
            "[contains(@name,'Are you sure?')]",
            type=MobileBy.XPATH)

    def is_home_page(self, timeout=10):
        """Check to see that we're on this page"""
        self.scroll_to_sign_out_button()
        return self.is_sign_out_button_displayed(timeout)

    def scroll_to_sign_out_button(self, no_of_swipes=30):
        self.driver.helper.swipe_until_found_element(
            self.sign_out_button.get("locator"),
            no_of_swipes, SwipeDirection.Up)

    def is_sign_out_button_displayed(self, timeout=10, wait=0):
        sleep(wait)  # If you just scrolled down, and new shelves load
        return self.helper.is_visible(
            self.sign_out_button, timeout)

    def click_on_sign_out_button(self, timeout=10):
        self.helper.click(self.sign_out_button.get("locator"), timeout,
                          self.sign_out_button.get("type"))

    def click_on_cancel_sign_out_button(self, timeout=10):
        self.helper.click(self.cancel_sign_out_button.get("locator"), timeout,
                          self.cancel_sign_out_button.get("type"))

    def get_confirm_sign_out_text(self, timeout=10):
        raise NotImplementedError()


class Home(Navigation, HomeAndroid, HomeiOS):
    def __init__(self, driver):
        Navigation.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            HomeAndroid.__init__(self, driver)
            self.home = HomeAndroid
        elif platform == "ios":
            HomeiOS.__init__(self, driver)
            self.home = HomeiOS

    def is_confirm_sign_out_text_displayed(self, timeout=5):
        return self.helper.is_visible(self.confirm_sign_out_text, timeout)

    def click_on_confirm_sign_out_button(self, timeout=10):
        self.helper.click(self.confirm_sign_out_button.get("locator"), timeout,
                          self.confirm_sign_out_button.get("type"))

    # Delegator methods

    def is_home_page(self, timeout=10):
        return self.home.is_home_page(self, timeout)

    def get_configm_sign_out_acc_text(self, timeout=10):
        return self.home.get_confirm_sign_out_acc_text(self, timeout)

    def get_confirm_sign_out_text(self, email, timeout=10):
        return self.home.get_confirm_sign_out_text(self, timeout)
