from time import time
from pathlib import Path

from appium.webdriver.common.mobileby import MobileBy
from selenium.common.exceptions import NoSuchElementException

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.asset_page import Asset

from helpers.configmanager import ConfigManager
from helpers.sleeper import Sleeper as sleep

from tools.image import ImageOCR

cm = ConfigManager()


class SeriesAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.seasons_list = dict(
            locator_prod="androidx.appcompat.app.a$c",
            locator_pp="androidx.appcompat.app.ActionBar$Tab",
            type=MobileBy.CLASS_NAME)
        self.episodes_list = dict(locator="root", type=MobileBy.ID)
        self.episodes_kids_list = dict(
            locator="//android.view.ViewGroup"
            "[@resource-id='com.hbo.android.app:id/content']",
            type=MobileBy.XPATH)
        self.cw_episode = dict(
            locator="mra", type=MobileBy.ID)
        self.genre_label = dict(locator="genre", type=MobileBy.ID)
        self.download_label = dict(
            locator="download_status", type=MobileBy.ID)

    def click_on_ep(self, ep_name, timeout=10):
        ep = self.get_episode(ep_name, timeout)
        self.helper.click(ep)

    def click_on_dl_ep_button(self, ep_name, timeout=10):
        ep = self.get_episode(ep_name, timeout)
        try:
            ep_dl = ep.find_element_by_id("download_button")
        except NoSuchElementException:
            self.driver.helper.swipe()
            sleep(5)
            ep = self.get_episode(ep_name, timeout)
            ep_dl = ep.find_element_by_id("download_button")
        self.helper.click(ep_dl)
        sleep(1)

    def is_episode_downloading(self, ep_name, path=None, timeout=20):
        # NOTE: 'path' fills no purpose on Android
        then = time()
        while time() - then <= timeout:
            status = self.get_text_of_episode_download_status(ep_name, 0)
            if status is None:
                return None
            if "%" in status:
                return True
            sleep(3)
        return False

    def is_episode_download_complete(self, ep_name, path, timeout=10):
        then, c = time(), 0
        while time() - then <= timeout:
            ss = self.get_screenshot_of_episode_download_button(
                ep_name, str(Path(str(path) + f"/is_complete{c}.png")), 0)
            imgocr = ImageOCR(ss)
            imgocr.convert_to_rgb()
            # Blue color found in dl complete button
            if imgocr.find_color((0, 163, 218)):
                return True
            sleep(1)
        return False

    def is_ep_dl_button_displayed(self, ep_name, timeout=10):
        ep = self.get_episode(ep_name, timeout)
        try:
            ep_dl = ep.find_element_by_id("download_button")
            return self.helper.is_visible(ep_dl)
        except NoSuchElementException:
            self.driver.helper.swipe()
            sleep(5)
            ep = self.get_episode(ep_name, timeout)
            try:
                ep_dl = ep.find_element_by_id("download_button")
                return self.helper.is_visible(ep_dl)
            except NoSuchElementException:
                return False

    def get_episodes_list(self, timeout=5):
        ep_list = self.helper.get_list(self.episodes_list, timeout)
        if ep_list:
            return ep_list
        return self.helper.get_list(self.episodes_kids_list, 0)

    def get_seasons_list(self, timeout=10):
        locator = self.__get_locator(self.seasons_list)
        return self.helper.get_list(locator, timeout)

    def get_episode_by_index(self, index, timeout=10):
        episode = self.get_episodes_list(timeout)[index]
        return self.helper.get(episode)

    def get_episode(self, ep_name, timeout=10, swipes=5):
        for _ in range(swipes):
            episodes = self.get_episodes_list(timeout)
            for i in range(len(episodes)):
                try:
                    ep_title = episodes[i].find_element_by_id("title")
                except NoSuchElementException:
                    continue
                ep_title_txt = self.helper.get_text(ep_title)
                if ep_name in ep_title_txt:
                    return self.get_episode_by_index(i, timeout)
            self.driver.helper.swipe()
            sleep(1)
        raise NoSuchElementException(f"Episode title {ep_name} wasn't found")

    def get_ep_dl_button(self, ep_name, timeout=5, swipes=5):
        ep = self.get_episode(ep_name, timeout, swipes)
        return ep.find_element_by_id("download_button")

    def get_episode_download_status(self, ep_name, timeout=10):
        ep = self.get_episode(ep_name, timeout)
        try:
            dl_status = ep.find_element_by_id("download_status")
        except NoSuchElementException:
            dl_status = None
        return dl_status

    def get_text_of_episode_download_status(self, ep_name, path=None,
                                            timeout=10):
        # NOTE: 'path' fills no purpose on Android
        dl_status = self.get_episode_download_status(ep_name)
        return dl_status if dl_status is None \
            else self.helper.get_text(dl_status)

    def get_episode_download_status_in_percent(self, ep_name, timeout=10):
        text = self.get_text_of_episode_download_status(
            ep_name, timeout)
        if text is None:
            # Assuming done == 100 percent
            return 100
        percent = text.split("%")
        # Assume it's queued if not % found in text == -1
        return int(percent[0]) if len(percent) == 2 else -1

    def get_screenshot_of_episode_download_button_base64(self, ep_name,
                                                         timeout=5):
        dl_btn = self.get_ep_dl_button(ep_name, timeout)
        dl_btn_ss = self.helper.take_screenshot_base64(dl_btn)
        return dl_btn_ss

    def get_screenshot_of_episode_download_button(self, ep_name, filepath,
                                                  timeout=5):
        dl_btn = self.get_ep_dl_button(ep_name, timeout)
        dl_btn_ss = self.helper.take_screenshot(dl_btn, filepath)
        return dl_btn_ss

    def wait_for_episode_download_to_complete(self, ep_name, path,
                                              timeout=1200):
        then = time()
        while self.get_episode_download_status_in_percent(ep_name) <= \
                99:
            if time() - then > timeout:
                return False
            sleep(20)
        sleep(10)
        return self.is_episode_download_complete(ep_name, path)

    def __get_locator(self, locator: dict):
        env = cm.environment
        locater = locator["locator_prod"] if env == "prod" \
            else locator["locator_pp"]
        return dict(locator=locater, type=locator["type"])


class SeriesiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.seasons_list = {
            "locator": "//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeCollectionView"
            "/XCUIElementTypeCell", "type": MobileBy.XPATH}
        self.episodes_list = {
            "locator": "//XCUIElementTypeScrollView/XCUIElementTypeOther"
            "/XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeCollectionView/XCUIElementTypeCell"
            "[position() > 2]",
            "type": MobileBy.XPATH}
        self.download_label = dict(
            locator="Download", type=MobileBy.ACCESSIBILITY_ID)

    def click_on_ep(self, ep_name, timeout=10):
        ep = self.get_episode(ep_name, timeout)
        self.helper.click(ep)

    def click_on_dl_ep_button(self, ep_name, timeout=10):
        loc = self.get_ep_element_location(ep_name, timeout)
        size = self.get_ep_element_size(ep_name, timeout)
        y = int(loc["y"] + (size["height"] / 2))
        x = int((loc["x"] + size["width"]) * 0.9)
        self.driver.helper.tap_on_screen([(x, y)])

    def is_episode_downloading(self, ep_name, path, timeout=20):
        timestamp = time()
        while time() - timestamp <= timeout:
            status = self.get_text_of_episode_download_status(
                ep_name, path, timeout)
            if "%" in status:
                return True
        return False

    def is_episode_download_complete(self, ep_name, path, timeout=10):
        then = time()
        while time() - then <= timeout:
            ss = self.get_screenshot_of_ep_element(ep_name, path, 0)
            imgocr = ImageOCR(ss)
            imgocr.convert_to_rgb()
            imgocr.crop(left=85)
            imgocr.write_to_file(str(path) + "/dl_button.png")
            # Blue color found in dl complete button
            if imgocr.find_color((22, 150, 185)):
                return True
            sleep(1)
        return False

    def get_episodes_list(self, timeout=10):
        return self.helper.get_list(self.episodes_list, timeout)

    def get_episode(self, ep_name, timeout=10, swipes=5):
        for _ in range(swipes):
            episodes = self.get_episodes_list(timeout=10)
            for ep in episodes:
                ep_txt = self.helper.get_text(ep)
                if ep_name in ep_txt:
                    return ep
            self.driver.helper.swipe()
            sleep(1)
        raise NoSuchElementException(f"Episode title {ep_name} wasn't found")

    def get_seasons_list(self, timeout=10):
        return self.helper.get_list(
            self.seasons_list.get("locator"), timeout,
            self.seasons_list.get("type"))

    def get_ep_element_size(self, ep_name, timeout=10):
        ep = self.get_episode(ep_name, timeout)
        return self.helper.get_size(ep)

    def get_ep_element_location(self, ep_name, timeout=10):
        ep = self.get_episode(ep_name, timeout)
        return self.helper.get_location(ep)

    def get_screenshot_of_ep_element(self, ep_name, path,
                                     timeout=5):
        ep = self.get_episode(ep_name, timeout)
        ss = self.helper.take_screenshot(
            ep, str(path) + "/episode.png")
        return ss

    def get_text_of_episode_download_status(self, ep_name, path, timeout=5):
        ss = self.get_screenshot_of_ep_element(ep_name, path, timeout)
        imgmgr = ImageOCR(ss)
        imgmgr.crop(top=38, bottom=35, left=42, right=10)
        imgmgr.write_to_file(str(path) + "/dl_status_crop.png")
        txt = imgmgr.scan_text(grayscale=True, binary=False, lang="ENGLISH")
        # Title is 2 rows. DL Status is further down
        if "min" in txt:
            imgmgr.reset()
            imgmgr.crop(top=60, bottom=15, left=42, right=10)
            imgmgr.write_to_file(str(path) + "/dl_status_crop2.png")
            txt = imgmgr.scan_text(grayscale=True, binary=False,
                                   lang="ENGLISH")
        return txt

    def get_episode_download_status_in_percent(self, ep_name, path,
                                               timeout=10):
        text = self.get_text_of_episode_download_status(ep_name, path, timeout)
        if text == "":
            return 100
        percent = text.split("%")
        return int(percent[0]) if len(percent) == 2 else -1

    def wait_for_episode_download_to_complete(self, ep_name, path,
                                              timeout=1200):
        then = time()
        while self.get_episode_download_status_in_percent(ep_name, path) <= \
                99:
            if time() - then > timeout:
                return False
            sleep(20)
        sleep(10)
        return self.is_episode_download_complete(ep_name, path)


class Series(Asset, SeriesAndroid, SeriesiOS):
    def __init__(self, driver):
        Asset.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            SeriesAndroid.__init__(self, driver)
            self.series = SeriesAndroid
        elif platform == "ios":
            SeriesiOS.__init__(self, driver)
            self.series = SeriesiOS

    def click_on_season(self, index, timeout=10):
        seasons = self.get_seasons_list(timeout)
        self.helper.click(seasons[index])

    def click_on_episode(self, index, timeout=10):
        episodes = self.get_episodes_list(timeout)
        self.helper.click(episodes[index])
        sleep(1)

    def click_on_cw_overview_episode(self, timeout=10):
        self.helper.click(
            self.cw_episode.get("locator"), timeout,
            self.cw_episode.get("type"))

    def get_text_of_genre_label(self, timeout=10):
        return self.helper.get_text(self.genre_label, timeout)

    def get_text_of_download_label(self, timeout=10):
        return self.helper.get_text(self.download_label, timeout)

    def is_download_label_displayed(self, timeout=10):
        return self.helper.is_visible(self.download_label, timeout)

    def is_episode_queued(self, ep_name, path=None, timeout=10):
        dl_status = self.get_text_of_episode_download_status(
            ep_name, path, timeout)
        return dl_status

    # Delegator methods
    def click_on_ep(self, ep_name, timeout=10):
        self.series.click_on_ep(self, ep_name, timeout)

    def click_on_dl_ep_button(self, ep_name, timeout=10):
        self.series.click_on_dl_ep_button(self, ep_name, timeout)

    def is_episode_downloading(self, ep_name, path, timeout=20):
        return self.series.is_episode_downloading(self, ep_name, path, timeout)

    def is_episode_download_complete(self, ep_name, path, timeout=5):
        return self.series.is_episode_download_complete(
            self, ep_name, path, timeout)

    def get_episodes_list(self, timeout=5):
        return self.series.get_episodes_list(self, timeout)

    def get_seasons_list(self, timeout=10):
        return self.series.get_seasons_list(self, timeout)

    def get_episode(self, ep_name, timeout=10, swipes=5):
        return self.series.get_episode(self, ep_name, timeout, swipes)

    def get_text_of_episode_download_status(self, ep_name, path, timeout=10):
        return self.series.get_text_of_episode_download_status(
            self, ep_name, path, timeout)

    def get_episode_download_status_in_percent(self, ep_name, timeout=10):
        return self.series.get_episode_download_status_in_percent(
            self, ep_name, timeout)

    def wait_for_episode_download_to_complete(self, ep_name, path,
                                              timeout=1200):
        return self.series.wait_for_episode_download_to_complete(
            self, ep_name, path, timeout)
