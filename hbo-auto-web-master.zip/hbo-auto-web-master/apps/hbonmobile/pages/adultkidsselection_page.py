from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class AdultKidsSelectionAndroid(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)
        self.series_movies_button = {
            "locator": "com.hbo.android.app:id/profile_main_logo",
            "type": MobileBy.ID}
        self.kids_button = {
            "locator": "com.hbo.android.app:id/profile_toonix_logo",
            "locator_es": "com.hbo.android.app:id/profile_kids_logo",
            "type": MobileBy.ID}
        self.header = {"locator": "com.hbo.android.app:id/profile_header",
                       "type": MobileBy.ID}
        self.sub_header = {
            "locator": "com.hbo.android.app:id/profile_subheader",
            "type": MobileBy.ID}

    def click_on_series_movies_button(self, timeout=60):
        self.helper.click(
            self.series_movies_button.get("locator"), timeout,
            self.series_movies_button.get("type"))

    def click_on_kids_button(self, timeout=60):
        locator = self.kids_button.get("locator_es") \
            if cm.region == "spain" \
            else self.kids_button.get("locator")
        self.helper.click(locator, timeout, self.kids_button.get("type"))

    def is_kids_button_displayed(self, timeout=60):
        locator = self.kids_button.get("locator_es") \
            if cm.region == "spain" \
            else self.kids_button.get("locator")
        return self.helper.is_visible(
            locator, timeout, self.kids_button.get("type"))

    def is_header_displayed(self, timeout=10):
        return self.helper.is_visible(self.header, timeout=timeout)

    def is_sub_header_displayed(self, timeout=10):
        return self.helper.is_visible(self.sub_header, timeout=timeout)

    def wait_until_header_displayed(self, timeout=30):
        return self.helper.wait_until_visible(self.header, timeout=timeout)


class AdultKidsSelectioniOS(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)
        self.series_movies_button = {
            "locator": "//XCUIElementTypeButton"
            "[@name='ProfilePicker.StandardButton']",
            "type": MobileBy.XPATH}
        self.kids_button = {
            "locator": "//XCUIElementTypeButton"
            "[@name='ProfilePicker.FamilyButton']",
            "type": MobileBy.XPATH}

    def click_on_series_movies_button(self, timeout=60):
        self.helper.click(
            self.series_movies_button.get("locator"), timeout,
            self.series_movies_button.get("type"))

    def click_on_kids_button(self, timeout=60):
        self.helper.click(
            self.kids_button.get("locator"), timeout,
            self.kids_button.get("type"))

    def is_kids_button_displayed(self, timeout=20):
        return self.helper.is_visible(
            self.kids_button.get("locator"), timeout,
            self.kids_button.get("type"))


class AdultKidsSelection(AdultKidsSelectionAndroid, AdultKidsSelectioniOS):
    def __init__(self, driver):
        platform = cm.platform
        if platform == "android":
            AdultKidsSelectionAndroid.__init__(self, driver)
        elif platform == "ios":
            AdultKidsSelectioniOS.__init__(self, driver)

    def is_series_movies_button_displayed(self, timeout=60):
        return self.helper.is_visible(
            self.series_movies_button.get("locator"), timeout,
            self.series_movies_button.get("type"))
