from helpers.sleeper import Sleeper as sleep

from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class LoginAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.email_input = {"locator": "com.hbo.android.app:id/sign_in_email",
                            "type": MobileBy.ID}
        self.password_input = {
            "locator": "com.hbo.android.app:id/sign_in_password",
            "type": MobileBy.ID}
        self.signin_button = {
            "locator": "com.hbo.android.app:id/sign_in_button",
            "type": MobileBy.ID}
        self.forgot_password_button = {
            "locator": "com.hbo.android.app:id/forgot_password",
            "type": MobileBy.ID}
        self.toggle_password_button = {
            "locator": "com.hbo.android.app:id/text_input_password_toggle",
            "type": MobileBy.ID}
        self.become_subscriber = {
            "locator": "com.hbo.android.app:id/sign_up_link",
            "type": MobileBy.ID}
        self.list_of_browsers = {"locator": "android:id/resolver_list",
                                 "type": MobileBy.ID}
        self.first_browser_on_the_list = {"locator": "android:id/text1",
                                          "type": MobileBy.ID}
        self.browsers_list_confirm_button = {
            "locator": "android:id/button_always",
            "type": MobileBy.ID}
        self.browsers_list_confirm_button_huawei = {
            "locator": "com.huawei.android.internal.app:id/hw_button_always",
            "type": MobileBy.ID}
        self.chrome_webbrowser = {"locator": "org.chromium.chrome.browser"
                                  ".ChromeTabbedActivity", "type": MobileBy.ID}
        self.url_webbrowser_bar = {"locator": "com.android.chrome:id/url_bar",
                                   "type": MobileBy.ID}
        self.red_error_ribbon = {
            "locator": "com.hbo.android.app:id/snackbar_text",
            "type": MobileBy.ID}
        self.email_warning = {
            "locator": "com.hbo.android.app:id/sign_in_email_feedback",
            "type": MobileBy.ID}
        self.password_warning = {
            "locator": "com.hbo.android.app:id/sign_in_password_feedback",
            "type": MobileBy.ID}
        self.version = {
            "locator": "com.hbo.android.app:id/version_code",
            "type": MobileBy.ID}
        self.endpoints = {
            "locator": "android:id/text1", "type": MobileBy.ID
        }
        # Debug version of app needs to be re-set each time we end
        # up on login page (such as logging out in middle of case)
        if self.is_version_displayed(3):
            self.click_on_version(0)
            if cm.environment == "preprod":
                self.click_on_endpoint_preprod()
            elif cm.environment == "prod":
                self.click_on_endpoint_prod()
            else:
                raise ValueError("Environment was neither prod or preprod")
            sleep(2)

    def click_on_become_subscriber(self, timeout=10):
        self.helper.click(self.become_subscriber.get("locator"), timeout,
                          self.become_subscriber.get("type"))

    def click_on_first_browser_on_the_list(self, timeout):
        self.helper.click(self.first_browser_on_the_list.get("locator"),
                          timeout, self.first_browser_on_the_list.get("type"))

    def click_on_browsers_list_confirm_button(self, timeout=10):
        visible = self.helper.is_visible(
            self.browsers_list_confirm_button.get("locator"), timeout,
            self.browsers_list_confirm_button.get("type"))
        if visible:
            self.helper.click(
                self.browsers_list_confirm_button.get("locator"), timeout,
                self.browsers_list_confirm_button.get("type"))
        elif self.helper.is_visible(
            self.browsers_list_confirm_button_huawei.get("locator"),
                timeout, self.browsers_list_confirm_button.get("type")):
            self.helper.click(
                self.browsers_list_confirm_button_huawei.get("locator"),
                timeout, self.browsers_list_confirm_button_huawei.get("type"))

    def click_on_version(self, timeout=5):
        self.helper.click(self.version.get("locator"), timeout,
                          self.version.get("type"))

    def click_on_endpoint_preprod(self):
        endpoints = self.get_endpoint_options()
        self.helper.click(
            [x for x in endpoints if x.text.lower().startswith("pre")][0])

    def click_on_endpoint_prod(self):
        endpoints = self.get_endpoint_options()
        self.helper.click(
            [x for x in endpoints if x.text.lower().startswith("prod")][0])

    def is_email_input_empty(self, timeout=10):
        email = self.helper.get_text(
            self.email_input.get("locator"), timeout,
            self.email_input.get("type"))
        return True if email == "Email" or str() else False

    def is_password_input_empty(self, timeout=10):
        password = self.helper.get_text(
            self.password_input.get("locator"), timeout,
            self.password_input.get("type"))
        return True if password == "Password" or str() else False

    def is_become_subscriber_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.become_subscriber.get("locator"), timeout,
            self.become_subscriber.get("type"))

    def is_browsers_list_poped(self, timeout=10):
        return self.helper.is_visible(
            self.first_browser_on_the_list.get("locator"),
            timeout, self.first_browser_on_the_list.get("type"))

    def is_invalid_user_error_displayed(self, timeout=20):
        return self.helper.is_visible(
            self.red_error_ribbon.get("locator"), timeout,
            self.red_error_ribbon.get("type"))

    def is_email_warning_displayed(self, timeout=3):
        return self.helper.is_visible(
            self.email_warning.get("locator"), timeout,
            self.email_warning.get("type"))

    def is_password_warning_displayed(self, timeout=3):
        return self.helper.is_visible(
            self.password_warning.get("locator"), timeout,
            self.password_warning.get("type"))

    def is_version_displayed(self, timeout=5):
        return self.helper.is_visible(self.version.get("locator"), timeout,
                                      self.version.get("type"))

    def get_text_of_email_input(self, timeout=10):
        return self.helper.get_text(
            self.email_input.get("locator"), timeout,
            self.email_input.get("type"))

    def get_webbrowser_url(self, timeout=10):
        return self.helper.get_text(
            self.url_webbrowser_bar.get("locator"), timeout,
            self.url_webbrowser_bar.get("type"))

    def get_endpoint_options(self, timeout=2):
        return self.helper.get_list(self.endpoints.get("locator"), timeout,
                                    self.endpoints.get("type"))


class LoginiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.email_input = {"locator": "//XCUIElementTypeTextField",
                            "type": MobileBy.XPATH}
        self.password_input = {"locator": "//XCUIElementTypeSecureTextField",
                               "type": MobileBy.XPATH}
        self.signin_button = {"locator": "SignIn.SignInButton",
                              "type": MobileBy.ACCESSIBILITY_ID}
        self.forgot_password_button = {"locator":
                                       "SignIn.ForgotPasswordButton",
                                       "type": MobileBy.ACCESSIBILITY_ID}
        self.password_warning = {"locator":
                                 "SignIn.PasswordError",
                                 "type": MobileBy.ACCESSIBILITY_ID}

        self.email_warning = {
            "locator": "SignIn.EmailError",
            "type": MobileBy.ACCESSIBILITY_ID}
        self.red_error_ribbon = {
            "locator": "//XCUIElementTypeOther[@name='Snackbar.Text']"
            "/XCUIElementTypeStaticText",
            "type": MobileBy.XPATH}

    def is_email_input_empty(self, timeout=10):
        return self.helper.get_attribute(self.email_input.get("locator"),
                                         "value", timeout,
                                         self.email_input.get("type")) is None

    def is_password_input_empty(self, timeout=10):
        return self.helper.get_attribute(
            self.password_input.get("locator"), "value", timeout,
            self.password_input.get("type")) is None

    def is_email_warning_displayed(self, timeout=3):
        return self.helper.get(
            self.email_warning.get("locator"), timeout,
            self.email_warning.get("type")) is not None

    def is_password_warning_displayed(self, timeout=3):
        return self.helper.get(
            self.password_warning.get("locator"), timeout,
            self.password_warning.get("type")) is not None

    def get_text_of_email_input(self, timeout=10):
        email = self.helper.get_text(self.email_input.get("locator"), timeout,
                                     self.email_input.get("type"))
        return str() if email == self.email_input.get("locator") else email


class Login(LoginAndroid, LoginiOS):
    def __init__(self, driver):
        self.name = "Login Page"
        platform = cm.platform
        if platform == "android":
            LoginAndroid.__init__(self, driver)
            self.login = LoginAndroid
        elif platform == "ios":
            LoginiOS.__init__(self, driver)
            self.login = LoginiOS

    def is_login_page(self):
        return self.is_email_input_displayed() and \
            self.is_password_input_displayed()

    def is_email_input_displayed(self, timeout=10):
        return self.helper.is_visible(self.email_input.get("locator"), timeout,
                                      self.email_input.get("type"))

    def is_password_input_displayed(self, timeout=10):
        return self.helper.is_visible(self.password_input.get("locator"),
                                      timeout, self.password_input.get("type"))

    def is_forgot_password_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.forgot_password_button.get("locator"), timeout,
            self.forgot_password_button.get("type"))

    def is_error_banner_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.red_error_ribbon.get("locator"), timeout,
            self.red_error_ribbon.get("type"))

    def is_toggle_password_button_displayed(self, timeout=2):
        return self.helper.is_visible(
            self.toggle_password_button.get("locator"), timeout,
            self.toggle_password_button.get("type"))

    def is_password_input_hidden(self, timeout=2):
        return True if self.helper.get_attribute(
            self.password_input.get("locator"), "password", timeout,
            self.password_input.get("type")) == "true" \
            else False

    def is_password_input_showing(self, timeout=2):
        return True if self.helper.get_attribute(
            self.password_input.get("locator"), "password", timeout,
            self.password_input.get("type")) == "false" \
            else False

    def click_on_email_input_button(self, timeout=10):
        self.helper.click(self.email_input.get("locator"), timeout,
                          self.email_input.get("type"))

    def click_on_password_input_button(self, timeout=10):
        self.helper.click(self.password_input.get("locator"), timeout,
                          self.password_input.get("type"))

    def click_on_signin_button(self, timeout=10):
        self.helper.click(self.signin_button.get("locator"),
                          timeout, self.signin_button.get("type"))

    def click_on_toggle_password_button(self, timeout=10):
        self.click_on_password_input_button()
        self.helper.click(self.toggle_password_button.get("locator"), timeout,
                          self.toggle_password_button.get("type"))

    def click_on_forgot_password_button(self, timeout=10):
        self.helper.click(self.forgot_password_button.get("locator"),
                          timeout, self.forgot_password_button.get("type"))

    def input_text_on_email(self, email, timeout=10):
        self.helper.input_text(self.email_input.get("locator"), email,
                               timeout, self.email_input.get("type"))

    def input_text_on_password(self, password, timeout=10):
        self.helper.input_text(self.password_input.get("locator"), password,
                               timeout, self.password_input.get("type"))

    def clear_email_input(self, timeout=10):
        self.helper.clear_text(self.email_input.get("locator"), timeout,
                               self.email_input.get("type"))

    def clear_password_input(self, timeout=10):
        self.helper.clear_text(self.password_input.get("locator"), timeout,
                               self.password_input.get("type"))

    def get_text_of_email_warning(self, timeout=3):
        return self.helper.get_text(self.email_warning.get("locator"), timeout,
                                    self.email_warning.get("type"))

    def get_text_of_error_banner(self, timeout=10):
        return self.helper.get_text(
            self.red_error_ribbon.get("locator"), timeout,
            self.red_error_ribbon.get("type"))

    def get_text_of_password_input(self, timeout=10):
        return self.helper.get_text(
            self.password_input.get("locator"), timeout,
            self.password_input.get("type"))

    # Delegator methods

    def is_email_input_empty(self, timeout=10):
        return self.login.is_email_input_empty(self, timeout)

    def is_password_input_empty(self, timeout=10):
        return self.login.is_password_input_empty(self, timeout)

    def is_email_warning_displayed(self, timeout=3):
        return self.login.is_email_warning_displayed(self, timeout)

    def is_password_warning_displayed(self, timeout=3):
        return self.login.is_password_warning_displayed(self, timeout)
