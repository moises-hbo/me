from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.navigation_partial import Navigation

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class WatchlistAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.explore_shows_button = {
            "locator": "com.hbo.android.app:id/explore_shows",
            "type": MobileBy.ID}
        self.assets_list = {
            "locator": "//android.view.ViewGroup"
            "[@resource-id='com.hbo.android.app:id/content']",
            "type": MobileBy.XPATH}
        self.asset_title = {
            "locator": "//android.widget.TextView"
            "[@resource-id='com.hbo.android.app:id/title']",
            "type": MobileBy.XPATH}
        self.asset_image = {
            "locator": "//android.widget.ImageView"
            "[@resource-id='com.hbo.android.app:id/image']",
            "type": MobileBy.XPATH}

    def click_on_asset(self, list_index=0, timeout=3):
        asset = self.get_assets_list(timeout)[list_index]
        img = asset.find_element(self.asset_image.get("type"),
                                 self.asset_image.get("locator"))
        self.helper.click(img)

    def is_watchlist_page(self, timeout=10):
        try:
            return self.get_header_text() == "Watchlist"
        except AttributeError:  # Unable to retrieve text
            return False

    def get_asset_title(self, list_index=0, timeout=3):
        asset = self.get_assets_list(timeout)[list_index]
        title = asset.find_element(
            self.asset_title.get("type"), self.asset_title.get("locator"))
        return title.text


class WatchlistiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.explore_shows_button = {
            "locator": "EXPLORE SHOWS",
            "type": MobileBy.ACCESSIBILITY_ID}
        self.watchlist_header_text = {
            "locator": "//XCUIElementTypeNavigationBar[@name='Watchlist']",
            "type": MobileBy.XPATH}
        self.assets_list = {
            "locator": "//XCUIElementTypeCell[contains(@name,'')]",
            "type": MobileBy.XPATH}

    def click_on_asset(self, list_index=0, timeout=3):
        asset = self.get_assets_list(timeout)[list_index]
        self.helper.click(asset)

    def is_watchlist_page(self, timeout=10):
        return self.helper.is_visible(
            self.watchlist_header_text.get("locator"), timeout,
            self.watchlist_header_text.get("type"))

    def get_asset_title(self, list_index=0, timeout=3):
        asset = self.get_assets_list(timeout)[list_index]
        title = self.helper.get_attribute(asset, "name")
        return title


class Watchlist(Navigation, WatchlistAndroid, WatchlistiOS):
    def __init__(self, driver):
        Navigation.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            WatchlistAndroid.__init__(self, driver)
            self.watchlist = WatchlistAndroid
        elif platform == "ios":
            WatchlistiOS.__init__(self, driver)
            self.watchlist = WatchlistiOS

    def click_on_explore_shows_button(self, timeout=10):
        self.helper.click(
            self.explore_shows_button.get("locator"), timeout,
            self.explore_shows_button.get("type"))

    def is_explore_shows_button_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.explore_shows_button.get("locator"), timeout,
            self.explore_shows_button.get("type"))

    def get_assets_list(self, timeout=3):
        return self.helper.get_list(
            self.assets_list.get("locator"), timeout,
            self.assets_list.get("type"))

    # Delegator methods

    def click_on_asset(self, list_index=0, timeout=3):
        self.watchlist.click_on_asset(self, list_index, timeout)

    def is_watchlist_page(self, timeout=10):
        return self.watchlist.is_watchlist_page(self, timeout)

    def get_asset_title(self, list_index=0, timeout=3):
        return self.watchlist.get_asset_title(self, list_index, timeout)
