from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class PrivacyPolicyUpdatesAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)
        self.hbo_logo = {"locator": "com.hbo.android.app:id/gdpr_logo",
                         "type": MobileBy.ID}
        self.got_it_button = {
            "locator": "com.hbo.android.app:id/button_gdpr_confirm",
            "type": MobileBy.ID}

    def click_on_got_it_button(self, timeout=20):
        self.helper.click(
            self.got_it_button.get("locator"), timeout,
            self.got_it_button.get("type"))

    def is_gdpr_logo_displayed(self, timeout=20):
        return self.helper.is_visible(
            self.hbo_logo.get("locator"), timeout,
            self.hbo_logo.get("type"))

    def is_got_it_button_displayed(self, timeout=20):
        return self.helper.is_visible(
            self.got_it_button.get("locator"), timeout,
            self.got_it_button.get("type"))


class PrivacyPolicyUpdatesiOS(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)


class PrivacyPolicyUpdates(PrivacyPolicyUpdatesAndroid,
                           PrivacyPolicyUpdatesiOS):
    def __init__(self, driver):
        platform = cm.platform
        if platform == "android":
            PrivacyPolicyUpdatesAndroid.__init__(self, driver)
        elif platform == "ios":
            PrivacyPolicyUpdatesiOS.__init__(self, driver)
