from time import time
from appium.webdriver.common.mobileby import MobileBy

from apps.hbonmobile.pages.base.page import BasePageObject as Page
from apps.hbonmobile.pages.navigation_partial import Navigation

from helpers.configmanager import ConfigManager
from helpers.sleeper import Sleeper as sleep

cm = ConfigManager()


class AssetAndroid(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.play_button = {
            "locator": "com.hbo.android.app:id/play_button",
            "type": MobileBy.ID}
        self.bookmark = {
            "locator": "com.hbo.android.app:id/bookmark", "type": MobileBy.ID}
        self.download_button = dict(locator="download_button",
                                    type=MobileBy.ID)
        self.download_status = dict(locator="download_status",
                                    type=MobileBy.ID)
        self.add_to_watchlist_button = {
            "locator": "com.hbo.android.app:id/watchlist", "type": MobileBy.ID}
        # Temp download overlay
        self.stop_download_button = dict(
            locator="downloads_bottom_sheet_stop_btn", type=MobileBy.ID)
        self.play_download_button = dict(
            locator="downloads_bottom_sheet_play_btn", type=MobileBy.ID)
        self.play_stream_button = dict(
            locator="downloads_bottom_sheet_play_stream_btn", type=MobileBy.ID)
        self.remove_download_button = dict(
            locator="downloads_bottom_sheet_delete_btn", type=MobileBy.ID)

    def click_on_play_button(self, timeout=10):
        for _ in range(30):
            self.helper.click(
                self.play_button.get("locator"), timeout,
                self.play_button.get("type"))
            # Assuming maximum streams
            if self.is_error_displayed():
                sleep(25)
            else:
                break

    def click_on_download_button(self, timeout=10):
        self.helper.click(self.download_button, timeout)

    def click_on_remove_from_watchlist_button(self, timeout=5):
        self.helper.click(self.add_to_watchlist_button.get("locator"), timeout,
                          self.add_to_watchlist_button.get("type"))
        sleep(1)  # For animation

    def is_bookmark_displayed(self, timeout=10):
        return self.helper.is_visible(
            self.bookmark.get("locator"), timeout, self.bookmark.get("type"))

    def is_add_to_watchlist_button_checked(self, timeout=3):
        return self.helper.get_attribute(
            self.add_to_watchlist_button.get("locator"), "checked", timeout,
            self.add_to_watchlist_button.get("type")) == "true"

    def is_add_to_watchlist_button_unchecked(self, timeout=3):
        return self.helper.get_attribute(
            self.add_to_watchlist_button.get("locator"), "checked", timeout,
            self.add_to_watchlist_button.get("type")) == "false"

    def get_screenshot_of_download_button_base64(self, timeout=3):
        return self.helper.take_screenshot_base64(
            self.download_button, timeout)

    def open_download_overlay(self, timeout=3):
        self.click_on_download_button(timeout)

    def open_play_overlay(self, timeout=3):
        # NOTE: only appears if asset has been downloaded first
        self.click_on_play_button(timeout)


class AssetiOS(Page):
    def __init__(self, driver):
        super().__init__(driver)

        self.play_button = {
            "locator": "//XCUIElementTypeCell[@name='Play']",
            "type": MobileBy.XPATH}
        self.add_to_watchlist_button = {
            "locator": "Add to watchlist", "type": MobileBy.ACCESSIBILITY_ID}
        self.remove_from_watchlist = {
            "locator": "Remove from watchlist",
            "type": MobileBy.ACCESSIBILITY_ID}
        self.download_button = dict(
            locator="downloadArrow", type=MobileBy.ACCESSIBILITY_ID)
        self.download_queued_button = dict(
            locator="downloadQueued", type=MobileBy.ACCESSIBILITY_ID)
        self.download_stop_button = dict(
            locator="downloadStop", type=MobileBy.ACCESSIBILITY_ID)
        self.download_complete_button = dict(
            locator="downloadComplete", type=MobileBy.ACCESSIBILITY_ID)
        self.download_status = dict(
            locator="//XCUIElementTypeOther/XCUIElementTypeOther"
            "/XCUIElementTypeStaticText[3]", type=MobileBy.XPATH)
        # Temp Download overlay
        self.play_download_button = dict(
            locator="Play Download", type=MobileBy.ACCESSIBILITY_ID)
        self.play_stream_button = dict(
            locator="Play Stream", type=MobileBy.ACCESSIBILITY_ID)
        self.stop_download_button = dict(
            locator="Remove Download", type=MobileBy.ACCESSIBILITY_ID)
        self.remove_download_button = self.stop_download_button
        # Inactive sub popup
        self.sub_inactive_header = dict(
            locator="Subscription Inactive", type=MobileBy.ACCESSIBILITY_ID)
        self.sub_inactive_ok_button = dict(
            locator="ConfirmButton", type=MobileBy.ACCESSIBILITY_ID)

    def click_on_remove_from_watchlist_button(self, timeout=5):
        self.helper.click(self.remove_from_watchlist.get("locator"), timeout,
                          self.remove_from_watchlist.get("type"))
        sleep(1)  # For animation

    def click_on_play_button(self, timeout=10):
        for _ in range(30):
            self.helper.click(
                self.play_button.get("locator"), timeout,
                self.play_button.get("type"))
            # Assuming maximum streams
            if self.is_error_displayed():
                self.click_on_error_ok_button()
                sleep(25)
            else:
                break

    def is_add_to_watchlist_button_checked(self, timeout=3):
        return not self.helper.is_visible(
            self.add_to_watchlist_button.get("locator"), 0,
            self.add_to_watchlist_button.get("type")) and \
            self.helper.is_visible(
                self.remove_from_watchlist.get("locator"), timeout,
                self.remove_from_watchlist.get("type"))

    def is_add_to_watchlist_button_unchecked(self, timeout=3):
        return self.helper.is_visible(
            self.add_to_watchlist_button.get("locator"), 3,
            self.add_to_watchlist_button.get("type")) and not \
            self.helper.is_visible(
                self.remove_from_watchlist.get("locator"), 0,
                self.remove_from_watchlist.get("type"))

    def is_play_stream_button_displayed(self, timeout=3):
        return self.helper.is_visible(self.play_stream_button, timeout)

    def get_download_button(self, timeout):
        dl_btn = self.helper.get(
            self.download_button, int(timeout / 3))
        if dl_btn:
            return dl_btn

        dl_btn_queued = self.helper.get(
            self.download_queued_button, int(timeout / 3))
        if dl_btn_queued:
            return dl_btn_queued

        dl_btn_stop = self.helper.get(
            self.download_stop_button, int(timeout / 3))
        if dl_btn_stop:
            return dl_btn_stop

        return None

    def get_screenshot_of_download_button_base64(self, timeout=3):
        dl_btn = self.get_download_button(timeout)
        return self.helper.take_screenshot_base64(dl_btn)

    def open_download_overlay(self, timeout=3):
        btn = self.helper.get(self.download_complete_button, 0)
        if not btn:
            btn = self.helper.get(self.download_stop_button, timeout)
        self.helper.click(btn)

    def open_play_overlay(self, timeout=3):
        # NOTE: only appears if asset has been downloaded first
        self.click_on_play_button(timeout)


class Asset(Navigation, AssetAndroid, AssetiOS):
    """ A movie or series episode """

    def __init__(self, driver):
        Navigation.__init__(self, driver)
        platform = cm.platform
        if platform == "android":
            AssetAndroid.__init__(self, driver)
            self.asset = AssetAndroid
        elif platform == "ios":
            AssetiOS.__init__(self, driver)
            self.asset = AssetiOS

    def click_on_add_to_watchlist_button(self, timeout=5):
        self.helper.click(self.add_to_watchlist_button.get("locator"), timeout,
                          self.add_to_watchlist_button.get("type"))
        sleep(1)  # For animation

    def click_on_play_stream_button(self, timeout=3):
        self.helper.click(self.play_stream_button, timeout)

    def click_on_play_download_button(self, timeout=3):
        self.helper.click(self.play_download_button, timeout)

    def click_on_stop_download_button(self, timeout=5, remove=True):
        if remove and self.is_remove_download_button_displayed(1):
            self.click_on_remove_download_button()
        else:
            self.helper.click(self.stop_download_button, timeout)

    def click_on_remove_download_button(self, timeout=5):
        self.helper.click(self.remove_download_button, timeout)

    def click_on_sub_inactive_ok_button(self, timeout=3):
        self.helper.click(self.sub_inactive_ok_button, timeout)

    def is_play_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.play_button.get("locator"),
                                      timeout, self.play_button.get("type"))

    def is_download_button_displayed(self, timeout=10):
        return self.helper.is_visible(self.download_button, timeout)

    def is_download_status_displayed(self, timeout=10):
        return self.helper.is_visible(self.download_status, timeout)

    def is_asset_downloadable(self, timeout=3):
        return self.get_text_of_download_status() == "Download"

    def is_asset_queued(self, timeout=3):
        return self.get_text_of_download_status() == "Queued"

    def is_asset_downloading(self, timeout=60):
        return self.wait_for_download_status_to_be_downloading(timeout)

    def is_stop_download_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.stop_download_button, timeout)

    def is_remove_download_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.remove_download_button, timeout)

    def is_play_download_button_displayed(self, timeout=5):
        return self.helper.is_visible(self.play_download_button, timeout)

    def is_asset_download_complete(self, timeout=5):
        status = self.get_text_of_download_status(timeout)
        return True in (x in status for x in ("Expires", "Downloaded"))

    def is_play_overlay_displayed(self, timeout=3):
        return self.helper.is_visible(self.play_stream_button, timeout)

    def is_asset_download_progressing(self, timeout=60):
        then = time()
        while time() - then < timeout:
            perc_then = self.get_percent_of_download_status(0)
            sleep(1)
            perc_now = self.get_percent_of_download_status(0)
            if perc_now > perc_then:
                return True
        return False

    def is_sub_inactive_header_displayed(self, timeout=5):
        return self.helper.is_visible(self.sub_inactive_header, timeout)

    def get_percent_of_download_status(self, timeout=5):
        text = self.get_text_of_download_status(timeout)
        dl_txt_list = text.split("%")
        return int(dl_txt_list[0]) if len(dl_txt_list) == 2 else 999

    def get_text_of_download_status(self, timeout=3):
        return self.helper.get_text(self.download_status)

    def wait_for_download_status_to_be(self, text, timeout=5):
        return self.helper.wait_for_text(
            self.download_status, text, timeout=timeout)

    def wait_for_download_status_to_be_downloadable(self, timeout=5):
        return self.wait_for_download_status_to_be("Download", timeout)

    def wait_for_download_status_to_be_queued(self, timeout=30):
        return self.wait_for_download_status_to_be("Queued", timeout)

    def wait_for_download_status_to_be_downloading(self, timeout=5):
        return self.wait_for_download_status_to_be("% ", timeout)

    def wait_for_download_status_to_be_complete(self, timeout=600):
        then = time()
        while time() - then <= timeout:
            status = self.get_text_of_download_status(0)
            if True in [x in status for x in ["Expires", "Downloaded"]]:
                return True
            sleep(10)
        return False

    def wait_for_asset_download_to_complete(self, timeout=2400):
        dling = self.wait_for_download_status_to_be_downloading(30)
        if not dling:
            return False
        return self.wait_for_download_status_to_be_complete(timeout)

    # Delegator method

    def click_on_remove_from_watchlist_button(self, timeout=10):
        self.asset.click_on_remove_from_watchlist_button(self, timeout)

    def click_on_play_button(self, timeout=10):
        self.asset.click_on_play_button(self, timeout)

    def is_add_to_watchlist_button_checked(self, timeout=10):
        return self.asset.is_add_to_watchlist_button_checked(self, timeout)

    def is_add_to_watchlist_button_unchecked(self, timeout=3):
        return self.asset.is_add_to_watchlist_button_unchecked(self, timeout)

    def get_screenshot_of_download_button_base64(self, timeout=3):
        return self.asset.get_screenshot_of_download_button_base64(
            self, timeout)

    def open_download_overlay(self, timeout=3):
        self.asset.open_download_overlay(self, timeout)

    def open_play_overlay(self, timeout=3):
        self.asset.open_play_overlay(self, timeout)
