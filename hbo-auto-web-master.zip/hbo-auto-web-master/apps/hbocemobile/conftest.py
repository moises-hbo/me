import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from helpers.configmanager import ConfigManager

cm = ConfigManager()
rm = ResourceManagerApp()


@pytest.fixture
def get_proper_user():
    """
    This function select proper user for all production environment plus portugal one.
    Also for qa and pre-rel environment.
    :return: B2B user for HBO CE , D2C user for HBO Portugal
    """
    if cm.environment == "qa":
        user_account = "b2b_qa"
    elif cm.environment == "pre_rel":
        user_account = "b2b_pre_rel"
    else:
        user_account = ("b2b_{}".format(cm.country_id)) if cm.country_id != "pt" else "d2c_pt"
    return rm.get_user_info(account=user_account)


@pytest.fixture
def get_proper_d2c_user():
    """
    This function get d2c user for HBO CE, there is only one d2c user available so it takes Hungary one.
    :return: D2C for hungary
    """
    user_account = "d2c_hu"
    return rm.get_user_info(account=user_account)
