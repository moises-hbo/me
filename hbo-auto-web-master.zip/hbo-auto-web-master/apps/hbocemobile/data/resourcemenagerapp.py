import json
from pathlib import Path
from random import choice

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class ResourceManagerApp(object):

    @staticmethod
    def read_resources_file(return_json=True):
        with open(Path("apps/hbocemobile/data/resources.json"), "r",
                  encoding="utf-8") as resources_file:
            return json.load(resources_file) if return_json else resources_file

    @staticmethod
    def read_apps_file(return_json=True):
        with open(Path("apps/hbocemobile/data/apps.json"), "r",
                  encoding="utf-8") as apps_file:
            return json.load(apps_file) if return_json else apps_file

    @staticmethod
    def read_translation_file(return_json=True):
        with open(Path("apps/hbocemobile/data/translation.json"), "r",
                  encoding="utf-8") as translation_file:
            return json.load(translation_file) if return_json else translation_file

    @classmethod
    def get_random_movie_content(cls, catalog="Normal"):
        resources = cls.read_resources_file()
        movie_list = resources["content"]["Movies"][catalog]
        return choice(movie_list)

    @classmethod
    def get_random_series_content(cls, catalog="Normal"):
        resources = cls.read_resources_file()
        series_list = resources["content"]["Series"][catalog]
        return choice(series_list)

    @classmethod
    def get_random_people(cls, job):
        resources = cls.read_resources_file()
        director_list = resources["content"]["People"][job]
        return choice(director_list)

    @classmethod
    def get_user_info(cls, account):
        resources = cls.read_resources_file()
        return resources["users"][account]

    @classmethod
    def get_app_info(cls):

        """
        Get proper application information depends on what environment the test are run.
        Whenever application is created on QA,
        PROD, PREREL, features package name will change, whenever package name changes webview will be different.
        :return: dictionary with "webview" and "name" key
        """
        apps = cls.read_apps_file()
        enviroment = cm.environment
        application_info = {}

        if cm.platform == "ANMO":
            apps = apps["android_apps"]
        elif cm.platform == "APMO":
            apps = apps["ios_apps"]

        for application in apps:
            if application.get("env") == enviroment:
                application_info["webview"] = application.get("webview")
                application_info["name"] = application.get("app")
                return application_info
        raise NameError(f"Application/environment was not found in the file")

    @classmethod
    def get_country_name(cls):
        translations = cls.read_translation_file()
        country = cm.country_id
        return translations["Countries"][country]["country_name"]

    @classmethod
    def get_country_native_language(cls):
        translations = cls.read_translation_file()
        country = cm.country_id
        return translations["Countries"][country]["language_selector"]

    @classmethod
    def get_country_api_language(cls):
        translations = cls.read_translation_file()
        country = cm.country_id
        return translations["Countries"][country]["api_language"]

    @classmethod
    def get_country_b2b_provider(cls):
        translations = cls.read_translation_file()
        country = cm.country_id
        return translations["Countries"][country]["gateway_provider"]

    @classmethod
    def get_translation_from_resources(cls, name):
        translations = cls.read_translation_file()
        language = cm.country_id
        return translations[name][language]

    @classmethod
    def get_ios_webview_selectors(cls, selector):
        translations = cls.read_translation_file()
        language = cm.country_id
        return translations["iOS_selectors"][language][selector]
