import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.content_flow import select_content_from_random_subcategory
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.navigation_menu_flow import select_watchlist_from_navigation_menu
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.search_page import Search
from helpers.configmanager import ConfigManager

rm = ResourceManagerApp()
cm = ConfigManager()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759180")
def test_remove_from_watchlist_movie(driver, get_proper_user):
    # Generate keyword for
    keyword = ResourceManagerApp.get_random_movie_content()

    # Adding a content to the watchlist with API
    page = Content(driver=driver, keyword=keyword)
    response = page.api_mobile.add_to_watchlist_with_api(name=keyword)
    page.log(
        "Adding to watchlist with API:\nResponse: {}".format(response))

    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select Watchlist from navigation menu
    select_watchlist_from_navigation_menu(driver)

    page = Content(driver=driver)

    # Remove the previously added content from there through the UI
    assert page.delete_from_watchlist_ui(name=keyword)

    # Go back to home screen
    page.go_back()

    assert Home(driver).is_no_content_message_visible()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C3065937")
def test_remove_from_watchlist_series(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "series")

    page = Content(driver=driver)
    page.select_watch_list_button_on_movie_detail()

    # Assert snackbar is visible
    assert page.is_watchlist_snackbar_visible()

    content_name_added = page.get_content_name_from_ui()

    # Go back to home screen
    page.go_back()

    # Select Watchlist from navigation menu
    select_watchlist_from_navigation_menu(driver)

    # Select first keyart
    Home(driver=driver).select_first_keyart()

    # Check if content is visible in Watchlist
    content_name_watchlist = page.get_content_name_from_ui()

    page.log(
        "Content name added to Watchlist: {}\nContent name on watchlist: {}".format(content_name_added,
                                                                                    content_name_watchlist))
    assert content_name_added == content_name_watchlist

    # Remove content from Watchlist
    Content(driver=driver).select_watch_list_button_on_movie_detail()

    # Assert snackbar is visible
    assert page.is_watchlist_snackbar_visible()

    # Go back to home screen
    page.go_back()

    assert Home(driver).is_no_content_message_visible()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759179")
def test_add_to_watchlist_movie(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Generate keyword search for it and return results
    page = Search(driver=driver)
    keyword = ResourceManagerApp.get_random_movie_content()
    page.search_content(keyword)
    results = page.get_search_results()

    page = Content(driver=driver)

    # Adding a content to watchlist and checking if it was successful or not.
    assert page.check_add_to_watchlist(results)

    # Get content name from detail screen
    content_name_added = page.get_content_name_from_ui()

    # Go back to search screen
    page.go_back()

    # Go back to home screen
    page.go_back()

    # Select Watchlist
    select_watchlist_from_navigation_menu(driver)

    # Check if content is visible in Watchlist
    Home(driver=driver).select_first_keyart()

    # Get content name from detail screen
    content_name = page.get_content_name_from_ui()

    page.log(
        "\nContent name added to Watchlist: {}\nContent name on watchlist: {}".format(content_name, content_name_added))

    assert content_name == content_name_added


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759199")
def test_add_to_watchlist_series(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Generate keyword search for it and return results
    page = Search(driver=driver)
    keyword = ResourceManagerApp.get_random_series_content()
    page.search_content(keyword)
    results = page.get_search_results()

    page = Content(driver=driver)

    # Adding a content to watchlist and checking if it was successful or not.
    assert page.check_add_to_watchlist(results, content_type="2")

    # Get content name from detail screen
    content_name_added = page.get_content_name_from_ui()

    # Go back to search screen
    page.go_back()

    # Go back to home screen
    page.go_back()

    # Select Watchlist
    select_watchlist_from_navigation_menu(driver)

    # Check if content is visible in Watchlist
    Home(driver=driver).select_first_keyart()

    # Get content name from detail screen
    content_name = page.get_content_name_from_ui()

    page.log(
        "Content name added to Watchlist: {}\nContent name on watchlist: {}".format(content_name, content_name_added))

    assert content_name == content_name_added


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2813669")
def test_delete_every_content_from_the_watchlist(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select Watchlist from navigation menu
    select_watchlist_from_navigation_menu(driver)

    page = Content(driver=driver)
    # Deleting everything from the watchlist through UI, and checking if it was successful.
    assert page.delete_everything_from_the_watchlist()
