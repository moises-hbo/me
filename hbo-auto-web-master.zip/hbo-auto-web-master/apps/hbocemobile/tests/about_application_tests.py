import pytest

from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.navigation_menu_flow import select_about_page_from_navigation_menu
from apps.hbocemobile.pages.about_Page import About


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2786406")
@pytest.mark.category("Smoke")
def test_about_application(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_about_page_from_navigation_menu(driver)

    page = About(driver)
    assert page.is_application_version_displayed()
    assert page.is_displayed_system_version_the_same()
    assert page.is_displayed_device_model_the_same()
    assert page.is_displayed_connection_the_same()
