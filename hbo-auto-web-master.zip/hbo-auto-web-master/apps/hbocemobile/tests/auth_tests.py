import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.login_flow import login_to_application, select_operator
from apps.hbocemobile.pages.auth_page import Auth

rm = ResourceManagerApp()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759128")
@pytest.mark.category("Smoke")
def test_login_b2b(driver, get_proper_user):
    page = Auth(driver, get_proper_user)
    page.api_mobile.change_app_language_by_api(language=rm.get_country_api_language())

    assert login_to_application(driver, get_proper_user)


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel")
@pytest.mark.id("C2759904")
def test_login_d2c(driver, get_proper_d2c_user):
    assert login_to_application(driver, get_proper_d2c_user)


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759964")
def test_invalid_login_b2b_no_password(driver, get_proper_user):
    # Trying to log in with empty password fields, then log in with valid data.
    select_operator(driver, get_proper_user)
    page = Auth(driver, get_proper_user)

    page.input_empty_credentials(password_empty=True, email_empty=False)
    assert page.is_login_button_displayed()

    page.input_password_text(page.login_type.get("pw"))
    page.click_on_finish_login_button()
    page.switch_context(webview=False)

    assert page.is_login_succesful()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel")
@pytest.mark.id("C2759965")
def test_invalid_login_d2c_no_password(driver, get_proper_d2c_user):
    # Trying to log in with empty password fields, then log in with valid data.

    select_operator(driver, get_proper_d2c_user)
    page = Auth(driver, get_proper_d2c_user)
    page.input_empty_credentials(password_empty=True, email_empty=False)

    # Check if login button is still  displayed
    assert page.is_login_button_displayed()

    page.input_password_text(page.login_type.get("pw"))
    page.click_on_finish_login_button()
    page.switch_context(webview=False)

    assert page.is_login_succesful()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759966")
def test_invalid_b2b_password(driver, get_proper_user):
    select_operator(driver, get_proper_user)
    page = Auth(driver, get_proper_user)
    page.input_wrong_credentials(correct_email=True, correct_password=False)

    # Check if login button and warning message is displayed
    assert page.is_warning_displayed()
    assert page.is_login_button_displayed()

    page.clear_password_field()

    page.input_password_text(page.login_type.get("pw"))
    page.click_on_finish_login_button()
    page.switch_context(webview=False)

    assert page.is_login_succesful()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel")
@pytest.mark.id("C2759967")
def test_invalid_d2c_password(driver, get_proper_d2c_user):
    select_operator(driver, get_proper_d2c_user)
    page = Auth(driver, get_proper_d2c_user)
    page.input_wrong_credentials(correct_email=True, correct_password=False)

    # Check if login button and warning message is displayed
    assert page.is_warning_displayed()
    assert page.is_login_button_displayed()

    page.clear_password_field()

    page.input_password_text(page.login_type.get("pw"))
    page.click_on_finish_login_button()
    page.switch_context(webview=False)

    assert page.is_login_succesful()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759968")
def test_forgot_password_button_b2b(driver, get_proper_user):
    page = Auth(driver=driver, login_type=get_proper_user)
    page.select_country()
    page.select_operator()

    page.select_forgot_password_button()

    assert page.is_forgotten_password_finish_button_displayed()
    assert page.is_email_forgot_password_form_visible()
    assert page.is_forgotten_password_finish_cancel_displayed()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel")
@pytest.mark.id("C2759969")
def test_forgot_password_button_d2c(driver, get_proper_d2c_user):
    page = Auth(driver=driver, login_type=get_proper_d2c_user)
    page.select_country()
    page.select_operator()

    page.select_forgot_password_button()

    assert page.is_forgotten_password_finish_button_displayed()
    assert page.is_email_forgot_password_form_visible()
    assert page.is_forgotten_password_finish_cancel_displayed()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2818465")
def test_back_button_in_authorization_flow(driver, get_proper_user):
    select_operator(driver, get_proper_user)

    # Select B2B operator
    page = Auth(driver, get_proper_user)
    assert page.is_login_screen_visible()

    # Go back to vip operator screen
    page.select_back_button()
    assert page.is_operator_selector_middle_screen_displayed()

    # Go back to provider screen
    page.select_back_button()
    assert page.is_select_operator_selector_screen_displayed()
    assert not page.is_back_button_visible()

    # Select D2C operator
    page.select_d2c_operator()
    assert page.is_login_screen_visible()

    # Go back to provider screen
    page.select_back_button()
    assert page.is_select_operator_selector_screen_displayed()
    assert not page.is_back_button_visible()
