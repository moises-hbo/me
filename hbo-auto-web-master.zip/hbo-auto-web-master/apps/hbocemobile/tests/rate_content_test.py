from helpers.sleeper import Sleeper as sleep

import pytest

from apps.hbocemobile.flows.content_flow import select_content_from_random_subcategory
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.pages.content_page import Content
from helpers.configmanager import ConfigManager

cm = ConfigManager()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C4915376")
def test_rate_random_series_content(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "series")

    page = Content(driver=driver)

    # Wait till detail screen loads
    assert page.is_rating_button_visible()

    # Get name of random Content
    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_rating_button()

    # Check if pop-up is visible

    assert page.is_cancel_rate_button_visible()
    assert page.is_submit_rate_button_visible()

    # Press Cancel button
    page.select_submit_rate_button()

    # Select random number of starts
    page.select_random_number_of_stars()

    # Press Cancel
    page.select_cancel_rate_button()

    sleep(2)

    # Select rate button, random number of starts and check toast msg visibility
    page.select_rating_button()
    page.select_random_number_of_stars()

    # Select Submit Button
    page.select_submit_rate_button()

    assert page.is_rate_snackbar_visible()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C4915375")
def test_rate_random_movie_content(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Wait till detail screen loads
    assert page.is_rating_button_visible()

    # Get name of random Content
    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_rating_button()

    # Check if everything is visible

    assert page.is_cancel_rate_button_visible()
    assert page.is_submit_rate_button_visible()

    # Press Cancel button
    page.select_submit_rate_button()

    # Check if pop-up ist still visible
    assert page.is_cancel_rate_button_visible()

    # Select random number of starts
    page.select_random_number_of_stars()

    # Press Cancel
    page.select_cancel_rate_button()

    sleep(2)

    # Select rate button, random number of starts and check toast msg visibility
    page.select_rating_button()
    page.select_submit_rate_button()
    page.select_random_number_of_stars()

    # Select Submit Button
    page.select_submit_rate_button()

    assert page.is_rate_snackbar_visible()
