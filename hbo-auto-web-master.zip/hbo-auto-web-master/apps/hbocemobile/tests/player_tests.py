from helpers.sleeper import Sleeper as sleep

import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.content_flow import select_content_from_random_subcategory
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.player_page import Player
from apps.hbocemobile.pages.search_page import Search

rm = ResourceManagerApp()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759165")
@pytest.mark.category("Smoke")
def test_player_movie_random(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_movie_detail()

    # Give player some time, some errors could happen after start
    sleep(30)

    # This is only for smoke purpose to check if player is playing
    page = Player(driver=driver)
    assert page.is_player_playing()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759183")
@pytest.mark.category("Smoke")
def test_player_series_random(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "series")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_series_detail()

    # Give player some time, some errors could happen after start
    sleep(30)

    # This is only for smoke purpose to check if player is playing
    page = Player(driver=driver)
    assert page.is_player_playing()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819449")
def test_player_pause(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Search for content and select is
    page = Search(driver=driver)
    page.search_and_select_first(keyword=None)

    page = Content(driver=driver)
    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)

    # Give player some time, relax and watch movie
    sleep(30)

    page.pause_playing()
    assert page.is_player_paused()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2813677")
def test_play_content_for_20_sec(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Search for content and select is
    page = Search(driver=driver)
    page.search_and_select_first(keyword=None)

    page = Content(driver=driver)
    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)
    played_time = page.play_content_for_20_sec()
    page.log("Played time: {} seconds.".format(played_time))

    assert played_time > 19


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759190")
def test_back_15_seconds_button(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Search for content and select it
    page = Search(driver=driver)
    page.search_and_select_first(keyword=None)

    page = Content(driver=driver)
    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)
    assert page.check_15_seconds_back_button()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2870931")
def test_player_menu_bars_visual_movies(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)

    assert page.is_player_playing()

    # Give player some time, some errors could happen after start
    sleep(10)

    page.pause_playing()

    # Assert all upper icons are visible
    assert page.is_player_back_button_visible()
    assert page.is_next_content_title_visible()
    assert page.is_chromecast_icon_visible()
    assert page.is_subtitle_size_icon_visible()
    assert page.is_audio_sub_option_visible()

    # Assert all top down icons are visible
    assert page.is_back_15s_button_visible()
    assert page.is_elapsed_time_visible()
    assert page.is_progress_bar_visible()
    assert page.is_total_time_visible()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819439")
def test_player_menu_bars_visual_series(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Generate keyword search for it and return results
    page = Search(driver=driver)
    keyword = rm.get_random_series_content()
    page.search_content(keyword)
    page.select_first_search_keyart()

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_series_detail(episode=1)

    page = Player(driver=driver)

    assert page.is_player_playing()

    # Give player some time, some errors could happen after start
    sleep(10)

    page.pause_playing()

    # Assert all upper icons are visible
    assert page.is_player_back_button_visible()
    assert page.is_next_content_title_visible()
    assert page.is_secondary_title_visible()
    assert page.is_chromecast_icon_visible()
    assert page.is_subtitle_size_icon_visible()
    assert page.is_audio_sub_option_visible()

    # Assert all top down icons are visible
    assert page.is_back_15s_button_visible()
    assert page.is_elapsed_time_visible()
    assert page.is_progress_bar_visible()
    assert page.is_total_time_visible()

    # Assert previous/next episode buttons is visible
    assert page.is_next_episode_button_visible()
    assert page.is_previous_episode_button_visible()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2860942")
def test_chromecast_menu(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)

    assert page.is_player_playing()

    # Give player some time, some errors could happen after start
    sleep(10)

    page.pause_playing()

    # Select Chromecast
    page.select_chromecast_icon()

    # Assert pop-up is visible
    assert page.is_chrome_cast_pop_up_visible()

    # TODO: Missing last step from TestRail


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819447")
def test_exit_player(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)

    assert page.is_player_playing()

    # Give player some time, some errors could happen after start
    sleep(10)

    page.pause_playing()

    # Select back button

    page.select_back_button_player()

    # Check if we are redirected to detail screen

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819454")
def test_lock_player(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)

    assert page.is_player_playing()

    # Give player some time, some errors could happen after start
    sleep(10)

    # Lock device for 5 seconds
    page.d_helper.lock_device(seconds=5)

    # Give player some time, some errors could happen after start
    sleep(15)

    assert page.is_player_playing()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819455")
def test_background_player(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)

    assert page.is_player_playing()

    # Give player some time, some errors could happen after start
    sleep(10)

    page.d_helper.background_app(seconds=5)

    # Give player some time, some errors could happen after start
    sleep(10)

    assert page.is_player_playing()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819462")
def test_jump_on_progress_player(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_movie_detail()

    # Give player some time, some errors could happen after start
    sleep(10)

    page = Player(driver=driver)
    page.pause_playing()

    elapsed_time_begin = page.get_elapsed_time()

    page.select_random_place_on_seek_bar(percent=90)

    elapsed_time_after = page.get_elapsed_time()

    # Check if time changed

    page.log("Begin time: {}, End time after the swipe: {}".format(elapsed_time_begin, elapsed_time_after))
    assert elapsed_time_begin < elapsed_time_after


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819465", "C2819466")
def test_elapsed_total_time(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "series")

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_series_detail()

    # Give player some time, some errors could happen after start
    sleep(10)

    page = Player(driver=driver)
    page.pause_playing()

    # Checked is elapsed time and total time is displayed in proper format
    assert page.is_elapsed_time_have_proper_time_format()
    assert page.is_total_time_have_proper_time_format()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2871763")
def test_skip_previous_episode(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver)
    page.search_content("True Detective")
    page.select_first_search_keyart()

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    page.select_play_button_on_series_detail(episode=1)

    page = Player(driver=driver)

    # Check if continue watch pop-up appear
    page.select_play_from_beginning_if_pop_up_appear()

    page.pause_playing()

    episode_number = page.get_episode_number_from_secondary_title()

    assert episode_number == 2

    page.select_previous_episode()

    # Check if continue watch pop-up appear
    page.select_play_from_beginning_if_pop_up_appear()

    page.pause_playing()

    episode_number = page.get_episode_number_from_secondary_title()
    # Assert episode have correct number
    assert episode_number == 1

    page.select_next_episode()

    # Give player some time, some errors could happen after start
    page.select_play_from_beginning_if_pop_up_appear()
    page.pause_playing()
    episode_number = page.get_episode_number_from_secondary_title()
    # Assert episode have correct number
    assert episode_number == 2


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819472", "C2819473")
def test_end_of_play(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver)
    page.search_content("True Detective")
    page.select_first_search_keyart()

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    # Get True Detective Season 3 episode 1
    page.select_play_button_on_series_detail(episode=0)

    # Give player some time, some errors could happen after start
    sleep(10)

    page = Player(driver=driver)
    assert page.is_player_playing()

    page.pause_playing()

    page.select_random_place_on_seek_bar(percent=95)

    # TODO: This is temporary hack for Samsung Galaxy S8 and Appium behaviour
    page.select_play_button_on_player()
    sleep(1)
    page.driver.press_keycode(127)

    # Assert all buttons on end of Play are visible
    assert page.is_end_of_play_visible()
    assert page.is_keyart_holder_visible()
    assert page.is_next_content_title_visible()
    assert page.is_next_episode_button_eop_visible()
    assert page.is_cancel_button_visible_eop()

    # Check if next is True Detective Season 3 episode 2
    assert page.is_end_of_play_title_displayed(series_season=3, series_episode=2)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2819474")
def test_end_of_play_auto_play(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver)
    page.search_content("True Detective")
    page.select_first_search_keyart()

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    # Get True Detective Season 3 episode 1
    page.select_play_button_on_series_detail(episode=0)

    # Give player some time, some errors could happen after start
    sleep(10)

    page = Player(driver=driver)
    assert page.is_player_playing()

    page.pause_playing()

    page.select_random_place_on_seek_bar(percent=95)

    # TODO: This is temporary hack for Samsung Galaxy S8 and Appium behaviour
    page.select_play_button_on_player()
    sleep(1)
    page.driver.press_keycode(127)

    # Assert end of play is visible
    assert page.is_end_of_play_visible()

    # Check if next is True Detective Season 3 episode 2
    assert page.is_end_of_play_title_displayed(series_season=3, series_episode=2)

    page.driver.press_keycode(127)

    # Assert that player is still playing
    assert page.is_player_playing()

    # Give player some time
    sleep(15)

    page.select_play_from_beginning_if_pop_up_appear()

    page.pause_playing()

    episode_number = page.get_episode_number_from_secondary_title()

    # Assert episode have correct number
    assert episode_number == 2


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C9063342")
def test_end_of_play_watch_now(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver)
    page.search_content("True Detective")
    page.select_first_search_keyart()

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    # Get True Detective Season 3 episode 1
    page.select_play_button_on_series_detail(episode=0)

    # Give player some time, some errors could happen after start
    sleep(10)

    page = Player(driver=driver)
    assert page.is_player_playing()

    page.pause_playing()

    page.select_random_place_on_seek_bar(percent=95)

    # TODO: This is temporary hack for Samsung Galaxy S8 and Appium behaviour
    page.select_play_button_on_player()
    sleep(1)
    page.driver.press_keycode(127)

    # Assert end of play is visible
    assert page.is_end_of_play_visible()

    # Check if next is True Detective Season 3 episode 2
    assert page.is_end_of_play_title_displayed(series_season=3, series_episode=2)

    # Select Watch now
    page.select_watch_now_button()

    # Give player some time
    sleep(5)

    page.select_play_from_beginning_if_pop_up_appear()

    page.pause_playing()

    episode_number = page.get_episode_number_from_secondary_title()

    # Assert episode have correct number
    assert episode_number == 2


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C9063343")
def test_end_of_play_cancel(driver, get_proper_user):  # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver)
    page.search_content("True Detective")
    page.select_first_search_keyart()

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    # Get True Detective Season 3 episode 1
    page.select_play_button_on_series_detail(episode=0)

    # Give player some time, some errors could happen after start
    sleep(10)

    page = Player(driver=driver)
    assert page.is_player_playing()

    page.pause_playing()

    page.select_random_place_on_seek_bar(percent=95)

    # TODO: This is temporary hack for Samsung Galaxy S8 and Appium behaviour
    page.select_play_button_on_player()
    sleep(1)
    page.driver.press_keycode(127)

    # Assert end of play is visible
    assert page.is_end_of_play_visible()

    # Check if next is True Detective Season 3 episode 2
    assert page.is_end_of_play_title_displayed(series_season=3, series_episode=2)

    page.select_cancel_end_of_play_button()

    sleep(30)

    page = Content(driver=driver)

    # Check if Detail screen icons are visible
    assert page.is_normal_detail_screen_visible()
