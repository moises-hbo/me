import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.content_flow import select_content_from_random_subcategory
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.search_page import Search
from helpers.configmanager import ConfigManager

rm = ResourceManagerApp()
cm = ConfigManager()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2865990")
def test_check_content_details_series_search(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Generate keyword and search for content
    page = Search(driver=driver)
    keyword = ResourceManagerApp.get_random_series_content()
    page.search_and_select_first(keyword)

    page = Content(driver=driver, keyword=keyword)

    # Check if  functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    # Checking if the appearing details on the UI are the same as those we got from the API call.
    assert page.check_content_details(page.get_series_content_data_from_ui(),
                                      page.api_mobile.get_series_content_data_from_api(keyword))

    # Checking if the appearing episode details on the UI are the same as those we got from the API call.
    assert page.check_content_details(page.get_episode_metadata_from_ui(),
                                      page.api_mobile.get_episode_metadata_from_api(keyword))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2860946")
def test_back_button_on_series(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "series")

    # Press back button
    page = Content(driver=driver)
    page.go_back()

    # Check if we where redirected to Series Screen
    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(rm.get_translation_from_resources("Series"))

    # Select content again
    page.select_first_keyart()
    page = Content(driver=driver)

    # Check if detail screen open
    page.is_watchlist_button_visible()
    page.select_android_back_button()

    # Check if we where redirected to Series Screen
    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(rm.get_translation_from_resources("Series"))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2860945")
def test_back_button_on_movies(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    # Press back button
    page = Content(driver=driver)
    page.go_back()

    # Check if we where redirected to Movie Screen
    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(rm.get_translation_from_resources("Movies"))

    # Select content again
    page.select_first_keyart()
    page = Content(driver=driver)

    # Check if detail screen open
    page.is_watchlist_button_visible()
    page.select_android_back_button()

    # Check if we where redirected to Movie Screen
    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(rm.get_translation_from_resources("Movies"))


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel","qa", "pre_rel")
@pytest.mark.id("C2860173")
@pytest.mark.category("Smoke")
def test_series_detail_screen(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "series")

    page = Content(driver=driver)

    # Check if  functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    # Get name from UI
    content_name = page.get_content_name_from_ui()

    # Checking if the appearing details on the UI are the same as those we got from the API call.
    assert page.check_content_details(page.get_series_content_data_from_ui(),
                                      page.api_mobile.get_series_content_data_from_api(content_name))

    # Thi Check only runs on Android because of https://hboeurope.atlassian.net/browse/EUAUTO-367
    if cm.platform == "ANMO":
        # Checking if the appearing episode details on the UI are the same as those we got from the API call.
        assert page.check_content_details(page.get_episode_metadata_from_ui(),
                                          page.api_mobile.get_episode_metadata_from_api(content_name))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2860175")
def test_related_stripe_series(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "series")

    page = Content(driver=driver)

    # Check if functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    page.swipe_to_related_stripe()

    # Check related stripe
    page.swipe_through_related_stripe(swipe_number=3)
    page.select_related_stripe_keyart(choose_keyart=2)

    # Check if content from related stripe open properly
    assert page.is_watchlist_button_visible()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759164")
def test_related_stripe_movies(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)

    # Check if functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    page.swipe_to_related_stripe()

    # Check related stripe
    page.swipe_through_related_stripe(swipe_number=3)
    page.select_related_stripe_keyart(choose_keyart=2)

    # Check if content from related stripe open properly
    assert page.is_watchlist_button_visible()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel","qa", "pre_rel")
@pytest.mark.id("C2819254")
@pytest.mark.category("Smoke")
def test_check_content_details_movies(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select content from random subcategory and go to detail screen.
    select_content_from_random_subcategory(driver, "movies")

    page = Content(driver=driver)
    # Check if functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    page.log("Content name: {}".format(page.get_content_name_from_ui()))

    # Check if play button is visible
    assert page.is_play_on_movie_detail_screen_visible()

    # Checking if the appearing details on the UI are the same as those we got from the API call.
    content_name = page.get_content_name_from_ui()
    assert page.check_content_details(page.get_movie_content_data_from_ui(),
                                      page.api_mobile.get_movie_content_data_from_api(content_name))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2813665")
def test_check_content_details_movies_search(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Generate keyword and search for content
    page = Search(driver=driver)
    keyword = ResourceManagerApp.get_random_movie_content()
    page.search_and_select_first(keyword)

    page = Content(driver=driver, keyword=keyword)

    # Check if  functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    # Check if play button is visible
    assert page.is_play_on_movie_detail_screen_visible()

    # Checking if the appearing details on the UI are the same as those we got from the API call.
    assert page.check_content_details(page.get_movie_content_data_from_ui(),
                                      page.api_mobile.get_movie_content_data_from_api(keyword))

