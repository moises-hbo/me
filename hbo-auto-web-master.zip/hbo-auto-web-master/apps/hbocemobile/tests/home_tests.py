import pytest

from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.menu_page import Menu
from apps.hbocemobile.pages.home_page import Home


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2805458")
def test_recently_added_section_of_home_page(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)

    # Navigating to the recently added section of home page.
    page.navigate_to_menu(menu="home", submenu="recently_added")

    page = Home(driver=driver)

    # Checking premiere tag of the contents.
    # Since not all of them has it,
    # it only fails if more then 90% of the contents doesn't have the premiere tag.
    assert page.check_recently_added()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2805463")
def test_imdb_toplist_section_of_home_page(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)

    # Navigating to the imdb_toplist section of home page.
    page.navigate_to_menu(menu="home", submenu="imdb_toplist")

    page = Home(driver=driver)

    # Checking imdb rating of the contents. Fails if it is under 7.
    # Test check this for 90 seconds
    assert page.check_imdb_toplist(test_duration=90)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2805461")
def test_last_chance_to_see_section_of_home_page(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)

    # Navigating to the "last chance to see" section of home page.
    page.navigate_to_menu(menu="home", submenu="last_chance_to_see")

    page = Home(driver=driver)

    # Checking "last chance" tag of the contents.
    assert page.check_last_chance_to_see()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2805459")
def test_coming_soon_section_of_home_page(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)

    # Navigating to the "coming soon" section of home page.
    page.navigate_to_menu(menu="home", submenu="coming_soon")

    page = Home(driver=driver)

    # Checking "coming soon" tag of the contents.
    assert page.check_coming_soon()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2805460")
def test_coming_soon_content_detail_screen(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)

    # Navigating to the "coming soon" section of home page.
    page.navigate_to_menu(menu="home", submenu="coming_soon")

    page = Home(driver=driver)
    page.select_first_keyart()

    page = Content(driver=driver)

    # Check if functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    assert page.is_available_date_visible()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2805462")
def test_last_chance_content_detail_screen(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)

    # Navigating to the "coming soon" section of home page.
    page.navigate_to_menu(menu="home", submenu="last_chance_to_see")

    page = Home(driver=driver)
    page.select_first_keyart()

    page = Content(driver=driver)

    # Check if functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert page.is_rating_button_visible()
    assert page.is_back_button_visible()

    assert page.is_available_date_visible()
