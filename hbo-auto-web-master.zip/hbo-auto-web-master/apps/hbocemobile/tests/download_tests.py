from helpers.sleeper import Sleeper as sleep

import pytest

from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.navigation_menu_flow import select_download_from_navigation_menu
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.download_page import Download
from apps.hbocemobile.pages.kids_page import Kids


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel","qa", "pre_rel")
@pytest.mark.id("C3321225")
@pytest.mark.category("Smoke")
def test_download_display(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_download_from_navigation_menu(driver)

    page = Content(driver)
    # TODO: temporary sleep for stability issue's
    sleep(2)
    assert page.is_search_button_visible()

    page = Download(driver)
    assert page.is_kids_switch_visible()
    assert page.is_no_content_message_displayed()

    # Switch to Kids Section
    page.select_kids_switch()

    # Unlock Kids
    page = Kids(driver)
    page.select_maybe_later_onboarding()

    # Waiting for app to reload(mostly for iOS stability)
    sleep(2)

    # Assert user is on Download KIDS section
    assert page.is_padlock_button_displayed()
