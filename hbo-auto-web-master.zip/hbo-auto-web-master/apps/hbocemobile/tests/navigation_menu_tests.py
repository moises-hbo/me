import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.navigation_menu_flow import select_home_from_navigation_menu, \
    select_series_from_navigation_menu, select_movies_from_navigation_menu, select_help_from_navigation_menu
from apps.hbocemobile.pages.help_page import Help
from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.menu_page import Menu
from helpers.configmanager import ConfigManager

rm = ResourceManagerApp()
cm = ConfigManager()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel","qa", "pre_rel")
@pytest.mark.id("C2759136")
@pytest.mark.category("Smoke")
def test_menu_help_page_redirect(driver, get_proper_user):
    assert login_to_application(driver, get_proper_user)

    select_help_from_navigation_menu(driver)
    page = Help(driver=driver)

    assert page.is_help_page_opened()

    # Additional check for Android (because its possible to automate it)
    if cm.platform == "ANMO":
        page.close_web_page_and_return_to_app()

        # Check if after returning to app everything works properly
        page = Menu(driver=driver)
        assert page.is_navigation_menu_expanded()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759130")
def test_general_navigation_behaviour(driver, get_proper_user):
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)
    page.open_menu()

    # Assert that navigation menu expanded
    assert page.is_navigation_menu_expanded()

    # Hide navigation menu by clicking of screen
    page.hide_navigation_menu_by_click_off_screen()

    # Assert that navigation menu is not expanded
    assert not page.is_navigation_menu_expanded()

    # Open Navigation menu by swipe
    page.open_navigation_menu_by_swipe()
    assert page.is_navigation_menu_expanded()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2778289")
def test_series_redirect(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)
    select_series_from_navigation_menu(driver)

    # Check if Series text is displayed
    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(page_title=rm.get_translation_from_resources("Series"))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759131")
def test_home_redirect(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)
    select_home_from_navigation_menu(driver)

    # Check if HBO home logo is displayed
    page = Home(driver=driver)
    assert page.is_hbo_logo_displayed()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2778290")
def test_movies_redirect(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)
    select_movies_from_navigation_menu(driver)

    # Check if Movies text is displayed
    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(page_title=rm.get_translation_from_resources("Movies"))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2785418")
def test_general_menu_buttons_visibility(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)
    page.open_menu()
    # Checking the main menu buttons visibility and their text.
    assert page.check_menu_buttons_visibility()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2778286")
def test_home_buttons_subsection_visibility(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)
    page.open_menu()
    # Checking the home menu subsection buttons visibility and their text.
    assert page.check_sub_menu_buttons_visibility(sub="home")


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759132")
def test_series_buttons_subsection_visibility(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)
    page.open_menu()
    # Checking the series menu subsection buttons visibility and their text.
    assert page.check_sub_menu_buttons_visibility("series")


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759133")
def test_movies_buttons_subsection_visibility(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)
    page.open_menu()
    # Checking the movie menu subsections buttons visibility and their text.
    assert page.check_sub_menu_buttons_visibility("movies")


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
def test_menu_buttons_visibility(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Menu(driver=driver)

    # Checking the main menu buttons visibility and their text.
    page.open_menu()
    assert page.check_menu_buttons_visibility()

    # Checking the home menu buttons visibility and their text.
    assert page.check_sub_menu_buttons_visibility(sub="home")

    # Checking the series menu buttons visibility and their text.
    assert page.check_sub_menu_buttons_visibility(sub="series")

    # Checking the movies menu buttons visibility and their text.
    assert page.check_sub_menu_buttons_visibility(sub="movies")
