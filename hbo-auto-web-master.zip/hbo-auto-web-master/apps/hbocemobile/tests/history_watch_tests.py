from helpers.sleeper import Sleeper as sleep

import pytest

from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.navigation_menu_flow import select_watch_history_from_navigation_menu
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.menu_page import Menu
from apps.hbocemobile.pages.watch_history_page import WatchHistory


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759181")
def test_watch_history_movies(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select random subcategory
    Menu(driver=driver).select_random_sub_category(category="movies")

    # Get content name from first keyart
    page = Home(driver=driver)
    content_name = page.get_first_visible_content_title_from_normal_stripe()

    # Open First visible keyart
    page.select_first_keyart()

    page = Content(driver=driver)

    # Wait for Detail Screen to Load
    assert page.is_rating_button_visible()
    assert page.is_watchlist_button_visible()
    page.select_play_button_on_movie_detail()

    # Wait for player
    sleep(10)

    # Close player
    page.select_android_back_button()

    # Return to home screen
    page.go_back()

    select_watch_history_from_navigation_menu(driver)

    page = WatchHistory(driver)

    watchlist_content_title = page.get_title_from_first_element_on_watchlist()

    page.log(
        "\nContent name played: {}\nContent name on watch history: {}".format(content_name, watchlist_content_title))

    assert content_name == watchlist_content_title


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759201")
def test_watch_history_series(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select random subcategory
    Menu(driver=driver).select_random_sub_category(category="series")

    # Get content name from first keyart
    page = Home(driver=driver)
    content_name = page.get_first_visible_content_title_from_normal_stripe()

    # Open First visible keyart
    page.select_first_keyart()

    page = Content(driver=driver)

    # Wait for Detail Screen to Load
    assert page.is_rating_button_visible()
    assert page.is_watchlist_button_visible()
    page.select_play_button_on_series_detail()

    # Wait for player
    sleep(10)

    # Close player
    page.select_android_back_button()

    # Return to home screen
    page.go_back()

    select_watch_history_from_navigation_menu(driver)

    page = WatchHistory(driver)

    watchlist_content_title = page.get_title_from_first_element_on_watchlist()

    page.log(
        "\nContent name played: {}\nContent name on watch history: {}".format(content_name, watchlist_content_title))

    assert content_name == watchlist_content_title


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759182")
def test_watch_history_movies_delete(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select random subcategory
    Menu(driver=driver).select_random_sub_category(category="movies")

    # Get content name from first keyart
    page = Home(driver=driver)
    content_name = page.get_first_visible_content_title_from_normal_stripe()

    # Open First visible keyart
    page.select_first_keyart()

    page = Content(driver=driver)

    # Wait for Detail Screen to Load
    assert page.is_rating_button_visible()
    assert page.is_watchlist_button_visible()
    page.select_play_button_on_movie_detail()

    # Wait for player
    sleep(10)

    # Close player
    page.select_android_back_button()

    # Return to home screen
    page.go_back()

    select_watch_history_from_navigation_menu(driver)

    page = WatchHistory(driver)

    watchlist_content_title = page.get_title_from_first_element_on_watchlist()

    page.log(
        "\nContent name played: {} \nContent name on watch history: {}".format(content_name, watchlist_content_title))

    assert content_name == watchlist_content_title

    # Swipe left on first element
    page.swipe_left_on_first_element()

    # Remove first element from watch history
    page.select_remove_from_watch_history()

    # Wait for list to reload
    sleep(2)

    # Get new content title
    watchlist_content_title = page.get_title_from_first_element_on_watchlist()

    page.log(
        "\nContent name played: {}\nContent name on watch history: {}".format(content_name, watchlist_content_title))

    assert content_name != watchlist_content_title


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759202")
def test_watch_history_series_delete(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select random subcategory
    Menu(driver=driver).select_random_sub_category(category="series")

    # Get content name from first keyart
    page = Home(driver=driver)
    content_name = page.get_first_visible_content_title_from_normal_stripe()

    # Open First visible keyart
    page.select_first_keyart()

    page = Content(driver=driver)

    # Wait for Detail Screen to Load
    assert page.is_rating_button_visible()
    assert page.is_watchlist_button_visible()
    page.select_play_button_on_series_detail()

    # Wait for player
    sleep(10)

    # Close player
    page.select_android_back_button()

    # Return to home screen
    page.go_back()

    select_watch_history_from_navigation_menu(driver)

    page = WatchHistory(driver)

    watchlist_content_title = page.get_title_from_first_element_on_watchlist()

    page.log(
        "\nContent name played: {} \nContent name on watch history: {}".format(content_name, watchlist_content_title))

    assert content_name == watchlist_content_title

    # Swipe left on first element
    page.swipe_left_on_first_element()

    # Remove first element from watch history
    page.select_remove_from_watch_history()

    # Wait for list to reload
    sleep(2)

    # Get new content title
    watchlist_content_title = page.get_title_from_first_element_on_watchlist()

    page.log(
        "\nContent name played: {}\nContent name on watch history: {}".format(content_name, watchlist_content_title))

    assert content_name != watchlist_content_title


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C3065936")
def test_delete_all_watch_history_elements(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Select Watch history
    select_watch_history_from_navigation_menu(driver)

    page = WatchHistory(driver)
    page.remove_all_watch_history_elements()

    # Assert the container with message is visible
    assert page.is_no_content_message_visible()
