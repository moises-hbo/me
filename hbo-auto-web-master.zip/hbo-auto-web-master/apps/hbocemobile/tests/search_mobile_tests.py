import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.content_flow import search_content
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.search_page import Search

rm = ResourceManagerApp()


@pytest.mark.platform("APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.category("Smoke")
def test_search_content(driver, get_proper_user):
    # TODO: This test will be removed after iOS work with iOs search will be done

    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Validating if search results on the UI are the same as the ones from the API call.
    assert search_content(driver, name=None)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2813678")
def test_search_invalid_keyword(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver=driver)

    # Checking invalid keyword in search input
    assert page.check_invalid_keyword()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2939194", "C2939195")
def test_search_design_general(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver=driver)
    page.select_search_icon()

    # Check visual layer of application "C2939194 Search - Design"
    assert page.is_default_search_hint_displayed()
    assert page.is_default_search_text_displayed()
    assert page.is_keyboard_displayed()
    assert page.is_search_back_button_displayed()

    # Check Search content C2939195

    page.enter_text_on_search_field("t")

    assert page.is_no_result_visible()

    page.enter_text_on_search_field("th")

    assert page.is_no_result_visible()

    page.enter_text_on_search_field("the")

    # Keyboard stays visible
    assert page.is_keyboard_displayed()

    # Result list is visible
    assert page.is_result_list_visible()

    # Keyboard disappear after swipe
    page.d_helper.swipe("Down")
    page.d_helper.swipe("Up")
    page.d_helper.swipe("Down")

    assert not page.is_keyboard_displayed()

    # Select keyart and open Detail screen
    page.select_first_search_keyart()

    # Check if detail screen open
    page = Content(driver=driver)
    page.is_watchlist_button_visible()
    page.go_back()

    # Check if we are back on search
    page = Search(driver=driver)
    page.is_result_list_visible()

    # Assert keyboard is not displayed
    assert not page.is_keyboard_displayed()

    # Tap on search field
    page.click_on_input_field()

    # Check if Keyboard return
    assert page.is_keyboard_displayed()

    # Select back button
    page.select_search_back_button()

    # Check if Home screen appears
    page = Home(driver=driver)
    page.is_hbo_logo_displayed()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2939196")
def test_search_by_name(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = Search(driver=driver)

    # Search for director
    keyword = rm.get_random_people(job="Director")
    page.select_search_and_enter_text(keyword=keyword)
    assert page.is_search_phrase_visible_in_result(keyword)

    # Clean test results
    page.select_clear_results_button()
    assert page.is_default_search_text_displayed()
    assert page.is_default_search_hint_displayed()

    # Search for Actor
    keyword = rm.get_random_people(job="Actor")
    page.enter_text_on_search_field(keyword=keyword)
    assert page.is_search_phrase_visible_in_result(keyword)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759150")
def test_search_content_kids_in_normal(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Validating if search results on the UI are the same as the ones from the API call.
    assert search_content(driver, name=rm.get_random_series_content(catalog="Kids"))

    page = Search(driver=driver)
    page.select_first_search_keyart()

    # Check if detail screen open
    page = Content(driver=driver)
    page.is_watchlist_button_visible()
    page.go_back()

    # Check if we are back on search
    page = Search(driver=driver)
    page.is_result_list_visible()

    # Assert keyboard is not displayed
    assert not page.is_keyboard_displayed()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759151")
def test_search_normal_plus_kids_content_in_normal(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Validating if search results on the UI are the same as the ones from the API call.
    assert search_content(driver, name=rm.get_random_movie_content(catalog="Kids_plus_normal"))

    page = Search(driver=driver)
    page.select_first_search_keyart()

    # Check if detail screen open
    page = Content(driver=driver)
    page.is_watchlist_button_visible()
    page.go_back()

    # Check if we are back on search
    page = Search(driver=driver)
    page.is_result_list_visible()

    # Assert keyboard is not displayed
    assert not page.is_keyboard_displayed()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759152")
@pytest.mark.category("Smoke")
def test_search_normal_content_in_normal(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Validating if search results on the UI are the same as the ones from the API call.
    assert search_content(driver, name=rm.get_random_movie_content(catalog="Normal"))

    page = Search(driver=driver)
    page.select_first_search_keyart()

    # Check if detail screen open
    page = Content(driver=driver)
    page.is_watchlist_button_visible()
    page.go_back()

    # Check if we are back on search
    page = Search(driver=driver)
    page.is_result_list_visible()

    # Assert keyboard is not displayed
    assert not page.is_keyboard_displayed()
