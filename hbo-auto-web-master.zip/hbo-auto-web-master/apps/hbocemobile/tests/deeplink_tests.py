import pytest

from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.pages.deeplink_page import DeepLink
from apps.hbocemobile.pages.home_page import Home


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("")
def test_deeplink(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    page = DeepLink(driver)
    page.d_helper.close_app()

    # Check Series
    series_id = page.api_mobile.get_menu_items_id_and_names()[1][1]
    series_page_title = page.api_mobile.get_menu_items_id_and_names()[1][0]
    page.get_and_run_proper_deeplink(group_id=series_id)

    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(
        page_title=series_page_title)


    # Check Movies
    page = DeepLink(driver)
    page.d_helper.close_app()

    series_id = page.api_mobile.get_menu_items_id_and_names()[2][1]
    series_page_title = page.api_mobile.get_menu_items_id_and_names()[2][0]
    page.get_and_run_proper_deeplink(group_id=series_id)

    page = Home(driver=driver)
    assert page.check_is_page_title_visible_an_have_proper_text(
        page_title=series_page_title)
