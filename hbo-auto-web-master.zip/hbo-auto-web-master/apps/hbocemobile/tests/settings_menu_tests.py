import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.home_flow import is_search_icon_displayed
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.navigation_menu_flow import select_settings_from_navigation_menu
from apps.hbocemobile.flows.settings_flow import sign_out_from_application
from apps.hbocemobile.pages.auth_page import Auth
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.menu_page import Menu
from apps.hbocemobile.pages.settings_page import Settings
from helpers.configmanager import ConfigManager

rm = ResourceManagerApp()

cm = ConfigManager()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C3091727")
def test_parental_screen(driver, get_proper_user):
    assert login_to_application(driver, get_proper_user)
    select_settings_from_navigation_menu(driver)

    page = Settings(driver)
    # Check if gateway load properly
    assert page.is_gateway_page_load()

    page.select_parental_control()

    # Assert buttons are visible
    assert page.is_change_pin_button_visible()
    assert page.is_radio_button_eighteen_visible()

    # Simple check if radio button is visible
    assert page.is_radio_button_eighteen_visible()

    assert not page.is_save_parental_pin_button_visible()

    # Select change pin button
    page.select_change_pin_button()

    # Assert save button will appear
    assert page.is_save_parental_pin_button_visible()

    # Input new Parental
    page.input_new_parental()
    assert page.is_save_parental_pin_button_visible()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C3076938")
def test_device_screen(driver, get_proper_user):
    assert login_to_application(driver, get_proper_user)
    select_settings_from_navigation_menu(driver)

    page = Settings(driver)
    # Check if gateway load properly
    assert page.is_gateway_page_load()

    page.select_devices_page()

    # Check if list is available and TV PIn is not empty
    assert page.is_device_list_visible()
    assert page.is_tv_pin_displayed()

    # Check if current device is on the list
    assert page.is_device_is_on_the_device_list()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C3046603", "C2759222")
def test_account_popup_crawler(driver, get_proper_user):
    assert login_to_application(driver, get_proper_user)

    select_settings_from_navigation_menu(driver)
    page = Settings(driver)

    # Check if gateway load properly
    assert page.is_gateway_page_load()

    # Select account management and modify email
    page.select_account_management()

    # C2759222
    # Check if all buttons are visible

    assert page.is_email_form_visible()
    assert page.is_account_management_logout_button_visible()
    assert page.is_account_management_save_button_visible()
    assert page.is_account_management_forgot_passowrd_button_visible()
    assert page.is_radio_newsletter_button_visible()

    page.modify_email()

    # Select back button without saving
    page.select_back_button_gateway()

    # Select no on pop-up
    page.select_no_on_confirmation_popup()

    # Select back button without saving
    page.select_back_button_gateway()

    # Select yes on pop-up
    page.select_yes_on_confirmation_popup()

    # Return to account management
    page.select_account_management()
    page.select_forgot_password()

    # Assert all buttons are visible
    assert page.is_email_form_visible()
    assert page.is_forgot_password_send_button_visible()
    assert page.is_cancel_forgot_password_button_visible()

    # Cancel reset password
    page.select_forgot_password_cancel()

    # Check if logout button is visible and we are on Account Management screen
    assert page.is_account_management_logout_button_visible()

    page.select_radio_button_newsletter()

    # Select back button without saving
    page.select_back_button_gateway()
    page.select_yes_on_confirmation_popup()
    page.select_account_management()

    page.select_save_button()

    # Assert that Settings close and we see expanded menu
    page = Menu(driver=driver)

    # Come back to native app context
    page.switch_context(webview=False)
    assert page.is_navigation_menu_expanded()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2759223")
@pytest.mark.category("Smoke")
def test_change_language_of_application_to_englisch(driver, get_proper_user):
    # Setup first test, change language to HUN
    page = Content(driver=driver)
    page.api_mobile.change_app_language_by_api(rm.get_country_api_language())

    assert login_to_application(driver, get_proper_user)

    select_settings_from_navigation_menu(driver)
    page = Settings(driver)
    # Check if gateway load properly
    assert page.is_gateway_page_load()

    # Select Application preferences and wait it to load
    page.select_application_preferences()
    assert page.is_gateway_page_load()

    # Change language to native one
    page.change_language_webview(nativ=False)

    # Wait till application reload (30 seconds)
    assert is_search_icon_displayed(driver)

    page = Menu(driver)
    page.open_menu()

    # Assert if all fields on menu are set to proper language
    assert page.compare_data(page.get_menu_buttons_text_from_ui(),
                             page.api_mobile.get_menu_buttons_name_from_api(
                                 content_data=page.api_mobile.get_raw_menu_data_api(language="ENG")))


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C3038685")
@pytest.mark.category("Smoke")
def test_change_language_of_application_to_native(driver, get_proper_user):
    # Setup first test, change language to ENG
    page = Content(driver=driver)
    page.api_mobile.change_app_language_by_api(language="ENG")

    assert login_to_application(driver, get_proper_user)

    select_settings_from_navigation_menu(driver)
    page = Settings(driver)
    # Check if gateway load properly
    assert page.is_gateway_page_load()

    # Select Application preferences and wait it to load
    page.select_application_preferences()
    assert page.is_gateway_page_load()

    # Change language to native one
    page.change_language_webview(nativ=True)

    # Wait till application reload (30 seconds)
    assert is_search_icon_displayed(driver)

    page = Menu(driver)
    page.open_menu()

    # Assert if all fields on menu are set to proper language
    assert page.compare_data(page.get_menu_buttons_text_from_ui(),
                             page.api_mobile.get_menu_buttons_name_from_api(
                                 content_data=page.api_mobile.get_raw_menu_data_api(rm.get_country_api_language())))


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "prod_pt", "rel", "qa", "pre_rel")
@pytest.mark.id("C2813681")
@pytest.mark.category("Smoke")
def test_logout_b2b(driver, get_proper_user):
    assert login_to_application(driver, get_proper_user)

    select_settings_from_navigation_menu(driver)

    # Logout from application
    sign_out_from_application(driver)

    page = Auth(driver, get_proper_user)

    # Check if country selector is visible
    # TODO: Resolve portugal logout issue
    if cm.environment != "prod_pt":
        assert page.is_country_selector_visible()

    # TODO: Temporary remove when uninstall solution will be ready
    page.remove_application()


@pytest.mark.platform("ANMO", "APMO")
@pytest.mark.env("prod", "rel", "qa", "pre_rel")
@pytest.mark.id("C2813680")
def test_logout_d2c(driver, get_proper_d2c_user):
    assert login_to_application(driver, get_proper_d2c_user)

    select_settings_from_navigation_menu(driver)

    # Logout from application
    sign_out_from_application(driver)

    page = Auth(driver, get_proper_d2c_user)
    # Check if country selector is visible
    assert page.is_country_selector_visible()

    # TODO: Temporary remove when uninstall solution will be ready
    page.remove_application()

