from helpers.sleeper import Sleeper as sleep
import pytest

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.flows.home_flow import is_hamburger_menu_displayed, is_search_icon_displayed
from apps.hbocemobile.flows.login_flow import login_to_application
from apps.hbocemobile.flows.navigation_menu_flow import select_kids_from_navigation_menu
from apps.hbocemobile.flows.content_flow import search_content
from apps.hbocemobile.pages.content_page import Content
from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.kids_page import Kids
from apps.hbocemobile.pages.player_page import Player
from apps.hbocemobile.pages.search_page import Search



@pytest.mark.platform("ANMO","APMO")
@pytest.mark.env("prod","prod_pt", "rel","qa", "pre_rel")
@pytest.mark.id("C3253175")
@pytest.mark.category("Smoke")
def test_normal_lock_smoke(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)
    page = Kids(driver)

    # Select never show again option
    page.select_show_never_onboarding_screen()

    # Check if hamburger menu is displayed
    assert is_hamburger_menu_displayed(driver)

    page.select_padlock_button()
    page.select_lock_kids()

    page = Search(driver=driver)

    # Check if adult content are not visible in Kids
    assert page.search_no_result(ResourceManagerApp.get_random_series_content("Normal"))

    # Go back to KIDS home screen
    page = Content(driver=driver)
    page.go_back()

    # Unlock Kids
    page = Kids(driver)
    page.select_padlock_button()

    # Provide proper Parental Pin
    page.input_parental_pin()

    # Application should be unlocked
    assert is_hamburger_menu_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod","rel","qa", "pre_rel")
@pytest.mark.id("C2963634")
def test_characters_stripe(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    page = Home(driver=driver)
    assert page.is_customer_group_visible(ResourceManagerApp.get_translation_from_resources("Characters"))

    page = Kids(driver)
    assert page.is_characters_keyarts_visible()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod","rel","qa", "pre_rel")
@pytest.mark.id("C2963632")
def test_lock_player_kids(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    # Generate keyword and search for content
    page = Search(driver=driver)
    keyword = ResourceManagerApp.get_random_movie_content("Kids_plus_normal")
    page.search_and_select_first(keyword)

    # Play content
    page = Content(driver=driver)
    page.select_play_button_on_movie_detail()

    page = Player(driver=driver)
    sleep(30)
    page.pause_playing()

    # Pause and select back on player screen
    assert page.is_player_paused()
    page.select_back_button_player()

    # Check if we are back on detail screen
    page = Content(driver=driver)
    assert page.is_watchlist_button_visible()

    # Go back to KIDS search screen
    page.go_back()

    # Go back to KIDS home screen
    page.go_back()

    # Check if application is still unlocked
    assert not is_hamburger_menu_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2963630")
def test_kids_lock_movie_screen(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    # Generate keyword and search for content
    page = Search(driver=driver)
    keyword = ResourceManagerApp.get_random_movie_content("Kids_plus_normal")
    page.search_and_select_first(keyword)

    page = Content(driver=driver, keyword=keyword)

    # Check if  functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert not page.is_rating_button_visible()
    assert page.is_back_button_visible()

    # Check if play button is visible
    assert page.is_play_on_movie_detail_screen_visible()

    # Checking if the appearing details on the UI are the same as those we got from the API call.
    assert page.check_content_details(page.get_movie_content_data_from_ui(),
                                      page.api_mobile.get_movie_content_data_from_api(keyword))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2963631")
def test_kids_lock_series_screen(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    # Generate keyword and search for content
    page = Search(driver=driver)
    keyword = ResourceManagerApp.get_random_series_content("Kids_plus_normal")
    page.search_and_select_first(keyword)

    page = Content(driver=driver, keyword=keyword)

    # Check if  functional buttons are visible
    assert page.is_watchlist_button_visible()
    assert not page.is_rating_button_visible()
    assert page.is_back_button_visible()

    # Checking if the appearing details on the UI are the same as those we got from the API call.
    assert page.check_content_details(page.get_series_content_data_from_ui(),
                                      page.api_mobile.get_series_content_data_from_api(keyword))

    # Checking if the appearing episode details on the UI are the same as those we got from the API call.
    assert page.check_content_details(page.get_episode_metadata_from_ui(),
                                      page.api_mobile.get_episode_metadata_from_api(keyword))


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759154", "C2759153")
@pytest.mark.parametrize("content", [ResourceManagerApp.get_random_movie_content("Kids_plus_normal"),
                                     ResourceManagerApp.get_random_series_content("Kids"),
                                     ResourceManagerApp.get_random_series_content("Kids_plus_normal")])
def test_search_kids(driver, content, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    assert search_content(driver, content)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod","rel","qa", "pre_rel")
@pytest.mark.id("C2759155")
@pytest.mark.parametrize("content", [ResourceManagerApp.get_random_movie_content("Normal"),
                                     ResourceManagerApp.get_random_series_content("Normal")])
def test_search_wrong_content(driver, content, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    page = Search(driver=driver)

    # Check if adult content are not visible in Kids
    assert page.search_no_result(content)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2897982")
def test_parental_pin_mod(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)
    page = Kids(driver)

    page.lock_kids_onboarding()

    assert not is_hamburger_menu_displayed(driver)

    page.select_padlock_button()

    # Provide 3 digits to parental pin
    page.input_parental_pin(parental_pin=543)

    # Application should be locked
    assert not is_hamburger_menu_displayed(driver)

    # Clear all digits using "X" button
    page.input_parental_pin(parental_pin="XXX")

    # Application should be locked
    assert not is_hamburger_menu_displayed(driver)

    # Provide proper Parental Pin
    page.input_parental_pin()

    # Application should be unlocked
    assert is_hamburger_menu_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2897981")
def test_wrong_parental_pin(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)
    page = Kids(driver)

    page.lock_kids_onboarding()

    assert not is_hamburger_menu_displayed(driver)

    page.select_padlock_button()

    # Provide  wrong Parental Pin
    page.input_parental_pin(parental_pin=9876)

    # Error should be visible
    assert page.is_parental_pin_error_visible()

    # Application should still be locked
    assert not is_hamburger_menu_displayed(driver)

    # Provide proper Parental Pin
    page.input_parental_pin()

    # Application should be unlocked
    assert is_hamburger_menu_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2892966")
def test_cancel_lock_kids(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)
    page = Kids(driver)

    # Select never show again option
    page.select_show_never_onboarding_screen()

    # Check if hamburger menu is displayed
    assert is_hamburger_menu_displayed(driver)

    page.select_padlock_button()
    page.select_cancel_lock_kids()

    assert is_hamburger_menu_displayed(driver)


@pytest.mark.platform("ANMO","APMO")
@pytest.mark.env("prod", "prod_pt", "rel","qa", "pre_rel")
@pytest.mark.id("C2892965", "C2889628")
@pytest.mark.category("Smoke")
def test_lock_unlock_kids(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)
    page = Kids(driver)

    # Select never show again option
    page.select_show_never_onboarding_screen()

    # Check if hamburger menu is displayed
    assert is_hamburger_menu_displayed(driver)

    page.select_padlock_button()

    # Assert all of the buttons are there

    assert page.is_cancel_lock_kids_displayed()
    assert page.is_lock_kids_button_displayed()

    # Lock KIds
    page.select_lock_kids()

    assert not is_hamburger_menu_displayed(driver)

    page.select_padlock_button()

    # Provide Parental Pin
    page.input_parental_pin()

    # Check if hamburger menu is displayed
    assert is_hamburger_menu_displayed(driver)
    # Check if search icon is displayed
    assert is_search_icon_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2892963")
def test_never_show_again_functionality_onboarding(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)
    page = Kids(driver)

    # Select never show again option
    page.select_show_never_onboarding_screen()

    # Check if hamburger menu is displayed
    assert is_hamburger_menu_displayed(driver)

    # Close and reopen application
    page.close_and_reopen_application()

    # Check if Search is displayed and application properly loaded
    assert is_search_icon_displayed(driver)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)

    # Check if onboarding screen is not displayed
    assert not page.is_activate_kids_button_onboarding_displayed()
    assert not page.is_description_onboarding_displayed()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2889529")
def test_maybe_later_functionality_onboarding(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)

    page = Kids(driver)

    # Select Maybe Later
    page.select_maybe_later_onboarding()

    # Check if hamburger menu is displayed
    assert is_hamburger_menu_displayed(driver)

    # Close and reopen application
    page.close_and_reopen_application()

    # Check if Search is displayed and application properly loaded
    assert is_search_icon_displayed(driver)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)

    # Check Onboarding screen visual display

    assert page.is_activate_kids_button_onboarding_displayed()
    assert page.is_maybe_later_button_onboarding_displayed()
    assert page.is_show_never_button_onboarding_displayed()
    assert page.is_description_onboarding_displayed()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759209")
def test_maybe_later_functionality_unlock(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # Choose from menu and select KIDS
    select_kids_from_navigation_menu(driver)

    page = Kids(driver)
    page.lock_kids_onboarding()

    page.select_padlock_button()
    # Select Maybe Later
    page.select_maybe_later()

    # Check if hamburger menu is not displayed
    assert not is_hamburger_menu_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2759219", "C2889523", "C2813670", "C2759134")
def test_lock_kids_onboarding(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    # C2759134 Menu redirect
    select_kids_from_navigation_menu(driver)

    page = Kids(driver)

    # Check Onboarding screen visual display
    # C2759219
    assert page.is_activate_kids_button_onboarding_displayed()
    assert page.is_maybe_later_button_onboarding_displayed()
    assert page.is_show_never_button_onboarding_displayed()
    assert page.is_description_onboarding_displayed()

    # Select yes on onboarding screen
    page.lock_kids_onboarding()

    # Unlock screen display
    # C2889523

    # Check if hamburger menu is not displayed
    assert not is_hamburger_menu_displayed(driver)

    # Check if search icon is displayed
    assert is_search_icon_displayed(driver)

    # Check Unlock Kids
    # C2813670
    page.select_padlock_button()

    # Check if all necessary buttons are there
    assert page.is_cancel_unlock_displayed()
    assert page.is_forgot_partental_displayed()

    # Provide Parental Pin
    page.input_parental_pin()

    # Check if hamburger menu is displayed
    assert is_hamburger_menu_displayed(driver)
    # Check if search icon is displayed
    assert is_search_icon_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2813672")
def test_kids_lock_after_going_to_background(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    # Go to background for 5 seconds
    driver.background_app(5)

    # Assert Kids are still locked
    assert not is_hamburger_menu_displayed(driver)


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2813671")
def test_kids_adult_search(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver=driver)
    page.lock_kids_onboarding()

    page = Search(driver=driver)
    # Check searching for adult content in locked kids mode
    assert page.check_adult_keywords_search()


@pytest.mark.platform("ANMO")
@pytest.mark.env("prod", "rel","qa", "pre_rel")
@pytest.mark.id("C2813674")
def test_if_application_is_locked_after_restart(driver, get_proper_user):
    # Logging in and check if login was successful
    assert login_to_application(driver, get_proper_user)

    select_kids_from_navigation_menu(driver)

    # Select yes on onboarding screen
    page = Kids(driver)
    page.lock_kids_onboarding()

    # This is necessary to avoid false negative
    sleep(3)

    # Close and reopen application
    page.close_and_reopen_application()

    # Wait for application to open
    assert is_search_icon_displayed(driver)

    # Check if application is still in kids mode
    assert not is_hamburger_menu_displayed(driver)


