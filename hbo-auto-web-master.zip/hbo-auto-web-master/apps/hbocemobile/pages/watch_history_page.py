from datetime import date
from time import time

from appium.webdriver.common.mobileby import MobileBy
from appium.webdriver.common.touch_action import TouchAction

from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager

from helpers.sleeper import Sleeper as sleep

cm = ConfigManager()


class WatchHistoryAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.watch_history_title = dict(locator="watch_history_title", type=MobileBy.ID)
        self.watch_history_timestamp = dict(locator="watch_history_timestamp", type=MobileBy.ID)
        self.watch_history_seasson = dict(locator="watch_history_season", type=MobileBy.ID)
        self.watch_history_picture = dict(locator="watch_history_thumbnail", type=MobileBy.ID)
        self.watch_history_delete = dict(locator="watch_history_delete_action", type=MobileBy.ID)
        self.watch_history_element = dict(locator="watch_history_main_view_container", type=MobileBy.ID)
        self.watch_history_no_content = dict(locator="no_content_message", type=MobileBy.ID)


class WatchHistoryIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)


class WatchHistory(WatchHistoryAndroid, WatchHistoryIOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            WatchHistoryAndroid.__init__(self, driver)
            self.watch_history = WatchHistoryAndroid
        elif self.platform == "APMO":
            WatchHistoryIOS.__init__(self, driver)
            self.watch_history = WatchHistoryIOS

    def get_visible_watchlist_containers(self):
        return self.page_helper.get_list(locator=self.watch_history_element)

    def get_text_from_watchlist_container_elements(self, mobile_element, property_id):
        return mobile_element.find_element_by_id(property_id).text

    def get_title_from_first_element_on_watchlist(self):
        mobile_element_list = self.get_visible_watchlist_containers()
        return self.get_text_from_watchlist_container_elements(mobile_element_list[0], "watch_history_title")

    def swipe_left_on_first_element(self):
        mobile_element = self.get_visible_watchlist_containers()
        mobile_element_title = mobile_element[0].find_element_by_id("watch_history_title").location
        mobile_element_picture = mobile_element[0].find_element_by_id("watch_history_thumbnail").location

        self.driver.swipe(start_x=mobile_element_title.get("x"), start_y=mobile_element_title.get("y"),
                          end_x=mobile_element_picture.get("x"), end_y=mobile_element_picture.get("y"),
                          duration=650)

    def select_remove_from_watch_history(self):
        self.wait.visible(self.watch_history_delete).click()

    def remove_all_watch_history_elements(self):
        now = time()
        while True and time() < now + 200:
            sleep(1)
            container_list = self.get_visible_watchlist_containers()
            if container_list is None:
                break
            else:
                self.log("Content was removed {}".format(self.get_title_from_first_element_on_watchlist()))
                self.swipe_left_on_first_element()
                self.select_remove_from_watch_history()

    def is_no_content_message_visible(self):
        return self.wait.visible(self.watch_history_no_content)

