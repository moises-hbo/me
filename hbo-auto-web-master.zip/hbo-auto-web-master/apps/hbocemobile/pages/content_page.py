import re
from random import randint

from appium.webdriver.common.mobileby import MobileBy
from appium.webdriver.common.touch_action import TouchAction

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager
from selenium.common.exceptions import WebDriverException, StaleElementReferenceException, \
    ElementClickInterceptedException
from time import time

from helpers.sleeper import Sleeper as sleep

cm = ConfigManager()
rm = ResourceManagerApp()


class ContentAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        # Buttons
        self.content_add_to_watchlist_button = dict(locator="detailsWatchlistView", type=MobileBy.ID)
        self.content_watchlist_snackbar = dict(locator="snackbar_text", type=MobileBy.ID)

        # Rate Button
        self.content_rate_button = dict(locator="detailsRatingHboView", type=MobileBy.ID)
        self.content_rating_stars = dict(locator="android.widget.ImageView", type=MobileBy.CLASS_NAME)
        self.content_rating_submit_button = dict(locator="button_right", type=MobileBy.ID)
        self.content_rating_rate_cancel_button = dict(locator="button_left", type=MobileBy.ID)
        self.content_rate_snackbar = dict(locator="snackbar_text", type=MobileBy.ID)

        # Top metadata
        self.content_title_label = dict(locator="title", type=MobileBy.ID)
        self.content_meta_data_label = dict(locator="metadaText", type=MobileBy.ID)
        self.content_age_rating_label = dict(locator="ageRating", type=MobileBy.ID)
        self.content_imdb_rating_label = dict(locator="ratingImdbText", type=MobileBy.ID)

        # Description
        self.content_short_description_label = dict(locator="shortDescriptionTextView", type=MobileBy.ID)
        self.content_long_description_label = dict(locator="longDescriptionTextView", type=MobileBy.ID)

        self.content_detail_labels = dict(
            locator="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout"
                    "/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android"
                    ".support.v7.widget.RecyclerView/android.view.ViewGroup["
                    "2]/android.view.ViewGroup/android.widget.TextView", type=MobileBy.XPATH)

        # Bottom metadata
        self.content_director_label = dict(locator="valueDirector", type=MobileBy.ID)
        self.content_cast_label = dict(locator="valueCast", type=MobileBy.ID)
        self.content_country_label = dict(locator="valueCountry", type=MobileBy.ID)
        self.content_audio_label = dict(locator="valueAudio", type=MobileBy.ID)
        self.content_subtitle_label = dict(locator="valueSubtitle", type=MobileBy.ID)
        self.content_duration_label = dict(locator="valueDuration", type=MobileBy.ID)
        self.watchlist_items = dict(locator="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout"
                                            "/android.widget.FrameLayout/android.widget.LinearLayout/android.widget"
                                            ".FrameLayout/android.view.ViewGroup/androidx.drawerlayout.widget"
                                            ".DrawerLayout/android.widget.LinearLayout/android.widget.LinearLayout"
                                            "/android.widget.LinearLayout/androidx.viewpager.widget.ViewPager/android"
                                            ".view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.widget"
                                            ".RelativeLayout["
                                            "1]/android.widget.RelativeLayout/android.widget.LinearLayout/android"
                                            ".widget.TextView",
                                    type=MobileBy.XPATH)
        self.content_date_available = dict(locator="valueAvailable", type=MobileBy.ID)
        self.related_stripe_keyarts = dict(locator="iv_thumbnail", type=MobileBy.ID)
        self.related_stripe_title = dict(locator="ctv_stripe_title", type=MobileBy.ID)
        self.episode_detail_dots = dict(locator="iv_dots", type=MobileBy.ID)

    def get_movie_description(self):
        self.wait.visible(element=self.content_short_description_label).click()
        self.d_helper.swipe(direction="Up")
        description = self.wait.visible(element=self.content_long_description_label)
        return description

    def get_series_description(self):
        return self.get_movie_description()

    def select_random_number_of_stars(self):
        stars_list = self.page_helper.get_list(self.content_rating_stars)
        select_stars = randint(1, 5)
        for i in range(select_stars):
            stars_list[i].click()
        self.log("The number of stars selected was: {}".format(select_stars))


class ContentIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        # Buttons
        self.content_add_to_watchlist_button = dict(locator="content-details-watchlist-button",
                                                    type=MobileBy.ACCESSIBILITY_ID)
        # Rate Button
        self.content_rate_button = dict(locator="content-details-rate-button", type=MobileBy.ACCESSIBILITY_ID)
        self.content_rating_stars = dict(locator="star_modal_empty", type=MobileBy.ID)
        self.content_rating_submit_button = dict(locator="content-details-rate-popup-accept",
                                                 type=MobileBy.ACCESSIBILITY_ID)
        self.content_rating_rate_cancel_button = dict(locator="content-details-rate-popup-cancel",
                                                      type=MobileBy.ACCESSIBILITY_ID)
        self.content_rate_snackbar = dict(locator="toast-content-rated", type=MobileBy.ID)

        # Top metadata
        self.content_title_label = dict(locator="content-details-top-metadata-label", type=MobileBy.ACCESSIBILITY_ID)
        self.content_meta_data_label = dict(locator="", type=MobileBy.ID)
        self.content_year_production = dict(locator="content-details-year-of-production-label",
                                            type=MobileBy.ACCESSIBILITY_ID)
        self.content_genera = dict(locator="content-details-genere-label", type=MobileBy.ACCESSIBILITY_ID)
        self.content_age_rating_label = dict(locator="content-details-age-rating-label", type=MobileBy.ID)
        self.content_imdb_rating_label = dict(locator="content-details-imdb-rating-label", type=MobileBy.ID)

        # Description label
        self.description_label_movies = dict(locator="content-details-metadata-description-label",
                                             type=MobileBy.ACCESSIBILITY_ID)
        self.description_lable_episode = dict()
        self.description_label_series = dict(locator="content-details-season-description-label",
                                             type=MobileBy.ACCESSIBILITY_ID)

        # Bottom metadata
        self.content_director_label = dict(locator="content-details-metadata-subtitle-GO5_META_LABEL_DIRECTOR",
                                           type=MobileBy.ACCESSIBILITY_ID)
        self.content_cast_label = dict(locator="content-details-metadata-subtitle-GO5_META_LABEL_CAST",
                                       type=MobileBy.ACCESSIBILITY_ID)
        self.content_country_label = dict(locator="content-details-metadata-subtitle-GO5_META_LABEL_COUNTRY",
                                          type=MobileBy.ACCESSIBILITY_ID)
        self.content_audio_label = dict(locator="content-details-metadata-subtitle-GO5_META_LABEL_AUDIO",
                                        type=MobileBy.ACCESSIBILITY_ID)
        self.content_subtitle_label = dict(locator="content-details-metadata-subtitle-GO5_META_LABEL_SUBTITLE",
                                           type=MobileBy.ACCESSIBILITY_ID)
        self.content_duration_label = dict(locator="content-details-metadata-subtitle-GO5_META_LABEL_DURATION",
                                           type=MobileBy.ACCESSIBILITY_ID)

        self.episode_detail_dots = dict(locator="content-details-episode-item-expand-icon", type=MobileBy.ID)

    def get_movie_description(self):
        description = self.wait.visible(self.description_label_movies)
        description.click()
        self.d_helper.swipe(direction="Up")
        return description

    def get_series_description(self):
        description = self.wait.visible(self.description_label_series)
        description.click()
        return description

    def select_random_number_of_stars(self):
        stars_list = self.page_helper.get_list(self.content_rating_stars)
        select_stars = randint(1, 5)
        for i in range(select_stars):
            location = stars_list[i].location

            actions = TouchAction(self.driver)
            actions.tap(None, location.get("x") + 2, location.get("y"))
            actions.perform()
        self.log("The number of stars selected was: {}".format(select_stars))


class Content(ContentAndroid, ContentIOS):
    def __init__(self, driver, keyword=None):
        self.platform = cm.platform
        self.country_id = cm.country_id

        if self.platform == "ANMO":
            ContentAndroid.__init__(self, driver)
            self.content = ContentAndroid
        elif self.platform == "APMO":
            ContentIOS.__init__(self, driver)
            self.content = ContentIOS

        self.keyword = keyword
        self.show_less_translated = rm.get_translation_from_resources("Showless")

    def check_content_details(self, data_ui, data_api):
        """
        This is the main function.
        Gets the content details from the UI and compares them with the ones from the API call,
        and validates if they are the same.
        :param data_ui dictionary with data taken from ui
        :param data_api dictionary with data taken from api
        :return: True or False
        """
        content_data_ui = data_ui
        to_log = "\nContent data from UI:"
        for key in content_data_ui.keys():
            to_log = to_log + "\n- {}:\t{}".format(key, content_data_ui[key])
        self.log(to_log)

        content_data_api = data_api
        to_log = "\nContent data from API:"
        for key in content_data_ui.keys():
            to_log = to_log + "\n- {}:\t{}".format(key, content_data_api[key])
        self.log(to_log)
        return self.compare_details(ui=content_data_ui, api=content_data_api)

    def get_movie_content_data_from_ui(self):
        """
        Gets the necessary content details from the UI of Movie detail screen.
        Stores them in a dictionary if they are visible.
        :return: dict with the necessary details of the content
        """
        if self.platform == "ANMO":
            meta_data = self.wait.visible(element=self.content_meta_data_label).text
        else:
            genere_text = self.wait.visible(element=self.content_genera).text.lower()
            meta_data = "{} | {}".format(self.wait.visible(element=self.content_year_production).text, genere_text)

        details = {"title": self.wait.visible(element=self.content_title_label).text,
                   "meta_data": meta_data,
                   "age_rating": self.wait.visible(element=self.content_age_rating_label).text}
        imdb_rating_label = self.wait.visible(element=self.content_imdb_rating_label)
        if imdb_rating_label:
            details["imdb_rating"]: float(imdb_rating_label.text)

        description = self.content.get_movie_description(self)
        if description:
            remove_from_description = "   {}".format(self.show_less_translated)
            details["description"] = description.text.strip(remove_from_description)

        self.d_helper.swipe(direction="Up")

        director = self.wait.visible(
            element=self.content_director_label)
        if director:
            details["director"] = director.text
        cast = self.wait.visible(element=self.content_cast_label)
        if cast:
            details["cast"] = cast.text
        country = self.wait.visible(element=self.content_country_label)
        if country:
            details["country"] = country.text
        audio = self.wait.visible(element=self.content_audio_label)
        details["audio"] = audio.text
        subtitle = self.wait.visible(
            element=self.content_subtitle_label)
        details["subtitle"] = subtitle.text
        duration = self.wait.visible(
            element=self.content_duration_label)
        if duration:
            details["duration"] = duration.text

        return details

    def compare_details(self, ui, api):
        """
        Comparing the dictionaries with the details we got from the UI and from the API call.
        :param ui: dict with details from the UI
        :param api: dict with details from the API call
        :return: True if the values of the API dict are the same as the ones of the UI dict, False if not
        """
        self.log("Comparing the detail dictionaries")
        for k in ui.keys():
            if k == "description" and ui[k].lower().replace(" ", "") not in api[k].lower().replace(" ", ""):
                self.log(
                    "Description is not the same:\nUI: {}\nAPI: {}".format(ui[k], api[k]))
                return False
            elif k != "description" and ui[k] != api[k]:
                self.log(
                    "The following values are not the same: {} != {}".format(ui[k], api[k]))
                return False
        return True

    def go_back(self, timeout=10):
        """
        Tries to click the back button on the top left of the screen.
        Had to be done like this because sometimes it finds the button but throws and exception when trying to click it.
        :param timeout: timeout in seconds
        :return: True if clicking back button was successful, False if not
        """
        now = time()
        while time() < now + timeout:
            back_button = self.wait.get(element=self.back_button)
            if back_button:
                try:
                    back_button.click()
                    return True
                except (ElementClickInterceptedException, StaleElementReferenceException, WebDriverException):
                    pass
        return False

    def check_add_to_watchlist(self, results, content_type="1"):
        """
        It tries to a content to the watchlist, then navigates to the watchlist page and checks if it is there.
        content_type:
        ContentTypeNone = 0,
        ContentTypeProduction = 1,
        ContentTypeSeries = 2,
        ContentTypeEpisode = 3,
        ContentTypePromo = 4,
        ContentTypeSeason = 5,
        :return: True if it was successful, False if not
        """
        content_title = results[0].find_element(
            "id", "search_result_top_text").text

        content_data = self.api_mobile.get_raw_content_data_from_api(
            keyword=content_title)

        results[0].click()

        # Clicking watchlist button.
        self.log(
            "Trying to add content ({}) to watchlist...".format(content_title))

        add_to_watchlist_button = self.wait.visible(
            element=self.content_add_to_watchlist_button)
        add_to_watchlist_button.click()
        self.wait.clickable(element=self.content_add_to_watchlist_button)

        watchlist_from_api = self.api_mobile.get_bookmarking().get_watchlist(
            customerid=self.api_mobile.get_user_info().get("customerid"),
            countrycode=self.api_mobile.get_user_info().get("country"),
            catalog="1",
            gotoken=self.api_mobile.get_auth_response()['response_body'][
                "Token"])

        e_id = watchlist_from_api.get("response_body")[0].get("externalId")
        content_from_api = self.api_mobile.get_api_core().content_by_externalid(
            eid=e_id, contenttype=content_type)

        self.log(
            "Content name taken from UI: {} Content name taken from API: {}".format(content_data.get("OriginalName"),
                                                                                    content_from_api.get(
                                                                                        "OriginalName")))
        return content_data.get("Id") == content_from_api.get("Id")

    def get_watchlist_from_ui(self):
        """
        Navigates to the watchlist page and get all the contents and their names.
        :return: dict with a list of the watchlist elements and another list of the titles of the contents
        """

        watchlist_items = self.page_helper.get_list(locator=self.watchlist_items)
        wl_item_texts = [item.text for item in watchlist_items]
        return dict(watchlist_elements=watchlist_items, watchlist_titles=wl_item_texts)

    def delete_everything_from_the_watchlist(self):
        """
        Navigates to the watchlist page and deletes all of the contents from there one by one.
        :return: True if all of the contents are deleted, False if not
        """

        watchlist_not_empty = self.wait.visible(
            element=self.watchlist_items)
        while watchlist_not_empty:
            items = self.page_helper.get_list(locator=self.watchlist_items)
            items[0].click()
            self.add_or_remove_from_watchlist()
            self.go_back()
            watchlist_not_empty = self.wait.visible(
                element=self.watchlist_items)
        return not self.wait.visible(element=self.watchlist_items, timeout=5)

    def add_or_remove_from_watchlist(self):
        """
        Just clicks the watchlist button on the detail page of a content.
        """
        watchlist_button = self.wait.visible(
            element=self.content_add_to_watchlist_button)
        watchlist_button.click()
        self.wait.clickable(element=self.content_add_to_watchlist_button)

    def delete_from_watchlist_ui(self, name=None):
        """
        Gets the watchlist through the UI, and checks if the given content is there or not.
        If it is there, deletes it.
        :param name: string with the keyword or the name of the content you want to delete
        :return: True if deleting was successful, False if not
        """
        if name is None:
            name = self.keyword
        content_data = self.api_mobile.get_raw_content_data_from_api(keyword=name)
        name = content_data.get("EditedName")
        e_id = content_data.get("ExternalId")

        watchlist = self.get_watchlist_from_ui()
        if name in watchlist.get("watchlist_titles"):
            i = watchlist.get("watchlist_titles").index(name)
            watchlist.get("watchlist_elements")[i].click()
            self.add_or_remove_from_watchlist()
            sleep(2)
            return not self.api_mobile.check_if_content_is_on_watchlist(e_id=e_id)
        else:
            self.log("{} is not in the watchlist.".format(name))
            return False

    def is_watchlist_button_visible(self):
        return self.wait.visible(element=self.content_add_to_watchlist_button)

    def is_rating_button_visible(self):
        return self.wait.visible(element=self.content_rate_button)

    def select_rating_button(self):
        self.wait.get(element=self.content_rate_button).click()

    def is_cancel_rate_button_visible(self):
        return self.wait.visible(element=self.content_rating_rate_cancel_button)

    def select_cancel_rate_button(self):
        self.wait.get(element=self.content_rating_rate_cancel_button).click()

    def is_submit_rate_button_visible(self):
        return self.wait.visible(element=self.content_rating_submit_button)

    def select_submit_rate_button(self):
        self.wait.get(element=self.content_rating_submit_button).click()

    def is_search_button_visible(self):
        return self.wait.visible(element=self.search_button)

    def is_back_button_visible(self):
        return self.wait.visible(element=self.back_button)

    def is_play_on_movie_detail_screen_visible(self):
        return self.wait.visible(element=self.content_play_button)

    def is_available_date_visible(self):
        self.d_helper.swipe(direction="Up")
        self.wait.visible(element=self.content_date_available)
        return self.wait.visible(element=self.content_date_available).text != ""

    def select_random_number_of_stars(self):
        return self.content.select_random_number_of_stars(self)

    def is_rate_snackbar_visible(self):
        return self.wait.visible(self.content_rate_snackbar)

    def is_watchlist_snackbar_visible(self):
        return self.wait.visible(self.content_watchlist_snackbar)

    def get_content_name_from_ui(self):
        """
        This function get Title from content Detail Screen, then remove all special characters.
        :return: Return string without special characters
        """
        content_name = self.wait.visible(element=self.content_title_label).text
        return re.sub('[^A-Za-z0-9]+', ' ', content_name)

    def swipe_through_related_stripe(self, swipe_number=1):
        """
        Swipe through related stripe from third element to first one.
        :param swipe_number: the number of times you want to swipe on related stripe
        :return:
        """
        counter = 0
        while counter < swipe_number:
            key_art_list = self.page_helper.get_list(self.related_stripe_keyarts)
            first_element = key_art_list[0].location
            last_element = key_art_list[2].location

            # Swipe left from third to first element.
            self.driver.swipe(start_x=last_element.get("x"), start_y=last_element.get("y"),
                              end_x=first_element.get("x"), end_y=first_element.get("y"),
                              duration=650)
            counter += 1

    def swipe_to_related_stripe(self):
        self.d_helper.swipe_until_found_element(self.related_stripe_title)

    def select_related_stripe_keyart(self, choose_keyart):
        """
        Select keyart from related stripe
        :param choose_keyart: select which keyart from 0-2 you want to select
        """
        key_art_list = self.page_helper.get_list(self.related_stripe_keyarts)
        key_art_list[choose_keyart].click()

    def get_series_content_data_from_ui(self):
        """
        Gets the necessary Series  content details from the UI.
        Stores them in a dictionary if they are visible.
        :return: dict with the necessary details of the content
        """
        if self.platform == "ANMO":
            meta_data = self.wait.visible(element=self.content_meta_data_label).text
        else:
            genere_text = self.wait.visible(element=self.content_genera).text.lower()
            if "talk-show" in genere_text:
                genere_text = genere_text.replace("talk-show", "TALK-SHOW")
            meta_data = "{} | {}".format(self.wait.visible(element=self.content_year_production).text, genere_text)

        details = {"title": self.wait.visible(element=self.content_title_label).text,
                   "meta_data": meta_data,
                   "age_rating": self.wait.visible(element=self.content_age_rating_label).text}
        imdb_rating_label = self.wait.visible(
            element=self.content_imdb_rating_label)
        if imdb_rating_label:
            details["imdb_rating"]: float(imdb_rating_label.text)

        description = self.content.get_series_description(self)
        if description:
            remove_from_description = "   {}".format(self.show_less_translated)
            details["description"] = description.text.strip(remove_from_description)

        return details

    def select_play_button_on_movie_detail(self):
        self.wait.visible(element=self.content_play_button).click()

    def select_watch_list_button_on_movie_detail(self):
        self.wait.visible(element=self.content_add_to_watchlist_button).click()

    def select_play_button_on_series_detail(self, episode=0):
        self.d_helper.swipe("Up")
        episodes_play = self.page_helper.get_list(self.content_series_play_button)
        episodes_play[episode].click()

    def get_episode_metadata_from_ui(self):
        """
        Gets the necessary Series episode content details from the UI.
        Stores them in a dictionary if they are visible.
        By default it looks for the first episode
        :return: dict with the necessary details of the content
        """
        # Select first episode from episode list
        detail_expand_dots = self.page_helper.get_list(self.episode_detail_dots)
        detail_expand_dots[0].click()

        # Swipe to Audio metadata to have all of metadata series visible

        self.d_helper.swipe_until_found_element(locator=self.content_audio_label.get("locator"), no_of_swipes=2,
                                                direction="Up", locator_type=self.content_audio_label.get("type"))

        # Store information in dictionary
        details = {}
        director = self.wait.visible(
            element=self.content_director_label)
        if director:
            details["director"] = director.text
        cast = self.wait.visible(element=self.content_cast_label)
        if cast:
            details["cast"] = cast.text
        country = self.wait.visible(element=self.content_country_label)
        if country:
            details["country"] = country.text
        audio = self.wait.visible(element=self.content_audio_label)
        details["audio"] = audio.text
        subtitle = self.wait.visible(
            element=self.content_subtitle_label)
        if subtitle:
            details["subtitle"] = subtitle.text
        duration = self.wait.visible(
            element=self.content_duration_label)
        if duration:
            details["duration"] = duration.text

        return details
    
    def is_normal_detail_screen_visible(self):
        """
        Check if Watchlist, rate button, search button are visible. 
        :return: True if all of the buttons are visible 
        """
        return all(
            [self.is_watchlist_button_visible(), self.is_rating_button_visible(), self.is_search_button_visible()])
