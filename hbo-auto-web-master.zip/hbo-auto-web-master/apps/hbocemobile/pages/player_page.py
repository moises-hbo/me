import re

from appium.webdriver.common.mobileby import MobileBy
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager
from helpers.sleeper import Sleeper as sleep
from time import strptime

cm = ConfigManager()


class Android(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        # Main Controls upper Bar
        self.back_button = dict(locator="iv_icon_back", type=MobileBy.ID)
        self.title = dict(locator="ctv_title", type=MobileBy.ID)
        self.secondary_title = dict(locator="ctv_subtitle", type=MobileBy.ID)
        self.settings_subtitle_size_button = dict(locator="iv_icon_config", type=MobileBy.ID)
        self.audio_subtitle_button = dict(locator="iv_icon_audiosub", type=MobileBy.ID)
        self.media_chromecast_button = dict(locator="media_route_button", type=MobileBy.ID)
        self.zoom_n_screen_button = dict(locator="iv_zoom", type=MobileBy.ID)

        self.load_icon = dict(locator="clp_loading", type=MobileBy.ID)

        # Main Controls bottom bar
        self.back_15_button = dict(locator="iv_icon_back_15", type=MobileBy.ID)
        self.elapsed_time_label = dict(locator="ctv_elapsed_time", type=MobileBy.ID)
        self.seek_bar = dict(locator="psb_seek_bar", type=MobileBy.ID)
        self.total_time_label = dict(locator="ctv_total_time", type=MobileBy.ID)
        self.previous_episode_button = dict(locator="iv_icon_prev_ep", type=MobileBy.ID)
        self.next_episode_button = dict(locator="iv_icon_next_ep", type=MobileBy.ID)

        self.play_button = dict(
            locator="iv_play_onscreen", type=MobileBy.ID)
        self.pause_button = dict(
            locator="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout"
                    "/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android"
                    ".widget.FrameLayout[3]/android.widget.FrameLayout/android.widget.ImageView",
            type="xpath"
        )

        # This is hidden in application accessibility id that show player SDK status.
        self.player_sdk_status = dict(
            player_play=dict(locator="player_state_play", type=MobileBy.ACCESSIBILITY_ID),
            player_pause=dict(locator="player_state_stop", type=MobileBy.ACCESSIBILITY_ID)
        )

        # After tapped audios_and_subtitles button
        self.save_button = dict(locator="cbtn_secondary", type=MobileBy.ID)

        # Chromecast container
        self.chromecast_container = dict(locator="mr_chooser_list", type=MobileBy.ID)
        self.chromecast_title = dict(locator="mr_chooser_title", type=MobileBy.ID)
        self.chromecast_device_icon = dict(locator="mr_chooser_route_icon", type=MobileBy.ID)
        self.chromecast_list_text = dict(locator="mr_chooser_route_name", type=MobileBy.ID)

        # Continue pop-up
        self.play_from_beginning_button = dict(locator="cbtn_primary", type=MobileBy.ID)
        self.play_from_bookmark_button = dict(locator="cbtn_secondary", type=MobileBy.ID)

        # End of Play
        self.end_of_play_container = dict(locator="rl_eop_root", type=MobileBy.ID)
        self.keyart_holder = dict(locator="thumbnail_end_of_play", type=MobileBy.ID)
        self.end_of_play_counter = dict(locator="thumbnail_end_of_play", type=MobileBy.ID)
        self.end_of_play_next_episode_title = dict(locator="next_episode", type=MobileBy.ID)
        self.cancel_end_of_play = dict(locator="btn_cancel", type=MobileBy.ID)
        self.next_episode_end_of_play = dict(locator="btn_watch_now", type=MobileBy.ID)


class IOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        # This is hidden in application accessibility id that show player SDK status.
        self.player_sdk_status = dict(
            player_play=dict(locator="player-state-play", type=MobileBy.ACCESSIBILITY_ID),
            player_pause=dict(locator="player-state-stop", type=MobileBy.ACCESSIBILITY_ID)
        )

        self.resume_play = dict(locator="Confirm", type=MobileBy.ACCESSIBILITY_ID)


class Player(Android, IOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            Android.__init__(self, driver)
        elif self.platform == "APMO":
            IOS.__init__(self, driver)
        self.screen_size = self.driver.get_window_size()
        self.center = [(int(self.screen_size.get("height") / 2),
                        int(self.screen_size.get("width") / 2))]

    def is_end_of_play_visible(self):
        # This function main responsibility is just wait for end of play
        return self.wait.visible(self.end_of_play_container, timeout=200)

    def is_player_back_button_visible(self):
        return self.wait.visible(self.back_button)

    def is_next_content_title_visible(self):
        return self.wait.visible(self.title)

    def is_chromecast_icon_visible(self):
        return self.wait.visible(self.media_chromecast_button)

    def is_subtitle_size_icon_visible(self):
        return self.wait.visible(self.audio_subtitle_button)

    def is_audio_sub_option_visible(self):
        return self.wait.visible(self.settings_subtitle_size_button)

    def is_back_15s_button_visible(self):
        return self.wait.visible(self.back_15_button)

    def is_elapsed_time_visible(self):
        return self.wait.visible(self.elapsed_time_label)

    def is_progress_bar_visible(self):
        return self.wait.visible(self.seek_bar)

    def is_total_time_visible(self):
        return self.wait.visible(self.total_time_label)

    def is_previous_episode_button_visible(self):
        return self.wait.visible(self.previous_episode_button)

    def is_next_episode_button_visible(self):
        return self.wait.visible(self.next_episode_button)

    def is_secondary_title_visible(self):
        return self.wait.visible(self.secondary_title)

    def select_chromecast_icon(self):
        self.wait.get(self.media_chromecast_button).click()

    def select_next_episode(self):
        self.wait.get(self.next_episode_button).click()

    def select_previous_episode(self):
        self.wait.get(self.previous_episode_button).click()

    def select_play_from_bookmark(self):
        self.wait.get(self.play_from_beginning_button).click()

    def select_play_from_beggining(self):
        self.wait.get(self.play_from_bookmark_button).click()

    def is_continue_watch_displayed(self):
        return self.wait.visible(self.play_from_beginning_button, timeout=15)

    def select_play_from_beginning_if_pop_up_appear(self):
        if self.is_continue_watch_displayed():
            self.select_play_from_beggining()

    def is_keyart_holder_visible(self):
        return self.wait.visible(self.keyart_holder)

    def is_counter_visible(self):
        return self.wait.visible(self.end_of_play_counter, timeout=2)

    def get_next_series_title_text_eop(self):
        return self.wait.get(self.end_of_play_next_episode_title, timeout=2).text

    def is_cancel_button_visible_eop(self):
        return self.wait.visible(self.cancel_end_of_play, timeout=2)

    def is_next_episode_button_eop_visible(self):
        return self.wait.visible(self.next_episode_end_of_play)

    def is_end_of_play_title_displayed(self, series_season, series_episode):

        series_season = int(series_season)
        series_episode = int(series_episode)
        series_next_eop = self.get_next_series_title_text_eop()
        series_episodes_seasons = re.findall(r"[-+]?\d*\.\d+|\d+", series_next_eop)

        self.log("Season: {} = {} Episode: {} = {}".format(series_season, series_episodes_seasons[0], series_episode,
                                                           series_episodes_seasons[1]))
        return all(
            [int(series_episodes_seasons[0]) == series_season, int(series_episodes_seasons[1]) == series_episode])

    def select_watch_now_button(self):
        self.wait.get(self.next_episode_end_of_play).click()

    def select_cancel_end_of_play_button(self):
        self.wait.get(self.cancel_end_of_play).click()

    def play_content_for_20_sec(self):
        # Wait for player to start, adding this helps make player test lees flaky
        sleep(10)
        self.pause_playing()

        start_time = self.get_elapsed_time()
        self.select_play_button_on_player()
        sleep(20)

        self.pause_playing()
        elapsed_time = self.get_elapsed_time()
        return elapsed_time - start_time

    def pause_playing(self):

        # TODO: Player in debug, pre-rel, prod and rel-automation version have additional option. Sending keycode 127
        #  will pause the player, this is for now the only option to pause player and find other icons by id.
        #  That will be stable on all android devices.
        #  More info why this is used in https://hboeurope.atlassian.net/browse/GOANDROID-3542

        self.driver.press_keycode(127)
        self.driver.tap(self.center)

    def un_pause_playing(self):
        self.driver.tap(self.center)
        self.wait.get(self.play_button).click()

    def check_15_seconds_back_button(self):
        # Wait for player to start, adding this helps make player test lees flaky
        sleep(10)
        self.pause_playing()

        start_time = self.get_elapsed_time()
        self.log("Start time: {}".format(start_time))
        self.select_play_button_on_player()

        sleep(15)
        self.pause_playing()
        self.wait.get(element=self.back_15_button).click()
        sleep(1)
        after_back15_button = self.get_elapsed_time()
        self.log(
            "Time after playing for 15 seconds, and then pushed the back_15_seconds button: {}".format(
                after_back15_button))
        return start_time - after_back15_button < 5

    def select_play_button_on_player(self):
        self.wait.visible(element=self.play_button).click()

    def get_elapsed_time(self):
        elapsed_time_list = self.wait.get(element=self.elapsed_time_label).text.split(":")[::-1]
        seconds = [1, 60, 3600]
        return sum(int(a) * b for a, b in zip(elapsed_time_list, seconds))

    def is_player_playing(self):
        # There is different behaviour on iOS, if o content is bookmark set user will see resume play pop-up
        if self.platform == "APMO" and self.wait.visible(self.resume_play, timeout=5):
            self.wait.get(self.resume_play).click()
            sleep(5)
            self.log("There was resume pop-up on player visible ")
        return self.wait.visible(element=self.player_sdk_status.get("player_play"), timeout=30, delay=5)

    def is_player_paused(self):
        return self.wait.visible(element=self.player_sdk_status.get("player_pause"))

    def select_back_button_player(self):
        self.wait.visible(self.back_button).click()

    def is_visible_text_have_proper_time_format(self, mobile_element_text):
        count_format = mobile_element_text.count(":")
        return (
            strptime(mobile_element_text, 'H%:M:%S') if count_format == 2 else strptime(mobile_element_text, '%M:%S'))

    def is_elapsed_time_have_proper_time_format(self):
        return self.is_visible_text_have_proper_time_format(self.wait.get(self.elapsed_time_label).text)

    def is_total_time_have_proper_time_format(self):
        return self.is_visible_text_have_proper_time_format(self.wait.get(self.total_time_label).text)

    def is_chrome_cast_pop_up_visible(self):
        """
        Check if chromecast pop_up is visible with necessary fields
        :return: True if title, device list, and pop-up container is visible
        """
        pop_up_title = self.wait.get(self.chromecast_title).text
        container = self.wait.visible(self.chromecast_container)
        device_list = self.wait.get(self.chromecast_list_text)

        return all([pop_up_title == "Cast to", container, device_list is not None])

    def select_random_place_on_seek_bar(self, percent):
        """
        Stolen from Linus (hboone mobile)
        It will swipe mobile_ce app  on progress bar.
        :param percent: The percent of progress bar we want to swipe to
        """
        progres_bar_element = self.wait.get(self.seek_bar)
        pb_loc = self.page_helper.get_location(progres_bar_element)
        pb_size = self.page_helper.get_size(progres_bar_element)
        start_x, start_y = pb_loc["x"], pb_loc["y"] + (pb_size["height"] / 2)
        pos_x = start_x + (pb_size["width"] * float(f"0.{percent}"))
        self.driver.helper.press_and_drag(progres_bar_element, (pos_x, start_y))

    def get_episode_number_from_secondary_title(self):
        secondary_title = self.wait.get(self.secondary_title).text
        numbers = re.findall(r"[-+]?\d*\.\d+|\d+", secondary_title)
        return int(numbers[1])
