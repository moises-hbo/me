import random
import re

from appium.webdriver.common.mobileby import MobileBy
from apps.hbocemobile.pages.base.page import BasePage
from apps.hbocemobile.pages.navigation_menu_selectors import NavigationSelectors
from helpers.configmanager import ConfigManager
from selenium.common.exceptions import WebDriverException, StaleElementReferenceException, \
    ElementClickInterceptedException, NoSuchElementException
from time import time

cm = ConfigManager()
selectors = NavigationSelectors()


class Android(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.menu_button = dict(locator="navigate_icon_menu", type=MobileBy.ACCESSIBILITY_ID)
        self.expanded_menu_navigation = dict(locator="navigationMenuListView", type=MobileBy.ID)


class IOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.menu_button = dict(locator="navigation-menu-button", type=MobileBy.ACCESSIBILITY_ID)


class Menu(Android, IOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            Android.__init__(self, driver)
        elif self.platform == "APMO":
            IOS.__init__(self, driver)

        self.menu_buttons = selectors.get_proper_menu_selectors()
        self.arrows = selectors.get_proper_expand_arrows_selectors()
        self.sub_buttons = selectors.get_proper_sub_menu_selectors()

    def check_menu_buttons_visibility(self):
        result = True
        for key in self.menu_buttons.keys():
            b = self.wait.get(element=self.menu_buttons.get(key))
            if not b:
                self.log("{} button is not found".format(key))
                result = False
        return result

    def open_menu(self, timeout=10):
        """
        Tries to click the back button on the top left of the screen.
        Had to be done like this because sometimes it finds the button but throws and exception when trying to click it.
        :param timeout: timeout in seconds
        :return: True if clicking back button was successful, False if not
        """
        now = time()
        while time() < now + timeout:
            menu_button = self.wait.get(element=self.menu_button)
            if menu_button:
                try:
                    menu_button.click()
                    return True
                except (ElementClickInterceptedException, StaleElementReferenceException,
                        WebDriverException, NoSuchElementException):
                    pass
        self.log("Hamburger menu button not found")
        return False

    def check_sub_menu_buttons_visibility(self, sub):
        result = True
        sub_button = self.wait.get(element=self.arrows.get(sub))
        sub_button.click()
        for key in self.sub_buttons.get(sub).keys():
            b = self.wait.get(element=self.sub_buttons.get(sub).get(key))
            """There is rare situation when the whole Movie category is not visible, this happen when the screen of 
            android phone is small. When this is happening last/next to last element is None. This small hack was 
            added to avoid this. 
            This is temporary solution as whole of this method should be rebuild later """
            if b is None:
                self.d_helper.swipe()
                b = self.wait.get(element=self.sub_buttons.get(sub).get(key))
                if not b:
                    self.log("{} button is not found".format(key))
                    result = False
        self.d_helper.swipe("down")
        sub_button.click()
        return result

    def navigate_to_menu(self, menu, submenu=None):
        if menu not in self.menu_buttons.keys():
            self.log("No menu with the given name: {}".format(menu))
            return False
        self.open_menu()
        if submenu:
            if submenu not in self.sub_buttons.get(menu).keys():
                self.log("No submenu with the given name: {}".format(submenu))

            self.select_navigation_menu_panel(self.arrows.get(menu))
            self.wait.get(element=self.sub_buttons.get(menu).get(submenu)).click()
        else:
            self.select_navigation_menu_panel(self.menu_buttons.get(menu))

    def select_navigation_menu_panel(self, mobile_element):
        """
        This method was created as a workaround for iOS Navigation bar.
        When Appium click on element with accessibility ID nothing happens.
        That's why for iOS it taps on coordinates where this element is.
        TODO: https://hboeurope.atlassian.net/browse/GOIOS-2549
        :param mobile_element: element we want to select
        """
        if self.platform == "APMO":
            self.tap_element_by_coordinates(mobile_element)
        else:
            self.wait.get(element=mobile_element).click()

    def open_navigation_menu_by_swipe(self):
        """
        Swipes on the edge of the screen to expand menu
        """
        size = self.driver.get_window_size()
        self.log(size.get("width"))
        self.driver.swipe(start_x=0, start_y=size.get("height") / 2,
                          end_x=size.get("width") * 2 / 5, end_y=size.get("height") / 2,
                          duration=650)

    def hide_navigation_menu_by_click_off_screen(self):
        """
        This function take the  x and y coordinates from movies section.
        Then tap on the coordinates plus additional 500 value on x to click off the navigation menu space.
        Could be flaky on different devices.

        """
        element_coordinates = self.d_helper.get_coordinates_of_element(self.arrows.get("movies"))
        element_coordinates[0] = element_coordinates[0] + 500
        self.d_helper.tap_on_screen([(element_coordinates[0], element_coordinates[1])])

    def is_navigation_menu_expanded(self):
        return self.wait.visible(self.expanded_menu_navigation)

    def select_random_sub_category(self, category):
        """
        This function navigates to selected category menu and selects random sub-category"
        """
        random_sub_category = random.choice(list(self.sub_buttons.get(category)))
        self.navigate_to_menu(category, random_sub_category)
        self.log("The {} Movie sub-category was chosen".format(random_sub_category))

    def get_menu_buttons_text_from_ui(self):
        """
        This method get text of menu buttons from UI and return dictionary.
        Api group number is scraped from content description.
        :return: dictionary  with "api group number" : "visible text"
        """
        ui_menu_names = {}
        for key in self.menu_buttons.keys():
            locator_string = self.menu_buttons[key]["locator"]
            b = self.wait.get(element=self.menu_buttons.get(key))
            if not b:
                self.log("{} button is not found".format(key))
            else:
                get_api_number = int(re.search(r'\d+', locator_string).group())
                if self.platform == "ANMO":
                    ui_menu_names[get_api_number] = b.find_element_by_xpath("//android.widget.TextView").text
                else:
                    ui_menu_names[get_api_number] = b.text

        return ui_menu_names
