from appium.webdriver.common.mobileby import MobileBy
from helpers.configmanager import ConfigManager

from apps.hbocemobile.pages.base.page import BasePage

cm = ConfigManager()


class AboutAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.device_name = dict(locator="about_item_DeviceName", type=MobileBy.ACCESSIBILITY_ID)
        self.application_version = dict(locator="about_item_AppVersion", type=MobileBy.ACCESSIBILITY_ID)
        self.system_version = dict(locator="about_item_OsVersion", type=MobileBy.ACCESSIBILITY_ID)
        self.network_status = dict(locator="about_item_NetworkStatus", type=MobileBy.ACCESSIBILITY_ID)


class AboutIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.device_name = dict(locator="GO5_ABOUT_DEVICE_TYPE", type=MobileBy.ACCESSIBILITY_ID)
        self.application_version = dict(locator="GO5_ABOUT_APP_VERSION", type=MobileBy.ACCESSIBILITY_ID)
        self.system_version = dict(locator="GO5_ABOUT_OS_VERSION", type=MobileBy.ACCESSIBILITY_ID)
        self.network_status = dict(locator="GO5_ABOUT_CONNECTION", type=MobileBy.ACCESSIBILITY_ID)


class About(AboutAndroid, AboutIOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            AboutAndroid.__init__(self, driver)
            self.about = AboutAndroid
        elif self.platform == "APMO":
            AboutIOS.__init__(self, driver)
            self.about = AboutIOS

    def is_displayed_device_model_the_same(self):
        """
        Check if model of device is the same as the one displayed on about page
        :return: True if string taken from UI contains that model name, false if not
        """"deviceName"
        ""
        device_model = self.driver.desired_capabilities.get(
            "deviceModel") if self.platform == "ANMO" else self.driver.desired_capabilities.get("deviceName")
        device_model_ui = self.wait.get(element=self.device_name).text
        self.log("Device model is {}, on UI device model is {}".format(device_model, device_model_ui))
        return device_model in device_model_ui

    def is_application_version_displayed(self):
        """
        Check if application version taken from package(apk and ipa) is the same as one displayed on UI
        :return: True if application version is in displayed application string
        """
        application_version = self.wait.get(element=self.application_version).text
        application_version_package = cm.package_info['version']
        self.log("Application version UI is: {}".format(application_version))
        self.log("Application version package is: {}".format(application_version_package))

        return application_version_package in application_version

    def is_displayed_system_version_the_same(self):
        """
        Check if platform version is the same as the one displayed on about page
        :return: True if string taken from UI contains the version number false if not
        """
        device_platform_version = self.driver.desired_capabilities.get("platformVersion")
        device_platform_version_ui = self.wait.get(element=self.system_version).text
        self.log("Device platform version is {}, on UI platform version is {}"
                 .format(device_platform_version, device_platform_version_ui))
        return device_platform_version in device_platform_version_ui

    def is_displayed_connection_the_same(self):
        """
        Check if connections is displayed properly. Currently the kind of connection is hardcoded to "wifi"
        as taking the connection from device seems to be problematic.
        :return: True if on UI connection is wifi false if not
        """
        device_connection = "wifi"
        device_connection_ui = self.wait.get(element=self.network_status).text
        self.log(
            "Device connection is {}, on UI connection is {}".format(device_connection, device_connection_ui))

        return device_connection in device_connection_ui.lower()
