from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager

cm = ConfigManager()


class DeepLinkAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)


class DeepLinkIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)


class DeepLink(DeepLinkAndroid, DeepLinkIOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            DeepLinkAndroid.__init__(self, driver)
        elif self.platform == "APMO":
            DeepLinkIOS.__init__(self, driver)

    def get_and_run_proper_deeplink(self, group_id):
        self.driver.get("hbogo://group/?id={}".format(group_id))
