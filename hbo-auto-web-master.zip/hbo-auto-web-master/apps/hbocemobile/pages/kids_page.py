from appium.webdriver.common.mobileby import MobileBy
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager

cm = ConfigManager()


class Android(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.padlock_button = dict(locator="kidsLock", type=MobileBy.ID)

        # Onboarding screen
        self.lock_onboarding_button = dict(locator="cbtn_primary", type=MobileBy.ID)
        self.later_onboarding_button = dict(locator="cbtn_secondary", type=MobileBy.ID)
        self.dont_show_again_onboarding_button = dict(locator="cbtn_tertiary", type=MobileBy.ID)
        self.onboarding_title = dict(locator="ctv_title", type=MobileBy.ID)
        self.onboarding_description = dict(locator="ctv_message", type=MobileBy.ID)

        # Parental Pin screen
        self.decline_unlock_parental_button = dict(locator="cbtn_primary", type=MobileBy.ID)
        self.forgot_parental_pin_button = dict(locator="recover_pin_button", type=MobileBy.ID)

        # Lock screen
        self.lock_kids_button = dict(locator="cbtn_primary", type=MobileBy.ID)
        self.cancel_lock_button = dict(locator="cbtn_secondary", type=MobileBy.ID)

        # Pin error
        self.parental_pin_error = dict(locator="snackbar_text", type=MobileBy.ID)

        # Character
        self.characters_keyart = dict(locator="iv_character", type=MobileBy.ID)


class IOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        # Onboarding screen
        self.lock_onboarding_button = dict(locator="GO5_BUTTON_ENTERKIDSMODE", type=MobileBy.ACCESSIBILITY_ID)
        self.later_onboarding_button = dict(locator="GO5_BUTTON_MAYBELATER", type=MobileBy.ACCESSIBILITY_ID)
        self.dont_show_again_onboarding_button = dict(locator="GO5_BUTTON_MAYBELATER", type=MobileBy.ACCESSIBILITY_ID)
        self.padlock_button = dict(locator="navigation-lock-button", type=MobileBy.ACCESSIBILITY_ID)

        # Parental Pin screen
        # TODO: Missing:
        self.decline_unlock_parental_button = dict(locator="", type=MobileBy.ID)

        self.forgot_parental_pin_button = dict(locator="GO5_BUTTON_FORGOTPARENTALPIN", type=MobileBy.ID)

        # Lock screen
        self.lock_kids_button = dict(locator="GO5_KIDS_BUTTON_ACTIVATE", type=MobileBy.ACCESSIBILITY_ID)
        self.cancel_lock_button = dict(locator="GO5_KIDS_BUTTON_LATER", type=MobileBy.ACCESSIBILITY_ID)



class Kids(Android, IOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            Android.__init__(self, driver)
        elif self.platform == "APMO":
            IOS.__init__(self, driver)

    def is_parental_pin_error_visible(self):
        return self.wait.visible(self.parental_pin_error)

    def is_activate_kids_button_onboarding_displayed(self):
        return self.wait.visible(self.lock_onboarding_button)

    def is_maybe_later_button_onboarding_displayed(self):
        return self.wait.visible(self.later_onboarding_button)

    def select_maybe_later_onboarding(self):
        self.wait.get(self.later_onboarding_button).click()

    def is_show_never_button_onboarding_displayed(self):
        return self.wait.visible(self.dont_show_again_onboarding_button)

    def is_description_onboarding_displayed(self):
        return self.wait.visible(self.onboarding_description)

    def select_show_never_onboarding_screen(self):
        self.wait.get(element=self.dont_show_again_onboarding_button).click()

    def is_forgot_partental_displayed(self):
        return self.wait.visible(self.forgot_parental_pin_button)

    def is_cancel_unlock_displayed(self):
        return self.wait.visible(self.decline_unlock_parental_button)

    def is_lock_kids_button_displayed(self):
        return self.wait.visible(self.lock_kids_button)

    def is_cancel_lock_kids_displayed(self):
        return self.wait.visible(self.cancel_lock_button)

    def select_padlock_button(self):
        self.wait.get(element=self.padlock_button).click()

    def is_padlock_button_displayed(self):
        return self.wait.visible(element=self.padlock_button)

    def select_maybe_later(self):
        self.wait.get(element=self.decline_unlock_parental_button).click()

    def lock_kids_onboarding(self):
        self.wait.get(element=self.lock_onboarding_button).click()

    def select_lock_kids(self):
        self.wait.get(element=self.lock_kids_button).click()

    def select_cancel_lock_kids(self):
        self.wait.get(element=self.cancel_lock_button).click()

    def unlock_kids_mode(self):
        self.select_padlock_button()
        self.input_parental_pin()

    def input_parental_pin(self, parental_pin=1111):
        self.wait.visible(self.is_forgot_partental_displayed())
        for i in list(str(parental_pin)):
            if self.platform == "ANMO":
                self.driver.find_element("id", ("button" + i)).click()
            else:
                self.driver.find_element("id", i).click()

    def is_characters_keyarts_visible(self):
        """
        Check if characters keyart are visible
        :return: True if more than four are visible
        """
        characters_stripe = self.page_helper.get_list(self.characters_keyart)
        return len(characters_stripe) > 4
