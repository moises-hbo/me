from helpers.sleeper import Sleeper as sleep

from appium.webdriver.common.mobileby import MobileBy
from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.helpers.api_mobile import ApiMobile
from apps.hbocemobile.helpers.driver_helper import DriverHelperMobileCE
from helpers.configmanager import ConfigManager
from helpers.logger import Log
from helpers.pagehelper import PageHelper
from helpers.wait import Wait

cm = ConfigManager()


class BasePageObjectAndroid(object):
    def __init__(self, driver):
        self.content_play_button = dict(locator="iv_keyart_play_button", type=MobileBy.ID)
        self.content_series_play_button = dict(locator="iv_normal_play_icon", type=MobileBy.ID)
        self.search_button = dict(locator="search", type=MobileBy.ID)

        self.back_button = dict(locator="navigate_icon_back", type=MobileBy.ACCESSIBILITY_ID)


class BasePageObjectiOS(object):
    def __init__(self, driver):
        self.content_play_button = dict(locator="content-details-keyart-play-button", type=MobileBy.ID)
        self.content_series_play_button = dict(locator="play", type=MobileBy.ACCESSIBILITY_ID)
        self.search_button = dict(locator="navigation-search", type=MobileBy.ACCESSIBILITY_ID)
        self.back_button = dict(locator="navigation-back-button", type=MobileBy.ACCESSIBILITY_ID)


class BasePage(BasePageObjectAndroid, BasePageObjectiOS):
    def __init__(self, driver):
        self.driver = driver
        self.error = Log(loglevel=Log.ERROR)
        self.log = Log(loglevel=Log.INFO)
        self.page_helper = PageHelper(driver=self.driver)
        self.wait = Wait(driver=driver, timeout=30, delay=0.5)
        self.d_helper = DriverHelperMobileCE(driver=self.driver)
        self.api_mobile = ApiMobile()

        if cm.platform == "ANMO":
            BasePageObjectAndroid.__init__(self, driver)
        elif cm.platform == "APMO":
            BasePageObjectiOS.__init__(self, driver)

    def switch_context(self, webview=False):
        """
        If false - context will switch to native app, if true context will switch to webview
        """
        native_app = "NATIVE_APP"
        if cm.platform == "ANMO":
            webview_string = ResourceManagerApp.get_app_info().get("webview")
        elif cm.platform == "APMO":
            sleep(5)
            self.log("List of available WEBVIEWS {}".format(self.driver.contexts))
            webview_string = self.driver.contexts[-1]
        else:
            webview_string = False
            self.log("Something go wrong, platform was not provided")

        self.driver.switch_to.context(webview_string) if webview else self.driver.switch_to.context(native_app)

    def percentage(self, percent, number):
        """
        Count percentage of provided number
        """
        return (percent * number) / 100.0

    def close_and_reopen_application(self):
        self.driver.close_app()
        self.driver.activate_app(ResourceManagerApp.get_app_info().get("name"))

    def select_android_back_button(self):
        self.driver.press_keycode(4)

    def select_home_android_button(self):
        self.driver.press_keycode(3)

    def compare_data(self, data_ui, data_api):
        """
        This function compare two dictionaries and check if they are the same.
        :param data_ui: dictionary that provide data from UI
        :param data_api: dictionary that provided data from API
        :return: true if the dictionaries are identical
        """
        content_data_ui = data_ui
        to_log = "\nContent data from UI:"
        for key in content_data_ui.keys():
            to_log = to_log + "\n- {}:\t{}".format(key, content_data_ui[key])
        self.log(to_log)

        content_data_api = data_api
        to_log = "\nContent data from API:"
        for key in content_data_api.keys():
            to_log = to_log + "\n- {}:\t{}".format(key, content_data_api[key])
        self.log(to_log)

        return content_data_ui == content_data_api

    def input_text_to_field(self, locator_or_element, text, timeout=10):
        """Write text on element (assumes it's an input field)."""
        element = self.wait.get(element=locator_or_element, timeout=timeout)
        element.send_keys(text)

    def tap_element_by_coordinates(self, mobile_element):
        element_coordinates = self.d_helper.get_coordinates_of_element(mobile_element)
        self.d_helper.tap_on_screen([(element_coordinates[0], element_coordinates[1])])

    def is_keyboard_displayed(self):
        """Check if keyboard is displayed"""
        self.log("Check if keyboard is visible\n")
        return self.driver.is_keyboard_shown()

    def remove_application(self):
        """Remove application from android device"""
        package_name = cm.package_info['package']
        self.log("Remove application: {}".format(package_name))
        self.driver.close_app()
        self.driver.remove_app(package_name)
