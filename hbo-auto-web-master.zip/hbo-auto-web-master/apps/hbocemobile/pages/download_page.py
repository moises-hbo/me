from appium.webdriver.common.mobileby import MobileBy

from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager

cm = ConfigManager()


class Android(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.no_content_message = dict(locator="messageTextView", type=MobileBy.ID)
        self.kids_switch = dict(locator="kidsSwitch", type=MobileBy.ID)


class IOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.no_content_message = dict(locator="GO5_TEXT_DOWNLOADS", type=MobileBy.ACCESSIBILITY_ID)
        self.kids_switch = dict(locator="download-mode-switch", type=MobileBy.ACCESSIBILITY_ID)


class Download(Android, IOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            Android.__init__(self, driver)
        elif self.platform == "APMO":
            IOS.__init__(self, driver)

    def is_no_content_message_displayed(self):
        return self.wait.visible(self.no_content_message)

    def is_kids_switch_visible(self):
        return self.wait.visible(self.kids_switch)

    def select_kids_switch(self):
        self.wait.get(self.kids_switch).click()
