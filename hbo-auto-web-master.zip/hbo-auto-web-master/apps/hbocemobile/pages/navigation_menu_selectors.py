from appium.webdriver.common.mobileby import MobileBy

from helpers.configmanager import ConfigManager

cm = ConfigManager()


class NavigationSelectors(object):
    def __init__(self):
        self.menu_buttons_android = dict(
            home=dict(locator="menu_list_item_200", type=MobileBy.ACCESSIBILITY_ID),
            series=dict(locator="menu_list_item_300", type=MobileBy.ACCESSIBILITY_ID),
            movies=dict(locator="menu_list_item_400", type=MobileBy.ACCESSIBILITY_ID),
            kids=dict(locator="menu_list_item_468", type=MobileBy.ACCESSIBILITY_ID),
            downloads=dict(locator="menu_list_item_475", type=MobileBy.ACCESSIBILITY_ID),
            settings=dict(locator="menu_list_item_500", type=MobileBy.ACCESSIBILITY_ID),
            help=dict(locator="menu_list_item_505", type=MobileBy.ACCESSIBILITY_ID),
            about=dict(locator="menu_list_item_535", type=MobileBy.ACCESSIBILITY_ID)
        )

        self.menu_buttons_portugal_android = dict(
            home=dict(locator="menu_list_item_300", type=MobileBy.ACCESSIBILITY_ID),
            series=dict(locator="menu_list_item_400", type=MobileBy.ACCESSIBILITY_ID),
            movies=dict(locator="menu_list_item_500", type=MobileBy.ACCESSIBILITY_ID),
            kids=dict(locator="menu_list_item_600", type=MobileBy.ACCESSIBILITY_ID),
            downloads=dict(locator="menu_list_item_899", type=MobileBy.ACCESSIBILITY_ID),
            settings=dict(locator="menu_list_item_901", type=MobileBy.ACCESSIBILITY_ID),
            help=dict(locator="menu_list_item_902", type=MobileBy.ACCESSIBILITY_ID),
            about=dict(locator="menu_list_item_908", type=MobileBy.ACCESSIBILITY_ID)
        )

        self.arrows_android = dict(
            home=dict(
                locator="//android.view.ViewGroup[@content-desc='menu_list_item_200']/android.widget.ImageView[2]",
                type=MobileBy.XPATH),
            series=dict(
                locator="//android.view.ViewGroup[@content-desc='menu_list_item_300']/android.widget.ImageView[2]",
                type=MobileBy.XPATH),
            movies=dict(
                locator="//android.view.ViewGroup[@content-desc='menu_list_item_400']/android.widget.ImageView[2]",
                type=MobileBy.XPATH)
        )

        self.arrows_portugal_android = dict(
            home=dict(
                locator="//android.view.ViewGroup[@content-desc='menu_list_item_300']/android.widget.ImageView[2]",
                type=MobileBy.XPATH),
            series=dict(
                locator="//android.view.ViewGroup[@content-desc='menu_list_item_400']/android.widget.ImageView[2]",
                type=MobileBy.XPATH),
            movies=dict(
                locator="//android.view.ViewGroup[@content-desc='menu_list_item_500']/android.widget.ImageView[2]",
                type=MobileBy.XPATH)
        )


        #TODO: "This is some nice easter egg on hungary watchlist group have diffrent ID"
        self.watch_history_locator = "menu_list_subitem_280" if cm.country_id == "hu" else "menu_list_subitem_275"

        self.sub_buttons_android = dict(
            home=dict(
                watchlist=dict(
                    locator="menu_list_subitem_205", type=MobileBy.ACCESSIBILITY_ID, label="watchlist"),
                continue_watching=dict(
                    locator="menu_list_subitem_210", type=MobileBy.ACCESSIBILITY_ID, label="continue watching"),
                featured=dict(
                    locator="menu_list_subitem_215", type=MobileBy.ACCESSIBILITY_ID, label="featured"),
                recently_added=dict(
                    locator="menu_list_subitem_220", type=MobileBy.ACCESSIBILITY_ID, label="recently added"),
                most_popular=dict(
                    locator="menu_list_subitem_225", type=MobileBy.ACCESSIBILITY_ID, label="most popular"),
                imdb_toplist=dict(
                    locator="menu_list_subitem_230", type=MobileBy.ACCESSIBILITY_ID, label="imdb toplist"),
                disney=dict(
                    locator="menu_list_subitem_250", type=MobileBy.ACCESSIBILITY_ID, label="disney"),
                last_chance_to_see=dict(
                    locator="menu_list_subitem_260", type=MobileBy.ACCESSIBILITY_ID, label="last chance to see"),
                coming_soon=dict(
                    locator="menu_list_subitem_265", type=MobileBy.ACCESSIBILITY_ID, label="coming soon"),
                watch_history=dict(
                    locator=self.watch_history_locator, type=MobileBy.ACCESSIBILITY_ID, label="watch history")),
            series=dict(
                drama=dict(
                    locator="menu_list_subitem_305", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="menu_list_subitem_310", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                crime_and_thriller=dict(
                    locator="menu_list_subitem_315", type=MobileBy.ACCESSIBILITY_ID, label="crime and thriller"),
                scifi_and_fantasy=dict(
                    locator="menu_list_subitem_320", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy"),
                documentary=dict(
                    locator="menu_list_subitem_330", type=MobileBy.ACCESSIBILITY_ID, label="documentary"),
                extra=dict(
                    locator="menu_list_subitem_340", type=MobileBy.ACCESSIBILITY_ID, label="extra"),
                weekly_shows=dict(
                    locator="menu_list_subitem_345", type=MobileBy.ACCESSIBILITY_ID, label="weekly shows")),
            movies=dict(
                action_and_adventure=dict(
                    locator="menu_list_subitem_405", type=MobileBy.ACCESSIBILITY_ID, label="action and adventure"),
                drama=dict(
                    locator="menu_list_subitem_410", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="menu_list_subitem_415", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                crime=dict(
                    locator="menu_list_subitem_420", type=MobileBy.ACCESSIBILITY_ID, label="crime"),
                romance=dict(
                    locator="menu_list_subitem_425", type=MobileBy.ACCESSIBILITY_ID, label="romance"),
                thriller_horror=dict(
                    locator="menu_list_subitem_430", type=MobileBy.ACCESSIBILITY_ID, label="thriller, horror"),
                scifi_and_fantasy=dict(
                    locator="menu_list_subitem_435", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy"),
                documentary=dict(
                    locator="menu_list_subitem_445", type=MobileBy.ACCESSIBILITY_ID, label="documentary"),
                music=dict(
                    locator="menu_list_subitem_450", type=MobileBy.ACCESSIBILITY_ID, label="music"),
                extra=dict(
                    locator="menu_list_subitem_460", type=MobileBy.ACCESSIBILITY_ID, label="extra"))
        )
        # TODO: This list is incomplete, add  more selectors later
        self.sub_buttons_portugal_android = dict(
            home=dict(
                watchlist=dict(
                    locator="menu_list_subitem_302", type=MobileBy.ACCESSIBILITY_ID, label="watchlist"),
                continue_watching=dict(
                    locator="menu_list_subitem_304", type=MobileBy.ACCESSIBILITY_ID, label="continue watching"),
                featured=dict(
                    locator="menu_list_subitem_306", type=MobileBy.ACCESSIBILITY_ID, label="featured"),
                recently_added=dict(
                    locator="menu_list_subitem_318", type=MobileBy.ACCESSIBILITY_ID, label="recently added"),
                watch_history=dict(
                    locator="menu_list_subitem_399", type=MobileBy.ACCESSIBILITY_ID, label="watch history")),
            series=dict(
                drama=dict(
                    locator="menu_list_subitem_416", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="menu_list_subitem_418", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                scifi_and_fantasy=dict(
                    locator="menu_list_subitem_414", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy")),
            movies=dict(
                action_and_adventure=dict(
                    locator="menu_list_subitem_504", type=MobileBy.ACCESSIBILITY_ID, label="action and adventure"),
                drama=dict(
                    locator="menu_list_subitem_508", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="menu_list_subitem_510", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                crime=dict(
                    locator="menu_list_subitem_520", type=MobileBy.ACCESSIBILITY_ID, label="crime"),
                thriller_horror=dict(
                    locator="menu_list_subitem_522", type=MobileBy.ACCESSIBILITY_ID, label="thriller, horror"),
                scifi_and_fantasy=dict(
                    locator="menu_list_subitem_506", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy"))
        )

        self.menu_buttons_ios = dict(
            home=dict(locator="menu-200", type=MobileBy.ACCESSIBILITY_ID),
            series=dict(locator="menu-300", type=MobileBy.ACCESSIBILITY_ID),
            movies=dict(locator="menu-400", type=MobileBy.ACCESSIBILITY_ID),
            kids=dict(locator="menu-468", type=MobileBy.ACCESSIBILITY_ID),
            downloads=dict(locator="menu-475", type=MobileBy.ACCESSIBILITY_ID),
            settings=dict(locator="menu-500", type=MobileBy.ACCESSIBILITY_ID),
            help=dict(locator="menu-505", type=MobileBy.ACCESSIBILITY_ID),
            about=dict(locator="menu-535", type=MobileBy.ACCESSIBILITY_ID)
        )

        self.menu_buttons_ios_portugal = dict(
            home=dict(locator="menu-300", type=MobileBy.ACCESSIBILITY_ID),
            series=dict(locator="menu-400", type=MobileBy.ACCESSIBILITY_ID),
            movies=dict(locator="menu-500", type=MobileBy.ACCESSIBILITY_ID),
            kids=dict(locator="menu-600", type=MobileBy.ACCESSIBILITY_ID),
            downloads=dict(locator="menu-899", type=MobileBy.ACCESSIBILITY_ID),
            settings=dict(locator="menu-901", type=MobileBy.ACCESSIBILITY_ID),
            help=dict(locator="menu-902", type=MobileBy.ACCESSIBILITY_ID),
            about=dict(locator="menu-908", type=MobileBy.ACCESSIBILITY_ID)
        )

        self.arrows_ios = dict(
            home=dict(locator="menu-200-expand-button", type=MobileBy.ACCESSIBILITY_ID),
            series=dict(locator="menu-300-expand-button", type=MobileBy.ACCESSIBILITY_ID),
            movies=dict(locator="menu-400-expand-button", type=MobileBy.ACCESSIBILITY_ID)
        )

        self.arrows_portugal_ios = dict(
            home=dict(locator="menu-300-expand-button", type=MobileBy.ACCESSIBILITY_ID),
            series=dict(locator="menu-400-expand-button", type=MobileBy.ACCESSIBILITY_ID),
            movies=dict(locator="menu-500-expand-button", type=MobileBy.ACCESSIBILITY_ID)
        )

        self.sub_buttons_ios = dict(
            home=dict(
                watchlist=dict(
                    locator="sub-205", type=MobileBy.ACCESSIBILITY_ID, label="watchlist"),
                continue_watching=dict(
                    locator="sub-210", type=MobileBy.ACCESSIBILITY_ID, label="continue watching"),
                featured=dict(
                    locator="sub-215", type=MobileBy.ACCESSIBILITY_ID, label="featured"),
                recently_added=dict(
                    locator="sub-220", type=MobileBy.ACCESSIBILITY_ID, label="recently added"),
                most_popular=dict(
                    locator="sub-225", type=MobileBy.ACCESSIBILITY_ID, label="most popular"),
                imdb_toplist=dict(
                    locator="sub-230", type=MobileBy.ACCESSIBILITY_ID, label="imdb toplist"),
                disney=dict(
                    locator="sub-250", type=MobileBy.ACCESSIBILITY_ID, label="disney"),
                last_chance_to_see=dict(
                    locator="sub-260", type=MobileBy.ACCESSIBILITY_ID, label="last chance to see"),
                coming_soon=dict(
                    locator="sub-265", type=MobileBy.ACCESSIBILITY_ID, label="coming soon"),
                watch_history=dict(
                    locator="sub-280", type=MobileBy.ACCESSIBILITY_ID, label="watch history")),
            series=dict(
                drama=dict(
                    locator="sub-305", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="sub-310", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                crime_and_thriller=dict(
                    locator="sub-315", type=MobileBy.ACCESSIBILITY_ID, label="crime and thriller"),
                scifi_and_fantasy=dict(
                    locator="sub-320", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy"),
                documentary=dict(
                    locator="sub-330", type=MobileBy.ACCESSIBILITY_ID, label="documentary"),
                extra=dict(
                    locator="sub-340", type=MobileBy.ACCESSIBILITY_ID, label="extra"),
                weekly_shows=dict(
                    locator="sub-345", type=MobileBy.ACCESSIBILITY_ID, label="weekly shows")),
            movies=dict(
                action_and_adventure=dict(
                    locator="sub-405", type=MobileBy.ACCESSIBILITY_ID, label="action and adventure"),
                drama=dict(
                    locator="sub-410", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="sub-415", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                crime=dict(
                    locator="sub-420", type=MobileBy.ACCESSIBILITY_ID, label="crime"),
                romance=dict(
                    locator="sub-425", type=MobileBy.ACCESSIBILITY_ID, label="romance"),
                thriller_horror=dict(
                    locator="sub-430", type=MobileBy.ACCESSIBILITY_ID, label="thriller, horror"),
                scifi_and_fantasy=dict(
                    locator="sub-435", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy"),
                documentary=dict(
                    locator="sub-445", type=MobileBy.ACCESSIBILITY_ID, label="documentary"),
                music=dict(
                    locator="sub-450", type=MobileBy.ACCESSIBILITY_ID, label="music"),
                extra=dict(
                    locator="sub-460", type=MobileBy.ACCESSIBILITY_ID, label="extra"))
        )

        self.sub_buttons_portugal_ios = dict(
            home=dict(
                watchlist=dict(
                    locator="sub-302", type=MobileBy.ACCESSIBILITY_ID, label="watchlist"),
                continue_watching=dict(
                    locator="sub-304", type=MobileBy.ACCESSIBILITY_ID, label="continue watching"),
                featured=dict(
                    locator="sub-306", type=MobileBy.ACCESSIBILITY_ID, label="featured"),
                recently_added=dict(
                    locator="sub-318", type=MobileBy.ACCESSIBILITY_ID, label="recently added"),
                watch_history=dict(
                    locator="sub-399", type=MobileBy.ACCESSIBILITY_ID, label="watch history")),
            series=dict(
                drama=dict(
                    locator="sub-416", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="sub-418", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                scifi_and_fantasy=dict(
                    locator="sub-414", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy")),
            movies=dict(
                action_and_adventure=dict(
                    locator="sub-504", type=MobileBy.ACCESSIBILITY_ID, label="action and adventure"),
                drama=dict(
                    locator="sub-508", type=MobileBy.ACCESSIBILITY_ID, label="drama"),
                comedy=dict(
                    locator="sub-510", type=MobileBy.ACCESSIBILITY_ID, label="comedy"),
                crime=dict(
                    locator="sub-520", type=MobileBy.ACCESSIBILITY_ID, label="crime"),
                thriller_horror=dict(
                    locator="sub-522", type=MobileBy.ACCESSIBILITY_ID, label="thriller, horror"),
                scifi_and_fantasy=dict(
                    locator="sub-506", type=MobileBy.ACCESSIBILITY_ID, label="sci-fi and fantasy"))
        )

    def general_selector_method(self, selectors_array):

        """
        General method to get proper selectors for navigation menu.
        :param selectors_array: take array of dictionary with all of the selectors for right part of application.
        :return: dictionary with right selectors for currently used platform
        """
        if cm.platform == "ANMO" and cm.country_id != "pt":
            return selectors_array[0]
        elif cm.platform == "ANMO" and cm.country_id == "pt":
            return selectors_array[1]
        elif cm.platform == "APMO" and cm.country_id != "pt":
            return selectors_array[2]
        elif cm.platform == "APMO" and cm.country_id == "pt":
            return selectors_array[3]
        else:
            print("Something go wrong")

    def get_proper_menu_selectors(self):
        """
        Get proper dictionary with selectors depending if this is iOS CE,
        iOS Portugal ora Android CE or Android Portugal
        :return: dictionary with navigation menu selectors
        """

        return self.general_selector_method([self.menu_buttons_android, self.menu_buttons_portugal_android,
                                             self.menu_buttons_ios, self.menu_buttons_ios_portugal])

    def get_proper_sub_menu_selectors(self):
        """
        Get proper dictionary with selectors depending if this is iOS CE,
        iOS Portugal ora Android CE or Android Portugal
        :return: dictionary with sub-menu elements
        """

        return self.general_selector_method([self.sub_buttons_android, self.sub_buttons_portugal_android,
                                             self.sub_buttons_ios, self.sub_buttons_portugal_ios])

    def get_proper_expand_arrows_selectors(self):
        """
        Get proper dictionary with selectors depending if this is iOS CE,
        iOS Portugal ora Android CE or Android Portugal
        :return: dictionary with expand arrows selectors
        """
        return self.general_selector_method([self.arrows_android, self.arrows_portugal_android,
                                             self.arrows_ios, self.arrows_portugal_ios])
