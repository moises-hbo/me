import time
from helpers.sleeper import Sleeper as sleep

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager
from appium.webdriver.common.mobileby import MobileBy

cm = ConfigManager()
rm = ResourceManagerApp()


class AuthAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.operator_selector = dict(locator="//*[@id='operatorselector']", type=MobileBy.XPATH)
        self.search_button = dict(locator="search", type=MobileBy.ID)
        self.continue_button = dict(locator="b_country_selector_next", type=MobileBy.ID)
        self.signin_button = dict(locator="sign_in_button", type=MobileBy.ID)
        self.country = dict(locator="ctv_title", type=MobileBy.ID)
        self.operators = dict(locator="android:id/text1", type=MobileBy.ID)
        self.menu_button = dict(locator="//android.widget.ImageButton", type=MobileBy.XPATH)
        self.warning_msg = dict(locator="//*[@class='hbo-message']", type=MobileBy.XPATH)
        self.forgotten_password = dict(locator="//*[@id='hbo_login_registration_reset_password_modal']",
                                       type=MobileBy.XPATH)
        self.forgotten_password_email_input = dict(
            locator="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/"
                    "android.widget.FrameLayout/android.widget.LinearLayout/"
                    "android.widget.FrameLayout/android.widget.RelativeLayout/"
                    "android.webkit.WebView/android.webkit.WebView/android.view.View/"
                    "android.view.View[4]/android.view.View/android.view.View[6]/"
                    "android.view.View[2]/android.view.View[1]/android.view.View[3]/"
                    "android.view.View/android.view.View[2]/android.widget.EditText",
            type=MobileBy.XPATH
        )
        self.forgotten_password_finish_button = dict(locator="//*[@id='gw_mailpassreset_04_send']", type=MobileBy.XPATH)
        self.forgotten_password_cancel_button = dict(
            locator="//*[@id='hbo_login_registration_reset_password_modal_cancel']",
            type=MobileBy.XPATH)
        self.invalid_mail_or_password_hint = dict(
            locator="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/"
                    "android.widget.FrameLayout/android.widget.LinearLayout/"
                    "android.widget.FrameLayout/android.widget.RelativeLayout/"
                    "android.webkit.WebView/android.webkit.WebView/android.view.View/"
                    "android.view.View[3]/android.view.View[3]/android.view.View",
            type=MobileBy.XPATH)
        self.invalid_password_hint = dict(
            locator="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/"
                    "android.widget.FrameLayout/android.widget.LinearLayout/"
                    "android.widget.FrameLayout/android.widget.RelativeLayout/"
                    "android.webkit.WebView/android.webkit.WebView/android.view.View/"
                    "android.view.View[4]/android.view.View/android.view.View[4]/"
                    "android.view.View[3]/android.view.View[3]",
            type=MobileBy.XPATH
        )

        self.gateway_back_button = dict(locator="//*[@id='hbo_header_back']", type=MobileBy.XPATH)

    def select_vip_operator(self):
        """
        Click to the operator selector dropdown list, search for the VIP one and clicks it.
        Info: Only for Android
        """
        self.wait.get(self.operator_selector).click()
        self.switch_context(webview=False)
        # Additional swipe to avoid flaky test on CZ and SK
        if cm.country_id == "cz":
            self.d_helper.swipe_until_element_with_text_is_found(locator=self.operators, text="Development")
            vip_operator = self.d_helper.swipe_until_element_with_text_is_found(
                locator=self.operators, text="HBO GO Vip/Club Czech Republic")
        elif cm.country_id == "sk":
            # Additional swipe to avoid flaky test on CZ and SK
            self.d_helper.swipe_until_element_with_text_is_found(locator=self.operators, text="Development")
            vip_operator = self.d_helper.swipe_until_element_with_text_is_found(
                locator=self.operators, text="HBO GO VIP/Club Slovakia")
        else:
            vip_operator = self.d_helper.swipe_until_element_with_text_is_found(
                locator=self.operators, text="vip")
        vip_operator.click()


class AuthIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.continue_button = dict(locator="Next", type=MobileBy.ID)
        self.country = dict(locator=rm.get_country_name(), type=MobileBy.ACCESSIBILITY_ID)
        self.picker_wheel = dict(locator="XCUIElementTypePickerWheel", type=MobileBy.CLASS_NAME)
        self.picker_wheel_done = dict(locator="Done", type=MobileBy.ID)
        self.operator_selector = dict(locator="operatorselector", type=MobileBy.ID)
        self.email_input = dict(locator="1", type=MobileBy.ID)
        self.password_input = dict(locator="5", type=MobileBy.ID)
        self.chromecast_screen_button = dict(locator="close", type=MobileBy.ACCESSIBILITY_ID)
        self.search_button = dict(locator="navigation-search", type=MobileBy.ACCESSIBILITY_ID)
        self.ios_popup_ok_button = dict(locator="OK", type=MobileBy.ACCESSIBILITY_ID)

    def select_vip_operator(self):
        """
        Click to the operator selector dropdown list, search for the VIP one and clicks it.
        Info: Only for iOS
        """
        sleep(2)
        self.wait.visible(self.operator_selector).click()
        self.switch_context(webview=False)
        self.wait.get(self.picker_wheel).send_keys(rm.get_country_b2b_provider())
        self.wait.get(self.picker_wheel_done).click()

    def select_chromecast_onboarding_screen(self):
        """
        Click OK on chromecast onboarding screen
        """
        self.wait.get(self.chromecast_screen_button, timeout=60).click()


class Auth(AuthAndroid, AuthIOS):
    def __init__(self, driver, login_type):
        self.platform = cm.platform
        if self.platform == "ANMO":
            AuthAndroid.__init__(self, driver)
            self.authorization = AuthAndroid
        elif self.platform == "APMO":
            AuthIOS.__init__(self, driver)
            self.authorization = AuthIOS

        self.login_type = login_type
        self.email_input = dict(locator="//*[@id='1']", type=MobileBy.XPATH)
        self.password_input = dict(locator="//*[@id='5']", type=MobileBy.XPATH)
        self.finish_login_button = dict(locator="//*[@id='gw_login_06_sign_in']", type=MobileBy.XPATH)
        self.d2c_signin_button = dict(locator="//*[@id='gw_operator_type_signin_d2c']", type=MobileBy.XPATH)
        self.b2b_signin_button = dict(locator="//*[@id='gw_operator_type_signin_b2b']", type=MobileBy.XPATH)
        self.operator_selector = dict(locator="//*[@id='operatorselector']", type=MobileBy.XPATH)

    def select_country(self):
        """
        Select country from country selector and click next button
        """
        self.wait.visible(element=self.continue_button)
        if "d2c" in self.login_type.get("mail") and cm.environment == 'prod':
            country_list = self.d_helper.swipe_until_element_with_text_is_found(locator=self.country,
                                                                                text="Magyarország")
        else:
            country_list = self.d_helper.swipe_until_element_with_text_is_found(locator=self.country,
                                                                                text=rm.get_country_name())
        country_list.click()
        self.wait.visible(element=self.continue_button).click()

    def select_operator(self):
        """
        Choose B2B or D2C operator on Gateway Webview
        """

        if self.platform == "APMO":
            self.wait.visible(self.ios_popup_ok_button)
            # This method wait for iOS webview to load if there will be more cases like this i will
            # remove this method and make it more general one
            timeout = time.time() + 60
            while True:
                if any("WEBVIEW" in s for s in self.driver.contexts) or time.time() > timeout:
                    self.log(self.driver.contexts)
                    break

        self.switch_context(webview=True)
        if "b2b" in self.login_type.get("mail"):
            if self.platform == "APMO":
                self.wait.get(element=self.b2b_signin_button, timeout=30).click()
            else:
                self.wait.visible(element=self.b2b_signin_button).click()
            self.authorization.select_vip_operator(self)
        # TODO: Temporary "or" for time I get proper email adress for Portugal
        elif "d2c" in self.login_type.get("mail") or cm.country_id == "pt":
            self.wait.visible(element=self.d2c_signin_button).click()

    def write_proper_credentials(self):
        """
         Write proper Login credentials and click next. Then switch to application context.
        """
        self.switch_context(webview=True)
        self.input_email_text(self.login_type.get("mail"))
        self.input_password_text(self.login_type.get("pw"))
        self.wait.visible(element=self.finish_login_button).click()
        self.switch_context(webview=False)

    def input_wrong_credentials(self, correct_email=True, correct_password=True):
        """
        Provide invalid credentials
        :param correct_email if false, password will be invalid
        :param correct_password if false, email will be invalid

        """
        self.switch_context(webview=True)
        if correct_email and not correct_password:
            self.input_email_text(self.login_type.get("mail"))
            self.input_password_text("verywrongPassword")
        elif correct_password and not correct_email:
            self.input_email_text("wrong_mail")
            self.input_password_text(self.login_type.get("pw"))

        self.wait.visible(element=self.finish_login_button).click()

    def input_email_text(self, email):
        # TODO Workaround for Webview switcher
        self.switch_context(webview=True)
        self.input_text_to_field(locator_or_element=self.email_input, text=email)
        if self.platform == "ANMO":
            self.driver.hide_keyboard()

    def input_password_text(self, password):
        self.switch_context(webview=True)
        sleep(2)
        self.input_text_to_field(locator_or_element=self.password_input, text=password)
        if self.platform == "ANMO":
            self.driver.hide_keyboard()

    def is_login_succesful(self):
        if self.platform == "APMO":
            self.select_chromecast_onboarding_screen()
        return self.wait.visible(element=self.search_button, timeout=30)

    def input_empty_credentials(self, password_empty=True, email_empty=True):
        """
        Provide credentials with one or more empty field and press Login Button
        :param password_empty if true, password field will be blank
        :param email_empty if true, email field will be blank

        """
        self.switch_context(webview=True)
        if password_empty and not email_empty:
            self.input_email_text(self.login_type.get("mail"))
        elif email_empty and not password_empty:
            self.input_password_text(self.login_type.get("pw"))

        self.wait.visible(element=self.finish_login_button).click()

    def is_login_button_displayed(self):
        self.switch_context(webview=True)
        return self.wait.visible(
            element=self.finish_login_button,
            timeout=5)

    def click_on_finish_login_button(self):
        self.wait.visible(element=self.finish_login_button).click()

    def select_forgot_password_button(self):
        self.switch_context(webview=True)
        self.wait.visible(element=self.forgotten_password).click()

    def is_country_selector_visible(self):
        return self.wait.visible(element=self.continue_button)

    def is_warning_displayed(self):
        self.switch_context(webview=True)
        self.log("Error msg {}".format(self.wait.get(element=self.warning_msg).text))
        return self.wait.visible(element=self.warning_msg, timeout=10)

    def clear_password_field(self):
        self.wait.get(element=self.password_input).clear()

    def click_on_forgott_password_button(self):
        self.switch_context(webview=True)
        self.wait.get(element=self.forgotten_password).click()

    def is_forgotten_password_finish_button_displayed(self):
        return self.wait.visible(element=self.forgotten_password_finish_button)

    def is_forgotten_password_finish_cancel_displayed(self):
        return self.wait.visible(element=self.forgotten_password_cancel_button)

    def is_email_forgot_password_form_visible(self):
        return self.wait.visible(self.email_input)

    def select_back_button(self):
        self.is_back_button_visible()
        self.wait.get(self.gateway_back_button).click()

    def is_back_button_visible(self):
        return self.wait.visible(self.gateway_back_button)

    def is_select_operator_selector_screen_displayed(self):
        self.switch_context(webview=True)
        return self.wait.visible(self.b2b_signin_button)

    def is_operator_selector_middle_screen_displayed(self):
        self.switch_context(webview=True)
        return self.wait.clickable(self.operator_selector)

    def is_login_screen_visible(self):
        self.switch_context(webview=True)
        return self.wait.visible(self.email_input)

    def select_d2c_operator(self):
        self.switch_context(webview=True)
        self.wait.visible(element=self.d2c_signin_button).click()
