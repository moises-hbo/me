from time import time

from appium.webdriver.common.mobileby import MobileBy

from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager
from selenium.common.exceptions import WebDriverException, StaleElementReferenceException, \
    NoSuchElementException

from helpers.sleeper import Sleeper as sleep

cm = ConfigManager()
rm = ResourceManagerApp()


class Android(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.search_button = dict(locator="search", type=MobileBy.ID)
        self.section_result_list = dict(
            locator="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout"
                    "/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/androidx"
                    ".drawerlayout.widget.DrawerLayout/android.widget.LinearLayout/android.widget.LinearLayout"
                    "/android.widget.LinearLayout/androidx.viewpager.widget.ViewPager/android.view.ViewGroup/androidx"
                    ".recyclerview.widget.RecyclerView/android.widget.RelativeLayout",
            type=MobileBy.XPATH)

        self.home_logo = dict(locator="iv_home_logo", type=MobileBy.ID)
        self.page_upper_title = dict(locator="ctv_toolbar", type=MobileBy.ID)
        self.no_content_message = dict(locator="home_no_content_message", type=MobileBy.ID)

        self.content_container = dict(locator="rl_normal_root_view", type=MobileBy.ID)
        self.content_name = dict(locator="ctv_normal_title", type=MobileBy.ID)


class IOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.search_button = dict(locator="navigation-search", type=MobileBy.ACCESSIBILITY_ID)
        self.section_result_list = dict(locator="XCUIElementTypeCell", type=MobileBy.CLASS_NAME)


class Home(Android, IOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            Android.__init__(self, driver)
        elif self.platform == "APMO":
            IOS.__init__(self, driver)

    def is_no_content_message_visible(self):
        return self.wait.visible(element=self.no_content_message)

    def check_recently_added(self):
        """
        Checks if contents from the recently added section of home page has premiere tag or not.
        :return: True if less then 10% of the contents has premiere tag, False if more
        """
        title_xpath = "//android.widget.RelativeLayout/android.widget.LinearLayout/" \
                      "android.widget.TextView[1]"
        premiere_tag_xpath = "//android.widget.RelativeLayout/" \
                             "android.widget.FrameLayout[1]/android.widget.TextView"
        contents = self.get_content_names_and_their_tag(title_xpath=title_xpath,
                                                        tag_xpath=premiere_tag_xpath,
                                                        all_have_tag=False)
        content_number = len(contents)
        premiere_number = 0
        self.log("Checking contents from recently added section of home page.\n")
        for content in contents:
            if content.get("tag") == rm.get_translation_from_resources("Premier"):
                premiere_number += 1
                self.log(
                    "{} is in the recently added section and has premiere tag.".format(
                        content.get("title")
                    )
                )
            else:
                self.log(
                    "{} is in the recently added section but doesn't have premiere tag.".format(
                        content.get("title")
                    )
                )

        self.log("{} contents have tags, {} contents dosen't have tags".format(premiere_number, content_number))
        return True if self.percentage(10, content_number) < premiere_number else False

    def check_imdb_toplist(self, test_duration):
        """
        Checks if contents of the imdb_toplist section of home page have at least 7 points.
        :return: True if all of them have at least 7 points, False if not
        """
        title_xpath = "//android.widget.RelativeLayout/android.widget.LinearLayout[2]/" \
                      "android.widget.TextView"
        imdb_tag_xpath = "//android.widget.RelativeLayout/" \
                         "android.widget.LinearLayout[1]/android.widget.TextView[1]"
        contents = self.get_content_names_and_their_tag(title_xpath=title_xpath,
                                                        tag_xpath=imdb_tag_xpath,
                                                        all_have_tag=True, duration=test_duration)
        result = True
        for content in contents:
            if float(content.get("tag")) < 7.0:
                self.log("{} have {} rating.".format(content.get("title"), content.get("tag")))
                result = False
        return result

    def check_last_chance_to_see(self):
        """
        Checks if contents from the "last chance" to see section of home page
        has last chance tag or not.
        :return: True if all of them has "last chance" tag, False if not
        """
        title_xpath = "//android.widget.RelativeLayout/android.widget.LinearLayout/" \
                      "android.widget.TextView[1]"
        last_chance_tag_xpath = "//android.widget.RelativeLayout/" \
                                "android.widget.FrameLayout[1]/android.widget.TextView"

        contents = self.get_content_names_and_their_tag(title_xpath=title_xpath,
                                                        tag_xpath=last_chance_tag_xpath)

        self.log(
            "Checking contents from 'last chance to see' section of home page.\n"
        )
        for content in contents:
            if content.get("tag") != rm.get_translation_from_resources("Last_chance"):
                self.log("Not all of the contents has 'last chance' tag.")
                return False
        return True

    def check_coming_soon(self):
        """
        Checks if contents from the "coming soon" section of home page
        has last chance tag or not.
        :return: True if all of them has 'coming soon' tag, False if not
        """
        title_xpath = "//android.widget.RelativeLayout/android.widget.LinearLayout/" \
                      "android.widget.TextView[1]"
        coming_soon_tag_xpath = "//android.widget.RelativeLayout/" \
                                "android.widget.FrameLayout[1]/android.widget.TextView"
        contents = self.get_content_names_and_their_tag(title_xpath=title_xpath,
                                                        tag_xpath=coming_soon_tag_xpath)
        self.log(
            "Checking contents from 'coming soon' section of home page.\n"
        )
        for content in contents:
            if content.get("tag") != rm.get_translation_from_resources("Coming_soon"):
                self.log("Not all of the contents has 'coming soon' tag.\n"
                         "{} != coming soon".format(content.get("tag")))
                return False
        return True

    def get_content_names_and_their_tag(self, title_xpath, tag_xpath, all_have_tag=True, duration=None):
        """
        Gets all the contents and their tag.
        :param: title_xpath: supposed to only contain the path from the result element, not from the root
        :param: tag_xpath: supposed to only contain the path from the result element, not from the root
        :param: all_have_tag: means if all the contents in the list should have the tag or not
        So if all_have_tag is True, then only contents with visible tag will be returned,
        if all_have_tag is False, then every content in the list will be returned, even if they
        don't have a tag at all (then tag will be None)
        :param duration for how long the test will check every keyart in stripe
        (duration was added because on long stripes test can go for 30 minutes, default is None)

        Yes I know it's not simple, but it's complicated instead.
        :return: list of dicts with title and tag of the contents
                 result = [{title="Avengers", tag="coming soon"}]
        """
        content_list = []
        now = time()
        timeout = True
        while True and timeout:
            if duration is not None:
                timeout = time() < now + duration

            result_list = self.page_helper.get_list(locator=self.section_result_list)
            contents = []
            for item in result_list:
                title_text = None
                tag_text = None
                try:
                    title_label = item.find_element_by_xpath(title_xpath)
                    title_text = title_label.text
                except (StaleElementReferenceException, WebDriverException,
                        NoSuchElementException):
                    pass
                if title_text is not None:
                    try:
                        tag_label = item.find_element_by_xpath(tag_xpath)
                        tag_text = tag_label.text.lower()
                    except (StaleElementReferenceException, WebDriverException,
                            NoSuchElementException):
                        pass
                    if tag_text is not None and all_have_tag:
                        current_content = dict(title=title_text, tag=tag_text)
                        if current_content not in contents:
                            contents.append(current_content)
                    elif not all_have_tag:
                        current_content = dict(title=title_text, tag=tag_text)
                        if current_content not in contents:
                            contents.append(current_content)
            number, counter = len(contents), 0
            for content in contents:
                if content not in content_list:
                    content_list.append(content)
                else:
                    counter += 1
            if number == counter:
                break

            self.d_helper.swipe(direction="up")
        return content_list

    def check_is_page_title_visible_an_have_proper_text(self, page_title):
        return self.wait.visible(self.page_upper_title, timeout=30).text.lower() == page_title.lower()

    def is_hbo_logo_displayed(self):
        return self.wait.visible(self.home_logo)

    def select_first_keyart(self):
        """ Select first content from the stripe"""
        sleep(3)
        result_list = self.page_helper.get_list(locator=self.section_result_list)
        result_list[0].click()
        sleep(4)

    def is_customer_group_visible(self, customer_group, direction="right", timeout=30):
        now = time()
        while time() < now + timeout:
            try:
                customer_group = self.driver.find_element_by_accessibility_id(customer_group)
                self.log(customer_group.text)
                customer_group.click()
                return customer_group.is_displayed()
            except NoSuchElementException:
                self.d_helper.swipe(direction=direction)

        self.log("No {} customer group found".format(customer_group))
        return False

    def get_first_visible_content_title_from_normal_stripe(self):
        sleep(2)
        mobile_list = self.page_helper.get_list(locator=self.content_container)
        mobile_element = mobile_list[0].find_element_by_id("ctv_normal_title").text
        return mobile_element
