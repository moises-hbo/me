from random import choice
from time import time

from appium.webdriver.common.mobileby import MobileBy
from requests import get
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager
from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp

cm = ConfigManager()
rm = ResourceManagerApp()


class SearchAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.search_character_hint = dict(
            locator="ctv_search_information_text",
            type=MobileBy.ID)
        self.search_no_result_hint = dict(
            locator="ctv_search_information_title",
            type=MobileBy.ID)
        self.content_add_to_watch_list_button = dict(
            locator="detailsWatchlistView",
            type=MobileBy.ID)
        self.content_imdb_rating_label = dict(
            locator="ratingImdbText", type=MobileBy.ID)
        self.content_age_rating_label = dict(
            locator="ageRating", type=MobileBy.ID)
        self.search_input = dict(
            locator="search_src_text", type=MobileBy.ID)
        self.search_results = dict(
            locator="search_result_top_text", type=MobileBy.ID)
        self.search_result_bottom_text = dict(
            locator="search_result_bottom_text", type=MobileBy.ID)
        self.clear_search_button = dict(
            locator="search_close_btn", type = MobileBy.ID)

    def is_no_result_visible(self):
        return self.wait.visible(element=self.search_character_hint)


class SearchIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.search_input = dict(locator="XCUIElementTypeTextField", type=MobileBy.CLASS_NAME)
        # self.search_results = dict(locator="XCUIElementTypeCell", type=MobileBy.CLASS_NAME)
        self.search_results = dict(locator="search-title-label", type=MobileBy.ID)

    def is_no_result_visible(self):
        """
        Waiting for iOS Devs to implement Accessibility element (So this is temporary)
        Currently this function is checking if results are visible
        :return: If no results(no results cells) are visible it will return True
        If there will be results in search it will return false
        """
        visible = self.wait.visible(element=self.search_results, timeout=3)
        return not visible


class Search(SearchAndroid, SearchIOS):
    def __init__(self, driver):
        self.platform = cm.platform
        if self.platform == "ANMO":
            SearchAndroid.__init__(self, driver)
            self.search_page = SearchAndroid
        elif self.platform == "APMO":
            SearchIOS.__init__(self, driver)
            self.search_page = SearchIOS

        self.search_keyword = rm.get_random_movie_content()
        self.invalid_keywords = ["//a", "///", "---", "+++", "{a}", "[a]"]
        self.short_keywords = ["a", "aa"]
        self.kids_not_proper_keywords = ["sex", "adult", "porn"]

    def enter_text_on_search_field(self, keyword=None):
        self.wait.get(element=self.search_input).send_keys(keyword)

    def select_clear_results_button(self):
        self.wait.get(element=self.clear_search_button).click()

    def select_search_icon(self):
        self.wait.get(element=self.search_button).click()

    def is_default_search_hint_displayed(self):
        character_hint = self.wait.get(element=self.search_character_hint)
        self.log("Character hint: {}".format(character_hint.text))
        return isinstance(character_hint.text, str)

    def is_search_back_button_displayed(self):
        return self.wait.visible(element=self.back_button)

    def select_search_back_button(self):
        self.wait.get(element=self.back_button).click()

    def is_default_search_text_displayed(self):
        search_text = self.wait.get(element=self.search_input)
        self.log("Default search text: {}".format(search_text.text))
        return isinstance(search_text.text, str)

    def check_too_short_keyword(self):
        self.select_search_and_enter_text(choice(self.short_keywords))
        return self.search_page.is_no_result_visible(self)

    def check_adult_keywords_search(self):
        self.select_search_and_enter_text(choice(self.kids_not_proper_keywords))
        return self.search_page.is_no_result_visible(self)

    def search_no_result(self, keyword):
        self.select_search_and_enter_text(keyword)
        return self.search_page.is_no_result_visible(self)

    def check_invalid_keyword(self):
        self.select_search_and_enter_text(choice(self.invalid_keywords))
        search_no_result_warning = self.wait.visible(element=self.search_no_result_hint)
        return search_no_result_warning

    def search_content(self, keyword=None):
        """
        Types the given keyword to the search input field, and hides the keyboard after that.
        :param keyword: the keyword you want to search
        """
        if keyword is None:
            keyword = ResourceManagerApp.get_random_movie_content()

        self.select_search_and_enter_text(keyword)
        api_result_names = self.get_search_result_names_api(keyword=keyword)

        results, result_names = [], []
        now = time()
        timeout = True
        while len(results) != len(api_result_names) and timeout:
            timeout = time() < now + 80
            results_temp = self.get_search_results()
            for r in results_temp:
                result_name = r.text
                if r not in results:
                    results.append(r)
                    result_names.append(result_name)
            self.d_helper.swipe(direction="Up")
        return dict(results=results, result_names=result_names, api_result_names=api_result_names)

    def get_search_results(self):
        """
        Gets all of the search results from the UI.
        :return: list of the search result elements
        """
        self.wait.get(element=self.search_results)
        results = self.page_helper.get_list(locator=self.search_results)
        return results

    def get_search_result_names_api(self, keyword=None, kids_lock=False):
        """
        Gets the names of the search results from the API call.
        :param keyword: keyword we want to search for
        :return: list of the names of the results
        """
        if keyword is None:
            keyword = ResourceManagerApp.get_random_movie_content()

        if kids_lock:
            url = self.api_mobile.get_search_api_url(catalog_number=2).replace("###KEYWORD###", keyword)
        else:
            url = self.api_mobile.get_search_api_url().replace("###KEYWORD###", keyword)

        response = get(url)
        data = response.json()
        result_names = [item["Name"]
                        for item in data["Container"][0]["Contents"]["Items"]]
        return result_names

    @staticmethod
    def compare_results(ui_result_names, api_result_names):
        """
        Comparing the list with the names of the search results appearing on the UI
        with the list with the names of the search results we got from the API call.
        :param ui_result_names: list of the search results appearing on the UI
        :param api_result_names: list of the search results from the API call
        :return: True if they are the same, False if not
        """
        for result in api_result_names:
            if result not in ui_result_names:
                return False
        return True

    def search_and_select_first(self, keyword=None):
        if keyword is None:
            keyword = ResourceManagerApp.get_random_movie_content()
        self.select_search_and_enter_text(keyword)
        self.log("Content:{}".format(keyword))
        self.wait.visible(element=self.search_results)
        results = self.page_helper.get_list(locator=self.search_results)
        results[0].click()

    def select_first_search_keyart(self):
        self.wait.visible(element=self.search_results)
        results = self.page_helper.get_list(locator=self.search_results)
        results[0].click()

    def is_result_list_visible(self):
        return self.wait.visible(element=self.search_results)

    def select_search_and_enter_text(self, keyword=None):
        """
        Select search icon and write keyword in search field
        :param keyword: keyword we want to search for
        """
        self.wait.get(element=self.search_button).click()
        self.wait.get(element=self.search_input).send_keys(keyword)
        self.driver.hide_keyboard()

    def click_on_input_field(self):
        self.wait.get(element=self.search_input).click()

    def is_search_phrase_visible_in_result(self, search_phrase):
        """
        Gets all of the search results (bottom text) from the UI.
        :return: True if on bottom text search phrase is visible
        """
        self.wait.get(element=self.search_result_bottom_text)
        results_mobile_elements = self.page_helper.get_list(locator=self.search_result_bottom_text)
        results = []
        for n in results_mobile_elements:
            results.append(n.text)
        for n in results:
            self.log("On Search was visible: {}".format(n))
        return any(search_phrase in s for s in results)
