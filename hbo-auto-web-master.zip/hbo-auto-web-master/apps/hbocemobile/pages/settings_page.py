from helpers.sleeper import Sleeper as sleep

from appium.webdriver.common.mobileby import MobileBy
from selenium.webdriver.support.select import Select
from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager

cm = ConfigManager()


class SettingsAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        # Application Preferences

        self.language_scroll = dict(locator="//*[@id='languages']", type=MobileBy.XPATH)
        self.language_save_button = dict(locator="//*[@id='gw_app_preferences_save']", type=MobileBy.XPATH)
        self.language_list_drop = dict(locator="//*[@id='applicationLanguage']", type=MobileBy.XPATH)

    def is_gateway_page_load(self):
        """
        Whenever Gateway Settings web view is opened on Android application
        it opens blank page and proper settings web page.
        This method search in current opened tabs the right one and selects it

        :return: True if appium was able to switch to proper tab in webview.
        False if something go wrong.
        """
        # TODO:Temporary sleep for stability, should be removed later
        sleep(3)

        webview_tabs = self.driver.window_handles
        for i in webview_tabs:
            self.driver.switch_to.window(i)
            webview_title = self.driver.title
            self.log("Webview titile is: {}".format(webview_title))
            if "HBO" in webview_title:
                return True

        return False

    def change_language_webview(self, nativ=False):

        """
        Change language to Nativ or English language
        :param nativ: if true it will select nativ language if false English
        """
        language = ResourceManagerApp.get_country_native_language() if nativ else "English"

        self.switch_context(webview=True)
        self.wait.get(element=self.language_list_drop).click()

        select_list = Select(self.driver.find_element_by_xpath("//*[@id='applicationLanguage']"))

        # This is needed to initialized pop-up on language screen
        self.wait.get(element=self.language_list_drop).click()

        select_list.select_by_visible_text(language)
        # Select save button
        self.wait.get(element=self.language_save_button).click()

        self.switch_context(webview=False)


class SettingsIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.language_list_drop = dict(locator="//*[@id='applicationLanguage']", type=MobileBy.XPATH)
        self.language_save_button = dict(locator="//*[@id='gw_app_preferences_save']", type=MobileBy.XPATH)
        self.picker_wheel = dict(locator="XCUIElementTypePickerWheel", type=MobileBy.CLASS_NAME)

    def is_gateway_page_load(self):
        # TODO: Temporary hack for webview stability
        sleep(5)
        return True

    def change_language_webview(self, nativ=False):
        """
        Change language to Nativ or English language
        :param nativ: if true it will select nativ language if false English
        """
        language = ResourceManagerApp.get_country_native_language() if nativ else "English"

        self.switch_context(webview=True)
        self.wait.get(element=self.language_list_drop).click()
        self.switch_context(webview=False)
        self.wait.get(self.picker_wheel).send_keys(language)
        self.switch_context(webview=True)
        # Select save button
        self.wait.get(element=self.language_save_button).click()
        self.switch_context(webview=False)

        # Wait until application reload
        sleep(6)


class Settings(SettingsAndroid, SettingsIOS):
    def __init__(self, driver, webview=True):
        self.platform = cm.platform
        if self.platform == "ANMO":
            SettingsAndroid.__init__(self, driver)
            self.settings_page = SettingsAndroid
        elif self.platform == "APMO":
            SettingsIOS.__init__(self, driver)
            self.settings_page = SettingsIOS

        # Initialize switch to webview on start of the page
        self.switch_context(webview)

        # General buttons

        self.back_button_settings = dict(locator="//*[@id='hbo_header_back']", type=MobileBy.XPATH)
        self.confirmation_button_yes_settings = dict(locator="//*[@id='hbo_notification_confirmation_first_button']",
                                                     type=MobileBy.XPATH)
        self.confirmation_button_no_settings = dict(locator="//*[@id='hbo_notification_confirmation_second_button']",
                                                    type=MobileBy.XPATH)

        # Device
        self.delete_device_popup = dict(locator="//*[@id='gw_device_management_delete_modal_delete']",
                                        type=MobileBy.XPATH)
        self.cancel_delete_device_popup = dict(locator="//*[@id='gw_device_management_delete_modal_cancel']",
                                               type=MobileBy.XPATH)
        self.trash_icon = dict(locator="//*[@id='gw_device_management_delete_modal']", type=MobileBy.XPATH)
        self.device_names = dict(locator="//*[@class='st-device-name']", type=MobileBy.XPATH)
        self.device_list = dict(locator="//*[@class='st-device-list']", type=MobileBy.XPATH)
        self.tv_pin = dict(locator="//*[@class='st-tv-pin']", type=MobileBy.XPATH)

        # Navigation Tab
        self.account_management = dict(locator="//*[@id='gw_settings_sidebar_account_management']", type=MobileBy.XPATH)
        self.application_preferences = dict(locator="//*[@id='gw_settings_sidebar_application_preferences']",
                                            type=MobileBy.XPATH)
        self.devices = dict(locator="//*[@id='gw_settings_sidebar_devices']", type=MobileBy.XPATH)
        self.parental_control = dict(locator="//*[@id='gw_settings_sidebar_parental_control']", type=MobileBy.XPATH)

        self.close_settings_button = dict(locator="//*[@id='hbo_header_close']", type=MobileBy.XPATH)

        # Application Preferences

        self.language_scroll = dict(locator="//*[@id='languages']", type=MobileBy.XPATH)
        self.language_save_button = dict(locator="//*[@id='gw_app_preferences_save']", type=MobileBy.XPATH)

        # Account management

        self.sing_out_button = dict(locator="//*[@id='gw_settings_sidebar_sign_out']", type=MobileBy.XPATH)
        self.accept_sing_out = dict(locator="//*[@id='hbo_notification_sign_out_yes']", type=MobileBy.XPATH)
        self.account_management_save_button = dict(locator="//*[@id='gw_accountmanagement_05_save']",
                                                   type=MobileBy.XPATH)
        self.account_management_email_form = dict(locator="//*[@id='1']", type=MobileBy.XPATH)
        self.account_management_newsletter_check_box = dict(locator="//*[@id='9']", type=MobileBy.XPATH)
        self.language_list_drop = dict(locator="//*[@id='applicationLanguage']", type=MobileBy.XPATH)

        # Forgot Password
        self.forgot_password_send = dict(locator="//*[@id='gw_mailpassreset_04_send']", type=MobileBy.XPATH)
        self.forgot_password_cancel = dict(locator="//*[@id='gw_accountmanagement_forgot_password_modal_cancel']",
                                           type=MobileBy.XPATH)
        self.forgot_password_button = dict(locator="//*[@id='gw_accountmanagement_forgot_password_modal']",
                                           type=MobileBy.XPATH)

        # Parental control

        self.new_parental_pin_button = dict(locator="//*[@id='gw_parental_control_change_pin']", type=MobileBy.XPATH)
        self.save_parental_change_button = dict(locator="//*[@id='gw_parental_control_save']", type=MobileBy.XPATH)
        self.pin_input_parental = dict(locator="//*[@type='password']", type=MobileBy.XPATH)
        self.pin_radio_button_eighteen = dict(locator="//*[@id='18']", type=MobileBy.XPATH)

    def is_change_pin_button_visible(self):
        return self.wait.visible(element=self.new_parental_pin_button)

    def select_radio_button_eighteen(self):
        self.wait.visible(element=self.pin_radio_button_eighteen).click()

    def is_radio_button_eighteen_visible(self):
        return self.wait.visible(element=self.pin_radio_button_eighteen)

    def is_save_parental_pin_button_visible(self):
        return self.wait.visible(element=self.save_parental_change_button, timeout=8)

    def select_change_pin_button(self):
        self.wait.visible(element=self.new_parental_pin_button).click()

    def input_new_parental(self, parental="1111"):
        self.wait.visible(element=self.pin_input_parental).send_keys(parental)

    def is_device_list_visible(self):
        return self.wait.visible(element=self.device_list)

    def is_tv_pin_displayed(self):
        return self.wait.visible(element=self.tv_pin).text != ""

    def is_account_management_save_button_visible(self):
        return self.wait.visible(element=self.account_management_save_button)

    def is_account_management_forgot_passowrd_button_visible(self):
        return self.wait.visible(element=self.forgot_password_button)

    def is_radio_newsletter_button_visible(self):
        return self.wait.visible(element=self.account_management_newsletter_check_box)

    def is_forgot_password_send_button_visible(self):
        return self.wait.visible(element=self.forgot_password_send)

    def is_account_management_logout_button_visible(self):
        return self.wait.visible(element=self.sing_out_button)

    def is_cancel_forgot_password_button_visible(self):
        return self.wait.visible(element=self.forgot_password_cancel)

    def is_email_form_visible(self):
        return self.wait.visible(element=self.account_management_email_form)

    def select_parental_control(self):
        self.wait.visible(element=self.parental_control).click()

    def select_radio_button_newsletter(self):
        self.wait.visible(element=self.account_management_newsletter_check_box).click()

    def select_save_button(self):
        self.wait.visible(element=self.account_management_save_button).click()

    def select_devices_page(self):
        self.wait.get(self.devices).click()

    def select_account_management(self):
        self.wait.visible(element=self.account_management).click()

    def select_forgot_password_cancel(self):
        self.wait.visible(element=self.forgot_password_cancel).click()

    def select_forgot_password(self):
        self.wait.visible(element=self.forgot_password_button).click()

    def select_back_button_gateway(self):
        self.wait.visible(element=self.back_button_settings).click()

    def select_no_on_confirmation_popup(self):
        self.wait.visible(element=self.confirmation_button_no_settings).click()

    def select_yes_on_confirmation_popup(self):
        self.wait.visible(element=self.confirmation_button_yes_settings).click()

    def modify_email(self):
        self.wait.get(element=self.account_management_email_form).send_keys("Test")

    def select_sign_out_button(self):
        self.wait.get(element=self.sing_out_button).click()

    def select_language_scroll(self):
        self.wait.get(element=self.language_scroll).click()

    def select_application_preferences(self):
        self.wait.get(element=self.application_preferences).click()

    def select_language_save_button(self):
        self.wait.get(element=self.language_save_button).click()

    def is_gateway_page_load(self):
        return self.settings_page.is_gateway_page_load(self)

    def accept_sign_out(self):
        self.wait.get(element=self.accept_sing_out).click()

    def is_device_is_on_the_device_list(self):
        devices_list = []
        device_model = self.driver.desired_capabilities.get("deviceModel")
        devices = self.page_helper.get_list(self.device_names)

        for element in devices:
            devices_list.append(element.text)

        return any(device_model in s for s in devices_list)

    def change_language_webview(self, nativ=False):
        return self.settings_page.change_language_webview(self, nativ=nativ)
