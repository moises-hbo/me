from time import time

from appium.webdriver.common.mobileby import MobileBy
from apps.hbocemobile.pages.base.page import BasePage
from helpers.configmanager import ConfigManager
from helpers.sleeper import Sleeper as sleep

cm = ConfigManager()


class HelpAndroid(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

        self.webview_chrome = "WEBVIEW_chrome"

    def is_help_page_opened(self):
        # wait for chrome webview
        now = time()
        while True and time() < now + 10:
            contexts = self.driver.contexts
            if self.webview_chrome in contexts:
                break
            else:
                self.driver.helper.log("Web view still unavailable: {}".format(contexts))
                continue
        # Check if chrome opened with proper URL
        self.driver.switch_to.context(self.webview_chrome)
        url = self.driver.current_url
        self.log("Opened url is: {}".format(url))
        return url == self.get_proper_url()

    def get_proper_url(self):
        if cm.country_id in ["cz"]:
            help_page_url = "https://helpcenter.hbogo.eu/cs/"
        elif cm.country_id in ["ba", "me"]:
            help_page_url = "https://helpcenter.hbogo.eu/hr/"
        elif cm.country_id in ["rs"]:
            help_page_url = "https://helpcenter.hbogo.eu/sr/"
        elif cm.country_id in ["si"]:
            help_page_url = "https://helpcenter.hbogo.eu/sl/"
        elif cm.country_id in ["sk"]:
            help_page_url = "https://helpcenter.hbogo.eu/sk"
        elif cm.country_id in ["pt"]:
            help_page_url = "https://helpcenter.hboportugal.com/pt"
        else:
            help_page_url = "https://helpcenter.hbogo.eu/{}/".format(cm.country_id)
        return help_page_url

    def close_web_page_and_return_to_app(self):

        # Press "Recent" Android button
        self.driver.press_keycode(187)
        sleep(1)

        # Swipe Right to navigate to previously opened web page, on Samsung it is always on the right,
        # it could be different on other devices (watch out for this)
        self.d_helper.swipe("right")

        # Close web page by swiping up
        self.d_helper.swipe("up")

        # Return to application context, and opening application from recent application view
        self.switch_context(webview=False)
        self.d_helper.swipe("down")


class HelpIOS(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.ios_url = dict(locator="//XCUIElementTypeOther[@name='URL']", type=MobileBy.XPATH)
        self.help_center = dict(locator="//XCUIElementTypeStaticText[@name='Help Center']", type=MobileBy.XPATH)

    def is_help_page_opened(self):
        # Check if Safari page opened
        # TODO: Check if after appium update Safari webview will be visible to get proper URL.
        sleep(5)
        page_name = self.wait.get(self.help_center).get_attribute("name")
        return self.wait.visible(self.help_center) and page_name == "Help Center"


class Help(HelpAndroid, HelpIOS):
    def __init__(self, driver, login_type="b2b"):
        self.platform = cm.platform
        self.login_type = login_type
        if self.platform == "ANMO":
            HelpAndroid.__init__(self, driver)
            self.help_page = HelpAndroid
        elif self.platform == "APMO":
            HelpIOS.__init__(self, driver)
            self.help_page = HelpIOS

    def is_help_page_opened(self):
        return self.help_page.is_help_page_opened(self)
