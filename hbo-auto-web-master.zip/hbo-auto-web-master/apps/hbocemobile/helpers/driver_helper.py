from helpers.driverhelper import MobileDriverHelper
from time import time
from selenium.common.exceptions import NoSuchElementException
from appium.webdriver.common.touch_action import TouchAction

from helpers.enums import SwipeDirection


class DriverHelperMobileCE(MobileDriverHelper):
    def __init__(self, driver):
        super().__init__(driver)

    def tap_element(self, element, count=1):
        if isinstance(element, dict):
            locator_type = element.get("type")
            locator = element.get("locator")
            element = self.driver.find_element(locator_type, locator)
        actions = TouchAction(self.driver)
        actions.tap(element=element, count=count)
        actions.perform()

    def get_coordinates_of_element(self, element):
        """
        Get x and y coordinates of element
        :param element:
        :return: list with x and y coordinates
        """
        if isinstance(element, dict):
            locator_type = element.get("type")
            locator = element.get("locator")
            element = self.driver.find_element(locator_type, locator).location
            element_coordinates = [element.get("x"), element.get("y")]
            return element_coordinates

    def swipe_until_element_with_text_is_found(self, locator, text, locator_type="xpath", timeout=10):
        if isinstance(locator, dict):
            locator_type = locator.get("type")
            locator = locator.get("locator")
        self.log("Swiping until {} seconds for finding element: {}.".format(
            timeout, locator))
        now = time()
        while time() < now + timeout:
            try:
                results = self.driver.find_elements(locator_type, locator)
                for result in results:
                    if text.lower() in result.text.lower():
                        return result
                self.swipe(direction="Up")
            except NoSuchElementException:
                self.swipe(direction="Up")
        self.log("Unable to find element: {}".format(locator))

    def swipe(self, direction="Up"):
        """
        Emulates a finger-swiping gesture on screen
        Note: Swiping up means dragging finger upwards,
        meaning the screen scrolls downwards
        """
        self.log(f"Swiping: {direction}\n")

        platform = self.get_platform()
        if platform == "android":
            self.__android_swipe(direction)
        elif platform == "ios":
            self.__ios_swipe(direction)

    def __android_swipe(self, direction):
        direction = direction.lower()
        size = self.driver.get_window_size()
        if direction == "down":
            self.driver.swipe(start_x=size.get("width") / 2, start_y=size.get("height") * 2 / 5,
                              end_x=size.get("width") / 2, end_y=size.get("height") * 4 / 5,
                              duration=650)
        elif direction == "up":
            self.driver.swipe(start_x=size.get("width") / 2, start_y=size.get("height") * 4 / 5,
                              end_x=size.get("width") / 2, end_y=size.get("height") * 2 / 5,
                              duration=650)
        elif direction == "right":
            self.driver.swipe(start_x=size.get("width") * 4 / 5, start_y=size.get("height") / 2,
                              end_x=size.get("width") * 2 / 5, end_y=size.get("height") / 2,
                              duration=650)
        elif direction == "left":
            self.driver.swipe(start_x=size.get("width") * 2 / 5, start_y=size.get("height") / 2,
                              end_x=size.get("width") * 4 / 5, end_y=size.get("height") / 2,
                              duration=650)

    def __ios_swipe(self, direction):
        if direction == SwipeDirection.Down:
            self.driver.execute_script("mobile: swipe", {"direction": "down"})
        elif direction == SwipeDirection.Up:
            self.driver.execute_script("mobile: swipe", {"direction": "up"})
        elif direction == SwipeDirection.Right:
            self.driver.execute_script("mobile: swipe", {"direction": "right"})
        elif direction == SwipeDirection.Left:
            self.driver.execute_script("mobile: swipe", {"direction": "left"})
