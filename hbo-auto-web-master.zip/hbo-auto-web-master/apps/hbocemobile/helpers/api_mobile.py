import json
import requests

from hboapi.hboce.apihandler import Core, Bookmarking, gwHandler
from requests import get
from apps.hbocemobile.data.resourcemenagerapp import ResourceManagerApp
from helpers.configmanager import ConfigManager

cm = ConfigManager()
rm = ResourceManagerApp()


class ApiMobile:

    def __init__(self):
        self.platform = cm.platform
        self.country_id = cm.country_id

        self.search_api_url_kids = "https://{}api.hbogo.eu/v8/Search/json/{}/{}/###KEYWORD###/-/-/-/-/-/2".format(
            cm.country_id, rm.get_country_api_language(), cm.platform)

    def get_search_api_url(self, catalog_number=3):
        """
        Get proper url for api initialization also to provide proper api request for Serbia
        """
        api_url = "https://{}api.hbogo.eu/v8/Search/json/{}/{}/###KEYWORD###/-/-/-/-/-/{}".format(
            cm.country_id, rm.get_country_api_language(), cm.platform, catalog_number)
        if cm.country_id == 'rs':
            return "https://srapi.hbogo.eu/v8/Search/json/{}/{}/###KEYWORD###/-/-/-/-/-/{}".format(
                rm.get_country_api_language(), cm.platform, catalog_number)
        return api_url

    def get_bookmarking(self):
        return Bookmarking(platform=self.platform, countryid=self.country_id)

    def get_gw_handler(self):
        return gwHandler(platform=self.platform, countryid=self.country_id)

    def get_user_info(self):

        # Get normal user info
        user_account = ("b2b_{}".format(cm.country_id)) if cm.country_id != "pt" else "d2c_pt"
        basic_info = rm.get_user_info(account=user_account)

        # Create dictionary for request
        auth_data = dict(email=basic_info.get("mail"),
                         password=basic_info.get("pw"),
                         indiv=basic_info.get("indiv"),
                         country=basic_info.get("country"),
                         customerid=basic_info.get("c_id"),
                         operatorid=self.get_vip_operator_data().get(
                             "operatorId") if cm.country_id != "pt" else self.get_d2c_operator_data().get("operatorId"),
                         operatorname=self.get_vip_operator_data().get(
                             "operatorName") if cm.country_id != "pt" else self.get_d2c_operator_data().get(
                             "operatorName"),
                         devid=basic_info.get("dev_id"),
                         username=basic_info.get("nick"), lastname="",
                         action="L", voucher="1234ab", token="", sessionid="",
                         authapiurl=self.get_api_core().settings_response["AuthenticationGwUrl"])

        return auth_data

    def get_api_core(self):
        return Core(platform=self.platform, countryid=self.country_id, native_langauge=True)

    def get_auth_response(self):
        return self.get_api_core().authentication_api(auth_data=self.get_user_info())

    def get_home_from_api(self):
        return self.get_api_core().menu()

    def get_vip_operator_data(self):
        return self.get_api_core().vip_operator()

    def get_d2c_operator_data(self):
        return self.get_api_core().d2c_operator(prerel=False)

    def get_raw_navigation_menu_items(self):
        return self.get_api_core().menu()

    def get_raw_menu_data_api(self, language="HUN"):

        if cm.country_id == 'rs':
            url = "https://srapi.hbogo.eu/v8/Menu/json/{}/{}/20/False".format(language, cm.platform)
        elif cm.country_id == 'ba' and language is not "ENG":
            url = "https://baapi.hbogo.eu/v8/Menu/json/SRP/{}/20/False".format(cm.platform)
        else:
            url = "https://{}api.hbogo.eu/v8/Menu/json/{}/{}/20/False".format(cm.country_id, language, cm.platform)
        r = requests.get(url)
        content_data = json.loads(r.text)

        return content_data

    def get_raw_content_data_from_api(self, keyword):
        """
        It gets (with API call) the raw content data.
        :param keyword: string with the keyword of the content we are looking for
        :return: dict with the raw content data
        """
        auth_data = self.get_user_info()
        if keyword is None:
            keyword = ResourceManagerApp.get_random_series_content()
        url = self.get_search_api_url().replace("###KEYWORD###", keyword)
        response = get(url)
        data = response.json()
        result = [item for item in data["Container"]
        [0]["Contents"]["Items"]][0]
        content_id = result["Id"]
        content_data = self.get_api_core().content_by_id(contentid=content_id, language=auth_data.get("country"))
        return content_data

    def get_menu_buttons_name_from_api(self, content_data):
        menu_names = {}
        for item in content_data["Items"]:
            if item.get("Name") not in ["NONE"]:
                menu_names[item.get("Index")] = item.get("Name")
        return menu_names

    def change_app_language_by_api(self, language):
        auth_data = self.get_user_info()
        session_id = self.get_auth_response().get("response_body").get("SessionId")
        token = self.get_auth_response()['response_body']["Token"]
        api_language = language
        self.get_gw_handler().set_app_language(gotoken=token,
                                               gosessionid=session_id,
                                               gocustomerid=auth_data.get("customerid"), expectedlang=api_language,
                                               authtype="b2b")

    def get_external_id_of_content_by_name(self, name=None):
        """
        Gets (with API call) the external id of the content with the given name/keyword.
        :param name: string with the name or the keyword of the content you are looking for
        :return: string with the external id of the wanted content
        """
        content_data = self.get_raw_content_data_from_api(keyword=name)
        external_id = content_data.get("ExternalId")
        return external_id

    def add_to_watchlist_with_api(self, name=None, content_type="1"):
        """
        Adds (with API call) the content with the given name to the watchlist.
        :param name: string with the name or the keyword of the content you are looking for
        :return: the response of the API call
        """
        content_type = str(content_type)
        auth_data = self.get_user_info()
        e_id = self.get_external_id_of_content_by_name(name=name)
        session_id = self.get_auth_response().get("response_body").get("SessionId")
        response = self.get_bookmarking().set_watchlist_item(
            customerid=auth_data.get("customerid"),
            countrycode=auth_data.get("country"), externalid=e_id, contenttype=content_type,
            loginsid=session_id, gotoken=self.get_auth_response()['response_body']["Token"]
        )
        return response

    def check_if_content_is_on_watchlist(self, e_id=None):
        """
        Checks (with API call) that if a content with the given external id is on the watchlist or not.
        :param e_id: string with the external id of the content you want to check
        :return: True if the content is on the watchlist, False if not
        """
        auth_data = self.get_user_info()
        watchlist_from_api = self.get_bookmarking().get_watchlist(customerid=auth_data.get("customerid"),
                                                                  countrycode=auth_data.get("country"),
                                                                  catalog="1",
                                                                  gotoken=self.get_auth_response()['response_body'][
                                                                      "Token"])
        e_ids = [e["externalId"]
                 for e in watchlist_from_api.get("response_body")]
        return e_id in e_ids

    def delete_from_watchlist_api(self, e_id=None):
        """
        Deletes a content with the given external id from the watchlist
        :param e_id: string with the external id of the content you want to delete
        """
        auth_data = self.get_user_info()
        session_id = self.get_auth_response().get("response_body").get("SessionId")
        self.get_bookmarking().delete_from_watchlist(customerid=auth_data.get("customerid"),
                                                     countrycode=auth_data.get("country"),
                                                     externalid=e_id, contenttype="1", loginsid=session_id,
                                                     gotoken=self.get_auth_response()['response_body'][
                                                         "Token"])

    def get_movie_content_data_from_api(self, keyword=None):
        """
        Does a search API call to get the content id. Then does another API call to get all the details of the content.
        Stores all the necessary details of the content if they have values.
        :param keyword: The keyword we want to search for
        :return: dict with the necessary details of the content
        """
        if keyword is None:
            keyword = ResourceManagerApp.get_random_series_content()
        content_data = self.get_raw_content_data_from_api(keyword=keyword)
        details = {"title": content_data["OriginalName"]}
        if content_data["SecondaryGenre"] != "":
            details["meta_data"] = "{} | {}, {}".format(
                content_data["ProductionYear"], content_data["Genre"], content_data["SecondaryGenre"])
        else:
            details["meta_data"] = "{} | {}".format(
                content_data["ProductionYear"], content_data["Genre"])
        age_rating = content_data["AgeRatingName"]
        if age_rating != "":
            details["age_rating"] = age_rating
        imdb_rating = float(content_data["ImdbRate"])
        if imdb_rating != "":
            details["imdb_rating"] = imdb_rating
        description = content_data["Description"]
        if description != "":
            details["description"] = description
        director = content_data["Director"]
        if director != "":
            details["director"] = director
        cast = content_data["Cast"]
        if cast != "":
            details["cast"] = cast
        country = content_data["OriginCountry"]
        if country != "":
            details["country"] = country
        audios = []
        for a in content_data["AudioTracks"]:
            if a["Name"] not in audios:
                audios.append(a["Name"])
        details["audio"] = ", ".join(audios)
        subs = []
        for sub in content_data["Subtitles"]:
            if sub["Name"] not in subs:
                subs.append(sub["Name"])
        details["subtitle"] = ", ".join(subs)
        duration = content_data["DurationText"]
        if duration != "":
            # On BG country in api response there is additional "/r/n" which create error in api ui checker
            # this avoids it
            details["duration"] = duration[:-2] if cm.country_id == "bg" else duration
        return details

    def get_series_content_data_from_api(self, keyword=None):
        """
        Does a search API call to get the content id. Then does another API call to get all the details of the content.
        Stores all the necessary details of the content if they have values.
        :param keyword: The keyword we want to search for
        :return: dict with the necessary details of the content
        """

        content_data = self.get_raw_content_data_from_api(keyword)
        details = {"title": content_data["Parent"]["OriginalName"]}

        last_season_year = content_data["ProductionYear"]
        first_season_year = content_data["Parent"]["ProductionYear"]

        if first_season_year == last_season_year:
            production_year = last_season_year
        else:
            production_year = "{} - {}".format(first_season_year, last_season_year)

        if content_data["Parent"]["SecondaryGenre"] != "":
            details["meta_data"] = "{} | {}, {}".format(
                production_year, content_data["Parent"]["Genre"], content_data["Parent"]["SecondaryGenre"])
        else:
            details["meta_data"] = "{} | {}".format(
                production_year, content_data["Genre"])

        age_rating = content_data["AgeRatingName"]
        if age_rating != "":
            details["age_rating"] = age_rating
        imdb_rating = float(content_data["ImdbRate"])
        if imdb_rating != "":
            details["imdb_rating"] = imdb_rating

        season_descriptions = content_data["Parent"]["ChildContents"]["Items"]

        season_number = str(content_data["Index"])
        description = ""
        for element in season_descriptions:
            if season_number in element["Name"]:
                # TODO: Currently this is setup like this but this can be error decision
                #  point was created on Android board !!
                if self.platform == "ANMO":
                    description = element["Abstract"]
                else:
                    description = element['Description']

        if description != "":
            details["description"] = description

        return details

    def get_episode_metadata_from_api(self, keyword=None):
        """
        Gets the necessary Series episode content details from the API.
        Stores them in a dictionary if they are visible.
        By default it looks for the first episode
        :return: dict with the necessary details of the content
        """
        # Get raw content data of Series
        episode_details = self.get_raw_content_data_from_api(keyword)
        # Get id of the first episode
        content_id = episode_details["ChildContents"]["Items"][0]["Id"]
        # Get details of first episode using id from previous GET
        content_data = self.get_api_core().content_by_id(contentid=content_id,
                                                         language=rm.get_country_api_language())
        details = {}

        description = content_data["Description"]
        if description != "":
            details["description"] = description
        director = content_data["Director"]
        if director != "":
            details["director"] = director
        cast = content_data["Cast"]
        if cast != "":
            details["cast"] = cast
        country = content_data["OriginCountry"]
        if country != "":
            details["country"] = country
        audios = []
        for a in content_data["AudioTracks"]:
            if a["Name"] not in audios:
                audios.append(a["Name"])
        details["audio"] = ", ".join(audios)
        subs = []
        for sub in content_data["Subtitles"]:
            if sub["Name"] not in subs:
                subs.append(sub["Name"])
        details["subtitle"] = ", ".join(subs)
        duration = content_data["DurationText"]
        if duration != "":
            details["duration"] = duration[:-2] if cm.country_id == "bg" else duration

        return details

    def get_menu_items_id_and_names(self):
        """
        This function return all of the main navigation menu groups with ID and native names as tuples.
        (native name = id of group)
        :return: List with menu navigation group :
        [ Home, Series, Films, Kids, Download, Settings, Help ]
        """
        raw_menu_items = self.get_raw_navigation_menu_items().get("Items")
        menu_items = []
        for element in raw_menu_items:
            if element["ObjectUrl"] != "SEPARATOR":
                menu_items.append((element["Name"],element["Id"]))
        return menu_items
