from apps.hbocemobile.pages.menu_page import Menu


def select_watchlist_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("home", submenu="watchlist")


def select_watch_history_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("home", submenu="watch_history")


def select_kids_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("kids")


def select_home_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("home")


def select_series_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("series")


def select_movies_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("movies")


def select_settings_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("settings")


def select_help_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("help")


def select_about_page_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("about")


def select_download_from_navigation_menu(driver):
    page = Menu(driver=driver)
    page.navigate_to_menu("downloads")
