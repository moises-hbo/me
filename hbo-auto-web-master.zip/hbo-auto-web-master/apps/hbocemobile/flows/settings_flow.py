from apps.hbocemobile.pages.settings_page import Settings


def sign_out_from_application(driver):
    page = Settings(driver)

    # Check if gateway load properly
    assert page.is_gateway_page_load()

    page.select_account_management()
    page.select_sign_out_button()
    page.accept_sign_out()
    page.switch_context(webview=False)
