from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.menu_page import Menu


def is_hamburger_menu_displayed(driver):
    page = Menu(driver)
    return page.wait.visible(element=page.menu_button, timeout=10)


def is_search_icon_displayed(driver):
    page = Home(driver)
    page.log("Current application context:{}".format(page.driver.current_context))
    return page.wait.visible(element=page.search_button, timeout=30)