from apps.hbocemobile.pages.auth_page import Auth
from helpers.configmanager import ConfigManager

cm = ConfigManager()


def login_to_application(driver, login_type):
    """
    The most general logger to application for b2b and d2c(Portugal) users
    :param driver:
    :param login_type: login data taken from resource.json
    :return:
    """
    page = Auth(driver, login_type)

    # If application is not Portugal it has Country Selectors Screen and Provider Screen
    if cm.country_id != "pt":
        page.select_country()
        page.select_operator()
    else:
        # If application is Portugal and is running on Android platform it has select Provider Screen
        if cm.platform == "ANMO":
            page.select_operator()
    # From this point is normal evry app have provide credential screen
    page.write_proper_credentials()
    return page.is_login_succesful()


def select_operator(driver, login_type):
    page = Auth(driver, login_type)
    page.select_country()
    page.select_operator()
