from apps.hbocemobile.pages.home_page import Home
from apps.hbocemobile.pages.menu_page import Menu
from apps.hbocemobile.pages.search_page import Search


def search_content(driver, name=None):
    """
    This is the main function.
    Search for a content, and compares the results appearing on the UI, with the ones from the API call.
    :param driver:
    :param name: the name of the content we are looking for if none take from data
    :return: True or False
    """
    page = Search(driver=driver)

    # Searching for the content.
    search_results = page.search_content(keyword=name)

    # Result names from API:
    api_result_names = search_results.get("api_result_names")
    page.log("API Search results:\n{}".format(api_result_names))

    # Result names from UI:
    ui_result_names = search_results.get("result_names")
    page.log("UI Search results:\n{}".format(ui_result_names))

    # Comparing them
    return page.compare_results(ui_result_names=ui_result_names,
                                api_result_names=api_result_names)


def select_content_from_random_subcategory(driver, category="movies"):

    """
    This function open navigation menu select random subcategory then open first visible detail screen
    :param driver:
    :param category: from what main category function should select subcategory
    :return:
    """

    # Select random subcategory
    page = Menu(driver=driver)
    page.select_random_sub_category(category=category)

    # Open First visible keyart
    page = Home(driver=driver)
    page.select_first_keyart()
