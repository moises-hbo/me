import logging
import json

from selenium.webdriver.common.by import By


class WSDKHandler(object):
    """ Helper class for API calls """

    def __init__(self, driver):
        self.driver = driver
        self.log = logging.getLogger("test.run")

    def get_current_device(self):
        """
        Returns with the current device information (used for api login atm)
        """
        return self.driver.execute_script("return go.customer.customer.CurrentDevice")
