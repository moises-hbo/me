from helpers.sleeper import Sleeper as sleep

from apps.hboce.pages.home import HomeUnauth, HomeAuth
from apps.hboce.pages.partials.gateway import GatewayLogin
from apps.hboce.pages.partials.loader import Loader

from apps.hboce.flows.settings import go_to_settings


def b2b_login(driver, email, password, operatorname, from_page=HomeUnauth):
    page = from_page(driver)

    page.click_on_login_button()

    page = GatewayLogin(driver)
    page.enter_gateway_iframe()
    page.click_on_b2b_sign_in_provider_button()
    page.click_on_provider_dropdown()

    provider = page.get_provider(operatorname)
    page.helper.click(provider)

    page.input_text_on_email(email)
    page.input_text_on_password(password)
    page.click_on_login_button()

    page.exit_gateway_iframe()

    page = HomeAuth(driver)
    page.wait_for_account_name()

    return page


def d2c_login(driver, email, password, from_page=HomeUnauth):
    page = from_page(driver)

    page.click_on_login_button()

    page = GatewayLogin(driver)
    page.enter_gateway_iframe()
    page.click_on_d2c_sign_in_provider_button()

    page.input_text_on_email(email)
    page.input_text_on_password(password)
    page.click_on_login_button()

    page.exit_gateway_iframe()

    page = HomeAuth(driver)
    page.wait_for_account_name()

    return page


def logout_through_settings(driver, from_page=HomeAuth):
    page = go_to_settings(driver, from_page=from_page)

    page.click_on_logout_button()
    page.click_on_confirm_sign_out_button()
    sleep(3)

    page.exit_gateway_iframe()

    return HomeUnauth(driver)
