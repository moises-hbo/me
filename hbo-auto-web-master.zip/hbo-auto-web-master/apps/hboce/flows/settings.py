from helpers.sleeper import Sleeper as sleep

from apps.hboce.pages.home import HomeAuth
from apps.hboce.pages.partials.gateway import GatewaySettings


def go_to_settings(driver, enter_iframe=True, from_page=HomeAuth):
    page = from_page(driver)
    sleep(2)
    page.hover_over_my_account()
    sleep(1)
    page.click_on_settings_button()

    page = GatewaySettings(driver)
    if enter_iframe:
        page.enter_gateway_iframe()

    return page


def go_to_settings_app_prefs(driver, enter_iframe=True, exit_iframe=False):
    page = go_to_settings(driver, enter_iframe)
    page.click_on_app_prefs_button()

    if exit_iframe:
        page.exit_gateway_iframe()

    return page


def switch_language(driver, exit_iframe=True):
    page = GatewaySettings(driver)
    page.click_on_language_dropdown()

    current_lang = page.get_current_language()
    langs = page.get_language_options()

    # Pick the non-active language
    for lang in langs:
        text = page.helper.get_text(lang.find_element_by_xpath("./span"))
        if text != current_lang:
            page.helper.click(lang)
            break
    page.click_on_save_button()

    if exit_iframe:
        page.exit_gateway_iframe()
