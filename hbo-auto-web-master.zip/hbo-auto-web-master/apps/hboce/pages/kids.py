from apps.hboce.pages.base.page import BasePageObject as Page
from hboapi.hboce.apihandler import Core
from apps.hboce.pages.player import PlayerPage
from time import time
from helpers.sleeper import Sleeper as sleep


class Kids(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)
        self.api = Core(platform=self.platform, countryid=self.country_id)
        self.player = PlayerPage(driver=driver)
        self.series_name = "spongebob"
        self.movie_name = "frozen"

        self.container = self.create(dict(locator="/html/body/nav[1]", type="xpath"))
        self.kids_button = self.create(dict(
            locator="/html/body/nav/div/ul/li[3]/a", type="xpath"))
        self.kids_lock_button = self.create(dict(
            locator="/html/body/nav/div/div/div[3]", type="xpath"))
        self.kids_onboarding_first_screen = self.create(dict(
            locator="onboarding-first-screen", type="id"))
        self.kids_onboarding_maybe_later = self.create(dict(locator="maybeLater", type="id"))
        self.kids_carousel_title = self.create(dict(
            locator="/html/body/main/div[1]/div/div/div[5]/div", type="xpath"))
        self.kids_carousel = self.create(dict(
            locator="/html/body/main/div[1]/div", type="xpath"))
        self.kids_content_in_carousel = self.create(dict(
            locator="//div[@class='flickity-slider']/div", type="xpath"), True)
        self.kids_carousel_flickity_prev_button = self.create(dict(
            locator="/html/body/main/div[1]/button[1]", type="xpath"))
        self.kids_carousel_flickity_next_button = self.create(dict(
            locator="/html/body/main/div[1]/button[2]", type="xpath"))
        self.kids_content_page_close_button = self.create(dict(
            locator="/html/body/div[4]", type="xpath"))
        self.kids_content_shortcut_shelf = self.create(dict(
            locator="/html/body/main/div[4]", type="xpath"))
        self.kids_player_close_button = self.create(dict(
            locator="hbo-sdk--player-close", type="id"))
        self.kids_next_episode_button = self.create(dict(
            locator="hbo-sdk--player-nextepisode", type="id"))
        self.kids_previous_episode_button = self.create(dict(
            locator="hbo-sdk--player-previousepisode", type="id"))
        self.kids_player_title = self.create(dict(locator="player-title", type="id"))
        self.kids_meta_table = self.create(dict(
            locator='/html/body/div[5]/div/div/div[3]/div[3]/div/div[2]', type="xpath"))
        self.kids_add_to_favorite = self.create(dict(
            locator='/html/body/div[5]/div/div/div[3]/div[2]/a[1]', type="xpath"))
        self.kids_remove_from_favorite = self.create(dict(
            locator='/html/body/div[5]/div/div/div[3]/div[2]/a[2]', type="xpath"))
        self.select_random_kids_series_episode = self.create(dict(locator="episodes", type="id"))
        self.alert_close = self.create(dict(locator="//div[@class='alert-close']", type="xpath"))

        self.default_text_color = "255, 255, 255"
        self.default_background_color = "0, 145, 234"

    def check_appearance(self):
        color = self.helper.get_element_css_property(
            locator="/html/body/nav[1]", locator_type="xpath", css_property="color")
        color_is_good = self.default_text_color in color
        background = self.helper.get_element_css_property(
            locator="/html/body/nav[1]", locator_type="xpath", css_property="background-color")
        bg_is_good = self.default_background_color in background
        if not color_is_good:
            if not bg_is_good:
                return self.Error("both font color and background color are not as expected")
            else:
                return self.Error("font color is not as expected")
        elif not bg_is_good:
            return self.Error("background color is not as expected")
        return True

    def check_kids_onboarding_screen(self):
        clicked_kids_lock_button = self.kids_lock_button.clickable_and_click
        if not clicked_kids_lock_button:
            return self.Error("failed to click kids lock button")
        result = self.kids_onboarding_first_screen.visible
        return True if result else self.Error("onboarding screen is not visible")

    def check_carousel_switching(self, direction):
        original = self.get_active_carousel()
        if isinstance(original, self.Error):
            return original
        self.next_or_previous_carousel(direction=direction)
        switched = self.get_active_carousel()
        if isinstance(switched, self.Error):
            return switched
        result = original != switched
        return True if result else self.Error("failed to switch carousel")

    def get_active_carousel(self):
        contents_in_carousel = self.kids_content_in_carousel.element
        if not contents_in_carousel:
            return self.Error("failed to get contents from carousel")
        for content in contents_in_carousel:
            aria_active = content.get_attribute("aria-selected")
            if aria_active == "true":
                return content
        return self.Error("failed to get active carousel")

    def next_or_previous_carousel(self, direction):
        self.kids_carousel_flickity_next_button.visible.click() if direction is "next" \
            else self.kids_carousel_flickity_prev_button.visible.click()

    def play_from_carousel(self, timeout=30):
        now = time()
        while time() < now + timeout:
            play_started = self.player.play_from_carousel()
            if isinstance(play_started, self.Error):
                return play_started
            alert_close = self.helper.wait.visible(element=self.alert_close.locator, timeout=3)
            if alert_close:
                alert_close.click()
                sleep(1)
                play_started = self.player.play_from_carousel()
                if isinstance(play_started, self.Error):
                    return play_started
            self.player.play_from_beginning()
            self.player.move_mouse()
            close_button = self.helper.wait.visible(
                element=self.kids_player_close_button.locator, timeout=3)
            if close_button:
                return True
        return self.Error("failed to open content from carousel")

    def check_episode_change(self, next_or_prev):
        original = self.player.start_series(keyword=self.series_name)
        if isinstance(original, self.Error):
            return original
        changed = self.player.press_on_next_or_previous_button(next_or_prev=next_or_prev)
        if isinstance(changed, self.Error):
            return changed
        result = original != changed
        return True if result else self.Error("failed to change episode")

    def check_favorite_category(self):
        if "your favorites" not in self.helper.get_shelf_titles():
            self.player.search_and_open_content(content_name=self.movie_name)
            self.player.add_or_remove_favorites()
            self.kids_content_page_close_button.clickable_and_click
            self.helper.open_section(section="kids")
        result = "your favorites" in self.helper.get_shelf_titles()
        return True if result else self.Error("favourite category is not visible")

    def is_kids_related_content(self):
        element = self.player.select_shelf_and_get_element()
        if isinstance(element, self.Error):
            return element
        eid = element.get_attribute('data-external-id')
        if not eid:
            return self.Error("failed to get external id of content")
        content_type = element.get_attribute('data-vcms-content-type')
        if not content_type:
            return self.Error("failed to get content type of content")
        content = self.api.content_by_externalid(
            eid=eid, contenttype=content_type)
        if "Id" not in content.keys():
            return self.Error("failed to get content id from api")
        content_id = content['Id']
        catalog_number = self.api.content_by_id(content_id)
        if "Catalog" not in catalog_number.keys():
            return self.Error("failed to get catalog number from api")
        return True if catalog_number['Catalog'] == 2 or catalog_number['Catalog'] == 3 else False
