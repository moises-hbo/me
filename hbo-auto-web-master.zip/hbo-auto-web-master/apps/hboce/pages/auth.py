from hboapi.hboce.utility import get_common_data
from hboapi.hboce.apihandler import Core
from apps.hboce.pages.base.page import BasePageObject as Page
from random import choice
from hboapi.hboce.utility import generate_username, generate_email_address,\
    generate_password, generate_voucher_code


class AuthPage(Page):
    def __init__(self, driver, login_type="b2b"):
        Page.__init__(self, driver)
        self.helper.login_type = login_type
        self.api = Core(platform=self.platform, countryid=self.country_id)
        self.login_type = login_type
        self.nick = self.get_nick_by_api()
        self.vip_operator = self.api.vip_operator().get("operatorName")
        self.mail = get_common_data().get("{}_login_email".format(login_type))
        self.password = get_common_data().get("login_password")
        self.operator = self.api.vip_operator()["operatorName"]
        self.reg_user = generate_username()
        self.reg_email = generate_email_address()
        self.reg_password = generate_password()

        # Elements
        self.gw_close_btn = self.create(dict(locator="div.modal-close", type="css selector"))
        self.gw_modal_container = self.create(dict(locator="gatewayFrameContainer", type="id"))
        self.logout_btn = self.create(dict(locator="signout", type="id"))
        self.logout_cancel_btn = self.create(dict(locator="span.btn.primary.selected.alert-btn", type="css selector"))
        self.logout_logout_btn = self.create(dict(locator="span.btn.secondary.selected.alert-btn", type="css selector"))
        self.logout_modal = self.create(dict(locator="div.alert-container", type="css selector"))
        self.login_btn = self.create(dict(locator="signin", type="id"))
        self.login_login_btn = self.create(dict(
            locator="gw_operator_type_signin_d2c" if self.login_type == "d2c" else "gw_operator_type_signin_b2b",
            type="id"))
        self.b2b_login_btn = self.create(dict(locator="gw_operator_type_signin_b2b", type="id"))
        self.login_form = self.create(dict(locator="div.st-loginForm-formWrapper", type="css selector"))
        self.provider_dropdown = self.create(dict(locator="div.dropdown-placeholder", type="css selector"))
        self.dropdown_options = self.create(dict(
            locator="div.dropdown-container > div > div", type="css selector"), True)
        self.email_input = self.create(dict(locator="1", type="id"))
        self.password_input = self.create(dict(locator="5", type="id"))
        self.login_finish_btn = self.create(dict(locator="gw_login_06_sign_in", type="id"))
        self.hbo_message = self.create(dict(locator="div.hbo-message", type="css selector"))
        self.gw_welcome_signin = self.create(dict(locator="gw_welcome_signin", type="id"))
        self.settings_btn = self.create(dict(locator="settings", type="id"))
        self.logout_btn_settings = self.create(dict(locator="gw_settings_sidebar_sign_out", type="id"))
        self.confirm_logout_btn_settings = self.create(dict(locator="hbo_notification_sign_out_yes", type="id"))
        self.registration_btn = self.create(dict(locator="signup", type="id"))
        self.signup_b2b_btn = self.create(dict(locator="gw_operator_type_signup_b2b", type="id"))
        self.signup_d2c_btn = self.create(dict(locator="gw_operator_type_signup_d2c", type="id"))
        self.voucher_input = self.create(dict(locator="12", type="id"))
        self.email_validation_input = self.create(dict(locator="2", type="id"))
        self.username_input = self.create(dict(locator="3", type="id"))
        self.password_validation_input = self.create(dict(locator="6", type="id"))
        self.newsletter_checkbox = self.create(dict(locator="9", type="id"))
        self.age_verification_checkbox = self.create(dict(locator="10", type="id"))
        self.registration_finish_btn = self.create(dict(
            locator="gw_registration_11_sing_in", type="id"))
        self.start_browsing_btn = self.create(dict(
            locator="gw_signup_success_start_browsing", type="id"))
        self.error_message = self.create(dict(
            locator="div.checkboxErrorContainer > span.st-error",
            type="css selector"))
        self.checkbox = self.create(dict(locator="10", type="id"))

    def get_nick_by_api(self):
        try:
            nick = self.api.nick_by_api(authtype=self.login_type)
        except AssertionError:
            nick = None
        return nick

    def check_ap_of_gw_close_btn(self):
        result = self.click_random_content_of_random_shelf()
        if isinstance(result, self.Error):
            return result
        gw_close_btn = self.gw_close_btn.visible
        gw_close_btn = gw_close_btn if gw_close_btn else self.Error("gateway close button is not visible")
        return gw_close_btn

    def click_random_content_of_random_shelf(self):
        shelf = choice(self.helper.get_shelf_titles())
        content = choice(self.helper.get_contents_from_shelf(shelf=shelf))
        content = self.helper.wait.visible(element=content)
        if not content:
            return self.Error("content is not visible")
        content.click()

    def check_fu_of_gw_close_btn(self):
        gw_close_btn = self.check_ap_of_gw_close_btn()
        if isinstance(gw_close_btn, self.Error):
            return gw_close_btn
        else:
            gw_close_btn.click()
        gw_modal_container = self.gw_modal_container.not_visible
        gw_modal_container = gw_modal_container if gw_modal_container else self.Error("gateway modal is not closed")
        return gw_modal_container

    def check_ap_of_logout_cancel_btn(self):
        nickname = self.nickname.visible
        if not nickname:
            return self.Error("nickname is not visible")
        self.d_helper.move_mouse_to(element=nickname)
        logout_btn = self.logout_btn.visible
        if not logout_btn:
            return self.Error("logout button is not visible")
        logout_btn.click()
        logout_cancel_btn = self.logout_cancel_btn.visible
        return logout_cancel_btn if logout_cancel_btn else self.Error("logout cancel button is not visible")

    def check_ap_of_logout_logout_btn(self):
        nickname = self.nickname.visible
        if not nickname:
            return self.Error("nickname is not visible")
        self.d_helper.move_mouse_to(element=nickname)
        logout_btn = self.logout_btn.visible
        if not logout_btn:
            return self.Error("logout button is not visible")
        logout_btn.click()
        logout_logout_btn = self.logout_logout_btn.visible
        return logout_logout_btn if logout_logout_btn else self.Error("logout logout button is not visible")

    def check_fu_of_logout_cancel_btn(self):
        nickname = self.nickname.visible
        if not nickname:
            return self.Error("nickname is not visible")
        self.d_helper.move_mouse_to(element=nickname)
        logout_btn = self.logout_btn.visible
        if not logout_btn:
            return self.Error("logout button is not visible")
        logout_btn.click()
        logout_cancel_btn = self.logout_cancel_btn.visible
        if not logout_cancel_btn:
            return self.Error("logout cancel button is not visible")
        logout_cancel_btn.click()
        logout_modal = self.logout_modal.not_visible
        return logout_modal if logout_modal else self.Error("logout modal is not closed")

    def check_ap_of_login_login_btn(self):
        login_btn = self.login_btn.visible
        if not login_btn:
            return self.Error("login button is not visible")
        login_btn.click()
        login_login_btn = self.helper.enter_iframe_and_wait_for_element_to_be_visible(
            element=self.login_login_btn.locator)
        return login_login_btn if login_login_btn else self.Error(
            "{} login button is not visible".format(self.login_type))

    def check_fu_of_login_btn_in_modal(self, tr_id):
        gw_modal = self.gw_modal_container.not_visible
        return dict(
            tr_id=tr_id, name="test_functionality_of_d2c_login_button_in_modal", status="passed",
            duration="0", msg="everything went good") if gw_modal else dict(
            tr_id=tr_id, name="test_functionality_of_d2c_login_button_in_modal", status="failed",
            duration="0", msg="gateway modal is not closed")

    def login_setup(self, url=None):
        if url:
            self.driver.get("{}{}".format(self.driver.current_url, url))
        self.helper.is_anonymus = self.helper.wait.script_to_be_executed(
            script=self.is_anonymus_script)
        if not self.helper.is_anonymus:
            return True if url in self.driver.current_url else self.Error("wrong url")
        if not url:
            # Clicking login button
            login_button = self.login_btn.visible
            if not login_button:
                return self.Error("login button is not visible")
            login_button.click()

        # Entering gateway frame
        gateway_frame = self.gateway_frame.element
        self.d_helper.enter_iframe(element=gateway_frame)
        if url == "activate":
            welcome_signin = self.gw_welcome_signin.visible
            if not welcome_signin:
                return self.Error("welcome signin button is not visible")
            welcome_signin.click()
        if url != "subscription-management":
            login_login_btn = self.login_login_btn.visible
            if not login_login_btn:
                return self.Error("{} login button is not visible".format(self.login_type))
            login_login_btn.click()
            provider_dropdown = self.provider_dropdown.visible
            if not provider_dropdown:
                return self.Error("provider dropdown is not visible")
            provider_dropdown.click()
            if self.dropdown_options.visible:
                operators = self.dropdown_options.element
                vip_operator = [x for x in operators if x.text == self.vip_operator][0]
                vip_operator = self.helper.wait.visible(element=vip_operator)
                if not vip_operator:
                    return self.Error("vip operator is not visible")
                vip_operator.click()
        login_form = self.login_form.visible
        return login_form if login_form else self.Error("login form is not visible")

    def check_pr_of_login(self, url=None):
        # Login setup
        log_in_setup_result = self.login_setup(url=url)
        if isinstance(log_in_setup_result, self.Error):
            return log_in_setup_result

        # Filling email input
        email_input = self.email_input.visible
        if not email_input:
            return self.Error("email input is not visible")
        self.helper.input_text(
            locator_or_element=email_input, text=self.mail, pause=0.05)

        # Filling password input
        password_input = self.password_input.visible
        if not password_input:
            return self.Error("password input is not visible")
        self.helper.input_text(
            locator_or_element=password_input, text=self.password, pause=0.05)
        login_finish_button = self.login_finish_btn.visible
        if not login_finish_button:
            return self.Error("login finish button is not visible")
        login_finish_button.click()
        hbo_message = self.helper.wait.visible(element=self.hbo_message.locator, timeout=5)
        if hbo_message:
            return self.Error(hbo_message.text)
        if not url:
            nick = self.helper.exit_iframe_and_wait_for_element_to_be_visible(
                element=self.nickname.element)
            result = nick.text if nick else False
            return result if result else self.Error("failed to log in")
        else:
            current_url = self.driver.current_url
            return True if url in current_url else False

    def check_fu_of_logout_logout_btn(self, tr_id):
        logout_modal = self.logout_modal.not_visible
        return dict(
            tr_id=tr_id, name="test_functionality_of_logout_logout_button_in_modal", status="passed",
            duration="0", msg="everything went good") if logout_modal else dict(
            tr_id=tr_id, name="test_functionality_of_logout_logout_button_in_modal", status="failed",
            duration="0", msg="logout gateway modal is not closed")

    def check_pr_of_logout(self):
        nickname = self.nickname.visible
        if not nickname:
            return self.Error("nickname is not visible")
        if not self.d_helper.move_mouse_to(element=nickname):
            return self.Error("failed to hover over nickname")
        logout_btn = self.logout_btn.visible
        if not logout_btn:
            return self.Error("logout button is not visible")
        logout_btn.click()
        logout_logout_btn = self.logout_logout_btn.visible
        if not logout_logout_btn:
            return self.Error("logout logout button is not visible")
        logout_logout_btn.click()
        successfully_logged_out = self.helper.wait.script_to_be_executed(
            script=self.is_anonymus_script, timeout=10)
        return True if successfully_logged_out else self.Error("logout was not successful")

    def check_fu_of_logout_btn_settings(self, tr_id):
        gateway_modal = self.gateway_frame.not_visible
        return dict(
            tr_id=tr_id, name="test_functionality_of_logout_logout_button_in_modal", status="passed",
            duration="0", msg="everything went good") if gateway_modal else dict(
            tr_id=tr_id, name="test_functionality_of_logout_logout_button_in_modal", status="failed",
            duration="0", msg="settings gateway modal is not closed")

    def check_pr_of_logout_through_settings(self):
        nick = self.helper.wait.visible(element=self.nickname.locator, timeout=5)
        if not nick:
            return self.Error("nickname is not visible")
        if not self.d_helper.move_mouse_to(element=nick):
            return self.Error("failed to hover over nickname")
        settings_button = self.settings_btn.visible
        if not settings_button:
            return self.Error("settings button is not visible")
        settings_button.click()
        logout_button = self.helper.enter_iframe_and_wait_for_element_to_be_visible(
            element=self.logout_btn_settings.locator)
        if not logout_button:
            return self.Error("logout button is not visible")
        self.d_helper.move_mouse_to(element=logout_button)
        logout_button.click()
        confirm_signout = self.confirm_logout_btn_settings.clickable_and_click
        if not confirm_signout:
            return self.Error("confirm signout button is not clickable")
        self.d_helper.exit_iframe()
        successfully_logged_out = self.helper.wait.script_to_be_executed(
            script=self.is_anonymus_script, timeout=10)
        return True if successfully_logged_out else self.Error("logout was not successful")

    def registration_setup(self):
        self.helper.is_anonymus = self.helper.wait.script_to_be_executed(
            script=self.is_anonymus_script, timeout=10
        )
        if not self.helper.is_anonymus:
            return self.Error("failed to register, user is logged in")
        registration_btn = self.registration_btn.visible
        if not registration_btn:
            return self.Error("registration button is not visible")
        registration_btn.click()
        entered_gateway_frame = self.helper.enter_iframe_and_wait_for_element_to_be_visible(
            element=self.signup_b2b_btn.locator)
        if not entered_gateway_frame:
            return self.Error("failed to enter gateway frame")
        if self.login_type == "b2b":
            b2b_btn = self.signup_b2b_btn.visible
            if not b2b_btn:
                return self.Error("b2b button is not visible")
            b2b_btn.click()
            provider_dropdown = self.provider_dropdown.visible
            if not provider_dropdown:
                return self.Error("provider dropdown is not visible")
            provider_dropdown.click()
            vip_operator = self.helper.get_list_item(
                self.dropdown_options.locator, self.operator)
            if not vip_operator:
                return self.Error("failed to find vip operator")
            vip_operator.click()
        elif self.login_type == "d2c":
            d2c_btn = self.signup_d2c_btn.visible
            if not d2c_btn:
                return self.Error("d2c button is not visible")
            d2c_btn.click()
        mail_input = self.email_input.visible
        return True if mail_input else self.Error("email input is not visible")

    def check_pr_of_registration(self, last_button="start_browsing", negative=False, delay=0.1):
        reg_setup = self.registration_setup()
        if isinstance(reg_setup, self.Error):
            return reg_setup
        registration_finish_button = self.registration_finish_btn.element
        voucher_input = self.voucher_input.element
        v = generate_voucher_code(countryid=self.country_id)

        if not negative:
            # Filling voucher code input
            if not self.voucher_input.visible:
                return self.Error("voucher input is not visible")
            self.helper.input_text(
                locator_or_element=voucher_input, text=v, pause=delay)

            # Filling email input
            email_input = self.email_input.visible
            if not email_input:
                return self.Error("email input is not visible")
            self.helper.input_text(
                locator_or_element=email_input, text=self.reg_email, pause=delay)

            # Filling email validation input
            email_validation_input = self.email_validation_input.visible
            if not email_validation_input:
                return self.Error("email validation input is not visible")
            self.helper.input_text(
                locator_or_element=email_validation_input, text=self.reg_email, pause=delay)

            # Filling username input
            username_input = self.username_input.visible
            if not username_input:
                return self.Error("username input is not visible")
            self.helper.input_text(
                locator_or_element=username_input, text=self.reg_user, pause=delay)

            # Filling password input
            password_input = self.password_input.visible
            if not password_input:
                return self.Error("password input is not visible")
            self.helper.input_text(
                locator_or_element=password_input, text=self.reg_password, pause=delay)

            # Filling password validation input
            password__validation_input = self.password_validation_input.visible
            if not password__validation_input:
                return self.Error("password validation input is not visible")
            self.helper.input_text(
                locator_or_element=password__validation_input, text=self.reg_password, pause=delay)

            # Clicking the checkbox
            checkbox = self.checkbox.visible
            if not checkbox:
                return self.Error("checkbox is not visible")
            checkbox.click()

        else:
            # Enter without filling voucher code input
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without voucher code")
            self.d_helper.move_mouse_to(element=voucher_input)

            # Filling voucher code input
            self.helper.input_text(
                locator_or_element=voucher_input, text=v, pause=delay)

            # Enter without filling email input
            email_input = self.email_input.visible
            if not email_input:
                return self.Error("email input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without email")

            # Filling email input
            self.helper.input_text(
                locator_or_element=email_input, text=self.reg_email, pause=delay)

            # Enter without filling email validation input
            email_validation_input = self.email_validation_input.visible
            if not email_validation_input:
                return self.Error("email validation input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without email validation")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling email validation input
            self.helper.input_text(
                locator_or_element=email_validation_input, text=self.reg_email, pause=delay)

            # Enter without filling username input
            username_input = self.username_input.visible
            if not username_input:
                return self.Error("username input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without username")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling username input
            self.helper.input_text(
                locator_or_element=username_input, text=self.reg_user, pause=delay)

            # Enter without filling password input
            password_input = self.password_input.visible
            if not password_input:
                return self.Error("password input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without password")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling password input
            self.helper.input_text(
                locator_or_element=password_input, text=self.reg_password, pause=delay)

            # Enter without filling password validation input
            password_validation_input = self.password_validation_input.visible
            if not password_validation_input:
                return self.Error("password validation input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without password validation")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling password validation input differently then the previous one
            self.helper.input_text(
                locator_or_element=password_validation_input, text="pongopongo", pause=delay)
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting with different passwords")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling password validation input
            password_validation_input.clear()
            self.helper.input_text(
                locator_or_element=password_validation_input, text=self.reg_password, pause=delay)

            # Enter without clicking the checkbox
            checkbox = self.checkbox.visible
            if not checkbox:
                return self.Error("checkbox is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_btn.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting with checkbox unchecked")
            self.d_helper.move_mouse_to(element=email_input)

            # Clicking the checkbox
            checkbox = self.checkbox.visible
            if not checkbox:
                return self.Error("checkbox is not visible")
            checkbox.click()

        # Clicking the finish button
        registration_finish_button = self.registration_finish_btn.visible
        if not registration_finish_button:
            return self.Error("registration finish button is not visible")
        registration_finish_button.click()
        last_button_element = self.gw_close_btn if last_button == "close" else self.start_browsing_btn
        last_button_visible = True if last_button_element.visible else False
        if not last_button_visible:
            return self.Error("{} button is not visible".format(last_button))
        last_button_element.clickable_and_click
        result = True if self.helper.exit_iframe_and_wait_for_element_to_be_visible(
            element=self.nickname.locator, timeout=20) else self.Error(
            "user nickname is not visible after registration")
        return dict(start_browsing_btn=last_button_visible, result=result)

    def check_fu_of_start_browsing_btn(self, tr_id):
        gateway_modal = self.gateway_frame.not_visible
        return dict(
            tr_id=tr_id, name="test_functionality_of_start_browsing_button", status="passed",
            duration="0", msg="everything went good") if gateway_modal else dict(
            tr_id=tr_id, name="test_functionality_of_start_browsing_button", status="failed",
            duration="0", msg="gateway modal is not closed")
