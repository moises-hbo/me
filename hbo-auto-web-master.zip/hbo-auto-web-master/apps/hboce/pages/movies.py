from apps.hboce.pages.base.page import BasePageObject as Page
from apps.hboce.pages.player import PlayerPage
from random import choice
from time import time
from hboapi.hboce.utility import get_common_data
from hboapi.hboce.apihandler import Core, Bookmarking
from requests import get


class MoviesPage(Page):
    def __init__(self, driver, login_type="b2b", timeout=10):
        Page.__init__(self, driver)
        self.timeout = timeout
        self.login_type = login_type
        self.player = PlayerPage(driver=driver)
        self.movie_names = ["game of thrones the last watch", "native son", "icebox", "o.g.",
                            "united skates", "the wizard of lies", "fahrenheit 451", "confirmation",
                            "life is awesome", "man at war", "australia", "nightingale"]
        self.movie_name = choice(self.movie_names)
        self.common_data = get_common_data()
        self.mail = self.common_data.get("{}_login_email".format(login_type))
        self.pw = self.common_data.get("login_password")
        self.auth = dict(b2b=dict(mail=self.mail, pw=self.pw,
                                  c_id="0e9473b3-9805-4647-b0bd-dc5813c917a3",
                                  indiv="F4C04296-9EB1-F3C4-E85A-9EF8DA745F9D",
                                  dev_id="00000000-0000-0000-0000-000000000000",
                                  nick="ReadyForTheHud", country="HUN"),
                         d2c=dict(mail="hboceauto+d2c@gmail.com", pw="common",
                                  c_id="765e70da-d000-4263-84c3-6d82b91ae9f7",
                                  indiv="71E59CFF-A1F9-844E-4FA2-D6EC7137124A",
                                  dev_id="00000000-0000-0000-0000-000000000000",
                                  country="HUN"))
        self.api = Core(platform=self.platform, countryid=self.country_id)
        self.bookmarking = Bookmarking(platform=self.platform, countryid=self.country_id)
        self.api.configuration_api()
        self.api.settings_api()
        self.search_api_url = "https://huapi.hbogo.eu/v7/Search/json/ENG/COMP/###KEYWORD###/-/-/-/-/-/3"

        # Elements
        self.shelf_title_header = self.create(dict(
            locator="//header[@class='shelf-header']/div[@class='shelf-title']/h2",
            type="xpath", color="255, 255, 255, 1", name="Shelf Title Header",
            background_color="0, 0, 0, 0"), True)
        self.movies_button = self.create(dict(
            locator="/html/body/nav/div/ul/li[2]", type="xpath", name="Movies Button"))
        self.content_shelves = self.create(dict(
            locator="/html/body/main/div[###NUM###]/div[@class='shelf-content']",
            type="xpath", name="Content Shelves"))
        self.content_shelf_headers = self.create(dict(
            locator="/html/body/main/div[###NUM###]/div[@class='shelf-content']/header/div[1]/h2/a",
            type="xpath", name="Content Shelf Headers"))
        self.new_contents_shelf = self.create(dict(
            locator="/html/body/main/div[3]/div[@class='shelf-content']", type="xpath",
            name="New Contents Shelf"))
        self.movie_category_buttons = self.create(dict(
            locator="/html/body/nav/div/ul/li[2]/div/ul[1]/li/a", type="xpath",
            name="Movie Category Buttons"), True)
        self.imdb_rating = self.create(dict(
            locator="//div/div/a/span[1]/span[@class='rate-val']", type="xpath",
            name="IMDb rating"), True)
        self.movie_category_buttons_2 = self.create(dict(
            locator="/html/body/nav/div/ul/li[2]/div/ul[2]/li/a", type="xpath",
            name="Movie Category Genre Buttons"), True)
        self.movie_category_buttons_3 = self.create(dict(
            locator="/html/body/nav/div/ul/li[2]/div/ul[3]/li/a", type="xpath",
            name="Movie Category Genre Buttons"), True)
        self.movie_content_in_a_category_page = self.create(dict(
            locator="/html/body/main/div[1]/div/div", type="xpath",
            name="Movie Content In A Category Page"), True)
        self.movie_category_genres = dict(
            action_adventure=["action", "adventure", "spy", "western", "martial arts",
                              "comics adaptation", "game adaptation", "comic"],
            drama=["drama", "disaster", "war feature", "war", "biography", "psychological", "history", "political"],
            comedy=["comedy", "dramedy", "satire", "sitcom", "parody"],
            crime=["crime", "spy"],
            romance=["romance"],
            thriller_horror=["thriller", "horror", "psychological", "mystery", "suspense"],
            scifi_fantasy=["science fiction", "fantasy", "comics adaptation", "fairy tale"],
            family=["family", "puppet", "animation"],
            documentary=["documentary", "news"],
            music=["music", "concert", "musical", "dance"],
            special=["special", "reality-tv", "nature",  "short", "stand-up", "science",
                     "filler programme", "talk-show", "magazine", "game-show", "feature",
                     "interview", "behind the scenes"]
        )
        self.movies_header = self.create(dict(
            locator="/html/body/main/div[1]/header/div[1]/h2", type="xpath",
            name="Movies Header"))

        # Content Detail Page
        self.metadata_table = self.create(dict(
            locator="//div[@class='show-info']/div/div[@class='show-meta']/table/tbody/tr",
            type="xpath", name="Meta-Data Label"), True)
        self.other_meta = self.create(dict(
            locator="//div[@class='meta']",
            type="xpath", name="Other Meta-Data"))
        self.content_imdb = self.create(dict(
            locator="//div[@class='meta']/div/span[@class='rate-val']",
            type="xpath", name="Content page IMDb label"))

    def check_shelf_title_appearance(self):
        shelf_headers = self.shelf_title_header.element
        shelf_header_titles = list(
            map(lambda title: title.text, shelf_headers))
        self.helper.log("shelf header titles of movies page:\n{titles}".format(
            titles=shelf_header_titles))
        for header in shelf_headers:
            if not header.is_displayed():
                return self.Error("{} shelf header is not visible".format(header.text))
        return True

    def check_css_property(self, element=None, css_property="background-color"):
        element = self.shelf_title_header if element is None else element
        if not element.visible:
            return self.Error("{} is not visible.".format(self.shelf_title_header.locator.get("name")))
        expected = self.shelf_title_header.locator.get(css_property)
        css_property = "background-color" if css_property == "background_color" else css_property
        actual = element.visible.value_of_css_property(
            css_property).split("(")[1].strip(")")
        return True if actual in expected else self.Error("{} is not as expected".format(element.name))

    def check_items_of_premier_shelf(self):
        contents = self.helper.get_contents_from_shelf(shelf="recently added")
        if not contents:
            return self.Error("failed to get contents from recently added shelf")
        links = [x.find_element_by_xpath("./a") for x in contents]
        if not links:
            return self.Error("failed to get content links of recently added shelf")
        link_texts = [x.get_property("text") for x in links]
        if not link_texts:
            return self.Error("failed to get the texts of content links")
        recently_added_types = []
        for text in link_texts:
            texty = text.split()
            first_part = str("{}".format(texty[0])).lower()
            recently_added_types.append(first_part)
            if first_part not in ["premiere", "returning"]:
                return self.Error("non-premiere content in recently added shelf")
        self.helper.log("contents of premier shelf has the following types: {}".format(
            recently_added_types))
        return True

    def check_items_of_imdb_highest(self):
        movies_button = self.movies_button.visible
        self.d_helper.move_mouse_to(element=movies_button)
        movie_cat_btns = self.movie_category_buttons.element
        for movie_cat_btn in movie_cat_btns:
            text = self.helper.wait.visible(
                element=movie_cat_btn).get_property("text").lower()
            if "critically acclaimed movies" == text or "imdb" in text:
                movie_cat_btn.click()
                break
        ratings_elements = self.imdb_rating.element
        if not ratings_elements:
            return self.Error("failed to find rating elements")
        ratings = map(float, [item.text for item in ratings_elements])
        for rating in ratings:
            if rating < 7.0:
                return self.Error("at least one of the movies has imdb rating under 7")
        return True

    def check_if_movies_in_a_category_have_the_right_genre(self):
        movies_button = self.movies_button.visible
        if not movies_button:
            return self.Error("movies button is not visible")
        self.d_helper.move_mouse_to(element=movies_button)
        movie_categories = self.movie_category_buttons_2.element
        movie_categories_2 = self.movie_category_buttons_3.element
        if not movie_categories or not movie_categories_2:
            return self.Error("failed to get movie categories")
        movie_categories = movie_categories + movie_categories_2
        selected_category = choice(movie_categories)
        category_name = selected_category.get_property("text").lower().replace("-", "").replace(", ", "_")
        self.helper.log("selected category: {}".format(category_name))
        selected_category = self.helper.wait.visible(element=selected_category)
        if not selected_category:
            return self.Error("selected category button is not visible")
        self.d_helper.move_mouse_to(element=selected_category)
        selected_category.click()
        movies = self.movie_content_in_a_category_page.element
        if not movies:
            return self.Error("failed to get contents in category page")
        everything_is_ok = True
        message = "success"
        for movie in movies:
            genre_label = movie.find_element_by_css_selector("span.genres")
            if not genre_label:
                return self.Error("failed to find genre label of content")
            genre = genre_label.text
            cat = self.movie_category_genres.get(category_name)
            okay = False
            for g in genre.split(", "):
                if g in cat:
                    okay = True
                    break
            if not okay:
                message = "this movie should not be in this category: \n{}".format(movie.get_property("innerText"))
                everything_is_ok = False
        return True if everything_is_ok else self.Error(message)

    def check_category_buttons_functionality(self):
        movies_button = self.movies_button.visible
        self.d_helper.move_mouse_to(element=movies_button)
        movie_categories = self.movie_category_buttons_2.element
        movie_categories = movie_categories + self.movie_category_buttons_3.element
        for cat in movie_categories:
            url = cat.get_attribute("href")
            category_name = cat.get_property("text")
            self.d_helper.open_window(url=url)
            self.d_helper.switch_to_window(1)
            header = self.movies_header.visible
            if category_name.lower() not in header.text.lower():
                if not category_name.lower() == "special" and "other" not in header.text.lower():
                    return self.Error("invalid category name: {}".format(header.text))
            self.d_helper.close_window()
            self.d_helper.switch_to_window(0)
        return True

    def check_coming_soon_stuff(self):
        movies_button = self.movies_button.visible
        if not movies_button:
            return self.Error("movies button is not visible")
        self.d_helper.move_mouse_to(element=movies_button)
        movie_cat_btns = self.movie_category_buttons.element
        if not movie_cat_btns:
            return self.Error("failed to get movie category buttons")
        found = False
        for movie_cat_btn in movie_cat_btns:
            text = movie_cat_btn.get_property("text").lower()
            if "coming soon" in text:
                movie_cat_btn.click()
                found = True
                break
        if not found:
            return self.Error("failed to find coming soon category")
        movies = self.movie_content_in_a_category_page.element
        if not movies:
            return self.Error("failed to find content in coming soon category")
        for movie in movies:
            movie_release_time = float(
                movie.get_attribute("data-available-date"))
            if movie_release_time < time():
                return self.Error("Not coming-soon content on coming-soon page")
        return True

    def get_metadata_of_content(self, content=None):
        content = self.movie_name if not content else content
        self.helper.log("Content name: {}".format(content))
        self.player.search_and_open_content(
            content_name=content, search_result_index=0)
        meta_data = dict()
        if self.metadata_table.visible:
            elements = self.metadata_table.element
            for element in elements:
                current = self.helper.wait.visible(element=element)
                if current:
                    meta_type = current.get_attribute("class").lower()
                    meta_text = current.text.lower()
                    i = meta_text.index(" ") + 1
                    meta_text = meta_text[i:]
                    split_text = meta_text.split(", ")
                    if meta_type == "meta-length":
                        meta_text = int(meta_text.replace(" mins", ""))
                    elif len(split_text) > 1:
                        meta_text = sorted(split_text)
                    meta_data[meta_type] = meta_text
        other_meta = self.other_meta.visible
        if other_meta:
            other_meta = other_meta.text.split("|")
        del other_meta[0]
        if len(other_meta) > 1:
            genre = other_meta[0].split(", ")
            meta_data["meta-genre"] = sorted(genre) if len(genre) > 1 else other_meta[0]
            if "/" not in other_meta[1]:
                meta_data["meta-age"] = int(other_meta[1].replace("+", ""))
        imdb = self.content_imdb.visible
        if imdb:
            meta_data["meta-imdb"] = float(imdb.text.lower())
        self.helper.log("ui\ncontent meta-data: {}".format(meta_data))
        return meta_data

    def get_raw_content_data_from_api(self, keyword):
        """
        It gets (with API call) the raw content data.
        :param keyword: string with the keyword of the content we are looking for
        :return: dict with the raw content data
        """
        if keyword is None:
            keyword = self.movie_name
        url = self.search_api_url.replace("###KEYWORD###", keyword)
        response = get(url)
        data = response.json()
        result = [item for item in data["Container"][0]["Contents"]["Items"]][0]
        content_id = result["Id"]
        content_data = self.api.content_by_id(contentid=content_id)
        return content_data

    def get_content_data_from_api(self, content=None):
        """
        Does a search API call to get the content id. Then does another API call to get all the details of the content.
        Stores all the necessary details of the content if they have values.
        :param content: The content we want to search for
        :return: dict with the necessary details of the content
        """
        if content is None:
            content = self.movie_name
        content_data = self.get_raw_content_data_from_api(keyword=content)
        details = {"meta-title": content_data["OriginalName"].lower(),
                   "meta-genre": sorted([content_data["Genre"].lower(), content_data["SecondaryGenre"].lower()])
                   if content_data["SecondaryGenre"] != "" else content_data["Genre"].lower()}
        age_rating = content_data["AgeRatingName"]
        if age_rating != "":
            details["meta-age"] = int(age_rating.replace("+", ""))
        imdb_rating = content_data["ImdbRate"]
        if imdb_rating != "":
            details["meta-imdb"] = float(imdb_rating)
        description = content_data["Description"]
        if description != "":
            details["description"] = description.lower()
        director = content_data["Director"].lower().split(", ")
        if director != "":
            details["meta-director"] = director if len(director) > 1 else director[0]
        cast = content_data["Cast"]
        if cast != "":
            details["meta-cast"] = sorted(cast.lower().split(", "))
        country = content_data["OriginCountry"]
        if country != "":
            details["meta-country"] = country.lower()
        audios = []
        for a in content_data["AudioTracks"]:
            if a["Name"] not in audios:
                audios.append(a["Name"].lower())
        details["meta-audio"] = sorted(audios) if len(audios) > 1 else audios[0]
        subs = []
        for sub in content_data["Subtitles"]:
            if sub["Name"] not in subs:
                subs.append(sub["Name"].lower())
        details["meta-subtitle"] = sorted(subs) if len(subs) > 1 else subs[0]
        duration = content_data["DurationText"]
        if duration != "":
            details["meta-length"] = int(duration.split()[0])
        return details

    def compare_meta(self, ui, api):
        """
        Iterate through the keys of "ui" and checks if the value of each key equals in both dicts.
        :param ui: dict
        :param api: dict
        :return: bool
        """
        if isinstance(ui, dict) and isinstance(api, dict):
            for key in ui.keys():
                if ui.get(key) != api.get(key):
                    self.helper.error("comparision error:\n{} != {}".format(
                        key, ui.get(key), api.get(key)))
                    return [False, "meta from ui is not the same as meta from api"]
            return [True, "Success"]
