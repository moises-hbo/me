from helpers.sleeper import Sleeper as sleep

from apps.hboce.pages.base.page import BasePageObject as Page


class SettingsPage(Page):
    def __init__(self, driver, login_type="b2b"):
        Page.__init__(self, driver)
        self.login_type = login_type

        self.settings_button = self.create(dict(locator="settings", type="id"))
        self.application_settings_button = self.create(dict(
            locator="//*[@id='gw_settings_sidebar_application_preferences']/a", type="xpath"))
        self.parental_settings_button = self.create(dict(
            locator="gw_settings_sidebar_parental_control", type="id"))
        self.current_language = self.create(dict(
            locator="//*[@id='languages']/div/div/div[1]/span", type="xpath"))
        self.language_selector = self.create(dict(
            locator="//div[@title='applicationLanguage']", type="xpath"))
        self.available_langs = dict(
            English=self.create(dict(
                locator="//*[@id='languages']/div/div/div[2]/div[1]", type="xpath")),
            Magyar=self.create(dict(
                locator="//*[@id='languages']/div/div/div[2]/div[2]", type="xpath")))
        self.menu_items = self.create(dict(locator="//nav/ul[@class='st-menu']/li/a/span", type="xpath"))
        self.app_preferences_save_button = self.create(dict(locator="gw_app_preferences_save", type="id"))
        self.expected_menu_item_ids = dict(
            d2c=["gw_settings_sidebar_account_management", "gw_settings_sidebar_application_preferences",
                 "gw_settings_sidebar_devices", "gw_settings_sidebar_parental_control",
                 "gw_settings_sidebar_subscription", "gw_settings_sidebar_payment_history"],
            b2b=["gw_settings_sidebar_account_management", "gw_settings_sidebar_application_preferences",
                 "gw_settings_sidebar_devices", "gw_settings_sidebar_parental_control"])
        self.devices_trash_icon = self.create(dict(
            locator="gw_device_management_delete_modal", type="id"), True)
        self.devices_deleting_hint = self.create(dict(
            locator="//device-managment/div/hbo-modal/div/div[2]/div/h1", type="xpath"))
        self.devices_confirm_deleting = self.create(dict(
            locator="gw_device_management_delete_modal_delete", type="id"))
        self.default_text_color = "255, 255, 255"
        self.default_background_color = "0, 0, 0"
        self.parental_message_sample = \
            'Az al&aacute;bbi Gyerekz&aacute;r &eacute;rt&eacute;ket &aacute;ll&iacute;tottad be:'
        self.parental_pin_change_button = self.create(dict(
            locator="gw_parental_control_change_pin", type="id"))
        self.parental_pin_change_input = self.create(dict(
            locator="//*[@id='parentalOpParam.ParameterType']/div/form/div/input", type="xpath"))
        self.parental_pin = "1234"
        self.parental_pin_ok_button = self.create(dict(locator="gw_access_pin_modal_done", type="id"))
        self.parental_pin_save_button = self.create(dict(locator="gw_parental_control_save", type="id"))
        self.parental_mail_icon = self.create(dict(locator="//hbo-modal/div/div[2]/img", type="xpath"))
        self.parental_pin_continue_button = self.create(dict(
            locator="//parental-control/div/div[2]/hbo-modal/div/div[3]/div/button", type="xpath"))
        self.language_translate = dict(hun="magyar", eng="english", pol="polish", rom="romanian")

    @property
    def settings_setup(self):
        nickname = self.nickname.visible
        if not nickname:
            return self.Error("nickname is not visible")
        self.d_helper.move_mouse_to(element=nickname)
        settings_button = self.settings_button.visible
        if not settings_button:
            return self.Error("settings button is not visible")
        settings_button.click()
        result = self.helper.enter_iframe_and_wait_for_element_to_be_visible(
            element=self.application_settings_button.locator, timeout=30)
        return True if result else self.Error("failed to open settings")

    def set_language(self, wanted_lang=None):
        app_settings_button = self.application_settings_button.visible
        if not app_settings_button:
            return self.Error("application settings button is not visible")
        app_settings_button.click()
        if wanted_lang is None:
            current = self.current_language.visible
            if not current:
                return self.Error("current language is not visible")
            current = current.text
            for lang in self.available_langs.keys():
                if current.lower() != lang.lower():
                    wanted_lang = lang
                    break
        lang_selector = self.language_selector.visible
        if not lang_selector:
            return self.Error("language selector is not visible")
        lang_selector.click()
        wanted_language = self.available_langs.get(wanted_lang).visible
        if not wanted_language:
            return self.Error("wanted language is not visible")
        wanted_language.click()
        save_button = self.app_preferences_save_button.visible
        if not save_button:
            self.Error("save button is not visible")
        save_button.click()
        self.driver.switch_to.default_content()
        sleep(10)  # Should be replaced later
        app_lang = self.helper.get_application_language()
        if not app_lang:
            return self.Error("failed to get application language from api")
        current_lang = app_lang.lower()
        lang = self.language_translate.get(current_lang)
        result = lang.lower() == wanted_lang.lower()
        return True if result else self.Error("setting language has failed")

    def check_menu_items_in_settings(self):
        for menu_item in self.expected_menu_item_ids.get(self.login_type):
            item_locator = {"locator": menu_item, "type": "id"}
            item = self.helper.wait.visible(element=item_locator)
            if not item:
                return self.Error("menu item in settings is not visible")
        return True

    def check_appearance(self):
        # Checking the color of text
        color = self.helper.get_element_css_property(locator="/html/body",
                                                     locator_type="xpath",
                                                     css_property="color")
        color_result = self.default_text_color in color

        # Checking the color of background
        background = self.helper.get_element_css_property(locator="/html/body",
                                                          locator_type="xpath",
                                                          css_property="background-color")
        bg_result = self.default_background_color in background
        if not color_result:
            if not bg_result:
                return self.Error("both font color and background color are not as expected")
            else:
                return self.Error("font color is not as expected")
        elif not bg_result:
            return self.Error("background color is not as expected")
        return True

    def check_navigation_in_settings_menu(self):
        for menu_item in self.expected_menu_item_ids.get(self.login_type):
            item = self.create(dict(locator=menu_item, type="id"))
            link = self.create(dict(locator="//*[@id='{id}']/a".format(id=menu_item), type="xpath"))
            h1 = self.create(dict(locator="//div/div[@class='st-body-content']/h1", type="xpath"))
            item = item.visible
            if not item:
                return self.Error("menu item in settings is not visible")
            link = link.visible
            if not link:
                return self.Error("link of menu item in settings is not visible")
            link.click()
            h1 = h1.visible
            if not h1:
                return self.Error("header of section in settings is not visible")
        return True

    def delete_device(self, all_of_them=False):
        # TODO: refactor a bit
        devices_button = self.helper.wait.visible(
            element={"locator": "gw_settings_sidebar_devices", "type": "id"})
        if not devices_button:
            return self.Error("devices button is not visible")
        devices_button.click()
        if not self.devices_trash_icon.visible:
            return self.Error("failed to delete device")
        trash_icons = self.devices_trash_icon.element
        number_of_devices = len(trash_icons)
        if all_of_them and number_of_devices > 1:
            for _ in range(number_of_devices):
                trash_icon = self.devices_trash_icon.visible
                if not trash_icon:
                    return self.Error("trash icon is not visible")
                trash_icon.click()
                confirm = self.devices_confirm_deleting.visible
                if not confirm:
                    return self.Error("confirm delete button is not visible")
                confirm.click()
        elif not all_of_them and number_of_devices > 0:
            trash_icon = self.devices_trash_icon.visible
            if not trash_icon:
                return self.Error("trash icon is not visible")
            trash_icon.click()
            confirm = self.devices_confirm_deleting.visible
            if not confirm:
                return self.Error("confirm delete button is not visible")
            confirm.click()
        self.helper.wait.not_visible(
            element=self.devices_deleting_hint.locator)
        trash_icons = self.devices_trash_icon.element
        if not trash_icons and all_of_them:
            return True
        elif len(trash_icons) < number_of_devices:
            return True
        return self.Error("failed to delete device")
