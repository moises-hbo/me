from apps.hboce.pages.base.page import BasePageObject as Page
from random import choice
from time import time


class SeriesPage(Page):
    def __init__(self, driver, login_type="b2b", timeout=10):
        Page.__init__(self, driver)
        self.timeout = timeout
        self.login_type = login_type

        # Elements
        self.shelf_title_header = self.create(dict(
            locator="//header[@class='shelf-header']/div[@class='shelf-title']/h2",
            type="xpath", color="255, 255, 255, 1", background_color="0, 0, 0, 0"), True)
        self.series_button = self.create(dict(locator="/html/body/nav/div/ul/li[1]", type="xpath"))
        self.content_shelves = self.create(dict(
            locator="/html/body/main/div[###NUM###]/div[@class='shelf-content']", type="xpath"))
        self.content_shelf_headers = self.create(dict(
            locator="/html/body/main/div[###NUM###]/div[@class='shelf-content']/header/div[1]/h2/a",
            type="xpath"))
        self.new_contents_shelf = self.create(dict(
            locator="/html/body/main/div[3]/div[@class='shelf-content']", type="xpath"))
        self.series_category_buttons = self.create(dict(
            locator="/html/body/nav/div/ul/li[1]/div/ul[1]/li/a", type="xpath"), True)
        self.imdb_rating = self.create(dict(
            locator="//span[@class='rate imdb small']/span[@class='rate-val']", type="xpath"), True)
        self.series_category_buttons_2 = self.create(dict(
            locator="/html/body/nav/div/ul/li[1]/div/ul[2]/li/a", type="xpath"), True)
        self.series_content_in_a_category_page = self.create(dict(
            locator="/html/body/main/div[1]/div/div", type="xpath"))
        self.series_category_genres = dict(
            drama=["drama", "war", "biography", "psychological", "history", "political", "anthology",
                   "disaster", "war series"],
            comedy=["comedy", "dramedy", "romance", "sitcom", "satire", "stand-up", "parody"],
            crimethriller=["crime", "spy", "thriller", "horror", "psychological", "adventure",
                           "mystery", "action", "comic", "western", "martial arts", "game adaptation",
                           "comics adaptation", "suspense"],
            scififantasy=["fantasy", "fiction", "comics adaptation", "fairy tale", "mystery",
                          "horror", "science fiction"],
            documentary=["documentary", "talk-show"],
            extra=["talk-show", "filler programme", "magazine", "musical", "game-show", "behind the scenes",
                   "reality-tv", "short", "interview", "concert", "nature", "stand", "documentary", "talk-show",
                   "sports", "special", "music", "dance"])
        self.series_header = self.create(dict(
            locator="/html/body/main/div[1]/header/div[1]/h2", type="xpath"))
        self.series_content_in_a_category_page = self.create(dict(
            locator="/html/body/main/div[1]/div/div", type="xpath"), True)
        self.series_sort_by = self.create(dict(
            locator="/html/body/main/div[1]/header/div[2]/div[2]", type="xpath"))
        self.series_sort_by_options = self.create(
            dict(locator="/html/body/main/div[1]/header/div[2]/div[2]/div/ul/li", type="xpath"), True)
        self.premier_labels = ["premier", "last", "new-episode", "premier-kids", "new-episode-kids",
                               "returning-premier", "series-premier", "episode-premier",
                               "series-episode-premier"]
        self.coming_soon_labels = ["comingsoon", "comingsoon-episode", "series-comingsoon",
                                   "season-comingsoon", "comingsoon-date", "comingsoon-episode-date",
                                   "season-comingsoon-date", "series-comingsoon-date"]

    def check_css_property(self, css_property):
        shelf_title_header = self.shelf_title_header.visible
        expected = self.shelf_title_header.locator.get(css_property)
        css_property = "background-color" if css_property == "background_color" else css_property
        actual = shelf_title_header.value_of_css_property(
            css_property).split("(")[1].strip(")")
        message = "{css_prop} of shelf title header is {actual} while {expected} is expected".format(
                  css_prop=css_property, actual=actual, expected=expected)
        return True if actual in expected else self.Error(message)

    def check_items_of_premier_shelf(self):
        contents = self.helper.get_contents_from_shelf(shelf="recently added")
        if not contents:
            return self.Error("failed to get contents from recently added shelf")
        links = [x.find_element_by_xpath("./a") for x in contents]
        if not links:
            return self.Error("failed to get links of contents")
        link_texts = [x.get_property("text") for x in links]
        if not link_texts:
            return self.Error("failed to get text of contents")
        for text in link_texts:
            texty = text.split()
            first_part = str("{} {}".format(texty[0], texty[1])).lower()
            if first_part not in ["new episode", "series premiere", "new season"]:
                return self.Error("non-premiere contents on recently added shelf")
        return True

    def check_items_of_imdb_highest(self):
        serie_cat_btns = self.series_category_buttons.element
        for serie_cat_btn in serie_cat_btns:
            text = serie_cat_btn.get_property("text").lower()
            if "critically acclaimed series" == text:
                self.d_helper.move_mouse_to(
                    element=self.series_button.visible)
                self.helper.scroll_to_element_by_xpath(
                    xpath=self.series_button.locator.get("locator"))
                self.helper.wait.visible(element=serie_cat_btn)
                serie_cat_btn.click()
                break
        ratings_elements = self.imdb_rating.element
        ratings = list(map(float, [item.text for item in ratings_elements]))
        for rating in ratings:
            if rating < 7.0:
                index = ratings.index(rating)
                serie = ratings_elements[index].find_element_by_xpath("../..")
                name = serie.get_property("innerText").split()[1]
                self.helper.log(
                    "{} has {} rating which is under 7".format(name, rating))
                return self.Error("content {} has {} rating which is under 7".format(name, rating))
        return True

    def check_if_series_in_a_category_have_the_right_genre(self):
        series_button = self.series_button.visible
        if not series_button:
            return self.Error("series button is not visible")
        self.d_helper.move_mouse_to(element=series_button)
        movie_categories = self.series_category_buttons_2.element
        if not movie_categories:
            return self.Error("failed to get movie categories")
        selected_category = choice(movie_categories)
        category_name = selected_category.get_property("text").lower()
        category_name = category_name.replace(", ", "").replace("-", "")
        self.helper.log("selected category: {}".format(category_name))
        selected_category = self.helper.wait.visible(element=selected_category)
        if not selected_category:
            return self.Error("selected category is not visible")
        self.d_helper.move_mouse_to(element=selected_category)
        selected_category.click()
        series = self.series_content_in_a_category_page.element
        if not series:
            return self.Error("failed to get contents in category page")
        everything_is_ok = True
        for serie in series:
            genre_label = serie.find_element_by_css_selector("span.genres")
            if not genre_label:
                return self.Error("failed to find genre label of content")
            genre = genre_label.text
            cat = self.series_category_genres.get(category_name)
            okay = False
            for g in genre.split(", "):
                if g in cat:
                    okay = True
                    break
            if not okay:
                self.helper.log(
                    "{} series should not be in this category".format(serie.get_property("innerText")))
                everything_is_ok = False
        return True if everything_is_ok else self.Error("not all series has the right category for this genre")

    def check_category_buttons_functionality(self):
        series_button = self.series_button.visible
        self.d_helper.move_mouse_to(element=series_button)
        series_categories = self.series_category_buttons_2.element
        for cat in series_categories:
            url = cat.get_attribute("href")
            category_name = cat.get_property("text")
            self.d_helper.open_window(url=url)
            self.d_helper.switch_to_window(1)
            header = self.series_header.visible
            if category_name.lower() not in header.text.lower():
                if not category_name.lower() == "extra" and "other" not in header.text.lower():
                    return self.Error("category name is not as expected")
            self.d_helper.close_window()
            self.d_helper.switch_to_window(0)
        return True

    def check_ribbon(self, shelf):
        if shelf == "coming soon":
            reference = self.coming_soon_labels
        elif shelf == "recently added":
            reference = self.premier_labels
        else:
            return self.Error("not valid shelf name for checking ribbon")
        series_button = self.series_button.visible
        if not series_button:
            return self.Error("series button is not visible")
        self.d_helper.move_mouse_to(element=series_button)
        series_cat_btns = self.series_category_buttons.element
        if not series_cat_btns:
            return self.Error("failed to get series category buttons")
        for series_cat_btn in series_cat_btns:
            cat = self.helper.wait.visible(element=series_cat_btn)
            if not cat:
                return self.Error("category button is not visible")
            self.d_helper.move_mouse_to(element=cat)
            text = series_cat_btn.get_property("text").lower()
            if shelf in text:
                cat.click()
                break
        if not self.series_content_in_a_category_page.visible:
            return self.Error("content in category page is not visible")
        series = self.series_content_in_a_category_page.element
        if not series:
            return self.Error("failed to get series")
        for s in series:
            ribbon = s.find_element_by_css_selector("div.ribbon")
            ribbon_label = ribbon.get_attribute("class").replace("ribbon-", "")
            ribbon_label = ribbon_label if " " not in ribbon_label else ribbon_label.split(" ")[1]
            if ribbon_label not in reference:
                return self.Error("not {} series on {} page".format(shelf, shelf))
        return True

    def check_sort_by(self):
        series_button = self.series_button.visible
        self.d_helper.move_mouse_to(element=series_button)
        series_cat_btns = self.series_category_buttons_2.element
        anakin = choice(series_cat_btns)
        category_name = anakin.get_property("text").lower()
        self.helper.log("selected category is: {cat}".format(cat=category_name))
        anakin.click()
        sort_by_button = self.series_sort_by.visible
        sort_by_button.click()
        sort_by_options = self.series_sort_by_options.element
        anakin = choice(sort_by_options)
        sort_type = anakin.text.lower()
        self.helper.log(
            "selected sorting type is: {s_type}".format(s_type=sort_type))
        anakin.click()
        contents = self.series_content_in_a_category_page.element
        if sort_type == "recently_added":
            ref_date = int(time())
            for content in contents:
                content_available_date = int(
                    content.get_attribute("data_available_date"))
                if content_available_date > ref_date:
                    msg = "contents are not sorted by available date\n{a} > {b}".format(
                        a=content_available_date, b=ref_date)
                    return self.Error(msg)
                else:
                    ref_date = content_available_date
        elif sort_type == "imdb rating":

            # It doesn't work now, because get_list() function does not return the elements in their order in the page

            ref_rating = float(11)
            ratings_elements = self.imdb_rating.element
            ratings = list(
                map(float, [item.text for item in ratings_elements]))
            for rating in ratings:
                if rating > ref_rating:
                    msg = "contents are not sorted by imdb rating\n{a} > {b}".format(
                        a=rating, b=ref_rating)
                    return self.Error(msg)
                else:
                    ref_rating = rating
        elif sort_type == "a - z":
            content_names = [str(c.get_property("text")).lower()
                             for c in contents]
            sorted_content_names = sorted(content_names)
            if content_names != sorted_content_names:
                return self.Error("contents are not alphabetically ordered")
        elif sort_type == "popularity":
            self.helper.log(
                "checking order by popularity is not yet automated")
        return True
