from apps.hboce.pages.base.page import BasePageObject as Page
from helpers.configmanager import ConfigManager


class Home(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)
        self.cm = ConfigManager()
        self.base_url = self.cm.url
        self.urls_auth = {
            "activate": self.create(dict(locator="deviceactivation", type="css_selector")),
            "appletv": self.create(dict(locator="", type="")),
            "register": self.create(dict(locator="", type="")),
            "register/b2b": self.create(dict(locator="", type="")),
            "register/d2c": self.create(dict(locator="", type="")),
            "login": self.create(dict(locator="", type="")),
            "login/b2b": self.create(dict(locator="", type="")),
            "login/d2c": self.create(dict(locator="", type="")),
            "parental": self.create(dict(locator="", type="")),
            "subscription": self.create(dict(locator="", type="")),
            "account": self.create(dict(locator="", type="")),
        }
        self.urls_unauth = {
            "activate": self.create(dict(locator="deviceactivation", type="css_selector")),
            "appletv": self.create(dict(locator="", type="")),
            "register": self.create(dict(locator="", type="")),
            "register/b2b": self.create(dict(locator="", type="")),
            "register/d2c": self.create(dict(locator="", type="")),
            "login": self.create(dict(locator="", type="")),
            "login/b2b": self.create(dict(locator="", type="")),
            "login/d2c": self.create(dict(locator="", type="")),
            "parental": self.create(dict(locator="", type="")),
            "subscription": self.create(dict(locator="", type="")),
            "account": self.create(dict(locator="", type="")),
        }

    def check_urls(self, auth=True):
        base_url = self.base_url if self.base_url[-1] == "/" else "{}/".format(self.base_url)
        urls = self.urls_auth if auth else self.urls_unauth
        for url in urls.keys():
            self.driver.get("{}{}".format(base_url, url))
            result = self.helper.enter_iframe_and_wait_for_element_to_be_visible(element=urls.get(url).element)
            print(result)
