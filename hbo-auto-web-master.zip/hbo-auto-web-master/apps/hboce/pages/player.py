from apps.hboce.pages.base.page import BasePageObject as Page
from apps.hboce.pages.search import SearchPage
from time import time
from helpers.sleeper import Sleeper as sleep
from random import choice


class PlayerPage(Page):
    def __init__(self, driver):
        Page.__init__(self, driver)
        self.search_page = SearchPage(driver=driver)
        self.movie_names = ["game of thrones the last watch", "native son", "conspiracy"]
        self.movie_name = choice(self.movie_names)
        self.series_names = ["game of thrones", "ballers", "true detective", "westworld"]
        self.serie_name = choice(self.series_names)

        self.container = self.create(dict(
            locator="hbo-sdk--controller-container", type="id"))
        self.play_button_main_screen = self.create(dict(
            locator="//*[@class='outer-play']", type="xpath"))
        self.modal_header = self.create(dict(
            locator="/div[@class='modal']/div[2]", type="xpath"))
        self.play_random_from_top_movies = self.create(dict(
            locator="/html/body/main/div[11]/div/div", type="xpath"))
        self.play_random_from_top_series = self.create(dict(
            locator="/html/body/main/div[5]/div/div", type="xpath"))
        self.series_episode = self.create(dict(
            locator="//div[@id='episodes']/div/a", type="xpath"), is_list=True)
        self.series_episode_play_button = self.create(dict(
            locator="//*[@id='episodes']/div[4]/span", type="xpath"))
        self.title = self.create(dict(locator="player-title", type="id"))
        self.played_before_modal = self.create(dict(
            locator="hbo-sdk--modal-start-position", type="id"))
        self.series_season_episode_label = self.create(dict(
            locator="//*[@id='player-title']/span", type="xpath"))
        self.resume_playback = self.create(dict(
            locator="//*[@id='hbo-sdk--modal-start-position']/a[1]", type="xpath"))
        self.play_from_beginning_button = self.create(dict(
            locator="//*[@id='hbo-sdk--modal-start-position']/a[2]", type="xpath"))
        self.play_button = self.create(dict(
            locator="hbo-sdk--player-play", type="id"))
        self.pause_button = self.create(dict(
            locator="hbo-sdk--player-pause", type="id"))
        self.previous_episode_button = self.create(dict(
            locator="hbo-sdk--player-previousepisode", type="id"))
        self.next_episode_button = self.create(dict(
            locator="hbo-sdk--player-nextepisode", type="id"))
        self.close_button = self.create(dict(
            locator="hbo-sdk--player-close", type="id"))
        self.timeline = self.create(dict(
            locator="hbo-sdk--player-timeline", type="id"))
        self.elapsed = dict(
            h=self.create(dict(locator="hbo-sdk--player-timestamp-elapsed-h", type="id")),
            i1=self.create(dict(locator="hbo-sdk--player-timestamp-elapsed-i1", type="id")),
            i2=self.create(dict(locator="hbo-sdk--player-timestamp-elapsed-i2", type="id")),
            s1=self.create(dict(locator="hbo-sdk--player-timestamp-elapsed-s1", type="id")),
            s2=self.create(dict(locator="hbo-sdk--player-timestamp-elapsed-s2", type="id")))
        self.full_time = dict(
            h=self.create(dict(locator="hbo-sdk--player-timestamp-full-h", type="id")),
            i1=self.create(dict(locator="hbo-sdk--player-timestamp-full-i1", type="id")),
            i2=self.create(dict(locator="hbo-sdk--player-timestamp-full-i2", type="id")),
            s1=self.create(dict(locator="hbo-sdk--player-timestamp-full-s1", type="id")),
            s2=self.create(dict(locator="hbo-sdk--player-timestamp-full-s2", type="id")))
        self.scrubber = self.create(dict(
            locator="hbo-sdk--player-scrubber", type="id"))
        self.timestamp = self.create(dict(
            locator="hbo-sdk--player-timstamp", type="id"))
        self.volume_button = self.create(dict(
            locator="hbo-sdk--player-volume", type="id"))
        self.subtitles_button = self.create(dict(
            locator="hbo-sdk--player-audiosubtitle", type="id"))
        self.subtitles_options = self.create(dict(
            locator="#player-subtitle > li", type="css selector"), is_list=True)
        self.active_subtitle = self.create(dict(
            locator="#player-subtitle > li.active", type="css selector"))
        self.audio_options = self.create(dict(
            locator="#player-audio > li", type="css selector"), is_list=True)
        self.active_audio = self.create(dict(
            locator="#player-audio > li.active", type="css selector"))
        self.settings_button = self.create(dict(
            locator="hbo-sdk--player-settings", type="id"))
        self.fullscreen_button = self.create(dict(
            locator="hbo-sdk--player-fullscreen", type="id"))
        self.add_to_favorite = self.create(dict(
            locator="//div[@class='ctas']/a[@class='btn flat secondary add']", type="xpath"))
        self.remove_from_favorite = self.create(dict(
            locator="//div[@class='ctas']/a[@class='btn flat secondary remove']", type="xpath"))
        self.content_page_close_button = self.create(dict(
            locator="/html/body/div[4]", type="xpath"))
        self.player_timestamp = self.create(dict(locator="hbo-sdk--player-timstamp", type="id"))
        self.chainplay_up_next = self.create(dict(locator="hbo-sdk--player-upnext-meta", type="id"), wait=50)

    def play_contents_from_shelf(self, section=None, shelf=None, strict=False, timeout=10):
        """
        Mainly, this function is for the "monitoring playback of content on recently added shelf" thing.
        :param section: str - "movies" by default
        :param shelf: str - "recently added" by default
        :param strict: bool - if False then it will look after another shelf
                              if it fails finding the given one
        :param timeout: int - 10 seconds for by default
        :return: bool - True if success, Error type object if not
        """
        section = section.lower() if section else "movies"
        if section not in ["movies", "series", "kids"]:
            return self.Error("there is no {} section on the page".format(section))
        if section == "kids":
            self.kids
        elif section == "movies":
            self.movies
        elif section == "series":
            self.series
        shelf = shelf.lower() if shelf else "recently added"
        contents = self.helper.get_contents_from_shelf(shelf)
        if strict and not contents:
            return self.Error("there is no {} shelf on the page".format(shelf))
        elif not strict and not contents:
            now = time()
            while time() < now + timeout and not contents:
                shelves = self.helper.get_shelf_titles()
                contents = self.helper.get_contents_from_shelf(choice(shelves))
        if not contents:
            return self.Error("failed to find content on {} shelf in {} seconds".format(shelf, timeout))
        played = 0
        num_of_contents = len(contents)
        for content in contents:
            title = content.find_element_by_css_selector("span.title")
            title = self.helper.wait.visible(element=title)
            if not title:
                return self.Error("title of content is not visible")
            title = title.text.lower()
            self.d_helper.move_mouse_to(element=content)
            if section == "movies":
                play_btn = content.find_element_by_css_selector("a.playbtn")
                play_btn = self.helper.wait.visible(element=play_btn)
                if not play_btn:
                    return self.Error("play button is not visible for {}".format(title))
                self.d_helper.move_mouse_to(element=play_btn)
                play_btn.click()
                if not self.helper.wait.not_visible(element=play_btn, timeout=5):
                    play_btn.click()
                    if not self.helper.wait.not_visible(element=play_btn, timeout=10):
                        return self.Error("failed to click on play button of {}".format(title))
            elif section == "series" and self.helper.wait.clickable_and_click(element=content):
                episodes_loc = self.create(dict(
                    locator="//div[@id='episodes']/div",
                    type="xpath"), True)
                first_episode = episodes_loc.visible
                if not first_episode:
                    return self.Error("no visible episodes for {}".format(title))
                episodes = list(episodes_loc.element)
                episodes.reverse()
                for e in episodes:
                    episode_number = e.find_element_by_css_selector("span.title")
                    episode_number = self.helper.wait.visible(element=episode_number)
                    if not episode_number:
                        return self.Error("episode number for {} is not visible".format(title))
                    episode_number = episode_number.text.lower()
                    self.d_helper.move_mouse_to(element=e)
                    label = e.find_element_by_xpath("./a//span")
                    label = self.helper.wait.visible(element=label, timeout=3)
                    if label and label.text.lower() == "premiere":
                        p_button = e.find_element_by_css_selector("span.playbtn")
                        p_button = self.helper.wait.visible(element=p_button)
                        if not p_button:
                            return self.Error(
                                "play button for {} of {} is not visible".format(episode_number, title))
                        self.d_helper.move_mouse_to(element=p_button)
                        p_button.click()
                        if not self.helper.wait.not_visible(element=p_button, timeout=5):
                            p_button.click()
                            if not self.helper.wait.not_visible(element=p_button, timeout=10):
                                return self.Error(
                                    "failed to click on play button for {} of {}".format(
                                        episode_number, title))
                        break
            if not self.play_from_beginning():
                return self.Error("failed to start content from beginning")
            sleep(2)
            paused = self.click_start_or_pause_button(play_or_pause="pause")
            if not paused:
                return self.Error("failed to pause {}".format(title))
            elapsed_time = self.get_elapsed_time()
            if isinstance(elapsed_time, self.Error):
                return elapsed_time
            started = self.click_start_or_pause_button(play_or_pause="play")
            if not started:
                return self.Error("failed to start {}".format(title))
            sleep(5)
            try:
                paused = self.click_start_or_pause_button(play_or_pause="pause")
                if not paused:
                    return self.Error("failed to pause {}".format(title))
                new_elapsed_time = self.get_elapsed_time()
                if isinstance(new_elapsed_time, self.Error):
                    return new_elapsed_time
                if new_elapsed_time > elapsed_time:
                    self.move_mouse()
                    sleep(1)
                    closed = self.close_player_and_detail_screen_js() if section == "series" else self.close_player_js()
                    if isinstance(closed, self.Error):
                        return closed
                    played += 1
                else:
                    return self.Error("elapsed time is less then it should be for {}".format(title))
            except Exception as e:
                return self.Error("test failed while playing {}\n{}".format(title, e))
        result = played == num_of_contents
        return True if result else self.Error("failed to play all contents from {} shelf".format(shelf))

    def move_mouse(self):
        self.d_helper.move_mouse_about(0, 10)
        self.d_helper.move_mouse_about(0, -10)

    def check_continue_watching(self, section=None):
        """
        Plays first content from continue watching shelf.
        :return: True if successful, False if not
        """
        playback_started = self.play_nth_element_from_shelf(
            shelf_name="continue watching", section=section, timeout=20)
        if isinstance(playback_started, self.Error):
            return playback_started
        if not self.play_from_beginning():
            return self.Error("failed to start content from beginning")
        result = self.close_button.visible
        return True if result else self.Error("close button is not visible")

    def add_or_remove_favorites(self):
        add_btn = self.add_to_favorite.visible
        rmv_btn = self.remove_from_favorite.visible
        if add_btn:
            add_btn.click()
            return "added" if self.remove_from_favorite.visible else \
                self.Error("remove favorite button is not visible")
        elif rmv_btn:
            rmv_btn.click()
            return "removed" if self.add_to_favorite.visible else \
                self.Error("add favorite button is not visible")
        else:
            return self.Error("add/remove favorite buttons are not visible")

    def select_shelf_and_get_element(self, shelf_name=None, index=0):
        """
        Navigates to the shelf with the given shelf_name and plays the content with the given index.
        By default it gets the first content of the shelf (index=0).
        :param shelf_name: str - name of the desired shelf
        :param index: int - index of the desired content
        :return: WebElement of the content if the shelf is found, False if not
        """
        shelf_name = choice(self.helper.get_shelf_titles()) if not shelf_name else shelf_name
        wanted_shelf = self.helper.get_contents_from_shelf(
            shelf=shelf_name.lower())
        return wanted_shelf[index] if wanted_shelf else \
            self.Error("failed to get contents from {} shelf".format(shelf_name))

    def play_nth_element_from_shelf(self, section=None, shelf_name=None, index=None, timeout=10):
        # TODO: Now it works with JS script and it is not so fancy
        """
        Clicks play button of the nth item from the desired shelf.
        :param section: str - name of section
        :param shelf_name: str - the name of the desired shelf
        :param index: int - index of the item to be played
        :param timeout: int - timeout in seconds
        :return: True if successful, Error object if not
        """
        section = section if section else "normal"
        index = index if index else 0
        shelf_name = choice(self.helper.get_shelf_titles()) if not shelf_name else shelf_name
        if shelf_name != "continue watching":
            contents = self.helper.get_contents_from_shelf(shelf=shelf_name)
            self.d_helper.move_mouse_to(element=contents[index])
            content_name = contents[index].text.lower()
            content = self.helper.wait.visible(element=contents[index])
            if not content:
                return self.Error("{} is not visible".format(content_name))
            play_btn = content.find_element_by_css_selector("a.playbtn")
            self.d_helper.move_mouse_to(element=play_btn)
            play_btn = self.helper.wait.visible(element=play_btn)
            if not play_btn:
                return self.Error("play button of {} is not visible".format(content_name))
            play_btn.click()
            pfb = self.play_from_beginning()
            if not pfb:
                return self.Error("failed to play content from beginning")
            result = self.timestamp.visible
            return True if result else self.Error("failed to play {}".format(content_name))
        else:
            shelf_name = shelf_name.replace(" ", "-")
            script = "var element = document.querySelector('#vcms-" \
                     "{}-{}').querySelectorAll('a.playbtn'); element[{}].click();".format(
                        shelf_name, section, index)
            now = time()
            while time() < now + timeout:
                try:
                    self.driver.execute_script(script)
                    return True
                except Exception:
                    sleep(1)
            return self.Error("failed to play first content of {} shelf".format(shelf_name))

    def search_and_open_content(self, content_name=None, search_result_index=0):
        content_name = self.movie_name if not content_name else content_name
        search_button = self.search_page.link.clickable_and_click
        if not search_button:
            return self.Error("search button is not visible")
        text_typed = self.search_page.enter_text_on_search(content_name)
        if not text_typed:
            return self.Error("failed to type text to search input field")
        result = self.search_page.click_on_search_result(search_result_index)
        return True if result else \
            self.Error("failed to click on {}. search result".format(search_result_index+1))

    def start_series_first_episode(self):
        scroll_to_episodes = "var element = document.getElementById('episodes'); " \
                             "element.scrollIntoView();"
        self.driver.execute_script(scroll_to_episodes)
        episodes = self.series_episode.element
        first_episode = self.helper.wait.visible(element=episodes[0])
        self.d_helper.move_mouse_to(first_episode)
        result = self.series_episode_play_button.clickable_and_click
        return True if result else self.Error("failed to start episode")

    def click_start_or_pause_button(self, play_or_pause):
        self.move_mouse()
        button = self.play_button.visible if play_or_pause == "play" else self.pause_button.visible
        if not button:
            return False
        button.click()
        return True

    def get_elapsed_time(self, timeout=20):
        now = time()
        while time() < now + timeout:
            self.move_mouse()
            try:
                elapsed_hours = int(self.elapsed.get("h").element.text)
                elapsed_minutes = 10 * int(
                    self.elapsed.get("i1").element.text) + int(
                    self.elapsed.get("i2").element.text)
                elapsed_seconds = 10 * int(
                    self.elapsed.get("s1").element.text) + int(
                    self.elapsed.get("s2").element.text)
                sec = 3600 * elapsed_hours + 60 * elapsed_minutes + elapsed_seconds
                return sec
            except Exception:
                sleep(1)
        return self.Error("failed to get elapsed time")

    def get_full_time(self):
        self.move_mouse()
        if not self.player_timestamp.visible:
            return False
        full_hours = int(self.full_time.get("h").element.text)
        full_minutes = 10 * int(self.full_time.get("i1").element.text) + int(self.full_time.get("i2").element.text)
        full_seconds = 10 * int(self.full_time.get("s1").element.text) + int(self.full_time.get("s2").element.text)
        sec = 3600 * full_hours + 60 * full_minutes + full_seconds
        return sec

    def get_audio_or_subtitle_options(self, aud_or_sub, active=False):
        if active:
            return self.active_audio.element if aud_or_sub == "aud" else self.active_subtitle.element
        else:
            return self.audio_options.element if aud_or_sub == "aud" else self.subtitles_options.element

    def check_audio_or_subtitle_selection(self, aud_or_sub, select=None):
        content_started = self.start_series()
        if not content_started:
            return self.Error("failed to start series")
        result = self.change_subtitle_or_audio(aud_or_sub=aud_or_sub, select=select)
        return True if not isinstance(result, self.Error) else result

    def change_subtitle_or_audio(self, aud_or_sub, select=None):
        options = self.get_audio_or_subtitle_options(aud_or_sub=aud_or_sub)
        if not options:
            return self.Error("failed to get options for changing {}".format(aud_or_sub))
        original = self.get_audio_or_subtitle_options(aud_or_sub=aud_or_sub, active=True)
        if not original:
            return self.Error(
                "originally selected option for changing {} is not visible".format(aud_or_sub))
        self.move_mouse()
        subtitles_btn = self.subtitles_button.visible
        if not subtitles_btn:
            return self.Error("subtitle/audio button is not visible")
        self.d_helper.move_mouse_to(element=subtitles_btn)
        for option in options:
            option = self.helper.wait.visible(element=option)
            if not option:
                return self.Error("option for changing {} is not visible".format(aud_or_sub))
            if select is None:
                if option.text != original.text:
                    option.click()
                    break
                sub1 = self.helper.wait.visible(element=options[1])
                if not sub1:
                    return self.Error(
                        "second option for changing {} is not visible".format(aud_or_sub))
                sub1.click()
                break
            else:
                if option.text.lower() == select.lower():
                    option.click()
                    break
        selected = self.get_audio_or_subtitle_options(aud_or_sub=aud_or_sub, active=True)
        result = selected != original
        return True if result else self.Error("failed to change {}".format(aud_or_sub))

    def scrubbing(self, t):
        self.move_mouse()
        scrubber = self.scrubber.visible
        if not scrubber:
            return False
        scrubber.click()
        self.d_helper.move_mouse_to_and_about(scrubber, t, 0)
        sleep(1)
        self.d_helper.click_on_screen()
        return self.get_elapsed_time()

    def get_series_title_and_episode(self):
        self.move_mouse()
        series_title = self.title.visible
        if not series_title:
            return self.Error("title of content is not visible")
        title = series_title.text
        episode_number_element = series_title.find_element_by_xpath("./span")
        if not episode_number_element:
            return self.Error("failed to get episode number of series")
        episode_number_element = self.helper.wait.visible(element=episode_number_element)
        if not episode_number_element:
            return self.Error("episode number of series is not visible")
        episode = episode_number_element.text
        return dict(title=title, episode=episode)

    def press_on_next_or_previous_button(self, next_or_prev="prev"):
        self.move_mouse()
        self.next_episode_button.visible.click() if next_or_prev == "next" else \
            self.previous_episode_button.visible.click()
        self.play_from_beginning()
        return self.get_series_title_and_episode()

    def start_series(self, keyword=None, search_result_index=0):
        keyword = keyword if keyword else self.serie_name
        content_opened = self.search_and_open_content(
            content_name=keyword, search_result_index=search_result_index)
        if isinstance(content_opened, self.Error):
            return content_opened
        episode_started = self.start_series_first_episode()
        if isinstance(episode_started, self.Error):
            return episode_started
        if not self.play_from_beginning():
            return self.Error("failed to start content from beginning")
        return self.get_series_title_and_episode()

    def open_content_and_check_scrubbing(self):
        if not self.search_and_open_content():
            return self.Error("failed to open content")
        self.play_from_detail_screen()
        return self.check_scrubbing()

    def check_scrubbing(self):
        first_time = self.scrubbing(t=100)
        second_time = self.scrubbing(t=-50)
        result = first_time > second_time
        return True if result else self.Error("scrubbing is not working correctly")

    def play_from_beginning(self, timeout=30):
        timestamp = False
        now = time()
        while time() < now + timeout:
            button = self.helper.wait.visible(
                element=self.play_from_beginning_button.locator, timeout=5)
            if button:
                button.click()
            self.move_mouse()
            timestamp = self.helper.wait.visible(element=self.timestamp.locator, timeout=5)
            if timestamp:
                break
        return True if timestamp else False

    def play_from_detail_screen(self):
        script_to_click_play = "var element = document.querySelector('.modal').querySelector('.btn.play');" \
                               "element.click();"
        self.driver.execute_script(script_to_click_play)
        if self.play_from_beginning():
            return True
        return False

    def play_from_carousel(self, timeout=10):
        script_to_click_play = "var element = document.querySelector('.carousel-item').querySelector('.btn.play');" \
                               "element.click();"
        now = time()
        while time() < now + timeout:
            try:
                self.driver.execute_script(script_to_click_play)
                return True
            except Exception:
                sleep(1)
        return self.Error("failed to play content from carousel")

    def close_player_and_detail_screen_js(self, timeout=20):
        script_to_close_player = "var element = document.querySelector('#hbo-sdk--player-close');" \
                                 "element.click();"
        script_to_close_modal = "var element = document.querySelector('div.modal-close');" \
                                "element.click();"
        now = time()
        while time() < now + timeout:
            try:
                sleep(2)
                self.driver.execute_script(script_to_close_player)
                sleep(3)
                self.driver.execute_script(script_to_close_modal)
                return True
            except Exception:
                sleep(1)
        return self.Error("failed to close player and modal")

    def close_player_js(self, timeout=20):
        script_to_close_player = "var element = document.querySelector('#hbo-sdk--player-close');" \
                                 "element.click();"
        now = time()
        while time() < now + timeout:
            try:
                self.driver.execute_script(script_to_close_player)
                return True
            except Exception:
                sleep(1)
        return self.Error("failed to close player")

    def start_playing_content(self):
        if not self.movies:
            return self.Error("failed to open movies page")
        started_content = self.play_nth_element_from_shelf(section="movies")
        if isinstance(started_content, self.Error):
            return started_content
        if not self.play_from_beginning():
            return self.Error("failed to start content from beginning")
        sleep(5)
        self.move_mouse()
        timestamp = self.player_timestamp.visible
        return True if timestamp else self.Error("timestamp is not visible")

    def check_playback(self):
        if not self.click_start_or_pause_button(play_or_pause="pause"):
            return self.Error("failed to click pause button")
        before = self.get_elapsed_time()
        if not before:
            return self.Error("failed to get elapsed time")
        if not self.click_start_or_pause_button(play_or_pause="play"):
            return self.Error("failed to click play button")
        sleep(5)
        after = self.get_elapsed_time()
        if not after:
            return self.Error("failed to get elapsed time")
        result = after - before > 4
        return True if result else self.Error("playback was not successful according to elapsed time")

    def check_watchlist(self):
        shelf_titles = self.helper.get_shelf_titles()
        if not shelf_titles:
            return self.Error("failed to get shelf titles")
        if "watchlist" not in shelf_titles:
            content_opened = self.search_and_open_content()
            if isinstance(content_opened, self.Error):
                return content_opened
            favorite = self.add_or_remove_favorites()
            if isinstance(favorite, self.Error):
                return favorite
            content_closed = self.content_page_close_button.clickable_and_click
            if not content_closed:
                return self.Error("failed to close content")
            if not self.home:
                return self.Error("failed to navigate to home page")
        shelf_titles = self.helper.get_shelf_titles()
        if not shelf_titles:
            return self.Error("failed to get shelf titles")
        result = "watchlist" in shelf_titles
        return True if result else self.Error("failed to find watchlist shelf")

    def check_favorite(self, keyword=None):
        self.search_and_open_content() if keyword is None \
            else self.search_and_open_content(content_name=keyword)
        result = self.add_or_remove_favorites()
        if result == "removed":
            result = self.add_or_remove_favorites()
            if result == "added":
                return True
        elif result == "added":
            result = self.add_or_remove_favorites()
            if result == "removed":
                return True
        return result if isinstance(result, self.Error) else \
            self.Error("failed to add/remove favorite")

    def check_switch_episode(self, next_or_prev):
        original = self.start_series()
        if isinstance(original, self.Error):
            return original
        new = self.press_on_next_or_previous_button(next_or_prev=next_or_prev)
        result = original != new
        return True if result else self.Error("failed to switch episode")

    def check_chainplay(self):
        started_series = self.start_series()
        if isinstance(started_series, self.Error):
            return started_series
        if not self.scrubbing(t=970):
            return self.Error("failed to do scrubbing")
        up_next = self.chainplay_up_next.visible
        if not up_next:
            return self.Error("chainplay up next is not visible")
        next_one = up_next.text.lower()
        if not next_one:
            return self.Error("failed to get text of \"chainplay up next\" label")
        result = self.helper.wait.str_in_text(
            element=self.series_season_episode_label.locator, string=next_one, timeout=50)
        return True if result else self.Error("title of next episode is not what it should be")
