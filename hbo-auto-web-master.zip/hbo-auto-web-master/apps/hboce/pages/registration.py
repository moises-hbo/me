from apps.hboce.pages.base.page import BasePageObject as Page
from hboapi.hboce.utility import generate_username, generate_email_address,\
    generate_password, generate_voucher_code
from hboapi.hboce.apihandler import Core
from helpers.sleeper import Sleeper as sleep


class RegistrationPage(Page):
    def __init__(self, driver, login_type="b2b"):
        Page.__init__(self, driver)
        self.api = Core(platform=self.platform, countryid=self.country_id)
        self.user = generate_username()
        self.email = generate_email_address()
        self.password = generate_password()
        self.operator = self.api.vip_operator()["operatorName"]
        self.login_type = login_type

        # Elements
        self.registration_button = self.create(dict(locator="signup", type="id"))
        self.sign_up_div = self.create(dict(locator="div.options", type="css selector"))
        self.sign_up_b2b = self.create(dict(locator="gw_operator_type_signup_b2b", type="id"))
        self.sign_up_d2c = self.create(dict(locator="gw_operator_type_signup_d2c", type="id"))
        self.voucher_input = self.create(dict(locator="12", type="id"))
        self.email_input = self.create(dict(locator="1", type="id"))
        self.email_validation_input = self.create(dict(locator="2", type="id"))
        self.username_input = self.create(dict(locator="3", type="id"))
        self.password_input = self.create(dict(locator="5", type="id"))
        self.password_validation_input = self.create(dict(locator="6", type="id"))
        self.newsletter_checkbox = self.create(dict(locator="9", type="id"))
        self.age_verification_checkbox = self.create(dict(locator="10", type="id"))
        self.registration_button = self.create(dict(locator="signup", type="id"))
        self.registration_finish_button = self.create(dict(
            locator="gw_registration_11_sing_in", type="id"))
        self.registration_after_finish_button = self.create(dict(
            locator="gw_signup_success_start_browsing", type="id"))
        self.error_message = self.create(dict(
            locator="//div[@class='checkboxErrorContainer']/span[@class='st-error']",
            type="xpath"))
        self.checkbox = self.create(dict(locator="10", type="id"))
        self.provider_dropdown = self.create(dict(
            locator="//div[@class='dropdown-container']/div[@class='dropdown-placeholder closed']",
            type="xpath"))
        self.dropdown_options = self.create(dict(
            locator="//div[contains(@class,'dropdown-list-element')]", type="xpath"))
        self.terms_and_conditions_button = self.create(dict(
            locator="//hbo-signup-host/hbo-form/div/div/div/div[2]/hbo-login-registration/div/div[1]/a",
            type="xpath"))
        self.terms_of_use_header = self.create(dict(locator="/html/body/main/div[1]/h2", type="xpath"))
        self.privacy_policy_button = self.create(dict(
            locator="//hbo-signup-host/hbo-form/div/div/div/div[2]/hbo-login-registration/div/div[2]/a",
            type="xpath"))
        self.data_policy_header = self.create(dict(locator="/html/body/main/div[1]/h2", type="xpath"))

    @property
    def setup(self):
        self.helper.is_anonymus = self.helper.wait.script_to_be_executed(
            script=self.is_anonymus_script, timeout=10
        )
        if not self.helper.is_anonymus:
            return self.Error("failed to register, user is logged in")
        registration_btn = self.registration_button.visible
        if not registration_btn:
            return self.Error("registration button is not visible")
        registration_btn.click()
        entered_gateway_frame = self.helper.enter_iframe_and_wait_for_element_to_be_visible(
            element=self.sign_up_b2b.locator)
        if not entered_gateway_frame:
            return self.Error("failed to enter gateway frame")
        if self.login_type == "b2b":
            b2b_btn = self.sign_up_b2b.visible
            if not b2b_btn:
                return self.Error("b2b button is not visible")
            b2b_btn.click()
            provider_dropdown = self.provider_dropdown.visible
            if not provider_dropdown:
                return self.Error("provider dropdown is not visible")
            provider_dropdown.click()
            vip_operator = self.helper.get_list_item(
                self.dropdown_options.locator, self.operator)
            if not vip_operator:
                return self.Error("failed to find vip operator")
            vip_operator.click()
        elif self.login_type == "d2c":
            d2c_btn = self.sign_up_d2c.visible
            if not d2c_btn:
                return self.Error("d2c button is not visible")
            d2c_btn.click()
        mail_input = self.email_input.visible
        return True if mail_input else self.Error("email input is not visible")

    def registration(self, negative=False, delay=0.1):
        """
        Registration test
        :param negative: Positive or negative test (False or True)
        :param delay: it's the speed for filling the input fields, the less is the faster
        :return: True if successful, False if not
        """
        # Filling out the form

        registration_finish_button = self.registration_finish_button.element
        voucher_input = self.voucher_input.element
        v = generate_voucher_code(countryid=self.country_id)

        if not negative:
            # Filling voucher code input
            if not self.voucher_input.visible:
                return self.Error("voucher input is not visible")
            self.helper.input_text(
                locator_or_element=voucher_input, text=v, pause=delay)

            # Filling email input
            email_input = self.email_input.visible
            if not email_input:
                return self.Error("email input is not visible")
            self.helper.input_text(
                locator_or_element=email_input, text=self.email, pause=delay)

            # Filling email validation input
            email_validation_input = self.email_validation_input.visible
            if not email_validation_input:
                return self.Error("email validation input is not visible")
            self.helper.input_text(
                locator_or_element=email_validation_input, text=self.email, pause=delay)

            # Filling username input
            username_input = self.username_input.visible
            if not username_input:
                return self.Error("username input is not visible")
            self.helper.input_text(
                locator_or_element=username_input, text=self.user, pause=delay)

            # Filling password input
            password_input = self.password_input.visible
            if not password_input:
                return self.Error("password input is not visible")
            self.helper.input_text(
                locator_or_element=password_input, text=self.password, pause=delay)

            # Filling password validation input
            password__validation_input = self.password_validation_input.visible
            if not password__validation_input:
                return self.Error("password validation input is not visible")
            self.helper.input_text(
                locator_or_element=password__validation_input, text=self.password, pause=delay)

            # Clicking the checkbox
            checkbox = self.checkbox.visible
            if not checkbox:
                return self.Error("checkbox is not visible")
            checkbox.click()

        else:
            # Enter without filling voucher code input
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without voucher code")
            self.d_helper.move_mouse_to(element=voucher_input)

            # Filling voucher code input
            self.helper.input_text(
                locator_or_element=voucher_input, text=v, pause=delay)

            # Enter without filling email input
            email_input = self.email_input.visible
            if not email_input:
                return self.Error("email input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without email")

            # Filling email input
            self.helper.input_text(
                locator_or_element=email_input, text=self.email, pause=delay)

            # Enter without filling email validation input
            email_validation_input = self.email_validation_input.visible
            if not email_validation_input:
                return self.Error("email validation input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without email validation")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling email validation input
            self.helper.input_text(
                locator_or_element=email_validation_input, text=self.email, pause=delay)

            # Enter without filling username input
            username_input = self.username_input.visible
            if not username_input:
                return self.Error("username input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without username")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling username input
            self.helper.input_text(
                locator_or_element=username_input, text=self.user, pause=delay)

            # Enter without filling password input
            password_input = self.password_input.visible
            if not password_input:
                return self.Error("password input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without password")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling password input
            self.helper.input_text(
                locator_or_element=password_input, text=self.password, pause=delay)

            # Enter without filling password validation input
            password_validation_input = self.password_validation_input.visible
            if not password_validation_input:
                return self.Error("password validation input is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting without password validation")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling password validation input differently then the previous one
            self.helper.input_text(
                locator_or_element=password_validation_input, text="pongopongo", pause=delay)
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting with different passwords")
            self.d_helper.move_mouse_to(element=email_input)

            # Filling password validation input
            password_validation_input.clear()
            self.helper.input_text(
                locator_or_element=password_validation_input, text=self.password, pause=delay)

            # Enter without clicking the checkbox
            checkbox = self.checkbox.visible
            if not checkbox:
                return self.Error("checkbox is not visible")
            self.d_helper.move_mouse_to(element=registration_finish_button)
            registration_finish_button = self.registration_finish_button.visible
            if not registration_finish_button:
                return self.Error("registration finish button is not visible")
            registration_finish_button.click()

            if not self.error_message.visible:
                return self.Error("error message is not visible after submitting with checkbox unchecked")
            self.d_helper.move_mouse_to(element=email_input)

            # Clicking the checkbox
            checkbox = self.checkbox.visible
            if not checkbox:
                return self.Error("checkbox is not visible")
            checkbox.click()

        # Clicking the finish button
        registration_finish_button = self.registration_finish_button.visible
        if not registration_finish_button:
            return self.Error("registration finish button is not visible")
        registration_finish_button.click()
        if not self.registration_after_finish_button.clickable_and_click:
            return self.Error("registration final finish button is not visible")

        result = self.helper.exit_iframe_and_wait_for_element_to_be_visible(
            element=self.nickname.element, timeout=20)
        return True if result else self.Error("user nickname is not visible after registration")

    def check_terms_and_conditions_button_functionality(self):
        """
        Checks if terms and conditions button is visible and has the correct href.
        Checks if the header of the terms and conditions page is visible.
        :return: WebElement if the header is visible, False if not
        """
        terms_and_conditions_button = self.terms_and_conditions_button.visible
        if not terms_and_conditions_button:
            return self.Error("terms and conditions button is not visible")
        href = terms_and_conditions_button.get_attribute("href")
        self.d_helper.open_window(url=href)
        self.d_helper.switch_to_window(index=1)
        terms_of_use_header = self.terms_of_use_header.visible
        return True if terms_of_use_header else self.Error("terms of use header is not visible")

    def check_privacy_policy_button_functionality(self):
        """
        Checks if privacy policy button is visible and has the correct href.
        Checks if the header of the privacy policy page is visible.
        :return: WebElement if the header is visible, False if not
        """
        privacy_policy_button = self.privacy_policy_button.visible
        if not privacy_policy_button:
            return self.Error("privacy policy button is not visible")
        href = privacy_policy_button.get_attribute("href")
        self.d_helper.open_window(url=href)
        self.d_helper.switch_to_window(index=1)
        data_policy_header = self.data_policy_header.visible
        return True if data_policy_header else self.Error("data policy header is not visible")
