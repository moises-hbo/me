from selenium.webdriver.support.color import Color
from functools import partial
from apps.hboce.helpers.pagehelper_ce import PageHelperCE
from apps.hboce.helpers.driverhelper_ce import DriverHelperCE
from apps.hboce.helpers.testrail_helper import TestRailHelper
from helpers.configmanager import ConfigManager


class BasePageObject(object):
    """Base page for all pages
    methods that all pages can use should go here"""

    class Error(object):
        def __init__(self, message):
            self.message = False, message

    class Element(object):
        def __init__(self, helper, locator, is_list=False, wait=None):
            self.helper = helper
            self.locator = locator if isinstance(locator, dict) else None
            self.is_list = is_list
            self.wait = wait if wait else 30

        @property
        def element(self):
            return self.helper.get_list(
                locator=self.locator) if self.is_list else self.helper.get(
                locator=self.locator)

        @property
        def name(self):
            return self.locator.get("name") if "name" in self.locator.keys() else None

        @property
        def visible(self):
            return self.helper.wait.visible(element=self.locator, timeout=self.wait)

        @property
        def not_visible(self):
            return self.helper.wait.not_visible(element=self.locator, timeout=self.wait)

        @property
        def clickable(self):
            return self.helper.wait.clickable(element=self.locator, timeout=self.wait)

        @property
        def clickable_and_click(self):
            return self.helper.wait.clickable_and_click(element=self.locator, timeout=self.wait)

    def __init__(self, driver):
        self.driver = driver
        self.helper = PageHelperCE(driver=driver)
        self.d_helper = DriverHelperCE(driver=driver)
        self.tr_helper = TestRailHelper()

        # The ultimate Element creator
        self.create = partial(self.Element, self.helper)

        # Common
        self.nickname = self.create(dict(locator="nickname", type="id"))
        self.gateway_frame = self.create(dict(locator="gatewayFrame", type="id"))
        self.is_anonymus_script = "return go.customer.customer.IsAnonymus;"
        self.get_current_language = "return go.customer.customer.Language;"
        self.get_customer_id = "return go.customer.customer.Id;"
        self.get_gotoken = "return go.customer.goToken;"
        self.get_session_id = "return go.customer.sessionId;"
        self.cm = ConfigManager()
        self.platform = self.cm.platform
        self.country_id = self.cm.country_id

    @property
    def setup(self):
        default_setup = self.helper.default_setup()
        return True if default_setup else self.Error("default setup has failed")

    @property
    def movies(self):
        result = self.helper.open_section(section="movies")
        return True if result else self.Error("failed to open movies section")

    @property
    def series(self):
        result = self.helper.open_section(section="series")
        return True if result else self.Error("failed to open series section")

    @property
    def home(self):
        result = self.helper.open_section(section="home")
        return True if result else self.Error("failed to open home section")

    @property
    def kids(self):
        result = self.helper.open_section(section="kids")
        return True if result else self.Error("failed to open kids section")

    @property
    def search(self):
        result = self.helper.open_section(section="search")
        return True if result else self.Error("failed to open search section")

    def get_background_color(self):
        body = self.helper.get("//html")
        return Color.from_string(
            f"{body.value_of_css_property('background-color')}").hex
