from hboapi.hboce.utility import get_common_data
from hboapi.hboce.apihandler import Core
from apps.hboce.pages.base.page import BasePageObject as Page


class LoginPage(Page):
    def __init__(self, driver, login_type="b2b"):
        Page.__init__(self, driver)
        self.helper.login_type = login_type
        self.api = Core(platform=self.platform, countryid=self.country_id)
        self.login_type = login_type
        self.nick = self.get_nick_by_api()
        self.vip_operator = self.api.vip_operator().get("operatorName")
        self.d2c_operator = self.api.d2c_operator()
        self.mail = get_common_data().get("{}_login_email".format(login_type))
        self.password = get_common_data().get("login_password")

        # Elements
        self.login_button = self.create(dict(locator="signin", type="id"))
        self.welcome_back_login = self.create(dict(locator="gw_welcome_signin", type="id"))
        self.b2b_sign_in_provider = self.create(dict(locator="gw_operator_type_signin_b2b", type="id"))
        self.d2c_sign_in_provider = self.create(dict(locator="gw_operator_type_signin_d2c", type="id"))
        self.provider_dropdown = self.create(dict(
            locator="//div[@class='dropdown-container']/div[@class='dropdown-placeholder closed']",
            type="xpath"))
        self.email_input = self.create(dict(locator="1", type="id"))
        self.password_input = self.create(dict(locator="5", type="id"))
        self.dropdown_options = self.create(dict(
            locator="//div[@class='dropdown-container']/div[2]/div", type="xpath"), True)
        self.login_finish_button = self.create(dict(locator="gw_login_06_sign_in", type="id"))
        self.settings_button = self.create(dict(locator='//*[@id="settings"]', type="xpath"))
        self.acc_man_log_out_button = self.create(dict(
            locator='//*[@id="gw_settings_sidebar_sign_out"]', type="xpath"))
        self.acc_man_confirm_sign_out_button = self.create(dict(
            locator='//*[@id="hbo_notification_sign_out_yes"]', type="xpath"))
        self.missing_email_error = self.create(dict(
            locator="//hbo-login-registration/hbo-reactive-form/div/form/div[1]/div/div/span[@class='st-error']",
            type="xpath"))
        self.missing_password_error = self.create(dict(
            locator="//hbo-login-registration/hbo-reactive-form/div/form/div[2]/div/div/span[@class='st-error']",
            type="xpath"))
        self.forgot_password_button = self.create(dict(
            locator="hbo_login_registration_reset_password_modal", type="id"))
        self.dont_have_an_account_yet_button = self.create(dict(
            locator="hbo_login_registration_no_account", type="id"))
        self.create_account_header = self.create(dict(
            locator="//hbo-signup-host/account-details/div/div[@class='account-details-middle-wrapper']/h1",
            type="xpath"))
        self.hbo_message = self.create(dict(locator="//div[@class='hbo-message']", type="xpath"))

    def get_nick_by_api(self):
        try:
            nick = self.api.nick_by_api(authtype=self.login_type)
        except AssertionError:
            nick = None
        return nick

    def log_in_setup(self):
        self.helper.is_anonymus = self.helper.wait.script_to_be_executed(
            script=self.is_anonymus_script)
        if not self.helper.is_anonymus:
            return True
        # Clicking login button
        login_button = self.login_button.visible
        if not login_button:
            return self.Error("login button is not visible")
        login_button.click()
        # Entering gateway frame
        gateway_frame = self.gateway_frame.element
        self.d_helper.enter_iframe(element=gateway_frame)
        if self.login_type == "b2b":
            b2b = self.b2b_sign_in_provider.visible
            if not b2b:
                return self.Error("b2b button is not visible")
            b2b.click()
            provider_dropdown = self.provider_dropdown.visible
            if not provider_dropdown:
                return self.Error("provider dropdown is not visible")
            provider_dropdown.click()
            if self.dropdown_options.visible:
                operators = self.dropdown_options.element
                vip_operator = [x for x in operators if x.text == self.vip_operator][0]
                vip_operator = self.helper.wait.visible(element=vip_operator)
                if not vip_operator:
                    return self.Error("vip operator is not visible")
                vip_operator.click()
        elif self.login_type == "d2c":
            d2c = self.d2c_sign_in_provider.visible
            if not d2c:
                return self.Error("d2c button is not visible")
            d2c.click()
        email = self.email_input.visible
        return True if email else self.Error("email input is not visible")

    def log_in(self):
        # Login setup
        log_in_setup_result = self.log_in_setup()
        if isinstance(log_in_setup_result, self.Error):
            return log_in_setup_result

        # Filling email input
        email_input = self.email_input.visible
        if not email_input:
            return self.Error("email input is not visible")
        self.helper.input_text(
            locator_or_element=email_input, text=self.mail, pause=0.05)

        # Filling password input
        password_input = self.password_input.visible
        if not password_input:
            return self.Error("password input is not visible")
        self.helper.input_text(
            locator_or_element=password_input, text=self.password, pause=0.05)
        login_finish_button = self.login_finish_button.visible
        if not login_finish_button:
            return self.Error("login finish button is not visible")
        login_finish_button.click()
        hbo_message = self.helper.wait.visible(element=self.hbo_message.locator, timeout=5)
        if hbo_message:
            return self.Error(hbo_message.text)
        nick = self.helper.exit_iframe_and_wait_for_element_to_be_visible(
            element=self.nickname.element)
        result = nick.text if nick else False
        return result if result else self.Error("failed to log in")

    def log_out_through_settings(self):
        nick = self.helper.wait.visible(element=self.nickname.locator, timeout=5)
        if not nick:
            nick = self.helper.wait.visible(element=self.nickname.locator, timeout=10)
            if not nick:
                return self.Error("nickname is not visible")
        self.d_helper.move_mouse_to(element=nick)
        settings_button = self.settings_button.visible
        if not settings_button:
            return self.Error("settings button is not visible")
        settings_button.click()
        logout_button = self.helper.enter_iframe_and_wait_for_element_to_be_visible(
            element=self.acc_man_log_out_button.locator)
        if not logout_button:
            return self.Error("logout button is not visible")
        self.d_helper.move_mouse_to(element=logout_button)
        logout_button.click()
        confirm_signout = self.acc_man_confirm_sign_out_button.clickable_and_click
        if not confirm_signout:
            return self.Error("confirm signout button is not visible")
        login_button = self.helper.exit_iframe_and_wait_for_element_to_be_visible(
            element=self.login_button.locator)
        return True if login_button else self.Error("login button is not visible, failed to log out")

    def log_in_with_deficient_form(self):
        # Login setup
        log_in_setup_result = self.log_in_setup()
        if isinstance(log_in_setup_result, self.Error):
            return log_in_setup_result

        # Try clicking finish button without e-mail and password
        login_finish_button = self.login_finish_button.visible
        if not login_finish_button:
            return self.Error("login finish button is not visible")
        login_finish_button.click()

        if not self.missing_email_error.visible:
            return self.Error("email error message is not visible")

        # Try clicking finish button without password
        email_input = self.email_input.visible
        if not email_input:
            return self.Error("email input is not visible")
        self.helper.input_text(
            locator_or_element=email_input, text=self.mail, pause=0.05)
        login_finish_button = self.login_finish_button.visible
        if not login_finish_button:
            return self.Error("login finish button is not visible")
        login_finish_button.click()
        pw_error = self.missing_password_error.visible
        if not pw_error:
            return self.Error("password error message is not visible")

        # Filling password input with valid data
        password_input = self.password_input.visible
        if not password_input:
            return self.Error("password input is not visible")
        self.helper.input_text(
            locator_or_element=password_input, text=self.password, pause=0.05)
        login_finish_button = self.login_finish_button.visible
        if not login_finish_button:
            return self.Error("login finish button is not visible")
        login_finish_button.click()
        hbo_message = self.helper.wait.visible(element=self.hbo_message.locator, timeout=5)
        if hbo_message:
            return self.Error(hbo_message.text)
        nick = self.helper.exit_iframe_and_wait_for_element_to_be_visible(
            element=self.nickname.element)
        return True if nick else self.Error("failed to log in")

    def check_forgot_password_button_functionality(self):
        # Login setup
        log_in_setup_result = self.log_in_setup()
        if isinstance(log_in_setup_result, self.Error):
            return log_in_setup_result

        # Clicking the forgot password button
        forgot_pw_button = self.forgot_password_button.visible
        if not forgot_pw_button:
            return self.Error("forgot password button is not visible")
        forgot_pw_button.click()

        # Checking if the email input field is visible
        result = self.email_input.visible
        return True if result else self.Error("email input field is not visible")

    def check_dont_have_an_account_yet_button_functionality(self):
        # Login setup
        log_in_setup_result = self.log_in_setup()
        if isinstance(log_in_setup_result, self.Error):
            return log_in_setup_result

        # Clicking the "don't have an account yet" button
        dont_have_an_account = self.dont_have_an_account_yet_button.visible
        if not dont_have_an_account:
            return self.Error("don't have an account button is not visible")
        dont_have_an_account.click()

        if self.login_type == "b2b":
            # Checking if the operator selector is visible
            result = self.provider_dropdown.visible
            error = self.Error("provider dropdown is not visible")

        else:
            # Checking if the "Create account" header is visible
            result = self.create_account_header.visible
            error = self.Error("create account header is not visible")
        return True if result else error
