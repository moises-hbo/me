from selenium.webdriver.remote.webelement import WebElement
from apps.hboce.pages.base.page import BasePageObject as Page
from requests import get
from json import loads


class MenuPage(Page):
    def __init__(self, driver, login_type="b2b", timeout=10):
        Page.__init__(self, driver)
        self.timeout = timeout
        self.login_type = login_type

        # Elements
        self.menu_item_links = dict(
            home=self.create(dict(locator="/html/body/nav/div/span/a", type="xpath", visible="both")),
            series=self.create(dict(locator="/html/body/nav/div/ul/li[1]/a", type="xpath", visible="both")),
            movies=self.create(dict(locator="/html/body/nav/div/ul/li[2]/a", type="xpath", visible="both")),
            kids=self.create(dict(locator="/html/body/nav/div/ul/li[3]/a", type="xpath", visible="both")),
            search=self.create(dict(locator="/html/body/nav/div/ul/li[4]/a/img", type="xpath", visible="both")),
            login=self.create(dict(locator="//*[@id='signin']", type="xpath", visible="logged_out")),
            registration=self.create(dict(locator="//*[@id='signup']", type="xpath", visible="logged_out")),
            nickname=self.create(dict(locator="//*[@id='nickname']", type="xpath", visible="logged_in"))
        )
        self.user_menu_item_links = dict(
            settings=self.create(dict(locator="//*[@id='settings']", type="xpath")),
            logout=self.create(dict(locator="//*[@id='signout']", type="xpath"))
        )
        self.default_text_color = "255, 255, 255"
        self.default_background_color = "0, 0, 0"
        self.kid_mode_default_text_color = "255, 255, 255"
        self.kid_mode_default_background_color = "0, 145, 234"
        self.footer = self.create(dict(locator="/html/body/div[1]/nav[2]", type="xpath"))
        self.footer_menu_items = dict(
            faq=self.create(dict(locator="/html/body/div[1]/nav[2]/ul/li[1]/a",
                                 type="xpath", href="https://helpcenter.hbogo.eu/")),
            user_conditions=self.create(dict(locator="/html/body/div[1]/nav[2]/ul/li[2]/a",
                                             type="xpath", href="###HBO###felhasznalasi-feltetelek")),
            data_security=self.create(dict(locator="/html/body/div[1]/nav[2]/ul/li[3]/a",
                                           type="xpath", href="###HBO###adatvedelem")),
            connect=self.create(dict(locator="/html/body/div[1]/nav[2]/ul/li[4]/a",
                                     type="xpath", href="###HBO###elerhetoseg")),
            cookie=self.create(dict(locator="/html/body/div[1]/nav[2]/ul/li[5]/a",
                                    type="xpath", href="###HBO###cookie-szabalyzat"))
        )
        self.social = self.create(dict(locator="/html/body/div[1]/nav[1]", type="xpath"))
        self.social_menu_items = dict(
            facebook=self.create(dict(locator="/html/body/div[1]/nav[1]/ul/li[1]/a",
                                      type="xpath", href="facebook.com")),
            twitter=self.create(dict(locator="/html/body/div[1]/nav[1]/ul/li[2]/a",
                                     type="xpath", href="twitter.com")),
            instagram=self.create(dict(locator="/html/body/div[1]/nav[1]/ul/li[3]/a",
                                       type="xpath", href="instagram.com")),
            youtube=self.create(dict(locator="/html/body/div[1]/nav[1]/ul/li[4]/a",
                                     type="xpath", href="youtube.com"))
        )
        self.language_selector = self.create(dict(
            locator="//span[@class='region']/ul/li/a", type="xpath"), True)

    def check_menu_items(self, logged_in):
        menu_items = []
        element = None
        for item in self.menu_item_links.keys():
            if logged_in:
                if self.menu_item_links.get(item).locator.get("visible") is not "logged_out":
                    element = self.menu_item_links.get(item).visible
            else:
                if self.menu_item_links.get(item).locator.get("visible") is not "logged_in":
                    element = self.menu_item_links.get(item).visible
            if not isinstance(element, WebElement):
                return self.Error("{} button is not visible".format(item))
            text = element.text
            if text:
                menu_items.append(
                    text if item is not "search" else
                    element.get_property("className")
                )
        if logged_in:
            nickname = self.nickname.visible
            if not nickname:
                return self.Error("nickname is not visible")
            self.d_helper.move_mouse_to(element=nickname)
            for item in self.user_menu_item_links.keys():
                element = self.user_menu_item_links.get(item).visible
                if not isinstance(element, WebElement):
                    return self.Error("{} button is not visible".format(item))
                text = element.text
                if text:
                    menu_items.append(element.text)
        self.helper.log("menu items: {items}".format(
            items=", ".join(map(str, menu_items))))
        return menu_items

    def click_on_menu_items(self):
        result = {"expected": [], "actual": []}
        for i in self.menu_item_links.keys():
            item = self.menu_item_links.get(i)
            if item.locator.get("visible") is "visible" or item.locator.get("visible") is "both":
                element = item.visible
                if not element:
                    return self.Error("{} button is not visible".format(i))
                text = element.text.lower()
                element.click()
                url_end = self.driver.current_url.split("/")[-1]
                if i == "home":
                    result["expected"].append(text)
                    result["actual"].append("hbo go")
                elif i == "nickname":
                    result["expected"].append(self.driver.execute_script(
                        "return go.customer.customer.Nick;"))
                    result["actual"].append(self.nickname.visible.text)
                elif i == "search":
                    result["expected"].append(i)
                    result["actual"].append(url_end)
                else:
                    result["expected"].append(text)
                    result["actual"].append(url_end)
        for i in range(len(result["expected"])):
            if result["expected"][i] != result["actual"][i]:
                return self.Error("{} != {}".format(result["expected"][i], result["actual"][i]))
        return True

    def check_kid_mode_appearance(self):
        kids_menu = self.menu_item_links.get("kids").visible
        if not kids_menu:
            return self.Error("kids menu is not visible")
        kids_menu.click()
        color = self.helper.get_element_css_property(
            locator="/html/body/nav", locator_type="xpath", css_property="color")
        background = self.helper.get_element_css_property(
            locator="/html/body/nav", locator_type="xpath", css_property="background-color")

        if self.kid_mode_default_text_color in color and self.kid_mode_default_background_color in background:
            return True
        else:
            return self.Error("kid mode appearance is not as expected")

    def check_menu_appearance(self, menu):
        base_url = self.driver.current_url
        for key in menu.keys():
            menu_item = menu.get(key).element
            self.d_helper.move_mouse_to(element=menu_item)
            menu_item = menu.get(key).visible
            if not menu_item:
                return self.Error("menu item is not visible")
            if menu == self.footer_menu_items:
                continue
            a = self.helper.get_attribute(locator_or_element=menu.get(key).visible,
                                          attribute_name="href")
            expected = menu.get(key).locator.get("href")
            if "###HBO###" in expected:
                expected = expected.replace("###HBO###", str(base_url))
            if expected not in a:
                return self.Error("url of menu item is not as expected")
        return True

    def check_menu_functionality(self, menu):
        base_url = self.driver.current_url
        for key in menu.keys():
            menu_item = menu.get(key).element
            self.d_helper.move_mouse_to(element=menu_item)
            menu_item = menu.get(key).visible
            if not menu_item:
                return self.Error("menu item is not visible")
            if menu == self.footer_menu_items:
                continue
            a = self.helper.get_attribute(locator_or_element=menu.get(key).visible,
                                          attribute_name="href")
            expected = menu.get(key).locator.get("href")
            if "###HBO###" in expected:
                expected = expected.replace("###HBO###", str(base_url))
            self.d_helper.open_window(a)
            self.d_helper.switch_to_window(1)
            url_is_good = self.helper.wait.url(url=expected, timeout=10)
            if not url_is_good:
                return self.Error("url is not as expected")
            self.d_helper.close_window()
            self.d_helper.switch_to_window(0)
        return True

    def check_footer_language_selector(self):
        country_id = self.country_id
        lang_elements = self.language_selector.element
        if not lang_elements:
            return self.Error("unable to find language selector list items")
        langs_ui = [l.get_attribute("text").lower() for l in lang_elements]

        lang_api_url = "https://{}api.hbogo.eu/v8/Languages/json".format(
            country_id if country_id != "rs" else "sr")
        api_response = get(url=lang_api_url)
        if not api_response:
            return self.Error("failed to get data from api")
        api_langs_dict = loads(api_response.content.decode(encoding="utf-8"))
        langs_api = [item.get("Name").lower() for item in api_langs_dict.get("Items")]
        for lang in langs_ui:
            if lang not in langs_api:
                return self.Error("{} is not a valid language for {}".format(lang.lower(), country_id))
        return True

    def check_appearance(self):
        color = self.helper.get_element_css_property(
            locator="/html/body", locator_type="xpath", css_property="color")
        color_is_good = self.default_text_color in color
        color_result = True if color_is_good else self.Error("text color is not as expected")
        background = self.helper.get_element_css_property(
            locator="/html/body", locator_type="xpath", css_property="background-color")
        bg_is_good = self.default_background_color in background
        bg_result = True if bg_is_good else self.Error("background color is not as expected")
        if not color_is_good:
            if not bg_is_good:
                return self.Error("both color and background are not as expected")
            else:
                return color_result
        elif not bg_is_good:
            return bg_result
        return color_result
