from requests import get
from apps.hboce.pages.base.page import BasePageObject as Page
from random import choice


class SearchPage(Page):
    def __init__(self, driver, login_type="b2b"):
        super().__init__(driver=driver)
        self.login_type = login_type

        # Elements
        self.link = self.create(dict(locator="//li/a[@href='/search']", type="xpath"))
        self.input = self.create(dict(locator="search-input", type="id"))
        self.clear_button = self.create(dict(locator="//div[@id='search-clear']", type="xpath"))
        self.results = self.create(dict(
            locator="//div[@class='grid']/div[@class='grid-item']/a", type="xpath"))
        self.search_results = self.create(dict(
            locator="//*[@id='list-results']/div/div/a", type="xpath"), True)
        self.noresult = self.create(dict(
            locator="//div[@id='list-noresult']/h2", type="xpath", name="no result label"))
        self.notification = self.create(dict(locator="search-notification", type="id"))
        self.result_counter = self.create(dict(locator="//div[@id='list-results']/h2", type="xpath"))
        self.results_header = self.create(dict(locator="//*[@id='list-results']/h2", type="xpath"))
        self.title_of_content = self.create(dict(
            locator="//div[@class='meta']/span[@class='original-title']", type="xpath"))
        self.modal = self.create(dict(locator="//div[@class='modal']", type="xpath"))

        self.search_texts = [
            "Game of Thrones", "The Big Bang Theory", "Sex and the City"]
        # self.text = choice(self.search_texts)
        self.text = "game"
        self.search_api_url = "https://huapi.hbogo.eu/v8/Search/json/ENG/COMP/###KEYWORD###/-/-/-/-/-/3"
        self.api_url = self.search_api_url.replace(
            "###KEYWORD###", self.text)
        self.invalid_char_search_texts = ["%aa", "???", "///", "((a"]
        self.invalid_char_search_text = choice(
            self.invalid_char_search_texts)
        self.default_text_color = "255, 255, 255"
        self.default_background_color = "0, 0, 0"
        self.looong_text = "qwertzuiopasdfghjklíyxcvbnmqwertzuiopasdfghjklíyxcvbnmqwertzuiopasdfghj" \
                           "ertzuiopasdfghjklíyxcvbnmqwertzuiopasdfghjklíyxcvbnmqwertzuiopasdfghjkl" \
                           "íyxcvbnmqwklíyxcvbnmqwertzuiopasdfghjklíyxcvbnmsajkdfhkasaaaaaaaaaaaaaaa"

    def enter_text_on_search(self, text=None, timeout=10, delay=0.05, wait_for_result=True):
        if text is None:
            text = self.text
        search_input = self.input.visible
        if not search_input:
            return self.Error("search input is not visible")
        self.helper.input_text(locator_or_element=search_input, text=text,
                               timeout=timeout, pause=delay)
        if not wait_for_result:
            return True
        first_result = self.helper.wait.visible(element=self.search_results.locator, timeout=5)
        if not first_result:
            self.input.visible.send_keys("\ue007")
        first_result = self.helper.wait.visible(element=self.search_results.locator, timeout=5)
        if not first_result:
            return self.Error("failed to get search result")
        return True

    def click_on_search_result(self, index):
        if not self.search_results.visible:
            return False
        results = self.search_results.element
        result = self.helper.wait.visible(element=results[index])
        if not result:
            return False
        result.click()
        return self.modal.visible

    def get_search_result_names(self):
        results = self.search_results.element
        if not results:
            return self.Error("failed to get search results")
        result_names = [result.find_element_by_css_selector(
            "span.title").get_property("innerText").lower() for result in results]
        return result_names if result_names else \
            self.Error("failed to get text of search results")

    def get_search_result_names_api(self):
        url = self.api_url
        response = get(url)
        data = response.json()
        if not data:
            return self.Error("failed to get response for the API call")
        result_names = [item["Name"].lower()
                        for item in data["Container"][0]["Contents"]["Items"]]
        return result_names if result_names \
            else self.Error("failed to get result names from the API response")

    def get_search_result_count(self):
        result_counter = self.result_counter.visible
        if not result_counter:
            return self.Error("result counter label is not visible")
        result_count_text = self.helper.wait.text(
            element=result_counter, timeout=10)
        if not result_count_text:
            return self.Error("failed to get text of result count label")
        result_count = int(result_count_text.split(" ")[0])
        return result_count if result_count else self.Error("failed to get result count")

    def get_search_result_count_api(self):
        data = get(self.api_url).json()
        return int(data["Container"][0]["ResultCount"]) if data else \
            self.Error("failed to get result count from api")

    def compare_results(self, a, b):
        for i in a:
            if i not in b:
                return self.Error("results from ui and from api are different")
        return True

    def check_search_results(self):
        try:
            return self.search_results.element
        except Exception:
            return self.Error("unable to get search results")

    def search_for_a_content_click_first_and_check_title(self):
        text_entered = self.enter_text_on_search(self.text)
        if isinstance(text_entered, self.Error):
            return text_entered
        if not self.click_on_search_result(0):
            return self.Error("failed to click on first search result")
        content = self.title_of_content.visible
        if not content:
            return self.Error("failed to find content for '{}' keyword".format(self.text))
        result = self.text.lower() in content.text.lower()
        return result if result else self.Error("title is not as expected")

    def check_short_searchtext(self):
        self.enter_text_on_search("aa", delay=1, wait_for_result=False)
        result = self.helper.wait.attribute(
            element=self.notification.element, attr="class", exp="fade-in-load")
        return result if result else self.Error(
            "hint for too short search text is not visible")

    def click_on_search_result_js(self, i):
        js_find = "var e = document.querySelector('#list-results>div>" \
                  "div.grid-item:nth-child({})>a.item-link');"
        js_click = "e.click();"
        script_to_click_result = js_find.format(i) + js_click
        self.driver.execute_script(script_to_click_result)

    def validate_search_results_with_api(self):
        result = self.enter_text_on_search()
        if isinstance(result, self.Error):
            return result
        ui_results = self.get_search_result_names()
        if isinstance(ui_results, self.Error):
            return ui_results
        self.helper.log("UI Results: {}".format(ui_results))
        api_results = self.get_search_result_names_api()
        if isinstance(api_results, self.Error):
            return api_results
        self.helper.log("API Results: {}".format(api_results))
        return self.compare_results(ui_results, api_results)

    def check_result_for_specific_searchtext(self, search_text, expected_element_to_be_visible):
        result = self.enter_text_on_search(
            text=search_text, delay=0.02, wait_for_result=False)
        if isinstance(result, self.Error):
            return result
        expected = expected_element_to_be_visible.visible
        name = expected.locator.get("name") if "name" in expected.locator.keys() else "element"
        return True if expected else self.Error("{} is not visible".format(name))

    def check_search_result_count(self):
        result = self.enter_text_on_search()
        if isinstance(result, self.Error):
            return result
        result_count_api = self.get_search_result_count_api()
        if isinstance(result_count_api, self.Error):
            return result_count_api
        result_count_ui = self.get_search_result_count()
        if isinstance(result_count_ui, self.Error):
            return result_count_ui
        result = result_count_api == result_count_ui
        return True if result else self.Error(
            "result count on ui is different then the one from the api call")

    def check_search_input_is_cleared(self):
        result = self.enter_text_on_search()
        if isinstance(result, self.Error):
            return result
        clear_button = self.clear_button.visible
        if not clear_button:
            return self.Error("clear button is not visible")
        clear_button.click()
        input_field = self.input.visible
        if not input_field:
            return self.Error("input field is not visible")
        result = self.helper.wait.attribute(
            element=input_field, attr="value", exp="")
        return True if result else self.Error("failed to clear input field")

    def check_search_navigation(self):
        result = self.enter_text_on_search("aa", delay=1, wait_for_result=False)
        if isinstance(result, self.Error):
            return result
        notification = self.notification.element
        if not notification:
            return self.Error("failed to get notification for typing less than 3 character")
        result = self.helper.wait.attribute(
            element=notification, attr="class", exp="fade-in-load")
        if not result:
            return self.Error("notification for typing less than 3 character is not visible")

        input_field = self.input.visible
        if not input_field:
            return self.Error("input field is not visible")
        input_field.clear()
        result = self.enter_text_on_search("gam")
        return True if result else self.Error("failed to get search result")

    def check_search_appearance(self):
        result = self.enter_text_on_search()
        if isinstance(result, self.Error):
            return result
        color = self.helper.get_element_css_property(
            locator="/html/body", locator_type="xpath", css_property="color")
        if not color:
            return self.Error("failed to get text color of body")
        color = color.split("(")[1].split(")")[0]
        result = self.default_text_color in color
        if not result:
            return self.Error("text color is not as expected")
        background = self.helper.get_element_css_property(
            locator="/html/body", locator_type="xpath", css_property="background-color")
        if not background:
            return self.Error("failed to get background color of body")
        background = background.split("(")[1].split(")")[0]
        result = self.default_background_color in background
        return True if result else self.Error("background color is not as expected")
