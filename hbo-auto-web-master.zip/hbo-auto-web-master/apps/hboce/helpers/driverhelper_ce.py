from helpers.driverhelper import DriverHelper
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import StaleElementReferenceException
from helpers.wait import Wait
from time import time
from helpers.sleeper import Sleeper as sleep
from selenium.webdriver.remote.webelement import WebElement


class DriverHelperCE(DriverHelper):
    def __init__(self, driver):
        super().__init__(driver)
        self.wait = Wait(driver=driver)

    def move_mouse_to(self, element, timeout=10):
        """Move mouse to the middle of an element.

        This will effectively hover over/highlight it.
        """
        element = element if isinstance(element, WebElement) else self.wait.get(element=element)
        now = time()
        while time() < now + timeout:
            try:
                ActionChains(self.driver).move_to_element(element).perform()
                return True
            except StaleElementReferenceException:
                sleep(1)
        return False
