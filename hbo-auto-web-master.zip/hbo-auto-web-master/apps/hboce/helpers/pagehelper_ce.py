from helpers.pagehelper import PageHelper
from selenium.webdriver.remote.webelement import WebElement
from hboapi.hboce.apihandler import Core
from pathlib import Path
import json
from helpers.wait import Wait
from time import time
from helpers.sleeper import Sleeper as sleep
from helpers.configmanager import ConfigManager

cm = ConfigManager()


class PageHelperCE(PageHelper):
    """
    Helper class for Page objects of HBOGO CE tests.
    Based on the original PageHelper class, but contains CE related functions.
        """

    def __init__(self, driver, login_type="b2b"):
        super().__init__(driver)
        self.is_anonymus_script = "return go.customer.customer.IsAnonymus;"
        self.is_anonymus = None
        self.platform = cm.platform
        self.country_id = cm.country_id
        self.api = Core(platform=self.platform, countryid=self.country_id)
        self.gw = self.api.gw
        self.wait = Wait(driver=driver, timeout=30, delay=0.5)
        self.login_type = login_type

        self.get_current_language = "return go.customer.customer.Language;"
        self.get_customer_id = "return go.customer.customer.Id;"
        self.get_gotoken = "return go.customer.goToken;"
        self.get_session_id = "return go.customer.sessionId;"

        self.nickname = {"locator": "nickname", "type": "id"}
        self.gateway_frame = {"locator": "gatewayFrame", "type": "id"}

        self.auth_data = dict(
            email="hboceauto+{}@gmail.com".format(self.login_type),
            pwd="common")
        self.customer_data = dict(
            hu=dict(
                b2b=dict(customer_id="0e9473b3-9805-4647-b0bd-dc5813c917a3",
                         indiv_id="F4C04296-9EB1-F3C4-E85A-9EF8DA745F9D"),
                d2c=dict(customer_id="765e70da-d000-4263-84c3-6d82b91ae9f7",
                         indiv_id="71E59CFF-A1F9-844E-4FA2-D6EC7137124A")),
            ro=dict(
                b2b=dict(customer_id="d6f1f045-053c-40b3-aa3e-9fd169741a6f",
                         indiv_id="BFC8623E-2C8E-BAD7-4F9C-90B8E69BF5FB"),
                d2c=dict(customer_id="", indiv_id="")),
            pl=dict(
                b2b=dict(customer_id="4719496a-fdf0-4060-ae91-295f00a4e877",
                         indiv_id="C1C670EB-429B-338B-F408-1E7B910E5BA8"),
                d2c=dict(customer_id="", indiv_id="")),
            ba=dict(
                b2b=dict(customer_id="80480449-6e2c-421f-84e0-cca448eeca30",
                         indiv_id="757FC29F-CC33-0A6C-1C2A-13D9F2DA6BB9"),
                d2c=dict(customer_id="", indiv_id="")),
            bg=dict(
                b2b=dict(customer_id="8a3bc827-5340-4167-a967-d6ab209cab51",
                         indiv_id="83E38D38-4B08-6213-2F55-DE220B1F4260"),
                d2c=dict(customer_id="", indiv_id="")),
            cz=dict(
                b2b=dict(customer_id="18cfae80-b8b0-4f5a-aa46-436ee23b94f3",
                         indiv_id="50B1FC24-A9EF-B425-2615-92B70CC00B87"),
                d2c=dict(customer_id="", indiv_id="")),
            hr=dict(
                b2b=dict(customer_id="167ded34-673f-41ad-ad40-a8e78be202ba",
                         indiv_id="77F03748-2C99-EE0A-A1CA-1ABE89F56822"),
                d2c=dict(customer_id="", indiv_id="")),
            me=dict(
                b2b=dict(customer_id="f26eac79-79fa-44c5-a842-5a57a5c08da4",
                         indiv_id="A03621EE-AD75-31D8-BADE-D9D307EE355E"),
                d2c=dict(customer_id="", indiv_id="")),
            mk=dict(
                b2b=dict(customer_id="6fad358f-87e0-4820-a076-746ed4d01928",
                         indiv_id="20C402FA-E4BB-90B0-7B77-4A4B243F00B2"),
                d2c=dict(customer_id="", indiv_id="")),
            si=dict(
                b2b=dict(customer_id="8498b295-59be-486a-9c4a-d8eafc40c40d",
                         indiv_id="958A10BF-188F-1046-A718-19B90360BCB0"),
                d2c=dict(customer_id="", indiv_id="")),
            sk=dict(
                b2b=dict(customer_id="dd4765df-368b-4885-bd3f-f2af1836c990",
                         indiv_id="13B72328-2553-343C-DD80-DDBA20F7F217"),
                d2c=dict(customer_id="", indiv_id="")),
            rs=dict(
                b2b=dict(customer_id="ecb0bcf5-a510-4310-80b5-151bf1aba5e8",
                         indiv_id="1DC7B0CD-2C47-D9D2-5474-128137EC7C3F"),
                d2c=dict(customer_id="", indiv_id="")),
            pt=dict(
                b2b=dict(customer_id="", indiv_id=""),
                d2c=dict(customer_id="", indiv_id=""))
        )

    def is_logged_in(self):
        return not self.driver.execute_script(self.is_anonymus_script)

    def default_setup(self, login_type="b2b", timeout=40):
        self.is_anonymus = self.wait.script_to_be_executed(
            script=self.is_anonymus_script, timeout=timeout)
        if self.is_anonymus:
            self.autologin(login_type=login_type)
        if not self.change_language_to_english():
            return False
        nick = self.wait.visible(element=dict(locator="nickname", type="id"), timeout=5)
        if not nick:
            nick = self.wait.visible(element=dict(locator="nickname", type="id"),
                                     timeout=timeout)
            if not nick:
                return False
        return True

    def change_language_to_english(self, login_type="b2b", timeout=20):
        now = time()
        current_language = str(
            self.get_application_language(timeout=10)).upper()
        if current_language == "ENG":
            return True
        while time() < now + timeout:
            customer_id = self.driver.execute_script(
                self.get_customer_id)
            go_token = self.driver.execute_script(self.get_gotoken)
            session_id = self.driver.execute_script(
                self.get_session_id)
            try:
                self.gw.set_app_language(
                    gotoken=go_token, gosessionid=session_id,
                    gocustomerid=customer_id, expectedlang="ENG", authtype=login_type)
                self.driver.refresh()
                self.wait.visible(
                    element=self.nickname, timeout=timeout)
                current_language = str(
                    self.get_application_language()).upper()
                if current_language == "ENG":
                    self.log("application language is set to english")
                    return True
            except Exception:
                sleep(1)
        return False

    def autologin(self, login_type):
        customer_data = {
            "b2b": {
                "Id": self.customer_data.get(self.country_id).get(self.login_type).get("customer_id"),
                "PayingStatus": "PAYING",
                                "Email": self.auth_data.get("email"),
                                "Individualization": self.customer_data.get(
                                    self.country_id).get(self.login_type).get("indiv_id"),
                                "AuthGWId": "1"
            },
            "d2c": {
                 "Id": self.customer_data.get(self.country_id).get(self.login_type).get("customer_id"),
                 "PayingStatus": "FREE_TRIAL",
                                 "Email": self.auth_data.get("email"),
                                 "Individualization": self.customer_data.get(
                                    self.country_id).get(self.login_type).get("indiv_id"),
                                 "AuthGWId": "2",
                                 "Passwordtag": "\"Password\": \"common\","
            }
        }

        script = str("localStorage.setItem('go-customer-data', JSON.stringify({ data: '{" +
                     "\"CurrentDevice\": {\"Individualization\": \""
                     + customer_data[login_type]["Individualization"] + "\"}, "
                     + "\"EmailAddress\": \"" + customer_data[login_type]["Email"]
                     + "\", \"SubscState\": \"" + customer_data[login_type]["PayingStatus"] + "\", "
                     + "\"Id\": \"" + customer_data[login_type]["Id"] + "\", "
                     + "\"IsAnonymus\": false}', expirationDate: '2020-04-07T12:45:22.862Z' }));")

        script = script + str("localStorage.setItem('go-customer-id', JSON.stringify({ data: '"
                              + customer_data[login_type]["Id"]
                              + "', expirationDate: '2020-04-07T12:45:22.862Z' }));")
        script = script + str("localStorage.setItem('go-customer-individualization', JSON.stringify({ data: '"
                              + customer_data[login_type]["Individualization"]
                              + "', expirationDate: '2020-04-07T12:45:22.862Z' }));")
        script = script + str("localStorage.setItem('go-customer-authenticationGatewayId',"
                              + " JSON.stringify({ data: '"
                              + customer_data[login_type]["AuthGWId"]
                              + "', expirationDate: '2020-04-07T12:45:22.862Z' }));")

        self.driver.execute_script(script)
        self.driver.refresh()
        logged_in = self.wait.function_to_return_value(
            func=self.is_logged_in,
            exp_value=True,
            timeout=40)
        return logged_in

    def get_login_data(self, login_type="b2b"):
        """
        :param login_type: "b2b" or "d2c"
        :type login_type: str
        """
        with open(file=Path("apps/hboce/hboce.json"), mode="r", encoding="utf-8") as f:
            hboce = json.load(f)
            login_data = {"mail": hboce["common"]["{lt}_login_email".format(lt=login_type)],
                          "pw": hboce["common"]["login_password"], "op": self.api.vip_operator().get("operatorName")}
            return login_data

    def login(self, email, password, operatorname, login_type="b2b"):
        login_button = {"locator": "signin", "type": "id"}
        login_button = self.wait.visible(element=login_button)
        if login_button:
            login_button.click()

        gateway_frame = {"locator": "gatewayFrame", "type": "id"}
        gateway_frame = self.get(gateway_frame)
        self.log("entering gateway frame")
        self.driver.switch_to.frame(gateway_frame)
        if login_type == "b2b":
            sign_in_provider = {
                "locator": "gw_operator_type_signin_b2b", "type": "id"}
            self.click(locator_or_element=sign_in_provider)
            provider_dropdown = {
                "locator": "//div[@title='operatorselector']", "type": "xpath"}
            self.click(locator_or_element=provider_dropdown)
            dropdown_options = {
                "locator": "//div[contains(@class,'dropdown-list-element')]", "type": "xpath"}
            provider = self.get_list_item(
                _list=dropdown_options, item=operatorname)
            self.click(provider)

        elif login_type == "d2c":
            sign_in_provider = {
                "locator": "gw_operator_type_signin_d2c", "type": "id"}
            self.click(locator_or_element=sign_in_provider)

        self.log("filling the email and password fields with valid credentials")
        email_input = {"locator": "1", "type": "id"}
        password_input = {"locator": "5", "type": "id"}

        self.input_text(locator_or_element=email_input, text=email, pause=0.05)
        self.input_text(locator_or_element=password_input,
                        text=password, pause=0.05)
        login_button = {"locator": "gw_login_06_sign_in", "type": "id"}
        self.click(locator_or_element=login_button)
        nick = self.wait.visible(element=self.nickname)
        if nick:
            self.log("successfully logged in as {}".format(nick.text))
            return True
        self.driver.switch_to.default_content()

    def get_application_language(self, timeout=10):
        """
        Gets the application language from the backend API.
        :return: the actual language of the application
        """
        now = time()
        while time() < now + timeout:
            try:
                response = self.driver.execute_script(
                    self.get_current_language)
                if response:
                    return response
            except Exception:
                sleep(1)
        return False

    def open_section(self, section):
        sections = dict(series=1, movies=2, kids=3, search=4)
        locator = "/html/body/nav/div/ul/li[{}]".format(sections.get(section)) \
            if section != "home" else "//span/a[@class='hbo-go']"
        return self.wait.clickable_and_click(element=dict(locator=locator, type="xpath"))

    def get_xpath_of_webelement(self, element):
        """
        Gets the xpath of a WebElement type object
        :type element: WebElement
        :return: the xpath of the given element
        """
        script_to_execute = """
            gPt=function(c){
                if(c.id!==''){
                    return'id("'+c.id+'")'
                } 
                if(c===document.body){
                    return c.tagName
                }
                var a=0;
                var e=c.parentNode.childNodes;
                for(var b=0;b<e.length;b++){
                    var d=e[b];
                    if(d===c){
                        return gPt(c.parentNode)+'/'+c.tagName+'['+(a+1)+']'
                    }
                    if(d.nodeType===1&&d.tagName===c.tagName){
                        a++
                    }
                }
            };
            return gPt(arguments[0]).toLowerCase();
        """
        xpath = self.driver.execute_script(script_to_execute, element)
        return xpath.replace("body", "/")

    def scroll_to_element_by_xpath(self, xpath):
        """
        Scrolls to the given element with JS.
        :type xpath: str
        :param xpath: xpath of the element you want to scroll to
        """
        str_xpath = str(xpath)
        script_to_run = "function getElementByXpath(path) {return document.evaluate(path, " \
                        "document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;} " \
                        "var element = getElementByXpath('" + str_xpath + "'); " \
                        "element.scrollIntoView();"
        self.driver.execute_script(script_to_run)

    def get_contents_from_shelf(self, shelf):
        """
        Returs a list of all the divs of the contents from the desired shelf.
        :param shelf: the shelf you want to contents from
        :type shelf: str
        :return: list of contents
        """
        loc = "//div[@class='shelf-content']"
        loc_type = "xpath"
        shelves = list(self.get_list(locator=loc, locator_type=loc_type))
        if not shelves:
            return False
        titles = []
        for sh in shelves:
            title = sh.text.split("\n")[0].lower()
            titles.append(title)
            if shelf.lower() in title:
                shelf_xpath = self.get_xpath_of_webelement(element=sh)
                self.scroll_to_element_by_xpath(xpath=shelf_xpath)
                shelfie = self.wait.visible(element=sh)
                if not shelfie:
                    return False
                contents = sh.find_elements_by_xpath(xpath=".//div[2]/div")
                if not contents:
                    return False
                del contents[-1]  # Last one is "show more" so it should be deleted
                return contents
        valid_shelf_names = ", ".join(map(str, titles))
        self.log("there is no {} shelf\nvalid shelf names: {}".format(shelf, valid_shelf_names))
        return False

    def get_shelf_titles(self):
        """
        Have to be on the movies page when calling this function
        :return: list of the shelf titles
        """
        shelf_titles = {
            "locator": "/html/body/main/div/div/header/div[@class='shelf-title']/h2", "type": "xpath"}
        titles = self.get_list(locator=shelf_titles)
        return [x.get_property("innerText").lower() for x in titles]

    def exit_iframe_and_wait_for_element_to_be_visible(self, element, timeout=20):
        """
        Sets the driver to the main frame and waits until quitting the iframe was successful and
        the desired element on the page is visible.
        :param element: the element you want to check if it is visible after quitting the iframe
        :type element: WebElement or dict
        :param timeout: timeout in seconds
        :type timeout: int
        :return: the element if it is visible, false if it is not
        """
        self.driver.switch_to.default_content()
        now = time()
        while time() < now + timeout:
            got_it = self.wait.visible(element=element, timeout=1)
            if isinstance(got_it, WebElement):
                return got_it
            else:
                sleep(1)
        return False

    def enter_iframe_and_wait_for_element_to_be_visible(self, element, timeout=20):
        """
        Sets the frame of the driver to gateway frame and waits until entering the frame was successful and
        the desired element on the page is visible.
        :param element: the element you want to check if it is visible after entering the iframe
        :type element: WebElement or dict
        :param timeout: timeout in seconds
        :type timeout: int
        :return: the element if it is visible, false if it is not
        """
        gateway = self.wait.get(element=self.gateway_frame)
        self.driver.switch_to.frame(gateway)
        now = time()
        got_it = None
        while time() < now + timeout:
            try:
                got_it = self.wait.visible(element=element, timeout=5)
            except Exception:
                pass
            if isinstance(got_it, WebElement):
                return got_it
            else:
                sleep(1)
        return False

    def input_text(self, locator_or_element, text, timeout=10,
                   locator_type="xpath", pause=0.25):
        """Write text on element (assumes it's an input field)."""
        element = self.get(locator=locator_or_element,
                           timeout=timeout, locator_type=locator_type)

        if cm.driver_name == "appium":
            element.send_keys(text)
        else:
            for c in text:
                element.send_keys(c)
                sleep(pause)
            if self.driver.capabilities["browserName"] == "firefox":
                element.send_keys("\ue007")
