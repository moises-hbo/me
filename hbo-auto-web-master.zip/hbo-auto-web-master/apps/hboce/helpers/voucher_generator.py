from pathlib import Path


class Voucher(object):
    def __init__(self):
        self.file_path = Path("apps/hboce/data/huvouchers.txt")
        self.vouchers = self.get_voucher()
        if self.vouchers:
            self.voucher = str(self.vouchers[0]).strip()
            self.delete_used_voucher()

    def get_voucher(self):
        this_is_it = self.file_path.exists()
        if this_is_it:
            with open(file=self.file_path, mode="r") as v_file:
                vouchers = v_file.readlines()
                v_file.close()
                return vouchers
        else:
            return False

    def delete_used_voucher(self):
        if self.file_path.exists():
            with open(file=self.file_path, mode="w") as v_file:
                del self.vouchers[0]
                v_file.writelines(self.vouchers)
                v_file.close()
