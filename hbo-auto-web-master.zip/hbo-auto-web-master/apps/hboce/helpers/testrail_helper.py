from tools.containers import TestRailResults


class TestRailHelper(object):
    # TODO - UNDER DEVELOPMENT
    @staticmethod
    def add(run_result):
        trr = TestRailResults
        tr_id = run_result.get("tr_id")
        tid = tr_id[1:] if tr_id.upper().startswith("C") else tr_id
        if not trr.results.get(tid):
            trr.results[tid] = list()
        trr.results[tid].append(
            {"name": run_result.get("name"),
             "status": run_result.get("status"),
             "duration": run_result.get("duration"),
             "msg": run_result.get("msg")})
