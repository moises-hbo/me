from os import chdir, listdir, getcwd
from helpers.sleeper import Sleeper as sleep
import smtplib
import sys
import pytest
from time import time
from pathlib import Path


"""
Script to run monitoring tests continuously.
Expects 6 arguments when called: runtime (in seconds), env, app, country, browser, category
Example:
monitory_recently_added.py 28800 prod hboce hu chrome monitor
"""


class Monitor(object):
    def __init__(self, env, app, country, browser, category, r=0):
        self.result = r
        self.suite = str(dict(
            driver="apps/{}/drivers/{}.json".format(app, browser),
            country=country,
            platform="COMP",
            driver_profile=app,
            url="apps/{app}/urls.json:{env}_{app}_{country}".format(
             app=app, env=env, country=country),
            app=app,
            testrail_project_id="22",
            testrail_suite_id="956",
            testrail_run_name="Monitoring Playback of Recently Added"))
        self.output = None
        self.category = category
        self.navigate_to_project_dir()

    def __iter__(self):
        return self

    def __next__(self):
        return self.next()

    def next(self):
        if self.result == 0:
            args = ["--suite={}".format(self.suite), "--category={}".format(self.category),
                    "--testrail", "--log-level=error", "apps/hboce/tests"]
            return pytest.main(args)
        else:
            return self.result

    @staticmethod
    def navigate_to_project_dir():
        list_dir = listdir(".")
        while "pytest.ini" not in list_dir:
            chdir("..")
            list_dir = listdir(".")


def get_result():
    list_of_files = listdir("results")
    if "result.xml" not in list_of_files:
        return "Failed to find results.\nPath of working dir: {}".format(getcwd())
    path_to_result = Path("results/result.xml")
    f = open(path_to_result, "r")
    return f.read()


def send_mail():
    gmail_user = "hbo.test.automation"
    gmail_password = "hbohbo123"

    sent_from = gmail_user
    to = "andras.szasz@hbo.com"
    subject = "Subject: Failed test of Monitoring Recently Added\n\n"
    body = "Automated Test of Monitoring Playback of Recently Added contents has failed.\n\n"
    xml = get_result()
    email_text = "{}{}{}".format(subject, body, xml)

    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.ehlo()
    server.login(gmail_user, gmail_password)
    server.sendmail(sent_from, to, email_text)
    server.close()


monitor = Monitor(env=sys.argv[2], app=sys.argv[3], country=sys.argv[4], browser=sys.argv[5], category=sys.argv[6])
result = monitor.next()
start = time()
runtime = int(sys.argv[1])  # seconds
while time() < start + runtime:
    result = monitor.next()
    if result != 0:
        sleep(60)
        send_mail()
