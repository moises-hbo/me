import pytest

from apps.hboce.pages.settings import SettingsPage


@pytest.mark.id("C122834")
@pytest.mark.category("settings")
def test_change_language(driver):
    """
    Checks if the user can change language through the settings.
    """
    # Setup
    page = SettingsPage(driver, login_type="b2b")
    if page.country_id.lower() != "hu":
        pytest.skip("currently this test is only for the hungarian app")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to settings page
    settings_setup = page.settings_setup
    assert not isinstance(settings_setup, page.Error), settings_setup.message

    # Check language change
    result = page.set_language()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117480")
@pytest.mark.category("setting")
def test_settings_appearance(driver):
    """
    Checks the appearance of the settings page.
    """
    # Setup
    page = SettingsPage(driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to settings page
    settings_setup = page.settings_setup
    assert not isinstance(settings_setup, page.Error), settings_setup.message

    # Check menu items
    result = page.check_menu_items_in_settings()
    assert not isinstance(result, page.Error), result.message

    # Check appearance
    result = page.check_appearance()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "settings")
@pytest.mark.id("C117481")
def test_settings_navigation(driver):
    """
    - hover over nickname
    - open settings
    - navigate to each submenu one by one and check if the header is visible
    """
    # Setup
    page = SettingsPage(driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to settings page
    settings_setup = page.settings_setup
    assert not isinstance(settings_setup, page.Error), settings_setup.message

    # Check navigation in settings menu
    result = page.check_navigation_in_settings_menu()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117484")
@pytest.mark.category("setting")
def test_settings_remove_device(driver):
    """
    Checks if the user can remove a device through settings.
    """
    # Setup
    page = SettingsPage(driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to settings page
    settings_setup = page.settings_setup
    assert not isinstance(settings_setup, page.Error), settings_setup.message

    # Check device deletion
    result = page.delete_device(all_of_them=False)
    assert not isinstance(result, page.Error), result.message
