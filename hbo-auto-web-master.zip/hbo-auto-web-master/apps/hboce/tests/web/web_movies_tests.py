import pytest

from apps.hboce.pages.movies import MoviesPage


@pytest.mark.id("C117504")
@pytest.mark.category("movies")
def test_movies_shelf_appearance(driver):
    """
    Checks the appearance of the shelf titles, the background and the text color.
    """
    # Setup
    page = MoviesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to movies section
    movies = page.movies
    assert not isinstance(movies, page.Error), setup.message

    # Check shelf title appearance
    result = page.check_shelf_title_appearance()
    assert not isinstance(result, page.Error), result.message

    # Check font color
    result = page.check_css_property(css_property="color")
    assert not isinstance(result, page.Error), result.message

    # Check background color
    result = page.check_css_property(css_property="background_color")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "movies")
@pytest.mark.id("C117507")
def test_movies_recently_added_shelf(driver):
    """
    Checks if the recently added shelf of the movies page have only "premiere" of "returning" contents.
    """
    # Setup
    page = MoviesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to movies section
    movies = page.movies
    assert not isinstance(movies, page.Error), setup.message

    # Check if only premier contents are available in premier shelf
    result = page.check_items_of_premier_shelf()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117509")
@pytest.mark.category("movies")
def test_movies_imdb_highest(driver):
    """
    Checks if the contents of the critically acclaimed page of the movies has only contents
    with IMDB rating at least 7.
    """
    if driver.capabilities["browserName"] == "firefox":
        pytest.skip("This test is not yet compatible with firefox browser.")
    # Setup
    page = MoviesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to movies section
    movies = page.movies
    assert not isinstance(movies, page.Error), setup.message

    # Check if contents in "IMDb Top" section have a rating at least 7
    result = page.check_items_of_imdb_highest()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117510")
@pytest.mark.category("movies")
def test_movies_genre_category(driver):
    """
    Checks if under the selected category, only movies with the valid genres are showed.
    """
    if driver.capabilities["browserName"] == "firefox":
        pytest.skip("This test is not yet compatible with firefox browser.")
    # Setup
    page = MoviesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check if movies in a category have the right genre
    result = page.check_if_movies_in_a_category_have_the_right_genre()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117508")
@pytest.mark.category("movies")
def test_movies_category_buttons_functionality(driver):
    """
    Checks the category buttons functionality.
    Clicking on a category button should open a page with contents from that category.
    """
    if driver.capabilities["browserName"] == "firefox":
        pytest.skip("This test is not yet compatible with firefox browser.")
    # Setup
    page = MoviesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to movies section
    movies = page.movies
    assert not isinstance(movies, page.Error), setup.message

    # Check category buttons functionality
    result = page.check_category_buttons_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "movies")
@pytest.mark.id("C1277448")
def test_movies_coming_soon_category(driver):
    """
    Checks if under coming soon page, only coming soon contents are displayed.
    """
    if driver.capabilities["browserName"] == "firefox":
        pytest.skip("This test is not yet compatible with firefox browser.")
    # Setup
    page = MoviesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to movies section
    movies = page.movies
    assert not isinstance(movies, page.Error), setup.message

    # Check if there is only premier contents under "coming soon" section
    result = page.check_coming_soon_stuff()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.skip(reason="results from api call are from vcms so they are different")
@pytest.mark.id("C1575654")
@pytest.mark.category("movies")
def test_movies_metadata(driver):
    """
    Check if meta-data of the content is the same from the ui and from the api call.
    """
    # Setup
    page = MoviesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    movie = page.movie_name
    meta_ui = page.get_metadata_of_content(content=movie)
    meta_api = page.get_content_data_from_api(content=movie)

    # Check differences between meta data from UI and from API
    result = page.compare_meta(ui=meta_ui, api=meta_api)
    assert not isinstance(result, page.Error), result.message
