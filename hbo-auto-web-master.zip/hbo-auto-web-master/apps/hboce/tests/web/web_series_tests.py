import pytest

from apps.hboce.pages.series import SeriesPage


@pytest.mark.id("C117521")
@pytest.mark.category("series")
def test_series_shelf_appearance(driver):
    """
    Checks the appearance of the shelves on the series page, background color, and text color.
    """
    # Setup
    page = SeriesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to series page
    navigate_to_series = page.series
    assert not isinstance(navigate_to_series, page.Error), navigate_to_series.message

    # Check page appearance
    result = page.check_css_property(css_property="color")
    assert not isinstance(result, page.Error), result.message
    result = page.check_css_property(css_property="background_color")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "series")
@pytest.mark.id("C117524")
def test_series_recently_added_category(driver):
    """
    Checks if only recently added contents are showed on the recently added page.
    """
    # Setup
    page = SeriesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check if recently added shelf has only premiere contents
    result = page.check_ribbon(shelf="recently added")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117526")
@pytest.mark.category("series")
def test_series_imdb_highest(driver):
    """
    Checks if only contents with IMDB rating above 7 are showed on the critically acclaimed series page.
    """
    # Setup
    page = SeriesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to series page
    navigate_to_series = page.series
    assert not isinstance(navigate_to_series, page.Error), navigate_to_series.message

    # Check if IMDb Highest page has contents with rating at least 7
    result = page.check_items_of_imdb_highest()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117527")
@pytest.mark.category("series")
def test_series_genre_category(driver):
    """
    Checks if under the selected category, only series with the valid genres are showed.
    """
    # Setup
    page = SeriesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to series page
    navigate_to_series = page.series
    assert not isinstance(navigate_to_series, page.Error), navigate_to_series.message

    # Check if series in a category have the right genre
    result = page.check_if_series_in_a_category_have_the_right_genre()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117525")
@pytest.mark.category("series")
def test_category_buttons_functionality(driver):
    """
    Checks the functionality of the category buttons.
    If clicked to a category button, a page should appear with contents only from that category.
    """
    # Setup
    page = SeriesPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to series page
    navigate_to_series = page.series
    assert not isinstance(navigate_to_series, page.Error), navigate_to_series.message

    # Check functionality of category buttons
    result = page.check_category_buttons_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "series")
@pytest.mark.id("C1340211")
def test_series_coming_soon_category(driver):
    """
    Checks if under coming soon page, only coming soon contents are displayed.
    """
    # Setup
    page = SeriesPage(driver=driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check if coming soon page has only coming-soon contents
    result = page.check_ribbon(shelf="coming soon")
    assert not isinstance(result, page.Error), result.message
