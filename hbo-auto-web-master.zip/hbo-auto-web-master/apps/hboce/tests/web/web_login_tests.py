import pytest

from apps.hboce.pages.login import LoginPage


@pytest.mark.category("smoke", "auth")
@pytest.mark.id("C117476")
def test_b2b_login(driver):
    """
    Does a successful login with a B2B provider, with valid data.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="b2b")

    # Check login with b2b
    result = page.log_in()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1524457")
@pytest.mark.category("auth")
def test_b2b_login_with_deficient_form(driver):
    """
    Tries to log in with deficient form (not all input fields are filled).
    First it leaves all the input fields blank, clicks login button, checks if the error is visible on the page,
    then fills the first input field with valid data, click login button, and check the error again.
    At the end, all the input fields are filled and login is successful.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="b2b")

    # Check login with deficient form with b2b
    result = page.log_in_with_deficient_form()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1547339")
@pytest.mark.category("auth")
def test_b2b_login_forgot_password(driver):
    """
    Checks if the "forgot password" button on the login page is visible and is working correctly.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="b2b")

    # Check "forgot password" button functionality with b2b
    result = page.check_forgot_password_button_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1547340")
@pytest.mark.category("auth")
def test_b2b_dont_have_an_account_yet_button_functionality(driver):
    """
    Checks if the "don't have an account yet" button on the login page is visible and is working correctly.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="b2b")

    # Check "don't have an account yet" button functionality with b2b
    result = page.check_dont_have_an_account_yet_button_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117475")
@pytest.mark.category("auth")
def test_d2c_login(driver):
    """
    Does a successful D2C login with valid data.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="d2c")

    # Check login with d2c
    result = page.log_in()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1546376")
@pytest.mark.category("auth")
def test_d2c_login_with_deficient_form(driver):
    """
    Tries to log in with deficient form (not all input fields are filled).
    First it leaves all the input fields blank, clicks login button, checks if the error is visible on the page,
    then fills the first input field with valid data, click login button, and check the error again.
    At the end, all the input fields are filled and login is successful.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="d2c")

    # Check login with deficient form with d2c
    result = page.log_in_with_deficient_form()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1547341")
@pytest.mark.category("auth")
def test_d2c_login_forgot_password(driver):
    """
    Checks if the "forgot password" button on the login page is visible and is working correctly.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="d2c")

    # Check "forgot password" button functionality with d2c
    result = page.check_forgot_password_button_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1547342")
@pytest.mark.category("auth")
def test_d2c_dont_have_an_account_yet_button_functionality(driver):
    """
    Checks if the "don't have an account yet" button on the login page is visible and is working correctly.
    """
    # Setup
    page = LoginPage(driver=driver, login_type="d2c")

    # Check "don't have an account yet" button functionality with d2c
    result = page.check_dont_have_an_account_yet_button_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke")
@pytest.mark.id("C117474")
@pytest.mark.category("auth")
def test_logout(driver):
    """
    Checks if the user can log out through the settings.
    """
    # Setup
    page = LoginPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check logout through settings
    result = page.log_out_through_settings()
    assert not isinstance(result, page.Error), result.message
