import pytest

from apps.hboce.pages.auth import AuthPage


"""
AUTHENTICATION / COMMON
"""


@pytest.mark.category("appearance", "authentication", "gateway", "modal")
@pytest.mark.id("C3930024")
def test_appearance_of_gateway_close_button(driver):
    # Setup
    page = AuthPage(driver=driver)

    # Check appearance of gateway close button
    result = page.check_ap_of_gw_close_btn()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("functionality", "authentication", "gateway", "modal")
@pytest.mark.id("C3311359")
def test_functionality_of_gateway_close_button(driver):
    # Setup
    page = AuthPage(driver=driver)

    # Check functionality of gateway close button
    result = page.check_fu_of_gw_close_btn()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("appearance", "authentication", "logout", "cancel")
@pytest.mark.id("C3930025")
def test_appearance_of_logout_cancel_button(driver):
    # Setup
    page = AuthPage(driver=driver)
    login = page.setup
    assert not isinstance(login, page.Error), login.message

    # Check appearance of cancel button
    result = page.check_ap_of_logout_cancel_btn()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("appearance", "authentication", "logout")
@pytest.mark.id("C3943702")
def test_appearance_of_logout_logout_button(driver):
    # Setup
    page = AuthPage(driver=driver)
    login = page.setup
    assert not isinstance(login, page.Error), login.message

    # Check appearance of logout button
    result = page.check_ap_of_logout_logout_btn()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("functionality", "authentication", "logout", "cancel")
@pytest.mark.id("C3704327")
def test_functionality_of_logout_cancel_button(driver):
    # Setup
    page = AuthPage(driver=driver)
    login = page.setup
    assert not isinstance(login, page.Error), login.message

    # Check functionality of cancel button
    result = page.check_fu_of_logout_cancel_btn()
    assert not isinstance(result, page.Error), result.message


"""
AUTHENTICATION / D2C
"""


@pytest.mark.category("appearance", "authentication", "login", "d2c")
@pytest.mark.id("C3939216")
def test_appearance_of_d2c_login_button(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="d2c")

    # Check appearance of D2C login button
    result = page.check_ap_of_login_login_btn()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("process", "authentication", "login", "d2c")
@pytest.mark.id("C3822958")
def test_process_of_d2c_login(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="d2c")

    # Check process of D2C login
    login_result = page.check_pr_of_login()

    # Testing the functionality of the login button in modal
    tr_id = "C3311373"  # TestRail ID

    result = page.check_fu_of_login_btn_in_modal(tr_id=tr_id)
    page.tr_helper.add(result)  # Adding the result to the TestRail report

    # Finally checking if the login was successful
    assert not isinstance(login_result, page.Error), login_result.message


@pytest.mark.category("process", "authentication", "login", "d2c", "url", "activation")
@pytest.mark.id("C4924336")
def test_process_of_login_activation_url(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="d2c")

    # Check process of D2C login with activation in URL
    result = page.check_pr_of_login(url="activate")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("process", "authentication", "login", "d2c", "url", "appletv", "activation")
@pytest.mark.id("C4925420")
def test_process_of_login_appletv_activation_url(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="d2c")

    # Check process of D2C login with Apple-TV activation in URL
    result = page.check_pr_of_login(url="appletv-activate")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("process", "authentication", "login", "d2c", "url", "subscription")
@pytest.mark.id("C4924338")
def test_process_of_login_subscription_management_url(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="d2c")

    # Check process of D2C login with subscription management in URL
    result = page.check_pr_of_login(url="subscription-management")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("process", "authentication", "logout", "d2c")
@pytest.mark.id("C3823989")
def test_process_of_logout(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="d2c")
    login = page.setup
    assert not isinstance(login, page.Error), login.message

    # Check process of logout
    logout_result = page.check_pr_of_logout()

    # Testing the functionality of the "logout logout button"
    tr_id = "C3704326"  # TestRail ID

    result = page.check_fu_of_logout_logout_btn(tr_id=tr_id)
    page.tr_helper.add(result)  # Adding the result to the TestRail report

    # Finally checking if the logout was successful
    assert not isinstance(logout_result, page.Error), logout_result.message


@pytest.mark.category("process", "authentication", "logout", "d2c", "settings")
@pytest.mark.id("C3824820")
def test_process_of_logout_through_settings(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="d2c")
    login = page.setup
    assert not isinstance(login, page.Error), login.message

    # Check process of logout through settings
    logout_result = page.check_pr_of_logout_through_settings()

    # Testing the functionality of the logout button in settings
    tr_id = "C3704662"  # TestRail ID

    result = page.check_fu_of_logout_btn_settings(tr_id=tr_id)
    page.tr_helper.add(result)  # Adding the result to the TestRail report

    # Finally checking if the logout through settings was successful
    assert not isinstance(logout_result, page.Error), logout_result.message


"""
AUTHENTICATION / B2B
"""


@pytest.mark.category("appearance", "authentication", "login", "b2b")
@pytest.mark.id("C3945053")
def test_appearance_of_b2b_login_button(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="b2b")

    # Check appearance of B2B login button
    result = page.check_ap_of_login_login_btn()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("process", "authentication", "login", "b2b")
@pytest.mark.id("C3311375")
def test_process_of_b2b_login(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="b2b")

    # Check process of B2B login
    login_result = page.check_pr_of_login()

    # Testing the functionality of the login button in modal
    tr_id = "C3886996"  # TestRail ID

    result = page.check_fu_of_login_btn_in_modal(tr_id=tr_id)
    page.tr_helper.add(result)  # Adding the result to the TestRail report

    # Finally checking if the login was successful
    assert not isinstance(login_result, page.Error), login_result.message


@pytest.mark.category("process", "authentication", "logout", "b2b")
@pytest.mark.id("C3825716")
def test_process_of_logout(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="b2b")
    login = page.setup
    assert not isinstance(login, page.Error), login.message

    # Check process of logout
    logout_result = page.check_pr_of_logout()

    # Testing the functionality of the "logout logout button"
    tr_id = "C3825715"  # TestRail ID

    result = page.check_fu_of_logout_logout_btn(tr_id=tr_id)
    page.tr_helper.add(result)  # Adding the result to the TestRail report

    # Finally checking if the logout was successful
    assert not isinstance(logout_result, page.Error), logout_result.message


@pytest.mark.category("process", "authentication", "logout", "b2b", "settings")
@pytest.mark.id("C3825718")
def test_process_of_logout_through_settings(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="b2b")
    login = page.setup
    assert not isinstance(login, page.Error), login.message

    # Check process of logout through settings
    logout_result = page.check_pr_of_logout_through_settings()

    # Testing the functionality of the logout button in settings
    tr_id = "C3825717"  # TestRail ID

    result = page.check_fu_of_logout_btn_settings(tr_id=tr_id)
    page.tr_helper.add(result)  # Adding the result to the TestRail report

    # Finally checking if the logout through settings was successful
    assert not isinstance(logout_result, page.Error), logout_result.message


@pytest.mark.category("process", "authentication", "registration", "b2b", "smoke")
@pytest.mark.id("C3311374")
def test_process_of_registration_b2b_start_browsing_button(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="b2b")

    # Check process of registration
    result = page.check_pr_of_registration(last_button="start_browsing")

    # Testing the functionality of the "finish registration" button
    tr_id = "C4923773"  # TestRail ID

    fu_of_finish_reg_btn = result.get("start_browsing_btn")
    sub_result = dict(
        tr_id=tr_id, name="test_functionality_of_finish_registration_button", status="passed",
        duration="0", msg="everything went good") if fu_of_finish_reg_btn else dict(
        tr_id=tr_id, name="test_functionality_of_finish_registration_button", status="failed",
        duration="0", msg="successful registration page is not visible")
    page.tr_helper.add(sub_result)  # Adding the result to the TestRail report

    # Testing the appearance of the "start browsing" button
    # I think this is basically a duplicate of the previous one, but we have this as a separated one...
    tr_id = "C3943869"  # TestRail ID

    ap_of_start_br_btn = result.get("start_browsing_btn")
    sub_result = dict(
        tr_id=tr_id, name="test_appearance_of_start_browsing_button", status="passed",
        duration="0", msg="everything went good") if ap_of_start_br_btn else dict(
        tr_id=tr_id, name="test_appearance_of_start_browsing_button", status="failed",
        duration="0", msg="the start browsing button is not visible")
    page.tr_helper.add(sub_result)  # Adding the result to the TestRail report

    # Testing the functionality of the "start browsing" button
    tr_id = "C3885381"  # TestRail ID

    sub_result = page.check_fu_of_start_browsing_btn(tr_id=tr_id)
    page.tr_helper.add(sub_result)  # Adding the result to the TestRail report

    # Finally checking if the registration was successful
    final_result = result.get("result")
    assert not isinstance(final_result, page.Error), final_result.message


@pytest.mark.category("process", "authentication", "registration", "b2b")
@pytest.mark.id("C7485408")
def test_process_of_registration_b2b_close_button(driver):
    # Setup
    page = AuthPage(driver=driver, login_type="b2b")

    # Check process of registration
    result = page.check_pr_of_registration(last_button="close").get("result")
    assert not isinstance(result, page.Error), result.message
