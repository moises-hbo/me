import pytest

from apps.hboce.pages.menu import MenuPage


@pytest.mark.category("smoke", "menu")
@pytest.mark.id("C117490")
def test_logged_out_appearance(driver):
    """
    - check visibility of menu items as an unauthenticated user
    - check color and background
    """
    # Setup
    page = MenuPage(driver)
    result = page.check_menu_items(logged_in=False)
    assert not isinstance(result, page.Error), result.message

    # Check appearance
    result = page.check_appearance()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "menu")
@pytest.mark.id("C967788")
def test_logged_in_appearance(driver):
    """
    - check visibility of menu items as an authenticated user
    - check color and background color
    """
    # Setup
    page = MenuPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check menu items
    result = page.check_menu_items(logged_in=True)
    assert not isinstance(result, page.Error), result.message

    # Check appearance
    result = page.check_appearance()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117491")
@pytest.mark.category("menu")
def test_menu_functionality(driver):
    """
    Checks the functionality of the menu buttons of the main page.
    When the user clicks on a button, the correct page should be opened.
    """
    # Setup
    page = MenuPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check menu items functionality
    result = page.click_on_menu_items()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117492")
@pytest.mark.category("menu")
def test_menu_kid_mode_appearance(driver):
    """
    Checks the appearance of the kids page, background color and text color.
    """
    # Setup
    page = MenuPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check kid mode appearance
    result = page.check_kid_mode_appearance()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1014985")
@pytest.mark.category("menu")
def test_footer_menu_visibility(driver):
    """
    Checks the visibility of the footer menu buttons.
    """
    # Setup
    page = MenuPage(driver)

    # Check footer menu appearance
    result = page.check_menu_appearance(menu=page.footer_menu_items)
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1021992")
@pytest.mark.category("menu")
def test_social_menu_appearance(driver):
    """
    Checks the appearance of the social menu buttons.
    """
    # Setup
    page = MenuPage(driver)

    # Check social menu appearance
    result = page.check_menu_appearance(menu=page.social_menu_items)
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1021993")
@pytest.mark.category("menu")
def test_social_menu_functionality(driver):
    """
    Checks the functionality of the social menu buttons.
    When the user clicks on a button of the social menu, the correct page should be opened. (Facebook, Youtube, etc.)
    """
    # Setup
    page = MenuPage(driver)

    # Check social menu functionality
    result = page.check_menu_functionality(page.social_menu_items)
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("menu")
def test_unauth_lang_change(driver):
    # Setup
    page = MenuPage(driver=driver)

    # Check footer language selector
    result = page.check_footer_language_selector()
    assert not isinstance(result, page.Error), result.message
