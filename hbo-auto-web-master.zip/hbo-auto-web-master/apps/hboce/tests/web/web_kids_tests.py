import pytest

from apps.hboce.pages.kids import Kids


@pytest.mark.id("C117556")
@pytest.mark.category("kids")
def test_kids_appearance(driver):
    """
    Checks appearance if kids page.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check appearance
    result = page.check_appearance()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117557")
@pytest.mark.category("kids")
def test_kids_onboarding(driver):
    """
    Checks if kids onboarding screen appears or not.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check if onboarding screen is visible
    result = page.check_kids_onboarding_screen()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117557")
@pytest.mark.category("kids")
def test_kids_carousel_switching(driver):
    """
    Checks if switching between carousel items is possible or not.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check switching to next carousel
    result = page.check_carousel_switching(direction="next")
    assert not isinstance(result, page.Error), result.message

    # Check switching to previous carousel
    result = page.check_carousel_switching(direction="prev")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "kids")
@pytest.mark.id("C1368572")
def test_kids_play_from_carousel(driver):
    """
    Tries to play content from carousel.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Open content from carousel
    result = page.play_from_carousel()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1369139")
@pytest.mark.category("kids")
def test_kids_continue_watching(driver):
    """
    Plays first content from continue watching shelf.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check continue watching
    result = page.player.check_continue_watching(section="kids")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1541177")
@pytest.mark.category("kids")
def test_is_kids_or_normal_plus_kids_category(driver):
    """
    Gets random content from kids page and checks if it is a kids category one or not.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Checking content category
    result = page.is_kids_related_content()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1442021")
@pytest.mark.category("kids")
def test_kids_next_episode(driver):
    """
    Check switching to next episode while playing kids series.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check switching to next episode
    result = page.check_episode_change(next_or_prev="next")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1442022")
@pytest.mark.category("kids")
def test_kids_previous_episode(driver):
    """
    Check switching to previous episode while playing kids series.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check switching to previous episode
    result = page.check_episode_change(next_or_prev="prev")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117564")
@pytest.mark.category("kids")
def test_kids_favorite_category(driver):
    """
    Checks if content is visible on favorite shelf after it is added as a favorite.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check favorites
    result = page.check_favorite_category()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1632456")
@pytest.mark.category("kids")
def test_kids_add_and_remove_favorite(driver):
    """
    Checks if add to favorite and remove from favorite functions are working correctly.
    If the content is added, it tries to remove it. If the content is not added, it tried to add it.
    """
    # Setup
    page = Kids(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to kids section
    kids = page.kids
    assert not isinstance(kids, page.Error), kids.message

    # Check add/remove favorite
    result = page.player.check_favorite(keyword=page.movie_name)
    assert not isinstance(result, page.Error), result.message
