import pytest

from apps.hboce.pages.registration import RegistrationPage


@pytest.mark.id("C120009")
@pytest.mark.category("auth")
def test_b2b_registration(driver):
    """
    Goes through the registration process with valid data, and finishes registration successfully.
    """
    page = RegistrationPage(driver=driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    result = page.registration()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1573199")
@pytest.mark.category("auth")
def test_b2b_registration_terms_and_conditions_button_functionality(driver):
    """
    Checks that the "terms and conditions" button at the registration process is visible, and is working correctly.
    """
    page = RegistrationPage(driver=driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    result = page.check_terms_and_conditions_button_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1573270")
@pytest.mark.category("auth")
def test_b2b_registration_privacy_policy_button_functionality(driver):
    """
    Checks that the "privacy policy" button at the registration process is visible, and is working correctly.
    """
    page = RegistrationPage(driver=driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    result = page.check_privacy_policy_button_functionality()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1050305")
@pytest.mark.category("auth")
def test_negative_b2b_registration(driver):
    """
    It goes through the registration form.
    First leaves all the input fields blank, and clicks on the finish button.
    Checks if the error appears on the page.
    Then it fills the first input field, clicks on the finish button, checks if the error appears.
    And so on, until all the fields are filled and the registration is finished successfully.

    If error message is not visible through the test,
    or the registration is not successful at the end it throws assertion error.
    """
    page = RegistrationPage(driver=driver, login_type="b2b")
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    result = page.registration(negative=True)
    assert not isinstance(result, page.Error), result.message
