import pytest

from apps.hboce.pages.search import SearchPage


@pytest.mark.category("smoke", "search")
@pytest.mark.id("C122835")
def test_open_search_result(driver):
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Search for a content, click first, and check title
    result = page.search_for_a_content_click_first_and_check_title()
    assert not isinstance(result, page.Error), result.message


# @pytest.mark.xfail(reason="results from api call are from vcms so they are different")
@pytest.mark.id("C932028")
@pytest.mark.category("search")
def test_compare_search_results(driver):
    """
    Testing if the search results displayed on the UI is the same that we get from the API call
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Search for a content and validate search results with API
    result = page.validate_search_results_with_api()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("smoke", "search")
@pytest.mark.id("C932029")
def test_too_short_searchtext(driver):
    """
    Testing what happens if searchtext is too short (less than 3 character)
    Expectation: Search notification div should be visible with the hint
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Type too short text to search input field and check if alert message appears
    result = page.check_short_searchtext()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C932030")
@pytest.mark.xfail(reason="returns undefined result, should return 0 result, or something like that")
@pytest.mark.category("search")
def test_too_many_chars_in_searchtext(driver):
    """
    Testing what happens if searchtext has more than 220 characters
    Expectation: should return 0 results, or a hint for typing too many characters
    Currently it returns "undefined result", so I expect it to fail, but should be fixed in the future.
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Type more then 220 chars in search input field and checks if there is not results
    result = page.check_result_for_specific_searchtext(
        search_text=page.looong_text, expected_element_to_be_visible=page.noresult)
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C932031")
@pytest.mark.xfail(reason="some cases search returns a lot of results instead of 0")
@pytest.mark.category("search")
def test_invalid_chars_in_searchtext(driver):
    """
    Testing what happens if searchtext has invalid characters
    Expectation: should return 0 results (or a hint for typing invalid characters)
    Currently it returns a lot of results, so I expect it to fail, but should be fixed in the future.
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Type invalid chars to search input field and check if the expected alert message appears
    result = page.check_result_for_specific_searchtext(
        search_text=page.invalid_char_search_text, expected_element_to_be_visible=page.noresult)
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C932032")
@pytest.mark.category("search")
def test_search_result_count(driver):
    """
    Testing if the number of result on UI equals with the number of result from the API call
    Expectation: should be equal
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Search for a content, and check if result count on UI is the same as the one from the API call
    result = page.check_search_result_count()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C932033")
@pytest.mark.category("search")
def test_search_input_is_cleared(driver):
    """
    Testing if the search input field gets cleared after clicking the search-clear button
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Search for a content, wait for results to appear,
    # then clicks on clear button and checks if input is cleared
    result = page.check_search_input_is_cleared()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117486")
@pytest.mark.category("search")
def test_search_navigation(driver):
    """
    As a User, you can search through the result only after typing at least 3 letters in.
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Type less then 3 chars in search input field, waits for the alert message to be visible,
    # then types a valid keyword to search input and checks if there is any visible result
    result = page.check_search_navigation()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117487")
@pytest.mark.category("search")
def test_search_appearance(driver):
    """
    Checks the background and the text color of the search page.
    """
    # Setup
    page = SearchPage(driver=driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Navigate to search section
    navigate_to_search = page.search
    assert not isinstance(navigate_to_search, page.Error), navigate_to_search.message

    # Check appearance of search page
    result = page.check_search_appearance()
    assert not isinstance(result, page.Error), result.message
