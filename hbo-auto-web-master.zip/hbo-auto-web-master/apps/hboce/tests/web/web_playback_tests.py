import pytest

from apps.hboce.pages.player import PlayerPage


@pytest.mark.id("C117546")
@pytest.mark.category("smoke", "player")
def test_start_playback(driver):
    """
    - opens movies page
    - selects random shelf
    - selects random content
    - start playing it
    - plays for 5 seconds
    """
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Start playing a content
    result = page.start_playing_content()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117547")
@pytest.mark.category("smoke", "player")
def test_pause_and_play(driver):
    """
    - opens movies page
    - selects random shelf
    - selects random content
    - start playing it
    - plays for 5 seconds
    - pause it and get elapsed time
    - plays for another 5 seconds and get elapsed time again
    - checks if the difference between the two elapsed time is more than 4
    """
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Start playing a content
    result = page.start_playing_content()
    assert not isinstance(result, page.Error), result.message

    # Check pause and play
    result = page.check_playback()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117551")
@pytest.mark.category("smoke", "player")
def test_scrubbing(driver):
    """
    - opens movies page
    - selects random shelf
    - selects random content
    - start playing it
    - plays for 5 seconds
    - scrub forward 100 and get elapsed time
    - scrub backwards 50 and get elapsed time again
    - checks if the first elapsed time is greater than the second one
    """
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Start playing a content
    result = page.start_playing_content()
    assert not isinstance(result, page.Error), result.message

    # Check scrubbing
    result = page.check_scrubbing()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117548")
@pytest.mark.category("player")
def test_play_previous_episode(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Open a content and check switching to previous episode
    result = page.check_switch_episode(next_or_prev="prev")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C967236")
@pytest.mark.category("player")
def test_play_next_episode(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Open a content and check switching to next episode
    result = page.check_switch_episode(next_or_prev="next")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1541176")
@pytest.mark.category("player")
def test_play_from_continue_watching(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check playing from continue watching shelf
    result = page.check_continue_watching()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117551")
@pytest.mark.category("player")
def test_open_content_and_check_scrubbing(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Open a content and check srubbing
    result = page.open_content_and_check_scrubbing()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117553")
@pytest.mark.category("player")
def test_audio_selection(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Open a content and check if audio can be changed
    result = page.check_audio_or_subtitle_selection(aud_or_sub="aud")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C117554")
@pytest.mark.category("player")
def test_subtitle_selection(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Open a content and check if subtitle can be changed
    result = page.check_audio_or_subtitle_selection(aud_or_sub="sub")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1071138")
@pytest.mark.category("player")
def test_disable_subtitles(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Open a content and check if subtitle can be disabled
    result = page.check_audio_or_subtitle_selection(aud_or_sub="sub", select="off")
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1632458")
@pytest.mark.category("player")
def test_watchlist_visibility_and_functionality(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check watchlist visibility and functionality
    result = page.check_watchlist()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.id("C1632459")
@pytest.mark.category("player")
def test_add_and_remove_favorites(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check adding/removing favorite
    result = page.check_favorite()
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("monitor", "player")
@pytest.mark.id("C2778983")
def test_playback_of_movies_on_recently_added_shelf(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Play contents from Recently Added shelf of Movies page
    result = page.play_contents_from_shelf(section="movies", shelf="recently added", strict=True)
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("monitor", "player")
@pytest.mark.id("C2778982")
def test_playback_of_series_on_recently_added_shelf(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Play contents from Recently Added shelf of Series page
    result = page.play_contents_from_shelf(section="series", shelf="recently added", strict=True)
    assert not isinstance(result, page.Error), result.message


@pytest.mark.category("player")
def test_chainplay(driver):
    # Setup
    page = PlayerPage(driver)
    setup = page.setup
    assert not isinstance(setup, page.Error), setup.message

    # Check chain-play
    result = page.check_chainplay()
    assert not isinstance(result, page.Error), result.message
