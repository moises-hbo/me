import pytest

from apps.hboce.pages.mobile_web.home import Home


@pytest.mark.category("series")
def test_gateway_opening(driver):
    """
    Checks if the gateways opens after a click on the registration button.
    """
    # Setup
    page = Home(driver=driver)
    d = page.driver
    # TODO write function for validating gateway opening


@pytest.mark.category("url")
def test_urls_auth(driver):
    """
    Checking the if the urls are pointing to the right page.
    """
    page = Home(driver=driver)

    # Setup
    assert page.setup

    # Check URLs
    assert page.check_urls()


@pytest.mark.category("url")
def test_urls_unauth(driver):
    """
    Checking the if the urls are pointing to the right page.
    """
    page = Home(driver=driver)

    # Check URLs
    assert page.check_urls()
