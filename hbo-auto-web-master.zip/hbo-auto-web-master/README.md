## About
Minutiae is a testing framework for HBO Nordic web app and mobile devices.
Minutiae comes from the word minutiae, which is a nice word. (It's no longer named Minutiae btw)

## Getting Started
##### Windows
1. Download and install Python 3.x
2. If not automagically; Add your *<python_install_dir>* and *<python_install_dir>\Scripts* to your %PATH%
3. Download required libraries; with a command prompt in *<project_directory>*:
```
pip install -r requirements.txt
```
4. Download the relevant webdrivers (i.e chromedriver & geckodriver) and put them in a folder detected by %PATH%
6. See Run.


##### Appium - Mobile apps
Download Appium desktop app http://appium.io/
###### Android
1. Install Android SDK
2. Add system environment ANDROID_HOME pointing to android-sdk directory
3. Run as admin SDK Manager.exe to update/download SDK packages
4. Run AVD Manager.exe to select/create and run Android emulator

## Run
To run the default suite:
```
pytest apps/hbonweb
```

to run a specific suite. You can:
```
pytest --suite=<suite_name or file> apps/hbonweb/tests
```
If no suite provided, it will look for default.json
Alternatively, provide a suite dictionary directly:
```
pytest --suite='{"driver": "chrome", ..}' apps/hbonweb/tests
```

to run 'test_one' and 'test_two' only.
```
pytest --suite=<suite_name or file> -k "test_one or test_two" apps/hbonweb
```


## Install/Upgrade 3rd party libraries
```
pip install -U -r requirements.txt
```
