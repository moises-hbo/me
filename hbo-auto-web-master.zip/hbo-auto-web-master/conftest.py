import os
import shutil
import subprocess
import time
from pathlib import Path

import pytest
from selenium.common.exceptions import (InvalidSessionIdException,
                                        WebDriverException)

from hboapi.testrail import Status as TestRailStatus
from hboapi.testrail import TestRailApiCalls
from helpers.configmanager import ConfigManager
from helpers.drivermanager import DriverManager as DM
from helpers.logger import Log
from helpers.utility_functions import is_windows
from tools.computer import write_computer_info, get_os_slash
from tools.package import print_package_info

cm = ConfigManager()


def pytest_addoption(parser):
    """Add command line option."""
    parser.addoption("--suite", action="store", metavar="suite_name",
                     help="suite to run. Will use default if not provided")
    parser.addoption("--env", action="store", metavar="environment_name",
                     help="only run tests matching the environment fixture. "
                     "Overrides suite")
    parser.addoption("--platform", action="store", metavar="ios|android",
                     help="run tests matching the platform fixture. "
                     "Overrides suite")
    parser.addoption("--remote", action="store", metavar="url",
                     help="Remote url, for Selenium Grid or services like "
                     "BrowserStack. Only has an effect with driver 'remote'. "
                     "Overrides suite")
    parser.addoption("--url", action="store", metavar="url",
                     help="Go to this url. Web only. Overrides suite")
    parser.addoption("--category", action="store", metavar="category",
                     help="Filter tests by given categories."
                     " Separated by commas. no:category to exclude. "
                     "Overrides suite")
    parser.addoption("--id", action="store", metavar="id",
                     help="Filter tests by given ids."
                     " Separated by commas. " "Overrides suite")
    parser.addoption("--testrail", action="store_true",
                     help="Enable reporting to Test Rail")
    parser.addoption("--testrail-dc", action="store_true",
                     help="Don't close test run when finished")
    parser.addoption("--testrail-cac", action="store_true",
                     help="Collect all P.Automated/Automated cases found in "
                     "TestRail")
    parser.addoption("--testrail-run-name", action="store", metavar="name",
                     help="Set name of TestRail Run if --testrail."
                     " Overrides suite.")
    parser.addoption("--testrail-project-id", action="store", metavar="id",
                     help="Set project id of TestRail Run if --testrail."
                     " Overrides suite.")
    parser.addoption("--testrail-suite-id", action="store", metavar="id",
                     help="Set suite id (if needed) of TestRail Run if "
                     "--testrail. Overrides suite.")
    parser.addoption("--appium", action="store_true",
                     help="Run the appium server.")
    parser.addoption("--appium-wait", action="store", metavar="seconds",
                     help="Sleep between starting appium server and start "
                     "of test run")
    parser.addoption("--appium-use-global-binary", action="store_true",
                     help="Run the appium command found in PATH instead of"
                     " local to project")
    parser.addoption("--force-run", action="store_true",
                     help="Include tests marked 'excluded'")


def pytest_sessionstart(session):
    clean_results()

    loglevel = session.config.getoption("--log-level")
    setup_logging(loglevel)

    # Set the suite and all its attributes
    suite = session.config.getoption("--suite")
    # Assuming session.config.args[0] is path to testfolder
    sessionstart_set_suite(suite, session.config.args[0])

    # Optional suite/config overrides
    env = session.config.getoption("--env")
    platform = session.config.getoption("--platform")
    remote_url = session.config.getoption("--remote")
    url = session.config.getoption("--url")
    category = session.config.getoption("--category")
    _id = session.config.getoption("--id")
    tr_run = session.config.getoption("--testrail-run-name")
    tr_pid = session.config.getoption("--testrail-project-id")
    tr_sid = session.config.getoption("--testrail-suite-id")
    sessionstart_overrides(env, platform, url, remote_url, category, _id,
                           tr_run, tr_pid, tr_sid)

    # Print mobile package info
    if cm.is_platform_mobile():
        print_package_info()
    # Gather computer info
    else:
        write_computer_info(Path("results/computer.txt"))

    # Start appium server
    appium = session.config.getoption("--appium")
    if appium:
        timeout = 10
        appium_timeout = session.config.getoption("--appium-wait")
        if appium_timeout:
            timeout = int(appium_timeout)
        use_global = True if \
            session.config.getoption("--appium-use-global-binary") else False
        sessionstart_appium(timeout, use_global)


def sessionstart_set_suite(suite, testpath):
    slash = "/" if "/" in testpath else get_os_slash()
    dirs_split = testpath.split(slash)
    app = None
    for i in range(len(dirs_split)):
        if dirs_split[i] == "apps" and len(dirs_split) >= i + 2:
            app = dirs_split[i+1]
            break
    if not app:
        app = "hbonweb"
    cm.set_suite(suite, app)


def sessionstart_overrides(env, platform, url, remote_url, category, _id,
                           tr_run, tr_pid, tr_sid):
    # env
    if env:
        cm.environment = env
    # platform
    if platform:
        cm.platform = platform
    # remote url
    if url:
        cm.url = url
    # url
    if remote_url:
        cm.remote_url = remote_url
    # category filter
    if category:
        cm.category_filter = category
    # id filter
    if _id:
        cm.id_filter = _id
    # testrail run name
    if tr_run:
        cm.testrail_run_name = tr_run
    if tr_pid:
        cm.testrail_project_id = tr_pid
    if tr_sid:
        cm.testrail_suite_id = tr_sid


def sessionstart_appium(timeout, use_global):
    if not use_global and not os.path.exists("node_modules"):
        install_appium()

    Log("Starting appium", Log.INFO, "test.framework")
    a, p = get_appium_host()
    cmd = "appium.cmd" if is_windows() else "appium"
    cmd_path = cmd if use_global else f"node_modules/.bin/{cmd}"
    proc = subprocess.Popen(
        [str(Path(cmd_path)),
            "-dc", str(Path(f"results/device.json")),
            "-a", f"{a}", "-p", f"{p}"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.PIPE)

    ac = get_ac()
    ac.process = proc

    Log("Appium PID: " + str(ac.process.pid), logname="test.framework")
    Log("Sleeping for " + str(timeout) + "s", logname="test.framework")
    time.sleep(timeout)


def pytest_sessionfinish(session, exitstatus):
    # Report to testrail
    testrail = session.config.getoption("--testrail")
    tr_dont_close = session.config.getoption("--testrail-dc")
    tr_collect_all_cases = session.config.getoption("--testrail-cac")
    if testrail:
        close = False if tr_dont_close else True
        collect_all = True if tr_collect_all_cases else False
        sessionfinish_testrail(close, collect_all)

    # Stop appium server
    appium = session.config.getoption("--appium")
    if appium:
        sessionfinish_appium()


def sessionfinish_testrail(close, collect_all):
    trr = get_trr()
    user = get_testrail_user()
    project_id = cm.testrail_project_id
    suite_id = cm.testrail_suite_id
    name = cm.testrail_run_name

    # Initialize api
    api = TestRailApiCalls(
        user["user"], user["password"], int(project_id), int(suite_id))

    # Add new test run on Testrail, filter by cases we ran that had ids
    # Or gather all auto cases we find from testrail, if 'collect_all' is True
    ids = api.get_automated_test_cases() if collect_all else trr.ids()
    run_id = api.add_test_run(name, ids)
    Log(f"\n\nStarted Testrail test run: {run_id} | ({name})", Log.INFO,
        "test.framework")
    # For every testrail id in results
    for tr_id in list(trr.results.keys()):
        tests = trr.results.get(tr_id)
        # For every test with same testrail id
        for test in tests:

            status = TestRailStatus.RETEST
            if test["status"] == "passed":
                status = TestRailStatus.PASSED
            elif test["status"] == "failed":
                status = TestRailStatus.FAILED

            Log(f"Adding '{test.get('status')}' to "
                f"{tr_id} | {test.get('name')}", logname="test.framework")
            # Push result to testrail
            api.add_result(
                run_id, tr_id, status,
                "{name}, \n\n{msg}".format(
                    name=test.get("name"),
                    msg=test.get("msg")
                    if test.get("msg") else ""),
                "{dur}".format(dur=str(int(test.get("duration"))) + "s"
                               if int(test.get("duration")) > 0 else 0))
        # If any failed, push a failed result at end, to make sure it's failed
        if any((x for x in tests if x.get("status") == "failed")):
            Log(f"Marking {tr_id} finally as failed.",
                logname="test.framework")
            api.add_result(run_id, tr_id, TestRailStatus.FAILED, "")

    if close:
        Log(f"Closing test run: {run_id}", Log.INFO, "test.framework")
        api.close_test_run(run_id)
    else:
        Log(f"Leaving testrail run: {run_id} open", Log.INFO, "test.framework")


def sessionfinish_appium():
    ac = get_ac()
    Log("Closing appium", Log.INFO, "test.framework")
    ac.process.terminate()


def pytest_runtest_setup(item):
    """Look for custom markers."""
    envmarker = item.get_closest_marker("env")
    env = cm.environment
    # If we have environment in suite and mark set
    if env and envmarker:
        # Match 'env' marker with set env, or '--env'
        if env not in list(envmarker.args):
            pytest.skip(f"suite requires env {env}. Test had {envmarker.args}")
    # env set in suite but test had no env mark
    if env and not envmarker:
        pytest.skip(f"suite requires {env} but test had no env mark.")

    # Match 'platform' marker with set platform, or '--platform'
    platformmarker = item.get_closest_marker("platform")
    if platformmarker:
        p = cm.platform
        if p not in list(platformmarker.args):
            pytest.skip(f"test requires platform {platformmarker}")

    # Match 'category' marker with set category filter, or '--category'
    categorymarker = item.get_closest_marker("category")
    catexcl = cm.category_exclusion_filter
    catincl = cm.category_inclusion_filter

    # If we have filter but test had no category marker
    if (catincl or catexcl) and not categorymarker:
        pytest.skip("We specified category filter, but test had none")
    # If test has category marker
    elif categorymarker:
        # Match marker with exclusion. Skips
        if tuple(set(catexcl) & set(list(categorymarker.args))):
            pytest.skip("test matches category for exclusion")
        # Match marker with inclusion. Skips if not found
        elif not tuple(set(catincl) & set(list(categorymarker.args))) and \
                catincl:
            pytest.skip("test didn't match the inclusion filter")

    # Match 'id' marker with set id filter, or '--id'
    idmarker = item.get_closest_marker("id")
    ids = cm.id_filter
    if ids and idmarker:
        if not tuple(set(ids) & set(list(idmarker.args))):
            pytest.skip("test did not match the id filter")
    if ids and not idmarker:
        pytest.skip("We specified id filter, but test had none")

    # Look for 'force_run' marker and only include if '--force-run' is included
    force_run_marker = item.get_closest_marker("excluded")
    if force_run_marker and not item.config.getoption("--force-run"):
        pytest.skip("Test was marked 'force_run'. "
                    "Will only run if '--force-run' is provided")


def pytest_runtest_teardown(item):
    """After test case run"""
    pass


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """See PyTest docs.

    https://docs.pytest.org/en/latest/example/simple.html#making-test-result-information-available-in-fixtures
    """
    outcome = yield
    rep = outcome.get_result()
    # Attach rep to item
    setattr(item, "rep_" + rep.when, rep)

    # Save result for use in Testrail
    testrail = item.config.getoption("--testrail")
    if testrail:
        # 'call' is test run, as opposed to 'setup' and 'teardown'
        if rep.when == "call":
            id_marker = item.get_closest_marker("id")
            if id_marker:
                trr = get_trr()
                for tr_id in id_marker.args:
                    tid = tr_id[1:] if tr_id.upper().startswith("C") else tr_id
                    if not trr.results.get(tid):
                        trr.results[tid] = list()
                    msg = rep.caplog if rep.caplog else ""
                    msg += f"\n\n\n__________ \n\n\n{rep.longrepr}" \
                        if rep.longrepr else ""
                    trr.results[tid].append(
                        {"name": rep.location[len(rep.location) - 1],
                         "status": rep.outcome,
                         "duration": rep.duration, "msg": msg})


@pytest.fixture()
def driver(request):
    """Set up and tear down webdriver."""
    # Override current driver_profile with one in mark
    profile = None
    dp_marker = request.node.get_closest_marker("driver_profile")
    if dp_marker:
        profile = dp_marker.args[0]
        if not cm.driver_profile_exists(profile):
            pytest.skip("Driver profile didn't exist in config, "
                        "or you're not using a config file")

    # Setup
    _driver = DM.init_driver(profile)
    _driver.implicitly_wait(1)
    _driver.set_page_load_timeout(30) if not cm.driver_name == "appium" \
        else None

    yield _driver  # Test run

    # Teardown
    if request.node.rep_setup.passed:
        try:
            if request.node.rep_call.failed:  # Take screenshot on test failure
                try:
                    _driver.get_screenshot_as_file(
                        f"results/{request.node.name}.png")
                except Exception as e:
                    Log("Failed to save screenshot:\n" + e, Log.WARNING,
                        "test.framework")
        except AttributeError:
            Log("'request.node.rep_call.failed didn't' "
                "exist because we tore down test run\n", Log.WARNING,
                "test.framework")

    try:
        _driver.quit()
    # If we re-defined the driver at runtime
    except InvalidSessionIdException as isie:
        Log(isie.msg, Log.ERROR, "test.framework")
    # This may happen for various reasons
    except WebDriverException as wde:
        Log(wde.msg, Log.ERROR, "test.framework")
    _driver = None


@pytest.fixture(scope="session")
def __init_eyes():
    from applitools.selenium import Eyes
    eyes = Eyes()
    os.environ["APPLITOOLS_API_KEY"] = cm.read_json_file(
        "applitools_eyes.json", "key")
    eyes.api_key = os.environ["APPLITOOLS_API_KEY"]

    yield eyes


@pytest.fixture()
def eyes(request, driver, __init_eyes):
    eyes = __init_eyes
    app = f"{cm.app_name} {cm.environment} ({cm.driver_name})"
    test = request.node.name

    eyes.open(driver, app, test)

    setattr(eyes.driver, "helper", driver.helper)
    yield eyes

    eyes.abort()


def install_appium():
    Log("Appium wasn't found! Installing..\n", Log.WARNING, "test.framework")
    try:
        cmd = "npm.cmd" if is_windows() else "npm"
        proc = subprocess.Popen(
            [cmd, "install", "appium"], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.wait()
    except FileNotFoundError as fnfe:
        Log("'npm' wasn't found. Please install Nodejs", Log.ERROR,
            "test.framework")
        raise fnfe


def get_appium_host():
    """Returns address & port as a tuple"""
    return (cm.url.split("http://")[1].split("/wd/hub")[0].split(":"))


def get_trr():
    from tools.containers import TestRailResults
    return TestRailResults


def get_ac():
    from tools.containers import AppiumContainer
    return AppiumContainer


def get_testrail_user():
    return cm.read_json_file("testrail.json")


def clean_results():
    """move 'results' folder & re-create an empty one"""
    folder = "results"
    bkp_folder = folder + ".old"
    if os.path.exists(folder):
        if os.path.exists(bkp_folder):
            shutil.rmtree(bkp_folder)
        shutil.move(folder, bkp_folder)
    os.makedirs(folder)


def setup_logging(loglevel):
    """Defines how logging should be printed"""
    import logging
    testlogger = logging.getLogger("test")
    handler = logging.StreamHandler()

    if loglevel:
        loglevel = loglevel.upper()
        testlogger.setLevel(eval(f"logging.{loglevel}"))
        handler.setLevel(eval(f"logging.{loglevel}"))
    else:
        testlogger.setLevel(logging.DEBUG)
        handler.setLevel(logging.DEBUG)

    formatter = logging.Formatter('%(asctime)s - %(name)s '
                                  '- %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    testlogger.addHandler(handler)
