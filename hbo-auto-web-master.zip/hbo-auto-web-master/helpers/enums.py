from enum import Enum


class MobilePlatform(object):
    Android = "android"
    Ios = "ios"


class TVPlatform(object):
    Android = "androidtv"
    TvOS = "tvos"


class Backend(object):
    Comp = "COMP"  # web
    ANMO = "ANMO"  # android
    APMO = "APMO"  # ios


class SwipeDirection(object):
    Up = "Up"
    Down = "Down"
    Right = "Right"
    Left = "Left"


class CreditCardType(Enum):
    Visa = 1
    MasterCard = 2
    AmericanExpress = 3
    Discover = 4


class Language(object):
    EN = "en"
    DK = "dk"
    NO = "no"
    FI = "fi"
    SE = "se"
    ES = "es"


class Country(object):
    UNSUPPORTED = "N/A"
    DK = "dk"
    NO = "no"
    FI = "fi"
    SE = "se"
    ES = "es"


class Region(object):
    UNSUPPORTED = "unsupported"
    NORDIC = "nordic"
    ESPANA = "spain"
    INSIDE_EU = "inside_eu"
    OUTSIDE_EU = "outside_eu"


class Environment(object):
    UNSUPPORTED = "unsupported"
    PREPROD = "preprod"
    PROD = "prod"


class Url(object):
    UNSUPPORTED = "unsupported"
    PROD_NORDIC_SE = "prod_se"
    PROD_NORDIC_FI = "prod_fi"
    PROD_NORDIC_DK = "prod_dk"
    PROD_NORDIC_NO = "prod_no"
    PROD_NORDIC_EN = "prod_en"
    PROD_ESPANA_ES = "prod_es"
    PROD_ESPANA_EN = "prod_en_es"
    PP_NORDIC_SE = "pp_se"
    PP_NORDIC_FI = "pp_fi"
    PP_NORDIC_DK = "pp_dk"
    PP_NORDIC_NO = "pp_no"
    PP_NORDIC_EN = "pp_en"
    PP_ESPANA_ES = "pp_es"
    PP_ESPANA_EN = "pp_en_es"


class Section(object):
    """enum class for choosing section."""
    ADULT = "adult"
    KIDS = "kids"
