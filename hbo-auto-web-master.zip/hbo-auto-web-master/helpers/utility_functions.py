from platform import system
import re
import datetime
import os


def replace_special_characters(text):
    """Replace a set of special characters with their ordinary counterparts"""
    return text.replace("'", "") \
        .replace("å", "a") \
        .replace("ä", "a") \
        .replace("ö", "o") \
        .replace("á", "a") \
        .replace("é", "e") \
        .replace("í", "i") \
        .replace("ó", "o") \
        .replace("ñ", "n")


def is_equal_nonable(nonable_value, comparing_value):
    """Compare 2 values. Also returns False if None"""
    if nonable_value is not None:
        return nonable_value == comparing_value
    return False


def get_os_slash():
    """Return \\ slashes for Windoze, otherwise /"""
    if is_windows():
        return "\\"
    return "/"


def is_windows():
    """Return true if OS is Windoze, otherwise false"""
    return system().lower() == "windows"


def is_year_format_valid(year):
    """Checks year format (1900 - 2099)"""
    return True if re.match('^(19|20)\d{2}$', year) is not None else False


def is_duration_format_valid(duration):
    """Checks duration format, should be H:MM:SS or MM:SS"""
    if len(duration) > 5:
        try:
            datetime.datetime.strptime(duration, '%H:%M:%S')
            return True
        except ValueError:
            return False
    else:
        try:
            datetime.datetime.strptime(duration, '%M:%S')
            return True
        except ValueError:
            return False


def get_duration_in_sec(duration):
    """Converts h:mm:ss duration to seconds"""
    if len(duration) > 5:
        h, m, s = duration.split(':')
        return float(h) * 3600 + float(m) * 60 + float(s)
    else:
        m, s = duration.split(':')
        return float(m) * 60 + float(s)


def file_reader(filename, line=0):
    with open(filename, "r") as f:
        if os.path.getsize(filename) == 0:
            return "File is empty"
        else:
            content = f.readlines()
            f.close()
            return str(content[line]).strip()


def delete_first_line(filename, deleteString):
    with open(filename, "r+") as f:
        new_f = f.readlines()
        f.seek(0)
        for line in new_f:
            if deleteString not in line:
                f.write(line)
            f.truncate()
        f.close()


def first_line_modifier(filename):
    with open(filename, "r+") as f:
        new_f = f.readlines()
        f.seek(0)

        for line in new_f:
            splitted_line = line.split("//r//n")
            for values in splitted_line:
                valueAsInt = int(values)
                mailGen = valueAsInt + 1
                f.write(str(mailGen))
                f.truncate()
        f.close()


def search_all_div_with_movies(section_name, element=1):
    return "//span[contains(@class, 'myclass') and text() = 'qwerty']"


def match_list_values(list1, list2):
    return tuple(set(list1) & set(list2))
