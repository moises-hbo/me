from time import sleep
from helpers.logger import Log


class Sleeper(object):
    def __init__(self, time: int):
        self.log = Log(loglevel=Log.INFO)

        self.log("sleeping for {} seconds".format(time))
        sleep(time)
