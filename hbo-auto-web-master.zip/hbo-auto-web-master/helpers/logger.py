import logging


class Log(object):
    CRITICAL = 50
    FATAL = CRITICAL
    ERROR = 40
    WARNING = 30
    WARN = WARNING
    INFO = 20
    DEBUG = 10
    NOTSET = 0

    def __init__(self, msg="", loglevel=DEBUG, logname="test.run"):
        self._logger = logging.getLogger(logname)
        self._loglevel = loglevel
        if msg:
            self.__call__(msg)

    def __call__(self, text, loglevel=NOTSET):
        self._logger.log(loglevel if loglevel else self._loglevel, text)
