import os
from helpers.sleeper import Sleeper as sleep

from selenium import webdriver
from selenium.webdriver.remote.webdriver import WebDriver as RemoteWebDriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.common.exceptions import WebDriverException

from appium import webdriver as appiumdriver

from helpers.logger import Log
from helpers.driverhelper import DriverHelper, MobileDriverHelper, \
    TVDriverHelper
from helpers.configmanager import ConfigManager

cm = ConfigManager()


class DriverManager(object):

    @classmethod
    def init_driver(cls, profile=None, override_mobile_app=None):
        dn = cm.driver_name
        webdriver = None

        if dn.lower() == "chrome":
            webdriver: webdriver.Chrome = cls._init_chrome(profile)
        elif dn.lower() == "firefox":
            webdriver: webdriver.Firefox = cls._init_firefox(profile)
        elif dn.lower() == "safari":
            webdriver: webdriver.Safari = cls._init_safari(profile)
        elif dn.lower() == "remote":
            webdriver: RemoteWebDriver = cls._init_remote(profile)
        elif dn.lower() == "edge":
            webdriver: webdriver.Edge = cls._init_edge(profile)
        elif dn.lower() == "appium":
            webdriver: appiumdriver.Remote = cls._init_appium(
                profile, override_mobile_app)
        else:
            raise ValueError(f"No driver '{dn}' available!")

        # Attach driverhelper
        webdriver = cls.__attach_helper(webdriver)

        # Set cookies
        cookies: dict = cm.driver.get("cookies")
        if cookies:
            for k, v in cookies.items():
                webdriver.add_cookie({"name": k, "value": v})
            webdriver.refresh()

        return webdriver

    @classmethod
    def _init_chrome(cls, profile):
        config = cls.get_config(profile)

        # A standard set of Chrome caps
        capabilities = DesiredCapabilities.CHROME.copy()
        chrome_options = ChromeOptions()

        # Arguments to browser
        options = list(config.get("options"))
        if any(options):
            for opt in options:
                chrome_options.add_argument(opt)

        # Experimental options
        experimental_options = dict(
            config.get("experimental_options")).items()
        if any(experimental_options):
            for opt_key, opt_val in experimental_options:
                chrome_options.add_experimental_option(opt_key, opt_val)

        # Add driver options to capabilities
        capabilities.update(chrome_options.to_capabilities())

        # Add driver capabilities to -||-
        capabilities.update(config["capabilities"])

        driver = webdriver.Chrome(desired_capabilities=capabilities)

        Log("Returning Chrome with desired capabilities:\n{caps}\n"
            .format(caps=driver.desired_capabilities), Log.INFO,
            "test.framework")
        driver.get(cm.url)
        cls._set_web_window_size(driver)

        return driver

    @classmethod
    def _init_firefox(cls, profile):
        config = cls.get_config(profile)

        # A standard set of FF caps
        capabilities = DesiredCapabilities.FIREFOX.copy()
        profile = FirefoxProfile()
        options = FirefoxOptions()

        # Set preferences
        for pref_key, pref_value in \
                dict(config.get("preferences")).items():
            profile.set_preference(pref_key, pref_value)
        # Set arguments to browser
        for opt in list(config.get("options")):
            options.add_argument(opt)
            if opt.endswith("headless"):
                os.environ["MOZ_HEADLESS"] = "1"
        capabilities.update(options.to_capabilities())

        driver = webdriver.Firefox(capabilities=capabilities,
                                   firefox_profile=profile)
        Log("Returning Firefox with desired capabilities:\n{caps}\n"
            .format(caps=driver.desired_capabilities), Log.INFO,
            "test.framework")
        driver.get(cm.url)
        cls._set_web_window_size(driver)

        return driver

    @classmethod
    def _init_edge(cls, profile):
        config = cls.get_config(profile)

        # A standard set of Edge caps
        capabilities = DesiredCapabilities.EDGE.copy()

        # Add custom caps
        for cap_key, cap_val in \
                dict(config.get("capabilities")).items():
            capabilities.update({cap_key: cap_val})

        driver = webdriver.Edge(capabilities=capabilities)
        Log("Returning Edge with desired capabilities:\n{caps}\n"
            .format(caps=driver.desired_capabilities), Log.INFO,
            "test.framework")
        driver.get(cm.url)
        cls._set_web_window_size(driver)

        return driver

    @classmethod
    def _init_safari(cls, profile):
        config = cls.get_config(profile)

        # A standard set of Safari caps
        capabilities = DesiredCapabilities.SAFARI.copy()
        # Add custom caps
        for cap_key, cap_val in \
                dict(config.get("capabilities")).items():
            capabilities.update({cap_key: cap_val})

        driver = webdriver.Safari(
            desired_capabilities=capabilities)
        Log("Returning Safari with desired capabilities:\n{caps}\n"
            .format(caps=driver.desired_capabilities), Log.INFO,
            "test.framework")
        driver.get(cm.url)
        cls._set_web_window_size(driver)

        return driver

    @classmethod
    def _init_appium(cls, profile, override_mobile_app):
        config = cls.get_config(profile)

        capabilities = {}

        # If want to override app defined in suite
        if override_mobile_app:
            capabilities["app"] = override_mobile_app
        else:
            # Retrieve absolute path relative to project
            capabilities["app"] = cm.package_path

        for cap_key, cap_val in config.get("capabilities").items():
            capabilities.update({cap_key: cap_val})

        driver = appiumdriver.Remote(
            cm.url, desired_capabilities=capabilities)
        Log("Returning Appium with desired capabilities:\n{caps}\n"
            .format(caps=driver.desired_capabilities), Log.INFO,
            "test.framework")

        return driver

    @classmethod
    def _init_remote(cls, profile):
        config = cls.get_config(profile)

        driver = RemoteWebDriver(
            command_executor=cm.remote_url,
            desired_capabilities=config)
        Log("Returning Remote WebDriver with desired capabilities:\n{caps}\n"
            .format(caps=driver.desired_capabilities), Log.INFO,
            "test.framework")

        driver.get(cm.url)
        cls._set_web_window_size(driver)

        return driver

    @classmethod
    def get_config(cls, profile):
        config = cm.driver
        if profile and cm.driver_config_path:
            config = cm.read_json_file(cm.driver_config_path, profile)
        return config

    @classmethod
    def _set_web_window_size(cls, driver):
        window_size = cm.driver.get("window_size")

        sleep(1)
        if window_size:
            driver.set_window_size(cm.driver["window_size"]["x"],
                                   cm.driver["window_size"]["y"])
        # No window size set. Maximizing.
        else:
            try:
                driver.maximize_window()
            except WebDriverException as wde:
                if "failed to change window state to maximized" \
                        not in wde.msg:
                    raise wde
                else:
                    Log("Failed to maximize window exception seen!",
                        Log.WARNING, "test.framework")
                    Log(wde.msg, Log.ERROR, "test.framework")

    @staticmethod
    def __attach_helper(driver):
        if cm.is_platform_mobile():
            helper = MobileDriverHelper(driver)
        elif cm.is_platform_tv():
            helper = TVDriverHelper(driver)
        else:
            helper = DriverHelper(driver)
        setattr(driver, "helper", helper)

        return driver
