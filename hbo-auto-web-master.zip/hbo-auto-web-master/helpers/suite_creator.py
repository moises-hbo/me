from pathlib import Path
from json import dumps

"""
Experimental Suite Creator - Use at your own risk
"""


class Suite(object):
    """
    app: str - "hboce"
    county: str - "hu"
    browser: str - "chrome"
    env: str - "prod"
    platform: str - "comp"
    url: str - "https://qafe.hbogo.hu"
    testrail: dict with the following keys: "project_id", "suite_id", "run_name"

    url parameter is only important if you don't have it in the urls.json file
    """
    def __init__(self, app, country, browser, env=None, platform=None, url=None, testrail=None):
        keys = testrail.keys if isinstance(testrail, dict) else []
        self.testrail = testrail if "project_id" in keys and "suite_id" in keys and "run_name" in keys \
            else dict(project_id="22", suite_id="956", run_name="No run name")
        self.app = app
        self.platform = platform.upper() if platform else "COMP"
        self.suite = dict(
            driver="apps/{}/drivers/{}.json".format(app, browser),
            country=country,
            platform=platform,
            driver_profile=app,
            url="apps/{app}/urls.json:{env}_{app}_{country}".format(
                app=app, env=env, country=country) if not url else url,
            app=app,
            testrail_project_id=self.testrail.get("project_id"),
            testrail_suite_id=self.testrail.get("suite_id"),
            testrail_run_name=self.testrail.get("run_name"))

    def get(self):
        return self.suite

    def save(self, suite_name):
        path = Path("../../{}/suites/{}.json".format(self.app, suite_name))
        with open(file=path, mode="w") as suite_file:
            suite_file.write(dumps(self.suite))
