import json
import os
from pathlib import Path

from helpers.enums import MobilePlatform, TVPlatform, Backend


class ConfigManager(object):
    """
    Initializes, sets and gets the framework in
    preparation for a test run.
    """
    def set_suite(self, suite, app):
        # First try to parse it as a dict
        if suite:
            try:
                s = dict(eval(suite))
                is_dict = True
            except NameError:
                is_dict = False
        else:
            is_dict = False

        if not is_dict:
            # Suite was not provided
            if not suite:
                with open(str(Path(f"apps/{app}/suites/default.json"))) as f:
                    s = json.load(f)
            # Try to read suite file as path
            elif Path(suite).is_file():
                with open(str(Path(suite))) as f:
                    s = json.load(f)
            # If we only got a suite name
            else:
                suite = suite + ".json" if not suite.endswith(".json") \
                    else suite
                with open(str(Path(f"apps/{app}/suites/{suite}"))) as f:

                    s = json.load(f)

        if "driver" in s:
            self.driver = s["driver"]

        if "env" in s:
            self.environment = s["env"]

        # Mobile app
        if "app" in s:
            self.app_name = s["app"]

        if "lang" in s:
            self.lang_id = s["lang"]

        if "country" in s:
            self.country_id = s["country"]

        if "region" in s:
            self.region = s["region"]

        if "url" in s:
            self.url = s["url"]

        if "remote" in s:
            self.remote_url = s["remote"]

        if "device" in s:
            self.device = s["device"]

        # android or ios
        if "platform" in s:
            self.platform = s["platform"]

        if "package" in s:
            self.package_path = s["package"]
            self.package_info = self.package_path

        # Filters to pick out specific test cases
        if "category_filter" in s:
            self.category_filter = s["category_filter"]

        if "id_filter" in s:
            self.id_filter = s["id_filter"]

        # Extra for testrail
        self.testrail_project_id = s["testrail_project_id"] \
            if "testrail_project_id" in s \
            else "0"
        self.testrail_suite_id = s["testrail_suite_id"] \
            if "testrail_suite_id" in s \
            else "0"
        self.testrail_run_name = s["testrail_run_name"] \
            if "testrail_run_name" in s \
            else "Test automation"

    def read_json_file(self, path, key=None):
        with open(str(Path(path))) as f:
            data = json.load(f)
        return data.get(key) if isinstance(key, str) else data

    @property
    def driver(self):
        return dict(eval(os.environ.get("HBOQA_DRIVER")))

    @driver.setter
    def driver(self, driver_config):
        # If profile written directly in suite file
        if isinstance(driver_config, dict):
            os.environ["HBOQA_DRIVER"] = str(driver_config)

            self.driver_name = driver_config["driver"]
            # No driver profile

        # If profile is in a different config file
        elif isinstance(driver_config, str):
            profile = "default"
            # Reversing in case of windows abspath ("C:\\")
            split = str(driver_config).split(":")[::-1]
            config = self.read_json_file(split[1], split[0]) \
                if len(split) > 1 \
                else self.read_json_file(driver_config, profile)
            os.environ["HBOQA_DRIVER"] = str(config)

            self.driver_name = config["driver"]
            self.driver_profile = profile
            self.driver_config_path = split[1] if len(split) > 1 \
                else driver_config

    @property
    def driver_name(self):
        return os.environ["HBOQA_DRIVER_NAME"]

    @driver_name.setter
    def driver_name(self, name):
        os.environ["HBOQA_DRIVER_NAME"] = name

    @property
    def driver_profile(self):
        return os.environ.get("HBOQA_DRIVER_PROFILE")

    @driver_profile.setter
    def driver_profile(self, profile):
        os.environ["HBOQA_DRIVER_PROFILE"] = profile

    def driver_profile_exists(self, profile):
        if not self.driver_config_path:
            return False
        with open(str(Path(self.driver_config_path))) as f:
            config = json.load(f)
        return True if config.get(profile) else False

    @property
    def driver_config_path(self):
        return os.environ.get("HBOQA_DRIVER_CONFIG_PATH")

    @driver_config_path.setter
    def driver_config_path(self, path):
        os.environ["HBOQA_DRIVER_CONFIG_PATH"] = path

    @property
    def environment(self):
        return os.environ.get("HBOQA_ENVIRONMENT")

    @environment.setter
    def environment(self, env_id):
        os.environ["HBOQA_ENVIRONMENT"] = env_id

    @property
    def app_name(self):
        return os.environ.get("HBOQA_APP_NAME")

    @app_name.setter
    def app_name(self, app):
        os.environ["HBOQA_APP_NAME"] = app

    @property
    def lang_id(self):
        return os.environ.get("HBOQA_LANGUAGE")

    @lang_id.setter
    def lang_id(self, lang_id):
        os.environ["HBOQA_LANGUAGE"] = lang_id

    @property
    def country_id(selfj):
        return os.environ.get("HBOQA_COUNTRY")

    @country_id.setter
    def country_id(self, country_id):
        os.environ["HBOQA_COUNTRY"] = country_id

    @property
    def region(self):
        return os.environ.get("HBOQA_REGION")

    @region.setter
    def region(self, region):
        os.environ["HBOQA_REGION"] = region

    @property
    def url(self):
        return os.environ.get("HBOQA_URL")

    @url.setter
    def url(self, url):
        # If 'url' points to file:id
        split = url.split(":")[::-1]
        url_id, path = split[0], split[1]
        if Path(path).is_file():
            url = self.read_json_file(path, url_id)
        os.environ["HBOQA_URL"] = url

    @property
    def remote_url(self):
        return os.environ.get("HBOQA_REMOTE_URL")

    @remote_url.setter
    def remote_url(self, url):
        # if 'remote' points to file:id
        split = url.split(":")[::-1]
        url_id, path = split[0], split[1]
        if Path(path).is_file():
            url = self.read_json_file(path, url_id)
        os.environ["HBOQA_REMOTE_URL"] = url

    @property
    def device(self):
        return dict(eval(os.environ.get("HBOQA_DEVICE")))

    @device.setter
    def device(self, device):
        ''' Appium config / Default Capabilities '''
        # 'device' config written directly in suite file
        if isinstance(device, dict):
            os.environ["HBOQA_DEVICE"] = str(device)
        # 'device' points to path with config
        elif isinstance(device, str):
            with open(str(Path(device))) as f:
                config = json.load(f)
            os.environ["HBOQA_DEVICE"] = str(config)
        self.write_device_config_to_file()

    def write_device_config_to_file(self, path="results/device.json"):
        with open(str(Path(path)), "w") as f:
            f.write(json.dumps(self.device, indent=4))

    @property
    def platform(self):
        return os.environ.get("HBOQA_PLATFORM")

    @platform.setter
    def platform(self, platform):
        os.environ["HBOQA_PLATFORM"] = platform

    def is_platform_mobile(self):
        return True if self.platform in \
            [MobilePlatform.Android, MobilePlatform.Ios,
             Backend.ANMO, Backend.APMO] else False

    def is_platform_tv(self):
        return True if self.platform in \
            [TVPlatform.Android, TVPlatform.TvOS] else False

    @property
    def package_path(self):
        return os.environ.get("HBOQA_PACKAGE_PATH")

    @package_path.setter
    def package_path(self, path):
        path = os.path.expandvars(path)
        if os.path.isabs(path):
            os.environ["HBOQA_PACKAGE_PATH"] = str(Path(path))
        else:
            os.environ["HBOQA_PACKAGE_PATH"] = os.path.abspath(
                str(Path("apps/{app}/packages/{pp}/".format(
                    app=self.app_name, pp=path))))

    @property
    def package_info(self):
        return dict(eval(os.environ["HBOQA_PACKAGE_INFO"]))

    @package_info.setter
    def package_info(self, package_path):
        if self.platform in [MobilePlatform.Android, Backend.ANMO,
                             TVPlatform.Android]:
            from pyaxmlparser import APK
            apk = APK(package_path)
            os.environ["HBOQA_PACKAGE_INFO"] = str(dict(
                application=apk.application, package=apk.package,
                version=apk.version_name, build=apk.version_code))
        elif self.platform in [MobilePlatform.Ios, Backend.APMO,
                               TVPlatform.TvOS]:
            from ipa import IPAFile
            ipa = IPAFile(package_path)
            os.environ["HBOQA_PACKAGE_INFO"] = str(dict(
                application=ipa.app_info['CFBundleName'],
                package=ipa.app_info['CFBundleIdentifier'],
                version=ipa.app_info['CFBundleShortVersionString'],
                build=ipa.app_info['CFBundleVersion']))

    @property
    def category_filter(self):
        catfilt_str = os.environ.get("HBOQA_CATEGORY_FILTER")
        if not catfilt_str:
            return list()
        return [x.strip() for x in catfilt_str.split(",")]

    @category_filter.setter
    def category_filter(self, categories):
        os.environ["HBOQA_CATEGORY_FILTER"] = categories

    @property
    def category_inclusion_filter(self):
        return [x for x in self.category_filter if not x.startswith("no:")]

    @property
    def category_exclusion_filter(self):
        return [x.split(":")[1] for x in self.category_filter
                if x.startswith("no:")]

    @property
    def id_filter(self):
        idfilt = os.environ.get("HBOQA_ID_FILTER")
        if not idfilt:
            return None
        return [x.strip() for x in idfilt.split(",")]

    @id_filter.setter
    def id_filter(self, ids):
        os.environ["HBOQA_ID_FILTER"] = ids

    @property
    def testrail_project_id(self):
        return os.environ.get("HBOQA_TESTRAIL_PROJECT_ID")

    @testrail_project_id.setter
    def testrail_project_id(self, pid):
        os.environ["HBOQA_TESTRAIL_PROJECT_ID"] = pid

    @property
    def testrail_suite_id(self):
        return os.environ.get("HBOQA_TESTRAIL_SUITE_ID")

    @testrail_suite_id.setter
    def testrail_suite_id(self, sid):
        os.environ["HBOQA_TESTRAIL_SUITE_ID"] = sid

    @property
    def testrail_run_name(self):
        return os.environ.get("HBOQA_TESRAIL_RUN_NAME")

    @testrail_run_name.setter
    def testrail_run_name(self, name):
        # replaces optional keywords before setting
        name = name.replace("@app_name", self.app_name)
        name = name.replace("@driver_name", self.driver_name)
        name = name.replace("@driver_config_path", self.driver_config_path)
        if self.package_path:
            pi = self.package_info
            name = name.replace("@package_path", self.package_path) \
                .replace("@package_application", pi["application"]) \
                .replace("@package_package", pi["package"]) \
                .replace("@package_version", pi["version"]) \
                .replace("@package_build", pi["build"])

        os.environ["HBOQA_TESRAIL_RUN_NAME"] = name
