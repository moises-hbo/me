from os.path import abspath
from time import time
from pathlib import Path

from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support import wait
from appium.webdriver.common.touch_action import TouchAction

from helpers.logger import Log
from helpers.sleeper import Sleeper as sleep
from helpers.enums import MobilePlatform, SwipeDirection


class DriverHelper(object):
    """Helper class which houses driver/client related methods."""

    def __init__(self, driver):
        """Initialize helper."""
        self.driver = driver
        self.log = Log()

    def go_to_url(self, url):
        """Loads defined url"""
        self.log(f"Loading webpage: {url}\n")
        self.driver.get(url)

    def get_url(self):
        """Returns the current webpage url"""
        url = self.driver.current_url
        self.log(f"Current url is: {url}\n")
        return url

    def go_back(self):
        self.log("Going back on current web page\n")
        self.driver.back()

    def click_on_screen(self):
        """Click on the current mouse position."""
        self.log("Clicking on current mouse position.\n")
        ActionChains(self.driver).click().perform()

    def move_mouse_to(self, element, timeout=10):
        """Move mouse to the middle of an element.

        This will effectively hover over/highlight it.
        """
        if isinstance(element, dict):
            locator = element.get("locator")
            locator_type = element.get("type")
            element = wait.WebDriverWait(self.driver, timeout=timeout) \
                .until(lambda driver: eval("driver.find_element")(
                    locator_type, locator))
        self.log("Moves mouse position to element.\n")
        ActionChains(self.driver).move_to_element(element).perform()

    def move_mouse_about(self, x, y):
        """Move mouse from current position to (x,y)."""
        self.log(f"Offsetting current mouse position:\nx: {x}\ny: {y}\n")
        ActionChains(self.driver).move_by_offset(x, y).perform()

    def move_mouse_to_and_about(self, element, x, y):
        """Move mouse to the middle of an element, and then offset"""
        self.log(f"Moves mouse to element, and offset x:{x}, y:{y}\n")
        ActionChains(self.driver).move_to_element_with_offset(
            element, x, y).perform()

    def scroll(self, x=0, y=0):
        """Scroll in the browser window to the set coordinates.

        Useful if acquired elements are above/below
        what is currently visible on screen.
        """
        self.log(f"Scrolling to coordinates:\nx: {x}\ny: {y}\n")
        self.driver.execute_script(f"window.scrollTo({x}, {y});")

    def scroll_to_bottom(self):
        """Scroll in the browser to the bottom of the page.

        self-explanatory, although for dynamic pages
        it can also trigger loading of assets.
        """
        self.log("Scrolling to bottom.\n")
        self.driver.execute_script("window.scrollTo(0, \
            document.body.scrollHeight)")

    def scroll_to_top(self):
        """Scroll in the browser to the top of the page.
        """
        self.log("Scrolling to top.\n")
        self.driver.execute_script("window.scrollTo(0, 0)")

    def resize_window(self, width, height):
        """Change the current size of browser window."""
        self.log(f"Resizing window:\nwidth: {width}\nheight: {height}\n")
        self.driver.set_window_size(width, height)

    def press_keys(self, keys):
        """Will input keys/text on currently focused element."""
        self.log(f"Inputting keys to current element: {keys}\n")
        ActionChains(self.driver).send_keys(keys).perform()

    def refresh_page(self, wait=0):
        """Refreshes the current page."""
        self.log("Refreshing page.\n")
        self.driver.refresh()
        sleep(wait)

    def hold_down_keys(self, keys, duration, element=None):
        """Holds down a key/keys for the duration specified.

        By default the focused element, unless specified.
        """
        end = time() + float(duration)
        chain = ActionChains(self.driver)
        while True:
            chain.key_down(keys, element=element)
            sleep(0.1)
            if time() > end:
                chain.key_up(keys, element=element)
                break
        self.log(
            f"Holding down keys:\nkeys: {keys}\nduration: {duration}\n")
        chain.perform()

    def get_window_size(self):
        """Returns size of current window"""
        size = self.driver.get_window_size()
        self.log("Window size:\nwidth: {w}\nheight: {h}\n".format(
            w=size.get("width"), h=size.get("height")))
        return size

    def get_window_center(self):
        """Returns the center coordinates of window"""
        size = self.get_window_size()
        x, y = (int(size.get("width") / 2), int(size.get("height") / 2))
        self.log(f"Center coordinates:\nx: {x}\ny: {y}\n")
        return x, y

    def hide_element(self, cssselector):
        """Hide elements in the webapplication by cssselector"""
        self.log("Hide element.\n")
        self.driver.execute_script(
            '$("' + cssselector + '").css("display", "none")')

    def set_cookie(self, name, value):
        """Set the given cookie for the driver"""
        self.log(f"Set cookie: {name}, value: {value}\n")
        self.driver.add_cookie({"name": name, "value": value})

    def get_cookie(self, name):
        """Returns the given cookie as dict, else None"""
        self.log(f"Retrieving cookie: {name}\n")
        return self.driver.get_cookie(name)

    def cookie_exists(self, name):
        """True if given cookie exists, else None"""
        exist = self.get_cookie(name) is not None
        self.log(f"Does cookie \"{name}\" exist: {exist}\n")
        return exist

    def delete_cookie(self, name):
        """Removes given from browser"""
        self.log(f"Removing cookie: {name}\n")
        self.driver.delete_cookie(name)

    def delete_all_cookies(self, name):
        """Removes all cookies from browser"""
        self.log("Removing all current cookies from browser.\n")
        self.driver.delete_all_cookies()

    def enter_iframe(self, element):
        self.log("Entering iframe\n")
        self.driver.switch_to.frame(element)

    def exit_iframe(self):
        self.log("Exiting iframe. Returning to 'default frame'\n")
        self.driver.switch_to.default_content()

    def open_window(self, url):
        self.log(f"Opening new tab with url: {url}\n")
        self.driver.execute_script(f"window.open('{url}')")

    def close_window(self):
        self.log("Closing active window/tab\n")
        self.driver.close()

    def switch_to_window(self, index=0):
        self.log(f"Switching to window/tab with index: {index}\n")
        self.driver.switch_to.window(self.driver.window_handles[index])
        sleep(1)

    def get_windows(self):
        wins = self.driver.window_handles
        self.log("Returning open windows/tabs.")
        return wins

    def take_screenshot(self, filepath):
        filepath = Path(abspath(filepath))
        self.log(f"Saving browser screenshot to {filepath}\n")
        self.driver.screenshot_as_file(filepath)
        return filepath


class MobileDriverHelper(DriverHelper):
    def __init__(self, driver):
        DriverHelper.__init__(self, driver)

    def tap_on_screen(self, positions):
        """send a list of positions [(x, y), (x, y)] to tap on"""
        self.log("Tapping coordinates:\n")
        for pos in positions:
            self.log("x: {x}, y: {y}\n".format(x=pos[0], y=pos[1]))
        self.driver.tap(positions)

    def swipe(self, direction=SwipeDirection.Up):
        """
        Emulates a finger-swiping gesture on screen
        Note: Swiping up means dragging finger upwards,
        meaning the screen scrolls downwards
        """
        self.log(f"Swiping: {direction}\n")

        platform = self.get_platform()
        if platform == MobilePlatform.Android:
            self.__android_swipe(direction)
        elif platform == MobilePlatform.Ios:
            self.__ios_swipe(direction)

    def swipe_until_found_element(self, locator, no_of_swipes=5,
                                  direction=SwipeDirection.Up,
                                  locator_type="xpath"):
        self.log(
            f"Swiping to find element.\nSwipes:{no_of_swipes}\n")

        for i in range(0, no_of_swipes):
            try:
                element = self.driver.find_element(locator_type, locator)
                return element.is_displayed()
            except NoSuchElementException:
                self.log(f"Element wasn't found. Swiping: {direction}")
                self.swipe(direction)
        self.log("Did not find element after swiping!\n", Log.WARNING)
        return False

    def swipe_multiple_times(self, no_of_swipes, direction=SwipeDirection.Up):
        self.log(f"Swiping {direction} {no_of_swipes} times\n")
        for swipe in range(0, no_of_swipes):
            self.swipe(direction)

    def press_and_drag(self, element, pos_xy):
        """
        Presses down on an element and then drags x, y
        on the screen.
        takes a tuple or list with x,y values to drag to
        """
        ta = TouchAction(self.driver)
        self.log("Pressing down on element")
        ta.press(element)
        ta.wait(250)
        x, y = int(pos_xy[0]), int(pos_xy[1])
        self.log(f"Moving to x: {x} y: {y}")
        ta.move_to(x=x, y=y)
        ta.wait(250)
        ta.release()
        ta.perform()

    def background_app(self, seconds=5):
        """Puts app in background for specified amount of time"""
        self.log(f"Backgrounding app for {seconds} sec\n")
        self.driver.background_app(seconds)

    def lock_device(self, seconds=5):
        """Puts the device in lock mode for specified amount of time"""
        self.log(f"Locking device for {seconds} sec\n")
        self.driver.lock(seconds)

    def unlock_device(self):
        self.log("Unlocking device.\n")
        self.driver.unlock()

    def hide_keyboard(self, key=None):
        """Hide keyboard by tapping outside, or pressing provided key"""
        self.log("Hiding keyboard\n")
        self.driver.hide_keyboard(key)

    def is_keyboard_displayed(self):
        """ Returns True if keyboard is open/seen """
        shown = self.driver.is_keyboard_shown()
        self.log("Checking if keyboard is seen: {}".format(str(shown)))
        return shown

    def get_driver_settings(self):
        """Gives you the current appium settings"""
        self.log("Retrieving driver settings\n")
        return self.driver.get_settings()

    def set_driver_setting(self, key, value):
        """Set a setting for appium"""
        self.log(f"Settings driver setting key: {key}, value: {value}\n")
        self.driver.update_settings({key: value})

    def get_platform(self):
        """Get current platform running"""
        platform = self.driver.capabilities["platformName"].lower()
        self.log(f"Platform is: {platform}\n")
        if platform == "android":
            return MobilePlatform.Android
        elif platform == "ios":
            return MobilePlatform.Ios
        else:
            raise ValueError(f"platform was {platform}, but we're"
                             " not managing that!")

    def get_orientation(self):
        """ Get whether the device is in PORTRAIT or LANDSCAPE mode """
        orientation = self.driver.orientation
        self.log(f"Orientation is: {orientation}\n")
        return orientation

    def close_app(self):
        self.driver.close_app()

    def start_app(self):
        self.driver.launch_app()

    def __android_swipe(self, direction):
        if direction == SwipeDirection.Down:
            self.driver.swipe(start_x=0, start_y=0.2, end_x=0, end_y=0.4,
                              duration=650)
        elif direction == SwipeDirection.Up:
            self.driver.swipe(start_x=0, start_y=0.4, end_x=0, end_y=0.2,
                              duration=650)
        elif direction == SwipeDirection.Right:
            self.driver.swipe(start_x=0.4, start_y=0, end_x=0.2, end_y=0,
                              duration=650)
        elif direction == SwipeDirection.Left:
            self.driver.swipe(start_x=0.2, start_y=0, end_x=0.4, end_y=0,
                              duration=650)

    def __ios_swipe(self, direction):
        if direction == SwipeDirection.Down:
            self.driver.execute_script("mobile: swipe", {"direction": "down"})
        elif direction == SwipeDirection.Up:
            self.driver.execute_script("mobile: swipe", {"direction": "up"})
        elif direction == SwipeDirection.Right:
            self.driver.execute_script("mobile: swipe", {"direction": "right"})
        elif direction == SwipeDirection.Left:
            self.driver.execute_script("mobile: swipe", {"direction": "left"})


class TVDriverHelper(object):
    def __init__(self, driver):
        self.driver = driver

    def select(self):
        self.__execute("Select")
        sleep(1)

    def home(self):
        self.__execute("Home")
        sleep(1)

    def playpause(self):
        self.__execute("Playpause")
        sleep(1)

    def click(self):
        element = self.get_active_element()
        element.click()
        sleep(1)

    def go(self, direction: str, times=1):
        for _ in range(times):
            self.__execute(direction)
            sleep(1)

    def go_up(self, times=1):
        self.go("Up", times)

    def go_down(self, times=1):
        self.go("Down", times)

    def go_left(self, times=1):
        self.go("Left", times)

    def go_right(self, times=1):
        self.go("Right", times)

    def get_active_element(self):
        return self.driver.switch_to.active_element

    def __execute(self, action):
        self.driver.execute_script("mobile: pressButton", {"name": action})
