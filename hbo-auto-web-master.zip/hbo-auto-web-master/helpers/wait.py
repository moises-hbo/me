"""
As we use it, a Wait class is created in the init of PageHelper_CE (since we use it everywhere)
So in page objects we can use it like this:

example_locator = {"locator": "//div[@class='high']", "type": "xpath"}
example_element = self.helper.wait.visible(element=example_locator, timeout=10)

So in this case it returns the desired element if it is visible in 10 seconds
"""

from time import time
from selenium.webdriver.remote.webelement import WebElement
from selenium.common.exceptions import WebDriverException, StaleElementReferenceException, NoSuchElementException,\
    ElementClickInterceptedException

from helpers.sleeper import Sleeper as sleep


class Wait(object):
    class Error(object):
        def __init__(self, message):
            self.message = False, message

    def __init__(self, driver, element=None, timeout=20, delay=0.5):
        self.driver = driver
        self.timeout = timeout
        self.delay = delay
        if element is not None:
            self.element = self.get(element=element)

    def get(self, element, timeout=None, delay=None):
        # It just gets the element itself
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        if isinstance(element, WebElement):
            self.element = element
            return self.element
        elif isinstance(element, dict):
            locator = element.get("locator")
            locator_type = element.get("type")
            now = time()
            while time() < now + timeout:
                try:
                    self.element = self.driver.find_element(
                        locator_type, locator)
                    return self.element
                except (StaleElementReferenceException, WebDriverException, NoSuchElementException):
                    sleep(delay)
        return False

    def visible(self, element, timeout=None, delay=None):
        """
        Checks if the given element is visible or not.
        :param element: dict or WebElement object
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: WebElement if it is visible, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        self.element = self.get(element=element, timeout=timeout)
        if not self.element:
            return False
        now = time()
        while time() < now + timeout:
            try:
                if self.element.is_displayed():
                    return self.element
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def not_visible(self, element, timeout=None, delay=None):
        """
        Checks if the given element is visible or not.
        :param element: dict or WebElement object
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: WebElement if it is NOT visible, False if it is visible
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        self.element = self.get(element=element, timeout=timeout)
        if not self.element:
            return False
        now = time()
        while time() < now + timeout:
            try:
                if not self.element.is_displayed():
                    return self.element
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def clickable(self, element, timeout=None, delay=None):
        """
        Checks if the given element is enabled/clickable or not.
        :param element: dict or WebElement object
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: WebElement if it is active/clickable, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        self.element = self.get(element=element, timeout=timeout)
        if not self.element:
            return False
        now = time()
        while time() < now + timeout:
            try:
                if self.element.is_enabled():
                    return self.element
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def clickable_and_click(self, element, timeout=None, delay=None):
        """
        Checks if the given element is enabled/clickable or not and clicks it.
        :param element: dict or WebElement object
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: WebElement if it is active/clickable, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        to_click = self.clickable(element=element, timeout=timeout)
        if not to_click:
            return False
        now = time()
        while time() < now + timeout:
            try:
                to_click.click()
                return True
            except (ElementClickInterceptedException, StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def url(self, url, timeout=None, delay=None):
        """
        Checks if the current url in the browser is the same as the given url in parameter.
        :param url: string object
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: True if the current url is the same as the given one, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        now = time()
        while time() < now + timeout:
            try:
                if url in self.driver.current_url:
                    return True
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def text(self, element, text=None, timeout=None, delay=None):
        """
        Checks if the given element has (the given) text or not.
        Basically it can be used in two ways:
        If text parameter is none, then it checks if the given element has text or not
        If text parameter is not none, then it checks if the given element has it or not
        :param element: dict or WebElement object
        :param text: str object
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: the text of the element if it is the same as the given one, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        self.element = self.get(element=element, timeout=timeout)
        if not self.element:
            return False
        now = time()
        while time() < now + timeout:
            try:
                result = self.element.text
                if text is None:
                    if result != "":
                        return result
                else:
                    if result.lower() == text.lower():
                        return result
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def str_in_text(self, element, string=None, timeout=None, delay=None):
        """
        Checks if the given element has (the given) string in its text or not.
        :param element: dict or WebElement object
        :param string: str object
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: True if the element has the given string in its text, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        now = time()
        while time() < now + timeout:
            try:
                self.element = self.get(element=element, timeout=timeout)
                if not self.element:
                    return False
                result = self.element.text
                if string.lower() in result.lower():
                    return True
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def attribute(self, element, attr=None, exp=None, timeout=None, delay=None):
        """
        Checks if the given element has the given attribute with the expected value.
        :param element: dict or WebElement object
        :param attr: str object (attribute)
        :param exp: str object (expected value)
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: True if the given attribute of the element has the expected value, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        self.element = self.get(element=element, timeout=timeout)
        if not self.element:
            return False
        if not attr or exp is None:
            return None
        now = time()
        while time() < now + timeout:
            try:
                if self.element.get_attribute(attr) == exp:
                    return True
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def property(self, element, prop=None, exp=None, timeout=None, delay=None):
        """
        Checks if the given element has the given property with the expected value.
        :param element: dict or WebElement object
        :param prop: str object (property)
        :param exp: str object (expected value)
        :param timeout: int object
        :param delay: int - seconds to wait before trying again
        :return: True if the given property of the element has the expected value, False if not
        """
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        self.element = self.get(element=element, timeout=timeout)
        if not self.element:
            return False
        if not prop or not exp:
            return None
        now = time()
        while time() < now + timeout:
            try:
                if self.element.get_property(prop) == exp:
                    return True
            except (StaleElementReferenceException, WebDriverException):
                sleep(delay)
        return False

    def script_to_be_executed(self, script, timeout=None, delay=None):
        """
        Mostly used for waiting for isanonymus value of go, to check if we are logged in or not.

        Example:
        isanonymus = script_to_be_executed(
            script="return go.customer.customer.IsAnonymus;", timeout=10
        )
        :param script: the script you want to run on the driver
        :type script: str
        :param timeout: timeout in seconds
        :param delay: int - seconds to wait before trying again
        :type timeout: int
        :return: the result of running the script
        """
        result = None
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        now = time()
        while time() < now + timeout:
            try:
                result = self.driver.execute_script(script)
            except WebDriverException:
                sleep(delay)
            if result:
                return result
        return False

    def function_to_return_value(self, func, exp_value, timeout=None, delay=None):
        delay = delay if delay else self.delay
        timeout = timeout if timeout else self.timeout
        now, last_exception = time(), None
        while time() < now + timeout:
            try:
                result = func()
                if result == exp_value:
                    return True
            except Exception as e:
                last_exception = self.Error(e)
                sleep(delay)
        return last_exception
