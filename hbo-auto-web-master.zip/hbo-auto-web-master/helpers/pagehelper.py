from os.path import abspath
from helpers.sleeper import Sleeper as sleep
from pathlib import Path

from selenium.webdriver.common.by import By
from selenium.webdriver.support import wait
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, \
    NoSuchElementException, StaleElementReferenceException

from helpers.configmanager import ConfigManager as CM
from helpers.logger import Log


class PageHelper(object):
    """ Helper class for Page objects """

    def __init__(self, driver):
        self.driver = driver
        self.error = Log(loglevel=Log.ERROR)
        self.log = Log(loglevel=Log.INFO)

    def get(self, locator, timeout=10, locator_type=By.XPATH):
        """
        Search for, and returns a web element.
        :param locator: locator of the element ("doovde")
        :type locator: str, dict, WebElement
        :param timeout: timeout in sec (10)
        :type timeout: int
        :param locator_type: type of the locator ("id")
        :type locator_type: str
        """
        if isinstance(locator, WebElement):
            return locator
        elif isinstance(locator, dict):
            locator_type = locator.get("type")
            locator = locator.get("locator")
        try:
            return self.__get_element(obj=locator, locator_type=locator_type,
                                      timeout=timeout)
        except Exception as e:
            self.log(
                f"Unable to retrieve '{locator}' with '{locator_type}'\n"
                f"Error: {type(e).__name__}", Log.WARNING)

    def get_list(self, locator, timeout=10, locator_type=By.XPATH):
        """
        Similar to get, but returns a list of WebElements.
        Assumes the locator will find several instances
        """
        if isinstance(locator, dict):
            locator_type = locator.get("type")
            locator = locator.get("locator")
        try:
            return self.__get_element(locator, timeout, locator_type, True)
        except TimeoutException as te:
            self.log("The following error occured:\n{}".format(te))
            return None

    def get_list_item(self, _list, item, timeout=10, locator_type=By.XPATH):
        """
        Gets an item in the list by string
        """
        if isinstance(_list, dict):
            locator = _list.get("locator")
            locator_type = _list.get("type")
        else:
            locator = _list
        listor = self.get_list(
            locator=locator, timeout=timeout, locator_type=locator_type)
        return [x for x in listor if x.text == item][0]

    def get_text(self, locator_or_element, timeout=10, locator_type=By.XPATH):
        """Return text within a web element (<html>text is here</html>)."""
        element = self.get(locator_or_element, timeout, locator_type)
        text = element.text
        self.log(f"Element text: {text}\n")

        return text

    def get_link(self, locator_or_element, timeout=10,
                 locator_type=By.XPATH):
        """
        Return href attribute of element.
        (<a href="http://link.me"/>)
        """
        element = self.get(locator_or_element, timeout, locator_type)
        href = element.get_attribute("href")
        self.log(f"Element link: {href}\n")

        return href

    def get_location(self, locator_or_element, timeout=10,
                     locator_type=By.XPATH):
        """Return dictionary with location x, y of element."""
        element = self.get(locator_or_element, timeout, locator_type)
        loc = element.location
        self.log(f"Element location: {loc}\n")

        return loc

    def get_location_when_visible(self, locator_or_element, timeout=10,
                                  locator_type=By.XPATH):
        """Return location (x,y) of webelement when visible.

        Not entirely trustworthy at all times.
        """
        element = self.get(locator_or_element, timeout, locator_type)
        loc = element.location_once_scrolled_into_view
        self.log(f"Element location (when visible): {loc}\n")

        return loc

    def get_attribute(self, locator_or_element, attribute_name,
                      timeout=10, locator_type=By.XPATH):
        """Return values from an attribute.

        ie <div class='attr' /> should return "attr"
        if "attribute_name = "class"
        """
        element = self.get(locator_or_element, timeout, locator_type)
        attr = element.get_attribute(attribute_name)
        self.log(f"Element attribute of '{attribute_name}': {attr}\n")

        return attr

    def wait_for_attribute(self, locator, attribute, expected,
                           locator_type=By.XPATH, timeout=10):
        if isinstance(locator, dict):
            locator_type = locator.get("type")
            locator = locator.get("locator")
        try:
            return wait.WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element(
                    locator_type, locator).get_attribute(
                        attribute) == expected)
        except TimeoutException as e:
            self.log(
                f"Attribute {attribute} of element is not equal to {expected}"
                f" after {timeout} seconds.\nException: {e}", Log.WARNING)
            return False

    def wait_for_text(self, locator, expected=None,
                      locator_type=By.XPATH, timeout=10):
        if isinstance(locator, dict):
            locator_type = locator.get("type")
            locator = locator.get("locator")

        if expected is not None:
            try:
                return wait.WebDriverWait(self.driver, timeout).until(
                    EC.text_to_be_present_in_element((locator_type, locator),
                                                     expected))
            except TimeoutException as e:
                self.log(
                    f"Text of element is not equal to {expected}"
                    f" after {timeout} seconds.\nException: {e}",
                    Log.WARNING)
                return False
        else:
            try:
                return wait.WebDriverWait(self.driver, timeout).until(
                    lambda x: x.find_element(locator_type, locator).text != "")
            except TimeoutException as e:
                self.log(
                    f"Text of element is still empty after {timeout} seconds."
                    f"\nException: {e}", Log.WARNING)
                return False

    def wait_until_clickable(self, locator_or_element,
                             locator_type=By.XPATH, timeout=10):
        """
        Locator parameter can be dict type or str type.
        locator_or_element = {"locator": "doovde", "type": "id"}
        locator_or_element = "doovde"
        :param locator_or_element: locator of the element ("//div[@id='id']")
        :type locator_or_element: str of dict
        :param locator_type: locator type of the element ("xpath")
        :type locator_type: str
        :param timeout: timeout in seconds
        :type timeout: int
        :return: WebElement if the element gets clickable, False if not
        """
        if isinstance(locator_or_element, dict):
            locator_type = locator_or_element.get("type")
            locator_or_element = locator_or_element.get("locator")
        try:
            return wait.WebDriverWait(
                driver=self.driver, timeout=timeout).until(
                EC.element_to_be_clickable((locator_type, locator_or_element))
            )
        except TimeoutException as e:
            self.log(
                f"Element is not clickable after {timeout} seconds.\n"
                f"Exception: {e}", Log.WARNING)
            return False

    def get_size(self, locator_or_element, timeout=10, locator_type=By.XPATH):
        """Return dictionary with width, height of element"""
        element = self.get(
            locator_or_element, timeout=timeout, locator_type=locator_type)
        size = element.size
        self.log(f"Element size: {size}\n")

        return size

    def is_visible(self, locator_or_element,
                   timeout=10, locator_type=By.XPATH):
        """Return true if element is visible in DOM tree."""
        try:
            element = self.get(locator_or_element,
                               timeout, locator_type)
            if not element:
                return False
            visible = element.is_displayed()
        except (TimeoutException, NoSuchElementException,
                StaleElementReferenceException):
            visible = False
        self.log(f"Element visible: {visible}\n")

        return visible

    def wait_until_visible(self, locator, locator_type="xpath", timeout=10):
        """
        Locator parameter can be dict type or str type.
        locator = {"locator": "doovde", "type": "id"}
        locator = "doovde"
        :param locator: locator of the element ("//div[@id='doovde']")
        :type locator: str of dict
        :param locator_type: locator type of the element ("xpath")
        :type locator_type: str
        :param timeout: timeout in seconds
        :type timeout: int
        :return: WebElement if the element gets visible, False if not
        """
        if isinstance(locator, dict):
            locator_type = locator.get("type")
            locator = locator.get("locator")
        self.log(f"Waiting until element is visible:\nLocator: {locator}\n"
                 f"Type: {locator_type}\nTimeout: {timeout}\n")
        try:
            return wait.WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located((locator_type, locator))
            )
        except TimeoutException as e:
            self.log(
                f"Element is not visible after {timeout} seconds.\n"
                f"Exception: {e}", Log.WARNING)
            return False

    def wait_until_not_visible(self, locator, locator_type="xpath",
                               timeout=10):
        if isinstance(locator, dict):
            locator_type = locator.get("type")
            locator = locator.get("locator")
        try:
            self.log(
                f"Waiting for '{locator}' with type '{locator_type}' "
                "to not be displayed\n")
            return wait.WebDriverWait(self.driver, timeout).until(
                EC.invisibility_of_element_located((locator_type, locator)))
        except TimeoutException as e:
            self.log(
                f"Element is still visible after {timeout} seconds."
                f"\nException: {e}", Log.WARNING)
            return False

    def is_selected(self, locator_or_element, timeout=10,
                    locator_type=By.XPATH):
        """Return true if element is checked (ie a checkbox)."""
        element = self.get(locator_or_element, timeout, locator_type)
        selected = element.is_selected()
        self.log(f"Element selected/checked: {selected}\n", Log.WARNING)

        return selected

    def click(self, locator_or_element, timeout=10, locator_type=By.XPATH):
        """Click on an element (assumes it's clickable)."""
        element = self.get(locator=locator_or_element,
                           locator_type=locator_type, timeout=timeout)
        self.log("Clicking on element.\n")
        element.click()
        sleep(0.5)

    def input_text(self, locator_or_element, text, timeout=10,
                   locator_type=By.XPATH, pause=0.25):
        """Write text on element (assumes it's an input field)."""
        element = self.get(locator=locator_or_element,
                           timeout=timeout, locator_type=locator_type)
        self.log(f"Sending text to element: {text}\n")

        if CM().driver_name == "appium":
            element.send_keys(text)
        else:
            for c in text:
                self.log(f"Sending: {c}")
                element.send_keys(c)
                sleep(pause)

    def clear_text(self, locator_or_element, timeout=10,
                   locator_type=By.XPATH):
        """Clear text on an input element."""
        element = self.get(locator_or_element, timeout,
                           locator_type)
        self.log("Clearing text on element.\n")
        element.clear()

    def get_element_css_property(self, locator, locator_type="xpath",
                                 css_property="color", timeout=10):
        """ Returns the desired css property of an element (color by default)
        """
        return self.get(
            locator, timeout=timeout,
            locator_type=locator_type).value_of_css_property(css_property)

    def take_screenshot(self, locator_or_element, filepath, timeout=10,
                        locator_type=By.XPATH):
        """ Saves a png screenshot of element to 'filepath'
        Returns 'filepath'
        """
        element = self.get(
            locator=locator_or_element, locator_type=locator_type,
            timeout=timeout)

        filepath = str(Path(abspath(filepath)))
        self.log(f"Saving element screenshot to {filepath}")
        element.screenshot(filepath)
        return filepath

    def take_screenshot_base64(self, locator_or_element, timeout=10,
                               locator_type=By.XPATH):
        """ Takes screenshot of element as base64 encoded string """
        element = self.get(locator=locator_or_element,
                           locator_type=locator_type, timeout=timeout)

        self.log("Taking screenshot of element as base64 encoded string")
        img_b64 = element.screenshot_as_base64
        return img_b64

    def __get_element(self, obj, timeout=10, locator_type=By.XPATH,
                      get_list=False):
        """private: attempt to get element from string.
        Else if already a WebElement, just return as is."""
        if isinstance(obj, str):
            func = "driver.find_element"
            if get_list:
                func += "s"
                self.log(
                    f"Looking for elements:\nLocator: {obj}\n"
                    f"By: {locator_type}\nTimeout: {timeout}\n")
            else:
                self.log(
                    f"Looking for element:\nLocator: {obj}\n"
                    f"By: {locator_type}\nTimeout: {timeout}\n")
            return wait.WebDriverWait(self.driver, timeout=timeout) \
                .until(lambda driver: eval(func)(locator_type, obj))
        elif isinstance(obj, WebElement):
            return obj
        raise NoSuchElementException(
            msg="'obj' needs to be either 'WebElement' or 'str'.\n"
                "Was: '{class_name}'"
                .format(class_name=obj.__class__.__name__))
