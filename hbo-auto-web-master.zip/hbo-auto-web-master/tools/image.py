from PIL import Image
import pytesseract

from helpers.logger import Log


class ImageOCR(object):
    def __init__(self, img_file: str):
        """
        Reads image from filepath to make available
        for manipulation and scanning
        :param img_file: path to image file
        """
        self.log = Log()
        self.filepath = img_file
        self.log(f"Opening img {self.filepath}")
        self.img = Image.open(self.filepath)

    def get(self):
        """
        Return image object
        :Returns Image: object of loaded image
        """
        self.log("Returning img")
        return self.img

    def write_to_file(self, filepath: str):
        """
        Write image numpy array to file
        :param filepath: path to save file.png to
        """
        self.log(f"Saving img to {filepath}")
        self.img.save(filepath)

    def convert_to_rgb(self):
        """
        Converts image to RGB
        :Returns Image: object of loaded img
        """
        self.log("Converting img to RGB")
        self.img = self.img.convert("RGB")

    def make_grayscale(self):
        """
        Converts read image to grayscale
        """
        self.log("Converting image to grayscale")
        img_grayscale = self.img.convert("L")
        self.img = img_grayscale

    def make_binary(self, thresh_val: int = 200):
        """
        Converts read image to binary (black/white)
        :param thresh_val: threshold value to dictate between black/white
        """
        self.log(f"Making image binary with a threshold of {thresh_val}")

        def f(x):
            return 255 if x > thresh_val else 0
        img_binary = self.img.point(f, mode="1")

        self.img = img_binary

    def crop(self, top: int = 0, bottom: int = 0,
             left: int = 0, right: int = 0):
        """
        Crops read image
        :param top: how much to crop from the top. In percent
        :param bottom: how much to crop from the bottom. In percent
        :param left: how much to crop from the left. In percent
        :param right: how much to crop from the right. In percent
        """
        w, h = self.img.size
        perc_top = int(h * self.__multiply(top))
        perc_bottom = int(h * self.__multiply(bottom))
        perc_left = int(w * self.__multiply(left))
        perc_right = int(w * self.__multiply(right))
        self.log(
            f"Cropping image with width: {w} and height: {h}\n"
            f" left: {perc_left}, top: {perc_top}, right: {perc_right},"
            f" bottom: {perc_bottom}")
        img_cropped = self.img.crop(
            (perc_left, perc_top, w - perc_right, h - perc_bottom))
        self.img = img_cropped

    def scan_text(self, grayscale: bool = True, binary: bool = True,
                  lang: str or None = None):
        """
        Attempts to read and then return text from image object
        :param grayscale: If True, runs make_grayscale() before scanning
        :param binary: If True, runs make_binary() before scanning
        :Returns str: text found in image
        """
        if grayscale:
            self.make_grayscale()
        if binary:
            self.make_binary()
        self.log("Scanning text of image..{}".format(f" with '{lang}'"))
        tess_lang = self.__lang_to_tess(lang)
        text = pytesseract.image_to_string(self.img.copy(), lang=tess_lang)
        self.log(f"{text}")
        return text

    def find_color(self, pixel):
        """
        Reads every pixel of image
        :param pixel: tuple with (R, G, B) values
        :Returns boolean: True if found in pixels, else False
        """
        for p in self.img.getdata():
            if p == pixel:
                return True
        return False

    def reset(self):
        """
        Re-reads image from file path, effectively reset'ing any changes done
        """
        self.log(f"Re-opening img {self.filepath}")
        self.img = Image.open(self.filepath)

    def __multiply(self, perc_nr: int):
        """
        Transform an int to a float, to use with multiplication.
        :param perc_nr: number in percent to transform into a
            multiplication-friendly variant
        :Returns float
        """
        return eval(f"0.0{perc_nr}" if perc_nr < 10 else f"0.{perc_nr}")

    def __lang_to_tess(self, lang: str):
        """
        Returns a language code that pytesseract understands,
        for specifying the language to read with
        :param lang: language to get tesseract-friendly string of
        :Returns string
        """
        langs = {"ENGLISH": "eng",
                 "SWEDISH": "swe",
                 "FINNISH": "fin",
                 "DANISH": "dan",
                 "NORWEGIAN": "nor",
                 "SPANISH": "spa"}
        return langs.get(lang)
