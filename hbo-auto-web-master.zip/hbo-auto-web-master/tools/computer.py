from os import makedirs
from pathlib import Path
import platform
import requests
import time
from urllib3.exceptions import ReadTimeoutError
from requests.exceptions import ReadTimeout

from helpers.logger import Log
from helpers.utility_functions import get_os_slash


def write_computer_info(path):
    """Writes basic computer info to a file"""
    Log("Gathering computer information..", Log.INFO)
    str_path = str(path)
    p = str_path[:-(len(str_path) - str_path.rfind(get_os_slash()))]
    makedirs(Path(p), exist_ok=True)

    try:
        res_json = requests.get("https://wtfismyip.com/json", timeout=3).json()
    except requests.exceptions.ConnectionError:
        res_json = dict()
        Log("Unable to retrieve IP information. Connection issue.\n",
            Log.WARNING)
    except (ReadTimeoutError, ReadTimeout):
        res_json = dict()
        Log("Unable to retrieve IP information. Timeout was hit.\n",
            Log.WARNING)

    with open(path, mode='w', encoding="utf-8") as comp:
        comp.write("\n \
            system: {system}\n \
            arch: {arch}\n \
            platform: {platform}\n \
            version: {version}\n \
            python: {python}\n\n \
            IP: {ip}\n \
            Hostname:  {hostname}\n \
            ISP: {isp}\n \
            CountryCode: {countrycode}\n"
                   .format(system=platform.system(),
                           arch=platform.machine(),
                           platform=platform.platform(aliased=True),
                           version=platform.version(),
                           python=platform.python_version(),
                           ip=res_json.get("YourFuckingIPAddress"),
                           hostname=res_json.get("YourFuckingHostname"),
                           isp=res_json.get("YourFuckingISP"),
                           countrycode=res_json.get("YourFuckingCountryCode")
                           if not None else "N/A"))


def get_date():
    """Returns current time in localtime"""
    lt = time.localtime()
    date = "{year}-{month}-{day}_{hour}.{min}.{sec}" \
        .format(year=lt.tm_year,
                month=lt.tm_mon, day=lt.tm_mday, hour=lt.tm_hour,
                min=lt.tm_min, sec=lt.tm_sec)
    return date


def convert_to_seconds(time):
    """Converts HH:mm:ss to seconds"""
    time_split = time.split(":")
    if len(time_split) == 3:
        seconds = (int(time_split[0]) * 3600) + (int(time_split[1]) * 60) \
            + int(time_split[2])
    elif len(time_split) == 2:
        seconds = (int(time_split[0]) * 60) + int(time_split[1])
    else:
        seconds = int(time)
    Log(f"{time} translates to {seconds} seconds", Log.INFO)
    return seconds
