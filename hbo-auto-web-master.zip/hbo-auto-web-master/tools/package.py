from helpers.logger import Log
from helpers.configmanager import ConfigManager

cm = ConfigManager()


def print_package_info():
    log = Log(loglevel=Log.INFO, logname="test.framework")

    pi = cm.package_info
    log(f"Platform: {cm.platform}")
    log(f"App name: {pi['application']}")
    log(f"App package: {pi['package']}")
    log(f"App version: {pi['version']}")
    log(f"App build: {pi['build']}")
