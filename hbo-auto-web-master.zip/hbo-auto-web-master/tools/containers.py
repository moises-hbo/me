class TestRailResults(object):
    """'Singleton' to hold TestRail test info throughout a test run"""
    __instance = None

    results = dict()

    @classmethod
    def ids(cls):
        return list(cls.results.keys())

    def __new__(cls):
        if not cls.__instance:
            cls.__instance = cls
        return cls.__instance


class AppiumContainer(object):
    """'Singleton' to hold the Appium process throughout a test run"""
    __instance = None

    process = None

    def __new__(cls):
        if not cls.__instance:
            cls.__instance = cls
        return cls.__instance
